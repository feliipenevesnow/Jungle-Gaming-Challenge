import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "TSS_INLINE_CSS_ENABLED": "false", "VITE_API_BASE_URL": "/api", "VITE_APP_NAME": "Kurio NFT Marketplace", "VITE_ENABLE_MSW": "true", "VITE_SOCKET_URL": "http://localhost:5173"};import axios, { AxiosError } from "/node_modules/.vite/deps/axios.js?v=6e1d6a79";
import { waitForNetwork } from "/src/lib/network-ready.ts";
export const api = axios.create({
	// Axios owns timeout/abort handling in the fetch adapter, including under the
	// browser clock used by the deterministic timeout and session E2E scenarios.
	adapter: "fetch",
	baseURL: import.meta.env.VITE_API_BASE_URL || "/api",
	timeout: 1e4,
	headers: { "Content-Type": "application/json" }
});
// Request interceptor to attach token from localStorage if present
api.interceptors.request.use(async (config) => {
	await waitForNetwork();
	const token = localStorage.getItem("kurio_session_token");
	if (token && config.headers) {
		config.headers.Authorization = `Bearer ${token}`;
	}
	// Allow passing scenario simulation header from localStorage or window if active
	const scenario = localStorage.getItem("kurio_msw_scenario");
	if (scenario && config.headers) {
		config.headers["x-msw-scenario"] = scenario;
	}
	return config;
});
// Response interceptor to handle session expiration or global errors
api.interceptors.response.use((response) => response, (error) => {
	if (error.response?.status === 401 && ![
		"/auth/login",
		"/auth/register",
		"/auth/logout"
	].includes(error.config?.url || "")) {
		// Dispatched when session expires
		window.dispatchEvent(new CustomEvent("kurio:session-expired"));
	}
	return Promise.reject(error);
});
export default api;

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGtCQUFrQjtBQUNsQyxTQUFTLHNCQUFzQjtBQUUvQixPQUFPLE1BQU0sTUFBTSxNQUFNLE9BQU87OztDQUc5QixTQUFTO0NBQ1QsU0FBUyxZQUFZLElBQUkscUJBQXFCO0NBQzlDLFNBQVM7Q0FDVCxTQUFTLEVBQ1AsZ0JBQWdCLG1CQUNsQjtBQUNGLENBQUM7O0FBR0QsSUFBSSxhQUFhLFFBQVEsSUFBSSxPQUFPLFdBQVc7Q0FDN0MsTUFBTSxlQUFlO0NBQ3JCLE1BQU0sUUFBUSxhQUFhLFFBQVEscUJBQXFCO0NBQ3hELElBQUksU0FBUyxPQUFPLFNBQVM7RUFDM0IsT0FBTyxRQUFRLGdCQUFnQixVQUFVO0NBQzNDOztDQUdBLE1BQU0sV0FBVyxhQUFhLFFBQVEsb0JBQW9CO0NBQzFELElBQUksWUFBWSxPQUFPLFNBQVM7RUFDOUIsT0FBTyxRQUFRLG9CQUFvQjtDQUNyQztDQUVBLE9BQU87QUFDVCxDQUFDOztBQUdELElBQUksYUFBYSxTQUFTLEtBQ3ZCLGFBQWEsV0FDYixVQUFzQjtDQUNyQixJQUFJLE1BQU0sVUFBVSxXQUFXLE9BQU8sQ0FBQztFQUFDO0VBQWU7RUFBa0I7Q0FBYyxDQUFDLENBQUMsU0FBUyxNQUFNLFFBQVEsT0FBTyxFQUFFLEdBQUc7O0VBRTFILE9BQU8sY0FBYyxJQUFJLFlBQVksdUJBQXVCLENBQUM7Q0FDL0Q7Q0FDQSxPQUFPLFFBQVEsT0FBTyxLQUFLO0FBQzdCLENBQ0Y7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImF4aW9zLnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBheGlvcywgeyBBeGlvc0Vycm9yIH0gZnJvbSAnYXhpb3MnXHJcbmltcG9ydCB7IHdhaXRGb3JOZXR3b3JrIH0gZnJvbSAnLi9uZXR3b3JrLXJlYWR5J1xyXG5cclxuZXhwb3J0IGNvbnN0IGFwaSA9IGF4aW9zLmNyZWF0ZSh7XHJcbiAgLy8gQXhpb3Mgb3ducyB0aW1lb3V0L2Fib3J0IGhhbmRsaW5nIGluIHRoZSBmZXRjaCBhZGFwdGVyLCBpbmNsdWRpbmcgdW5kZXIgdGhlXHJcbiAgLy8gYnJvd3NlciBjbG9jayB1c2VkIGJ5IHRoZSBkZXRlcm1pbmlzdGljIHRpbWVvdXQgYW5kIHNlc3Npb24gRTJFIHNjZW5hcmlvcy5cclxuICBhZGFwdGVyOiAnZmV0Y2gnLFxyXG4gIGJhc2VVUkw6IGltcG9ydC5tZXRhLmVudi5WSVRFX0FQSV9CQVNFX1VSTCB8fCAnL2FwaScsXHJcbiAgdGltZW91dDogMTAwMDAsXHJcbiAgaGVhZGVyczoge1xyXG4gICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICB9LFxyXG59KVxyXG5cclxuLy8gUmVxdWVzdCBpbnRlcmNlcHRvciB0byBhdHRhY2ggdG9rZW4gZnJvbSBsb2NhbFN0b3JhZ2UgaWYgcHJlc2VudFxyXG5hcGkuaW50ZXJjZXB0b3JzLnJlcXVlc3QudXNlKGFzeW5jIChjb25maWcpID0+IHtcclxuICBhd2FpdCB3YWl0Rm9yTmV0d29yaygpXHJcbiAgY29uc3QgdG9rZW4gPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgna3VyaW9fc2Vzc2lvbl90b2tlbicpXHJcbiAgaWYgKHRva2VuICYmIGNvbmZpZy5oZWFkZXJzKSB7XHJcbiAgICBjb25maWcuaGVhZGVycy5BdXRob3JpemF0aW9uID0gYEJlYXJlciAke3Rva2VufWBcclxuICB9XHJcblxyXG4gIC8vIEFsbG93IHBhc3Npbmcgc2NlbmFyaW8gc2ltdWxhdGlvbiBoZWFkZXIgZnJvbSBsb2NhbFN0b3JhZ2Ugb3Igd2luZG93IGlmIGFjdGl2ZVxyXG4gIGNvbnN0IHNjZW5hcmlvID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2t1cmlvX21zd19zY2VuYXJpbycpXHJcbiAgaWYgKHNjZW5hcmlvICYmIGNvbmZpZy5oZWFkZXJzKSB7XHJcbiAgICBjb25maWcuaGVhZGVyc1sneC1tc3ctc2NlbmFyaW8nXSA9IHNjZW5hcmlvXHJcbiAgfVxyXG5cclxuICByZXR1cm4gY29uZmlnXHJcbn0pXHJcblxyXG4vLyBSZXNwb25zZSBpbnRlcmNlcHRvciB0byBoYW5kbGUgc2Vzc2lvbiBleHBpcmF0aW9uIG9yIGdsb2JhbCBlcnJvcnNcclxuYXBpLmludGVyY2VwdG9ycy5yZXNwb25zZS51c2UoXHJcbiAgKHJlc3BvbnNlKSA9PiByZXNwb25zZSxcclxuICAoZXJyb3I6IEF4aW9zRXJyb3IpID0+IHtcclxuICAgIGlmIChlcnJvci5yZXNwb25zZT8uc3RhdHVzID09PSA0MDEgJiYgIVsnL2F1dGgvbG9naW4nLCAnL2F1dGgvcmVnaXN0ZXInLCAnL2F1dGgvbG9nb3V0J10uaW5jbHVkZXMoZXJyb3IuY29uZmlnPy51cmwgfHwgJycpKSB7XHJcbiAgICAgIC8vIERpc3BhdGNoZWQgd2hlbiBzZXNzaW9uIGV4cGlyZXNcclxuICAgICAgd2luZG93LmRpc3BhdGNoRXZlbnQobmV3IEN1c3RvbUV2ZW50KCdrdXJpbzpzZXNzaW9uLWV4cGlyZWQnKSlcclxuICAgIH1cclxuICAgIHJldHVybiBQcm9taXNlLnJlamVjdChlcnJvcilcclxuICB9LFxyXG4pXHJcblxyXG5leHBvcnQgZGVmYXVsdCBhcGlcclxuIl19
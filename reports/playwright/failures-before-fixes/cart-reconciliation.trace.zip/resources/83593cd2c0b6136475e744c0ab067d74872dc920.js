import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/select.tsx");const React = ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(__vite__cjsImport0_react, 1);const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=7abeec5e";
import { cn } from "/src/lib/utils.ts";
import { CheckIcon, ChevronDownIcon, ChevronUpIcon } from "/node_modules/.vite/deps/lucide-react.js?v=c7b96d59";
import { Select as SelectPrimitive } from "/node_modules/.vite/deps/radix-ui.js?v=6839bb60";
var _jsxFileName = "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/ui/select.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7abeec5e";
function Select({ ...props }) {
	return /* @__PURE__ */ _jsxDEV(SelectPrimitive.Root, {
		"data-slot": "select",
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 9,
		columnNumber: 10
	}, this);
}
_c = Select;
function SelectGroup({ ...props }) {
	return /* @__PURE__ */ _jsxDEV(SelectPrimitive.Group, {
		"data-slot": "select-group",
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 10
	}, this);
}
_c2 = SelectGroup;
function SelectValue({ ...props }) {
	return /* @__PURE__ */ _jsxDEV(SelectPrimitive.Value, {
		"data-slot": "select-value",
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 21,
		columnNumber: 10
	}, this);
}
_c3 = SelectValue;
function SelectTrigger({ className, size = "default", children, ...props }) {
	return /* @__PURE__ */ _jsxDEV(SelectPrimitive.Trigger, {
		"data-slot": "select-trigger",
		"data-size": size,
		className: cn("flex h-10 w-full items-center justify-between gap-2 rounded-[3px] border border-[#3F2319] bg-[#140D0A] px-3 py-2 font-mono text-sm text-[#F5F1EB] whitespace-nowrap transition-colors outline-none focus-visible:border-[#D28A4C] focus-visible:ring-1 focus-visible:ring-[#D28A4C] disabled:cursor-not-allowed disabled:opacity-50 data-[placeholder]:text-[#B39463] data-[size=sm]:h-8 *:data-[slot=select-value]:truncate [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg]:size-4", className),
		...props,
		children: [children, /* @__PURE__ */ _jsxDEV(SelectPrimitive.Icon, {
			asChild: true,
			children: /* @__PURE__ */ _jsxDEV(ChevronDownIcon, { className: "size-4 opacity-50" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 43,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 33,
		columnNumber: 5
	}, this);
}
_c4 = SelectTrigger;
function SelectContent({ className, children, position = "item-aligned", align = "center", ...props }) {
	return /* @__PURE__ */ _jsxDEV(SelectPrimitive.Portal, { children: /* @__PURE__ */ _jsxDEV(SelectPrimitive.Content, {
		"data-slot": "select-content",
		className: cn("relative z-[150] max-h-(--radix-select-content-available-height) min-w-[8rem] overflow-x-hidden overflow-y-auto rounded-lg border border-[#55321F] bg-[#241612] font-mono text-[#F5F1EB] shadow-xl", position === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1", className),
		position,
		align,
		...props,
		children: [
			/* @__PURE__ */ _jsxDEV(SelectScrollUpButton, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 71,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(SelectPrimitive.Viewport, {
				className: cn("p-1", position === "popper" && "w-full min-w-[var(--radix-select-trigger-width)] scroll-my-1"),
				children
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 72,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(SelectScrollDownButton, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 81,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 59,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 58,
		columnNumber: 5
	}, this);
}
_c5 = SelectContent;
function SelectLabel({ className, ...props }) {
	return /* @__PURE__ */ _jsxDEV(SelectPrimitive.Label, {
		"data-slot": "select-label",
		className: cn("px-2 py-1.5 text-xs text-[#B39463]", className),
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 92,
		columnNumber: 5
	}, this);
}
_c6 = SelectLabel;
function SelectItem({ className, children, ...props }) {
	return /* @__PURE__ */ _jsxDEV(SelectPrimitive.Item, {
		"data-slot": "select-item",
		className: cn("relative flex w-full cursor-pointer items-center gap-2 rounded-md py-2.5 pr-8 pl-3 text-sm outline-none select-none data-[highlighted]:bg-[#382617] data-[highlighted]:text-[#E89B55] data-[state=checked]:text-[#E89B55] data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg]:size-4", className),
		...props,
		children: [/* @__PURE__ */ _jsxDEV("span", {
			"data-slot": "select-item-indicator",
			className: "absolute right-2 flex size-3.5 items-center justify-center",
			children: /* @__PURE__ */ _jsxDEV(SelectPrimitive.ItemIndicator, { children: /* @__PURE__ */ _jsxDEV(CheckIcon, { className: "size-4" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 119,
				columnNumber: 11
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 118,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 114,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV(SelectPrimitive.ItemText, { children }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 122,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 106,
		columnNumber: 5
	}, this);
}
_c7 = SelectItem;
function SelectSeparator({ className, ...props }) {
	return /* @__PURE__ */ _jsxDEV(SelectPrimitive.Separator, {
		"data-slot": "select-separator",
		className: cn("pointer-events-none -mx-1 my-1 h-px bg-[#3F2319]", className),
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 132,
		columnNumber: 5
	}, this);
}
_c8 = SelectSeparator;
function SelectScrollUpButton({ className, ...props }) {
	return /* @__PURE__ */ _jsxDEV(SelectPrimitive.ScrollUpButton, {
		"data-slot": "select-scroll-up-button",
		className: cn("flex cursor-default items-center justify-center py-1", className),
		...props,
		children: /* @__PURE__ */ _jsxDEV(ChevronUpIcon, { className: "size-4" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 153,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 145,
		columnNumber: 5
	}, this);
}
_c9 = SelectScrollUpButton;
function SelectScrollDownButton({ className, ...props }) {
	return /* @__PURE__ */ _jsxDEV(SelectPrimitive.ScrollDownButton, {
		"data-slot": "select-scroll-down-button",
		className: cn("flex cursor-default items-center justify-center py-1", className),
		...props,
		children: /* @__PURE__ */ _jsxDEV(ChevronDownIcon, { className: "size-4" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 171,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 163,
		columnNumber: 5
	}, this);
}
_c10 = SelectScrollDownButton;
export { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectScrollDownButton, SelectScrollUpButton, SelectSeparator, SelectTrigger, SelectValue };
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10;
$RefreshReg$(_c, "Select");
$RefreshReg$(_c2, "SelectGroup");
$RefreshReg$(_c3, "SelectValue");
$RefreshReg$(_c4, "SelectTrigger");
$RefreshReg$(_c5, "SelectContent");
$RefreshReg$(_c6, "SelectLabel");
$RefreshReg$(_c7, "SelectItem");
$RefreshReg$(_c8, "SelectSeparator");
$RefreshReg$(_c9, "SelectScrollUpButton");
$RefreshReg$(_c10, "SelectScrollDownButton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/select.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/ui/select.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/ui/select.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/ui/select.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsWUFBWSxXQUFXO0FBQ3ZCLFNBQVMsVUFBVTtBQUNuQixTQUFTLFdBQVcsaUJBQWlCLHFCQUFxQjtBQUMxRCxTQUFTLFVBQVUsdUJBQXVCOzs7QUFFMUMsU0FBUyxPQUFPLEVBQ2QsR0FBRyxTQUNpRDtDQUNwRCxPQUFPLHdCQUFDLGdCQUFnQixNQUFqQjtFQUFzQixhQUFVO0VBQVMsR0FBSTtDQUFROzs7OztBQUM5RDs7QUFFQSxTQUFTLFlBQVksRUFDbkIsR0FBRyxTQUNrRDtDQUNyRCxPQUFPLHdCQUFDLGdCQUFnQixPQUFqQjtFQUF1QixhQUFVO0VBQWUsR0FBSTtDQUFROzs7OztBQUNyRTs7QUFFQSxTQUFTLFlBQVksRUFDbkIsR0FBRyxTQUNrRDtDQUNyRCxPQUFPLHdCQUFDLGdCQUFnQixPQUFqQjtFQUF1QixhQUFVO0VBQWUsR0FBSTtDQUFROzs7OztBQUNyRTs7QUFFQSxTQUFTLGNBQWMsRUFDckIsV0FDQSxPQUFPLFdBQ1AsVUFDQSxHQUFHLFNBR0Y7Q0FDRCxPQUNFLHdCQUFDLGdCQUFnQixTQUFqQjtFQUNFLGFBQVU7RUFDVixhQUFXO0VBQ1gsV0FBVyxHQUNULDRkQUNBLFNBQ0Y7RUFDQSxHQUFJO1lBUE4sQ0FTRyxVQUNELHdCQUFDLGdCQUFnQixNQUFqQjtHQUFzQjthQUNwQix3QkFBQyxpQkFBRCxFQUFpQixXQUFVLG9CQUFxQjs7Ozs7RUFDNUI7Ozs7VUFDQzs7Ozs7O0FBRTdCOztBQUVBLFNBQVMsY0FBYyxFQUNyQixXQUNBLFVBQ0EsV0FBVyxnQkFDWCxRQUFRLFVBQ1IsR0FBRyxTQUNvRDtDQUN2RCxPQUNFLHdCQUFDLGdCQUFnQixRQUFqQixZQUNFLHdCQUFDLGdCQUFnQixTQUFqQjtFQUNFLGFBQVU7RUFDVixXQUFXLEdBQ1Qsc01BQ0EsYUFBYSxZQUNYLG1JQUNGLFNBQ0Y7RUFDVTtFQUNIO0VBQ1AsR0FBSTtZQVZOO0dBWUUsd0JBQUMsc0JBQUQsQ0FBdUI7Ozs7O0dBQ3ZCLHdCQUFDLGdCQUFnQixVQUFqQjtJQUNFLFdBQVcsR0FDVCxPQUNBLGFBQWEsWUFDWCw4REFDSjtJQUVDO0dBQ3VCOzs7OztHQUMxQix3QkFBQyx3QkFBRCxDQUF5Qjs7Ozs7RUFDRjs7Ozs7VUFDSDs7Ozs7QUFFNUI7O0FBRUEsU0FBUyxZQUFZLEVBQ25CLFdBQ0EsR0FBRyxTQUNrRDtDQUNyRCxPQUNFLHdCQUFDLGdCQUFnQixPQUFqQjtFQUNFLGFBQVU7RUFDVixXQUFXLEdBQUcsc0NBQXNDLFNBQVM7RUFDN0QsR0FBSTtDQUNMOzs7OztBQUVMOztBQUVBLFNBQVMsV0FBVyxFQUNsQixXQUNBLFVBQ0EsR0FBRyxTQUNpRDtDQUNwRCxPQUNFLHdCQUFDLGdCQUFnQixNQUFqQjtFQUNFLGFBQVU7RUFDVixXQUFXLEdBQ1Qsd1ZBQ0EsU0FDRjtFQUNBLEdBQUk7WUFOTixDQVFFLHdCQUFDLFFBQUQ7R0FDRSxhQUFVO0dBQ1YsV0FBVTthQUVWLHdCQUFDLGdCQUFnQixlQUFqQixZQUNFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLFNBQVU7Ozs7WUFDRjs7Ozs7RUFDM0I7Ozs7WUFDTix3QkFBQyxnQkFBZ0IsVUFBakIsRUFBMkIsU0FBbUM7Ozs7VUFDMUM7Ozs7OztBQUUxQjs7QUFFQSxTQUFTLGdCQUFnQixFQUN2QixXQUNBLEdBQUcsU0FDc0Q7Q0FDekQsT0FDRSx3QkFBQyxnQkFBZ0IsV0FBakI7RUFDRSxhQUFVO0VBQ1YsV0FBVyxHQUFHLG9EQUFvRCxTQUFTO0VBQzNFLEdBQUk7Q0FDTDs7Ozs7QUFFTDs7QUFFQSxTQUFTLHFCQUFxQixFQUM1QixXQUNBLEdBQUcsU0FDMkQ7Q0FDOUQsT0FDRSx3QkFBQyxnQkFBZ0IsZ0JBQWpCO0VBQ0UsYUFBVTtFQUNWLFdBQVcsR0FDVCx3REFDQSxTQUNGO0VBQ0EsR0FBSTtZQUVKLHdCQUFDLGVBQUQsRUFBZSxXQUFVLFNBQVU7Ozs7O0NBQ0w7Ozs7O0FBRXBDOztBQUVBLFNBQVMsdUJBQXVCLEVBQzlCLFdBQ0EsR0FBRyxTQUM2RDtDQUNoRSxPQUNFLHdCQUFDLGdCQUFnQixrQkFBakI7RUFDRSxhQUFVO0VBQ1YsV0FBVyxHQUNULHdEQUNBLFNBQ0Y7RUFDQSxHQUFJO1lBRUosd0JBQUMsaUJBQUQsRUFBaUIsV0FBVSxTQUFVOzs7OztDQUNMOzs7OztBQUV0Qzs7QUFFQSxTQUNFLFFBQ0EsZUFDQSxhQUNBLFlBQ0EsYUFDQSx3QkFDQSxzQkFDQSxpQkFDQSxlQUNBIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInNlbGVjdC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCJcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL3V0aWxzXCJcbmltcG9ydCB7IENoZWNrSWNvbiwgQ2hldnJvbkRvd25JY29uLCBDaGV2cm9uVXBJY29uIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiXG5pbXBvcnQgeyBTZWxlY3QgYXMgU2VsZWN0UHJpbWl0aXZlIH0gZnJvbSBcInJhZGl4LXVpXCJcblxuZnVuY3Rpb24gU2VsZWN0KHtcbiAgLi4ucHJvcHNcbn06IFJlYWN0LkNvbXBvbmVudFByb3BzPHR5cGVvZiBTZWxlY3RQcmltaXRpdmUuUm9vdD4pIHtcbiAgcmV0dXJuIDxTZWxlY3RQcmltaXRpdmUuUm9vdCBkYXRhLXNsb3Q9XCJzZWxlY3RcIiB7Li4ucHJvcHN9IC8+XG59XG5cbmZ1bmN0aW9uIFNlbGVjdEdyb3VwKHtcbiAgLi4ucHJvcHNcbn06IFJlYWN0LkNvbXBvbmVudFByb3BzPHR5cGVvZiBTZWxlY3RQcmltaXRpdmUuR3JvdXA+KSB7XG4gIHJldHVybiA8U2VsZWN0UHJpbWl0aXZlLkdyb3VwIGRhdGEtc2xvdD1cInNlbGVjdC1ncm91cFwiIHsuLi5wcm9wc30gLz5cbn1cblxuZnVuY3Rpb24gU2VsZWN0VmFsdWUoe1xuICAuLi5wcm9wc1xufTogUmVhY3QuQ29tcG9uZW50UHJvcHM8dHlwZW9mIFNlbGVjdFByaW1pdGl2ZS5WYWx1ZT4pIHtcbiAgcmV0dXJuIDxTZWxlY3RQcmltaXRpdmUuVmFsdWUgZGF0YS1zbG90PVwic2VsZWN0LXZhbHVlXCIgey4uLnByb3BzfSAvPlxufVxuXG5mdW5jdGlvbiBTZWxlY3RUcmlnZ2VyKHtcbiAgY2xhc3NOYW1lLFxuICBzaXplID0gXCJkZWZhdWx0XCIsXG4gIGNoaWxkcmVuLFxuICAuLi5wcm9wc1xufTogUmVhY3QuQ29tcG9uZW50UHJvcHM8dHlwZW9mIFNlbGVjdFByaW1pdGl2ZS5UcmlnZ2VyPiAmIHtcbiAgc2l6ZT86IFwic21cIiB8IFwiZGVmYXVsdFwiXG59KSB7XG4gIHJldHVybiAoXG4gICAgPFNlbGVjdFByaW1pdGl2ZS5UcmlnZ2VyXG4gICAgICBkYXRhLXNsb3Q9XCJzZWxlY3QtdHJpZ2dlclwiXG4gICAgICBkYXRhLXNpemU9e3NpemV9XG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICBcImZsZXggaC0xMCB3LWZ1bGwgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMiByb3VuZGVkLVszcHhdIGJvcmRlciBib3JkZXItWyMzRjIzMTldIGJnLVsjMTQwRDBBXSBweC0zIHB5LTIgZm9udC1tb25vIHRleHQtc20gdGV4dC1bI0Y1RjFFQl0gd2hpdGVzcGFjZS1ub3dyYXAgdHJhbnNpdGlvbi1jb2xvcnMgb3V0bGluZS1ub25lIGZvY3VzLXZpc2libGU6Ym9yZGVyLVsjRDI4QTRDXSBmb2N1cy12aXNpYmxlOnJpbmctMSBmb2N1cy12aXNpYmxlOnJpbmctWyNEMjhBNENdIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCBkaXNhYmxlZDpvcGFjaXR5LTUwIGRhdGEtW3BsYWNlaG9sZGVyXTp0ZXh0LVsjQjM5NDYzXSBkYXRhLVtzaXplPXNtXTpoLTggKjpkYXRhLVtzbG90PXNlbGVjdC12YWx1ZV06dHJ1bmNhdGUgWyZfc3ZnXTpwb2ludGVyLWV2ZW50cy1ub25lIFsmX3N2Z106c2hyaW5rLTAgWyZfc3ZnXTpzaXplLTRcIixcbiAgICAgICAgY2xhc3NOYW1lXG4gICAgICApfVxuICAgICAgey4uLnByb3BzfVxuICAgID5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICAgIDxTZWxlY3RQcmltaXRpdmUuSWNvbiBhc0NoaWxkPlxuICAgICAgICA8Q2hldnJvbkRvd25JY29uIGNsYXNzTmFtZT1cInNpemUtNCBvcGFjaXR5LTUwXCIgLz5cbiAgICAgIDwvU2VsZWN0UHJpbWl0aXZlLkljb24+XG4gICAgPC9TZWxlY3RQcmltaXRpdmUuVHJpZ2dlcj5cbiAgKVxufVxuXG5mdW5jdGlvbiBTZWxlY3RDb250ZW50KHtcbiAgY2xhc3NOYW1lLFxuICBjaGlsZHJlbixcbiAgcG9zaXRpb24gPSBcIml0ZW0tYWxpZ25lZFwiLFxuICBhbGlnbiA9IFwiY2VudGVyXCIsXG4gIC4uLnByb3BzXG59OiBSZWFjdC5Db21wb25lbnRQcm9wczx0eXBlb2YgU2VsZWN0UHJpbWl0aXZlLkNvbnRlbnQ+KSB7XG4gIHJldHVybiAoXG4gICAgPFNlbGVjdFByaW1pdGl2ZS5Qb3J0YWw+XG4gICAgICA8U2VsZWN0UHJpbWl0aXZlLkNvbnRlbnRcbiAgICAgICAgZGF0YS1zbG90PVwic2VsZWN0LWNvbnRlbnRcIlxuICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgIFwicmVsYXRpdmUgei1bMTUwXSBtYXgtaC0oLS1yYWRpeC1zZWxlY3QtY29udGVudC1hdmFpbGFibGUtaGVpZ2h0KSBtaW4tdy1bOHJlbV0gb3ZlcmZsb3cteC1oaWRkZW4gb3ZlcmZsb3cteS1hdXRvIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1bIzU1MzIxRl0gYmctWyMyNDE2MTJdIGZvbnQtbW9ubyB0ZXh0LVsjRjVGMUVCXSBzaGFkb3cteGxcIixcbiAgICAgICAgICBwb3NpdGlvbiA9PT0gXCJwb3BwZXJcIiAmJlxuICAgICAgICAgICAgXCJkYXRhLVtzaWRlPWJvdHRvbV06dHJhbnNsYXRlLXktMSBkYXRhLVtzaWRlPWxlZnRdOi10cmFuc2xhdGUteC0xIGRhdGEtW3NpZGU9cmlnaHRdOnRyYW5zbGF0ZS14LTEgZGF0YS1bc2lkZT10b3BdOi10cmFuc2xhdGUteS0xXCIsXG4gICAgICAgICAgY2xhc3NOYW1lXG4gICAgICAgICl9XG4gICAgICAgIHBvc2l0aW9uPXtwb3NpdGlvbn1cbiAgICAgICAgYWxpZ249e2FsaWdufVxuICAgICAgICB7Li4ucHJvcHN9XG4gICAgICA+XG4gICAgICAgIDxTZWxlY3RTY3JvbGxVcEJ1dHRvbiAvPlxuICAgICAgICA8U2VsZWN0UHJpbWl0aXZlLlZpZXdwb3J0XG4gICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgIFwicC0xXCIsXG4gICAgICAgICAgICBwb3NpdGlvbiA9PT0gXCJwb3BwZXJcIiAmJlxuICAgICAgICAgICAgICBcInctZnVsbCBtaW4tdy1bdmFyKC0tcmFkaXgtc2VsZWN0LXRyaWdnZXItd2lkdGgpXSBzY3JvbGwtbXktMVwiXG4gICAgICAgICAgKX1cbiAgICAgICAgPlxuICAgICAgICAgIHtjaGlsZHJlbn1cbiAgICAgICAgPC9TZWxlY3RQcmltaXRpdmUuVmlld3BvcnQ+XG4gICAgICAgIDxTZWxlY3RTY3JvbGxEb3duQnV0dG9uIC8+XG4gICAgICA8L1NlbGVjdFByaW1pdGl2ZS5Db250ZW50PlxuICAgIDwvU2VsZWN0UHJpbWl0aXZlLlBvcnRhbD5cbiAgKVxufVxuXG5mdW5jdGlvbiBTZWxlY3RMYWJlbCh7XG4gIGNsYXNzTmFtZSxcbiAgLi4ucHJvcHNcbn06IFJlYWN0LkNvbXBvbmVudFByb3BzPHR5cGVvZiBTZWxlY3RQcmltaXRpdmUuTGFiZWw+KSB7XG4gIHJldHVybiAoXG4gICAgPFNlbGVjdFByaW1pdGl2ZS5MYWJlbFxuICAgICAgZGF0YS1zbG90PVwic2VsZWN0LWxhYmVsXCJcbiAgICAgIGNsYXNzTmFtZT17Y24oXCJweC0yIHB5LTEuNSB0ZXh0LXhzIHRleHQtWyNCMzk0NjNdXCIsIGNsYXNzTmFtZSl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgKVxufVxuXG5mdW5jdGlvbiBTZWxlY3RJdGVtKHtcbiAgY2xhc3NOYW1lLFxuICBjaGlsZHJlbixcbiAgLi4ucHJvcHNcbn06IFJlYWN0LkNvbXBvbmVudFByb3BzPHR5cGVvZiBTZWxlY3RQcmltaXRpdmUuSXRlbT4pIHtcbiAgcmV0dXJuIChcbiAgICA8U2VsZWN0UHJpbWl0aXZlLkl0ZW1cbiAgICAgIGRhdGEtc2xvdD1cInNlbGVjdC1pdGVtXCJcbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwicmVsYXRpdmUgZmxleCB3LWZ1bGwgY3Vyc29yLXBvaW50ZXIgaXRlbXMtY2VudGVyIGdhcC0yIHJvdW5kZWQtbWQgcHktMi41IHByLTggcGwtMyB0ZXh0LXNtIG91dGxpbmUtbm9uZSBzZWxlY3Qtbm9uZSBkYXRhLVtoaWdobGlnaHRlZF06YmctWyMzODI2MTddIGRhdGEtW2hpZ2hsaWdodGVkXTp0ZXh0LVsjRTg5QjU1XSBkYXRhLVtzdGF0ZT1jaGVja2VkXTp0ZXh0LVsjRTg5QjU1XSBkYXRhLVtkaXNhYmxlZF06cG9pbnRlci1ldmVudHMtbm9uZSBkYXRhLVtkaXNhYmxlZF06b3BhY2l0eS01MCBbJl9zdmddOnBvaW50ZXItZXZlbnRzLW5vbmUgWyZfc3ZnXTpzaHJpbmstMCBbJl9zdmddOnNpemUtNFwiLFxuICAgICAgICBjbGFzc05hbWVcbiAgICAgICl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgPlxuICAgICAgPHNwYW5cbiAgICAgICAgZGF0YS1zbG90PVwic2VsZWN0LWl0ZW0taW5kaWNhdG9yXCJcbiAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtMiBmbGV4IHNpemUtMy41IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiXG4gICAgICA+XG4gICAgICAgIDxTZWxlY3RQcmltaXRpdmUuSXRlbUluZGljYXRvcj5cbiAgICAgICAgICA8Q2hlY2tJY29uIGNsYXNzTmFtZT1cInNpemUtNFwiIC8+XG4gICAgICAgIDwvU2VsZWN0UHJpbWl0aXZlLkl0ZW1JbmRpY2F0b3I+XG4gICAgICA8L3NwYW4+XG4gICAgICA8U2VsZWN0UHJpbWl0aXZlLkl0ZW1UZXh0PntjaGlsZHJlbn08L1NlbGVjdFByaW1pdGl2ZS5JdGVtVGV4dD5cbiAgICA8L1NlbGVjdFByaW1pdGl2ZS5JdGVtPlxuICApXG59XG5cbmZ1bmN0aW9uIFNlbGVjdFNlcGFyYXRvcih7XG4gIGNsYXNzTmFtZSxcbiAgLi4ucHJvcHNcbn06IFJlYWN0LkNvbXBvbmVudFByb3BzPHR5cGVvZiBTZWxlY3RQcmltaXRpdmUuU2VwYXJhdG9yPikge1xuICByZXR1cm4gKFxuICAgIDxTZWxlY3RQcmltaXRpdmUuU2VwYXJhdG9yXG4gICAgICBkYXRhLXNsb3Q9XCJzZWxlY3Qtc2VwYXJhdG9yXCJcbiAgICAgIGNsYXNzTmFtZT17Y24oXCJwb2ludGVyLWV2ZW50cy1ub25lIC1teC0xIG15LTEgaC1weCBiZy1bIzNGMjMxOV1cIiwgY2xhc3NOYW1lKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmZ1bmN0aW9uIFNlbGVjdFNjcm9sbFVwQnV0dG9uKHtcbiAgY2xhc3NOYW1lLFxuICAuLi5wcm9wc1xufTogUmVhY3QuQ29tcG9uZW50UHJvcHM8dHlwZW9mIFNlbGVjdFByaW1pdGl2ZS5TY3JvbGxVcEJ1dHRvbj4pIHtcbiAgcmV0dXJuIChcbiAgICA8U2VsZWN0UHJpbWl0aXZlLlNjcm9sbFVwQnV0dG9uXG4gICAgICBkYXRhLXNsb3Q9XCJzZWxlY3Qtc2Nyb2xsLXVwLWJ1dHRvblwiXG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICBcImZsZXggY3Vyc29yLWRlZmF1bHQgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHB5LTFcIixcbiAgICAgICAgY2xhc3NOYW1lXG4gICAgICApfVxuICAgICAgey4uLnByb3BzfVxuICAgID5cbiAgICAgIDxDaGV2cm9uVXBJY29uIGNsYXNzTmFtZT1cInNpemUtNFwiIC8+XG4gICAgPC9TZWxlY3RQcmltaXRpdmUuU2Nyb2xsVXBCdXR0b24+XG4gIClcbn1cblxuZnVuY3Rpb24gU2VsZWN0U2Nyb2xsRG93bkJ1dHRvbih7XG4gIGNsYXNzTmFtZSxcbiAgLi4ucHJvcHNcbn06IFJlYWN0LkNvbXBvbmVudFByb3BzPHR5cGVvZiBTZWxlY3RQcmltaXRpdmUuU2Nyb2xsRG93bkJ1dHRvbj4pIHtcbiAgcmV0dXJuIChcbiAgICA8U2VsZWN0UHJpbWl0aXZlLlNjcm9sbERvd25CdXR0b25cbiAgICAgIGRhdGEtc2xvdD1cInNlbGVjdC1zY3JvbGwtZG93bi1idXR0b25cIlxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJmbGV4IGN1cnNvci1kZWZhdWx0IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBweS0xXCIsXG4gICAgICAgIGNsYXNzTmFtZVxuICAgICAgKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICA8Q2hldnJvbkRvd25JY29uIGNsYXNzTmFtZT1cInNpemUtNFwiIC8+XG4gICAgPC9TZWxlY3RQcmltaXRpdmUuU2Nyb2xsRG93bkJ1dHRvbj5cbiAgKVxufVxuXG5leHBvcnQge1xuICBTZWxlY3QsXG4gIFNlbGVjdENvbnRlbnQsXG4gIFNlbGVjdEdyb3VwLFxuICBTZWxlY3RJdGVtLFxuICBTZWxlY3RMYWJlbCxcbiAgU2VsZWN0U2Nyb2xsRG93bkJ1dHRvbixcbiAgU2VsZWN0U2Nyb2xsVXBCdXR0b24sXG4gIFNlbGVjdFNlcGFyYXRvcixcbiAgU2VsZWN0VHJpZ2dlcixcbiAgU2VsZWN0VmFsdWUsXG59XG4iXX0=
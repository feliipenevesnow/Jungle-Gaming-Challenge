import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/NFTCard.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=7abeec5e";
import { Heart, ShoppingBag, Search } from "/node_modules/.vite/deps/lucide-react.js?v=c7b96d59";
var _jsxFileName = "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/NFTCard.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7abeec5e";
export const NFTCard = ({ nft, isFavorite = false, isFavoritePending = false, onToggleFavorite, onAddToCart, onSelect, eager = false }) => {
	return /* @__PURE__ */ _jsxDEV("article", {
		tabIndex: 0,
		onKeyDown: (e) => {
			if (e.key === "Enter" && e.target === e.currentTarget) onSelect?.(nft.id);
		},
		className: "nft-card group relative flex w-full max-w-[260px] flex-col rounded-xl border border-[#3F2319] bg-[#241612] p-2.5 transition-all duration-300 hover:border-[#D28A4C] hover:shadow-2xl focus-within:border-[#D28A4C] focus:outline-none",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			onClick: () => onSelect?.(nft.id),
			className: "nft-art relative aspect-square w-full cursor-pointer overflow-hidden rounded-2xl bg-[#140D0A]",
			children: [
				/* @__PURE__ */ _jsxDEV("img", {
					src: nft.imageUrl,
					alt: nft.name,
					loading: eager ? "eager" : "lazy",
					fetchPriority: eager ? "high" : "auto",
					width: 520,
					height: 520,
					className: "h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 37,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "nft-mobile-favorite",
					disabled: isFavoritePending,
					"aria-pressed": isFavorite,
					"aria-label": isFavorite ? `Remover ${nft.name} dos favoritos` : `Favoritar ${nft.name}`,
					onClick: (e) => {
						e.stopPropagation();
						onToggleFavorite?.(nft.id);
					},
					children: /* @__PURE__ */ _jsxDEV(Heart, {
						size: 19,
						fill: isFavorite ? "currentColor" : "none"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 47,
						columnNumber: 273
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 47,
					columnNumber: 9
				}, this),
				nft.badge && /* @__PURE__ */ _jsxDEV("span", {
					className: "absolute left-0 top-3 rounded-r-sm bg-[#D28A4C] px-3 py-1 font-mono text-xs font-bold uppercase tracking-wider text-[#140D0A] shadow-md z-10",
					children: nft.badge
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 50,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "nft-actions absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-2 rounded-lg border border-[#3F2319] bg-[#140D0A]/90 p-1.5 opacity-0 backdrop-blur-md transition-all duration-200 group-hover:opacity-100 group-focus-within:opacity-100 z-20 shadow-xl",
					children: [
						onAddToCart && /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: (e) => {
								e.stopPropagation();
								onAddToCart?.(nft);
							},
							"aria-label": `Adicionar ${nft.name} ao carrinho`,
							className: "flex h-8 w-8 items-center justify-center rounded-md bg-[#241612] text-[#F5F1EB] transition-colors hover:bg-[#D28A4C] hover:text-[#140D0A] cursor-pointer",
							children: /* @__PURE__ */ _jsxDEV(ShoppingBag, { className: "h-4 w-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 67,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 58,
							columnNumber: 27
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							disabled: isFavoritePending,
							"aria-pressed": isFavorite,
							onClick: (e) => {
								e.stopPropagation();
								onToggleFavorite?.(nft.id);
							},
							"aria-label": isFavorite ? `Remover ${nft.name} dos favoritos` : `Favoritar ${nft.name}`,
							className: `flex h-8 w-8 items-center justify-center rounded-md bg-[#241612] transition-colors cursor-pointer ${isFavorite ? "text-[#F0805F] hover:bg-[#F0805F] hover:text-white" : "text-[#F5F1EB] hover:bg-[#D28A4C] hover:text-[#140D0A]"}`,
							children: /* @__PURE__ */ _jsxDEV(Heart, { className: `h-4 w-4 ${isFavorite ? "fill-current" : ""}` }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 86,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 71,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: (e) => {
								e.stopPropagation();
								onSelect?.(nft.id);
							},
							"aria-label": `Ver detalhes de ${nft.name}`,
							className: "flex h-8 w-8 items-center justify-center rounded-md bg-[#241612] text-[#F5F1EB] transition-colors hover:bg-[#D28A4C] hover:text-[#140D0A] cursor-pointer",
							children: /* @__PURE__ */ _jsxDEV(Search, { className: "h-4 w-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 99,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 90,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 33,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "nft-caption flex flex-col gap-1 px-1 pt-3 pb-1",
			children: [/* @__PURE__ */ _jsxDEV("h3", {
				onClick: () => onSelect?.(nft.id),
				className: "cursor-pointer truncate font-mono text-base font-medium text-[#F5F1EB] transition-colors group-hover:text-[#E89B55]",
				title: nft.name,
				children: nft.name
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 106,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-baseline gap-2.5 pt-0.5",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "font-mono text-lg font-bold text-[#E89B55]",
					children: [nft.priceEth, " ETH"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 116,
					columnNumber: 11
				}, this), nft.originalPriceEth && /* @__PURE__ */ _jsxDEV("span", {
					className: "font-mono text-sm text-[#B39463] line-through",
					children: [nft.originalPriceEth, " ETH"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 120,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 115,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 105,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 25,
		columnNumber: 5
	}, this);
};
_c = NFTCard;
var _c;
$RefreshReg$(_c, "NFTCard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/NFTCard.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/NFTCard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/NFTCard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/NFTCard.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsT0FBTyxhQUFhLGNBQWM7OztBQWEzQyxPQUFPLE1BQU0sV0FBbUMsRUFDOUMsS0FDQSxhQUFhLE9BQ2Isb0JBQW9CLE9BQ3BCLGtCQUNBLGFBQ0EsVUFDQSxRQUFRLFlBQ0o7Q0FDSixPQUNFLHdCQUFDLFdBQUQ7RUFDRSxVQUFVO0VBQ1YsWUFBWSxNQUFNO0dBQ2hCLElBQUksRUFBRSxRQUFRLFdBQVcsRUFBRSxXQUFXLEVBQUUsZUFBZSxXQUFXLElBQUksRUFBRTtFQUMxRTtFQUNBLFdBQVU7WUFMWixDQVFFLHdCQUFDLE9BQUQ7R0FDRSxlQUFlLFdBQVcsSUFBSSxFQUFFO0dBQ2hDLFdBQVU7YUFGWjtJQUlFLHdCQUFDLE9BQUQ7S0FDRSxLQUFLLElBQUk7S0FDVCxLQUFLLElBQUk7S0FDVCxTQUFTLFFBQVEsVUFBVTtLQUMzQixlQUFlLFFBQVEsU0FBUztLQUNoQyxPQUFPO0tBQ1AsUUFBUTtLQUNSLFdBQVU7SUFDWDs7Ozs7SUFFRCx3QkFBQyxVQUFEO0tBQVEsTUFBSztLQUFTLFdBQVU7S0FBc0IsVUFBVTtLQUFtQixnQkFBYztLQUFZLGNBQVksYUFBYSxXQUFXLElBQUksS0FBSyxrQkFBa0IsYUFBYSxJQUFJO0tBQVEsVUFBUyxNQUFLO01BQUUsRUFBRSxnQkFBZ0I7TUFBRyxtQkFBbUIsSUFBSSxFQUFFO0tBQUU7ZUFBRyx3QkFBQyxPQUFEO01BQU8sTUFBTTtNQUFJLE1BQU0sYUFBYSxpQkFBaUI7S0FBUzs7Ozs7SUFBUzs7Ozs7SUFFOVUsSUFBSSxTQUNILHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQ2IsSUFBSTtJQUNEOzs7OztJQUlSLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFFRyxlQUFlLHdCQUFDLFVBQUQ7T0FDZCxNQUFLO09BQ0wsVUFBVSxNQUFNO1FBQ2QsRUFBRSxnQkFBZ0I7UUFDbEIsY0FBYyxHQUFHO09BQ25CO09BQ0EsY0FBWSxhQUFhLElBQUksS0FBSztPQUNsQyxXQUFVO2lCQUVWLHdCQUFDLGFBQUQsRUFBYSxXQUFVLFVBQVc7Ozs7O01BQzVCOzs7OztNQUdSLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsVUFBVTtPQUNWLGdCQUFjO09BQ2QsVUFBVSxNQUFNO1FBQ2QsRUFBRSxnQkFBZ0I7UUFDbEIsbUJBQW1CLElBQUksRUFBRTtPQUMzQjtPQUNBLGNBQVksYUFBYSxXQUFXLElBQUksS0FBSyxrQkFBa0IsYUFBYSxJQUFJO09BQ2hGLFdBQVcscUdBQ1QsYUFDSSx1REFDQTtpQkFHTix3QkFBQyxPQUFELEVBQU8sV0FBVyxXQUFXLGFBQWEsaUJBQWlCLEtBQU87Ozs7O01BQzVEOzs7OztNQUdSLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsVUFBVSxNQUFNO1FBQ2QsRUFBRSxnQkFBZ0I7UUFDbEIsV0FBVyxJQUFJLEVBQUU7T0FDbkI7T0FDQSxjQUFZLG1CQUFtQixJQUFJO09BQ25DLFdBQVU7aUJBRVYsd0JBQUMsUUFBRCxFQUFRLFdBQVUsVUFBVzs7Ozs7TUFDdkI7Ozs7O0tBQ0w7Ozs7OztHQUNGOzs7OztZQUdMLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxNQUFEO0lBQ0UsZUFBZSxXQUFXLElBQUksRUFBRTtJQUNoQyxXQUFVO0lBQ1YsT0FBTyxJQUFJO2NBRVYsSUFBSTtHQUNIOzs7O2FBR0osd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWhCLENBQ0csSUFBSSxVQUFTLE1BQ1Y7Ozs7O2NBQ0wsSUFBSSxvQkFDSCx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFoQixDQUNHLElBQUksa0JBQWlCLE1BQ2xCOzs7OztZQUVMOzs7OztXQUNGOzs7OztVQUNFOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJORlRDYXJkLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IEhlYXJ0LCBTaG9wcGluZ0JhZywgU2VhcmNoIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xyXG5pbXBvcnQgdHlwZSB7IE5GVCB9IGZyb20gJ0AvdHlwZXMvYXBpJ1xyXG5cclxuaW50ZXJmYWNlIE5GVENhcmRQcm9wcyB7XHJcbiAgbmZ0OiBORlRcclxuICBpc0Zhdm9yaXRlPzogYm9vbGVhblxyXG4gIGlzRmF2b3JpdGVQZW5kaW5nPzogYm9vbGVhblxyXG4gIG9uVG9nZ2xlRmF2b3JpdGU/OiAoaWQ6IHN0cmluZykgPT4gdm9pZFxyXG4gIG9uQWRkVG9DYXJ0PzogKG5mdDogTkZUKSA9PiB2b2lkXHJcbiAgb25TZWxlY3Q/OiAoaWQ6IHN0cmluZykgPT4gdm9pZFxyXG4gIGVhZ2VyPzogYm9vbGVhblxyXG59XHJcblxyXG5leHBvcnQgY29uc3QgTkZUQ2FyZDogUmVhY3QuRkM8TkZUQ2FyZFByb3BzPiA9ICh7XHJcbiAgbmZ0LFxyXG4gIGlzRmF2b3JpdGUgPSBmYWxzZSxcclxuICBpc0Zhdm9yaXRlUGVuZGluZyA9IGZhbHNlLFxyXG4gIG9uVG9nZ2xlRmF2b3JpdGUsXHJcbiAgb25BZGRUb0NhcnQsXHJcbiAgb25TZWxlY3QsXHJcbiAgZWFnZXIgPSBmYWxzZSxcclxufSkgPT4ge1xyXG4gIHJldHVybiAoXHJcbiAgICA8YXJ0aWNsZVxyXG4gICAgICB0YWJJbmRleD17MH1cclxuICAgICAgb25LZXlEb3duPXsoZSkgPT4ge1xyXG4gICAgICAgIGlmIChlLmtleSA9PT0gJ0VudGVyJyAmJiBlLnRhcmdldCA9PT0gZS5jdXJyZW50VGFyZ2V0KSBvblNlbGVjdD8uKG5mdC5pZClcclxuICAgICAgfX1cclxuICAgICAgY2xhc3NOYW1lPVwibmZ0LWNhcmQgZ3JvdXAgcmVsYXRpdmUgZmxleCB3LWZ1bGwgbWF4LXctWzI2MHB4XSBmbGV4LWNvbCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItWyMzRjIzMTldIGJnLVsjMjQxNjEyXSBwLTIuNSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgaG92ZXI6Ym9yZGVyLVsjRDI4QTRDXSBob3ZlcjpzaGFkb3ctMnhsIGZvY3VzLXdpdGhpbjpib3JkZXItWyNEMjhBNENdIGZvY3VzOm91dGxpbmUtbm9uZVwiXHJcbiAgICA+XHJcbiAgICAgIHsvKiBTcXVhcmUgQXJ0d29yayBDb250YWluZXIgKi99XHJcbiAgICAgIDxkaXZcclxuICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblNlbGVjdD8uKG5mdC5pZCl9XHJcbiAgICAgICAgY2xhc3NOYW1lPVwibmZ0LWFydCByZWxhdGl2ZSBhc3BlY3Qtc3F1YXJlIHctZnVsbCBjdXJzb3ItcG9pbnRlciBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC0yeGwgYmctWyMxNDBEMEFdXCJcclxuICAgICAgPlxyXG4gICAgICAgIDxpbWdcclxuICAgICAgICAgIHNyYz17bmZ0LmltYWdlVXJsfVxyXG4gICAgICAgICAgYWx0PXtuZnQubmFtZX1cclxuICAgICAgICAgIGxvYWRpbmc9e2VhZ2VyID8gJ2VhZ2VyJyA6ICdsYXp5J31cclxuICAgICAgICAgIGZldGNoUHJpb3JpdHk9e2VhZ2VyID8gJ2hpZ2gnIDogJ2F1dG8nfVxyXG4gICAgICAgICAgd2lkdGg9ezUyMH1cclxuICAgICAgICAgIGhlaWdodD17NTIwfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiaC1mdWxsIHctZnVsbCBvYmplY3QtY292ZXIgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tNTAwIGdyb3VwLWhvdmVyOnNjYWxlLTEwNVwiXHJcbiAgICAgICAgLz5cclxuXHJcbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwibmZ0LW1vYmlsZS1mYXZvcml0ZVwiIGRpc2FibGVkPXtpc0Zhdm9yaXRlUGVuZGluZ30gYXJpYS1wcmVzc2VkPXtpc0Zhdm9yaXRlfSBhcmlhLWxhYmVsPXtpc0Zhdm9yaXRlID8gYFJlbW92ZXIgJHtuZnQubmFtZX0gZG9zIGZhdm9yaXRvc2AgOiBgRmF2b3JpdGFyICR7bmZ0Lm5hbWV9YH0gb25DbGljaz17ZSA9PiB7IGUuc3RvcFByb3BhZ2F0aW9uKCk7IG9uVG9nZ2xlRmF2b3JpdGU/LihuZnQuaWQpIH19PjxIZWFydCBzaXplPXsxOX0gZmlsbD17aXNGYXZvcml0ZSA/ICdjdXJyZW50Q29sb3InIDogJ25vbmUnfSAvPjwvYnV0dG9uPlxyXG4gICAgICAgIHsvKiBUb3AtTGVmdCBSZWN0YW5ndWxhciBCYWRnZSAoZS5nLiwgUkFSTyBvbiBOZW9uIFZlc3NlbCAjNTUyKSAqL31cclxuICAgICAgICB7bmZ0LmJhZGdlICYmIChcclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtMCB0b3AtMyByb3VuZGVkLXItc20gYmctWyNEMjhBNENdIHB4LTMgcHktMSBmb250LW1vbm8gdGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtWyMxNDBEMEFdIHNoYWRvdy1tZCB6LTEwXCI+XHJcbiAgICAgICAgICAgIHtuZnQuYmFkZ2V9XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgKX1cclxuXHJcbiAgICAgICAgey8qIEhvdmVyIC8gRm9jdXMgRmxvYXRpbmcgQWN0aW9uIEJhciAoMyBTcXVhcmUgQnV0dG9ucyBDZW50ZXJlZCBhdCBCb3R0b20gb2YgQXJ0d29yaykgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJuZnQtYWN0aW9ucyBhYnNvbHV0ZSBib3R0b20tMyBsZWZ0LTEvMiAtdHJhbnNsYXRlLXgtMS8yIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1bIzNGMjMxOV0gYmctWyMxNDBEMEFdLzkwIHAtMS41IG9wYWNpdHktMCBiYWNrZHJvcC1ibHVyLW1kIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCBncm91cC1mb2N1cy13aXRoaW46b3BhY2l0eS0xMDAgei0yMCBzaGFkb3cteGxcIj5cclxuICAgICAgICAgIHsvKiAxLiBBZGQgdG8gQ2FydCAqL31cclxuICAgICAgICAgIHtvbkFkZFRvQ2FydCAmJiA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKClcclxuICAgICAgICAgICAgICBvbkFkZFRvQ2FydD8uKG5mdClcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgYXJpYS1sYWJlbD17YEFkaWNpb25hciAke25mdC5uYW1lfSBhbyBjYXJyaW5ob2B9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaC04IHctOCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1tZCBiZy1bIzI0MTYxMl0gdGV4dC1bI0Y1RjFFQl0gdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6YmctWyNEMjhBNENdIGhvdmVyOnRleHQtWyMxNDBEMEFdIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPFNob3BwaW5nQmFnIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxyXG4gICAgICAgICAgPC9idXR0b24+fVxyXG5cclxuICAgICAgICAgIHsvKiAyLiBUb2dnbGUgRmF2b3JpdGUgKi99XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBkaXNhYmxlZD17aXNGYXZvcml0ZVBlbmRpbmd9XHJcbiAgICAgICAgICAgIGFyaWEtcHJlc3NlZD17aXNGYXZvcml0ZX1cclxuICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcclxuICAgICAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpXHJcbiAgICAgICAgICAgICAgb25Ub2dnbGVGYXZvcml0ZT8uKG5mdC5pZClcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgYXJpYS1sYWJlbD17aXNGYXZvcml0ZSA/IGBSZW1vdmVyICR7bmZ0Lm5hbWV9IGRvcyBmYXZvcml0b3NgIDogYEZhdm9yaXRhciAke25mdC5uYW1lfWB9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaC04IHctOCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1tZCBiZy1bIzI0MTYxMl0gdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgJHtcclxuICAgICAgICAgICAgICBpc0Zhdm9yaXRlXHJcbiAgICAgICAgICAgICAgICA/ICd0ZXh0LVsjRjA4MDVGXSBob3ZlcjpiZy1bI0YwODA1Rl0gaG92ZXI6dGV4dC13aGl0ZSdcclxuICAgICAgICAgICAgICAgIDogJ3RleHQtWyNGNUYxRUJdIGhvdmVyOmJnLVsjRDI4QTRDXSBob3Zlcjp0ZXh0LVsjMTQwRDBBXSdcclxuICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxIZWFydCBjbGFzc05hbWU9e2BoLTQgdy00ICR7aXNGYXZvcml0ZSA/ICdmaWxsLWN1cnJlbnQnIDogJyd9YH0gLz5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgIHsvKiAzLiBWaWV3IERldGFpbHMgKi99XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKClcclxuICAgICAgICAgICAgICBvblNlbGVjdD8uKG5mdC5pZClcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgYXJpYS1sYWJlbD17YFZlciBkZXRhbGhlcyBkZSAke25mdC5uYW1lfWB9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaC04IHctOCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1tZCBiZy1bIzI0MTYxMl0gdGV4dC1bI0Y1RjFFQl0gdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6YmctWyNEMjhBNENdIGhvdmVyOnRleHQtWyMxNDBEMEFdIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBEZXRhaWxzIChOYW1lICsgUHJpY2UgUm93IE9ubHksIG1hdGNoaW5nIEZpZ21hIDI6MikgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibmZ0LWNhcHRpb24gZmxleCBmbGV4LWNvbCBnYXAtMSBweC0xIHB0LTMgcGItMVwiPlxyXG4gICAgICAgIDxoM1xyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gb25TZWxlY3Q/LihuZnQuaWQpfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiY3Vyc29yLXBvaW50ZXIgdHJ1bmNhdGUgZm9udC1tb25vIHRleHQtYmFzZSBmb250LW1lZGl1bSB0ZXh0LVsjRjVGMUVCXSB0cmFuc2l0aW9uLWNvbG9ycyBncm91cC1ob3Zlcjp0ZXh0LVsjRTg5QjU1XVwiXHJcbiAgICAgICAgICB0aXRsZT17bmZ0Lm5hbWV9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge25mdC5uYW1lfVxyXG4gICAgICAgIDwvaDM+XHJcblxyXG4gICAgICAgIHsvKiBQcmljZSBpbiBIaWdobGlnaHQgKyBTdHJpa2V0aHJvdWdoIFByaWNlIHdoZW4gZGlzY291bnRlZCAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtYmFzZWxpbmUgZ2FwLTIuNSBwdC0wLjVcIj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LVsjRTg5QjU1XVwiPlxyXG4gICAgICAgICAgICB7bmZ0LnByaWNlRXRofSBFVEhcclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIHtuZnQub3JpZ2luYWxQcmljZUV0aCAmJiAoXHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXNtIHRleHQtWyNCMzk0NjNdIGxpbmUtdGhyb3VnaFwiPlxyXG4gICAgICAgICAgICAgIHtuZnQub3JpZ2luYWxQcmljZUV0aH0gRVRIXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9hcnRpY2xlPlxyXG4gIClcclxufVxyXG4iXX0=
import { i as __toESM, n as __exportAll } from "/node_modules/.vite/deps/rolldown-runtime-DbVrKiKs.js?v=a728df00";
import { t as require_react } from "/node_modules/.vite/deps/react-eZXm9bZy.js?v=a728df00";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/jsx-runtime-hYFZm98l.js?v=a728df00";
import { a as useLayoutEffect2, o as createContextScope, r as useControllableState, s as composeEventHandlers, t as Primitive } from "/node_modules/.vite/deps/dist-CQ95zGK7.js?v=a728df00";
import { o as useComposedRefs, r as createSlot } from "/node_modules/.vite/deps/dist-DIJv4qBM.js?v=a728df00";
//#region node_modules/@radix-ui/number/dist/index.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var __defProp$4 = Object.defineProperty;
var __name$4 = (target, value) => __defProp$4(target, "name", {
	value,
	configurable: true
});
function clamp(value, [min, max]) {
	return Math.min(max, Math.max(min, value));
}
__name$4(clamp, "clamp");
//#endregion
//#region node_modules/@radix-ui/react-direction/dist/index.mjs
var dist_exports$1 = /* @__PURE__ */ __exportAll({
	DirectionProvider: () => DirectionProvider,
	Provider: () => DirectionProvider,
	useDirection: () => useDirection
});
var import_jsx_runtime = require_jsx_runtime();
var __defProp$3 = Object.defineProperty;
var __name$3 = (target, value) => __defProp$3(target, "name", {
	value,
	configurable: true
});
var Direction$1 = {
	LTR: "ltr",
	RTL: "rtl"
};
var DirectionContext = import_react.createContext(void 0);
var DirectionProvider = /* @__PURE__ */ __name$3((props) => {
	const { dir, children } = props;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DirectionContext.Provider, {
		value: dir,
		children
	});
}, "DirectionProvider");
function useDirection(localDir) {
	const globalDir = import_react.useContext(DirectionContext);
	return localDir || globalDir || Direction$1.LTR;
}
__name$3(useDirection, "useDirection");
//#endregion
//#region node_modules/@radix-ui/react-use-size/dist/index.mjs
var __defProp$2 = Object.defineProperty;
var __name$2 = (target, value) => __defProp$2(target, "name", {
	value,
	configurable: true
});
function useSize(element) {
	const [size, setSize] = import_react.useState(void 0);
	useLayoutEffect2(() => {
		if (element) {
			setSize({
				width: element.offsetWidth,
				height: element.offsetHeight
			});
			let rAF = 0;
			const resizeObserver = new ResizeObserver((entries) => {
				if (!Array.isArray(entries)) return;
				if (!entries.length) return;
				const entry = entries[0];
				window.cancelAnimationFrame(rAF);
				rAF = window.requestAnimationFrame(() => {
					let width;
					let height;
					if ("borderBoxSize" in entry) {
						const borderSizeEntry = entry["borderBoxSize"];
						const borderSize = Array.isArray(borderSizeEntry) ? borderSizeEntry[0] : borderSizeEntry;
						width = borderSize["inlineSize"];
						height = borderSize["blockSize"];
					} else {
						width = element.offsetWidth;
						height = element.offsetHeight;
					}
					setSize({
						width,
						height
					});
				});
			});
			resizeObserver.observe(element, { box: "border-box" });
			return () => {
				window.cancelAnimationFrame(rAF);
				resizeObserver.unobserve(element);
			};
		} else setSize(void 0);
	}, [element]);
	return size;
}
__name$2(useSize, "useSize");
//#endregion
//#region node_modules/@radix-ui/react-collection/dist/index.mjs
var __defProp$1 = Object.defineProperty;
var __name$1 = (target, value) => __defProp$1(target, "name", {
	value,
	configurable: true
});
// @__NO_SIDE_EFFECTS__
function createCollection(name) {
	const PROVIDER_NAME = name + "CollectionProvider";
	const [createCollectionContext, createCollectionScope] = createContextScope(PROVIDER_NAME);
	const [CollectionProviderImpl, useCollectionContext] = createCollectionContext(PROVIDER_NAME, {
		collectionRef: { current: null },
		itemMap: /* @__PURE__ */ new Map()
	});
	const CollectionProvider = /* @__PURE__ */ __name$1((props) => {
		const { scope, children } = props;
		const ref = import_react.useRef(null);
		const itemMap = import_react.useRef(/* @__PURE__ */ new Map()).current;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionProviderImpl, {
			scope,
			itemMap,
			collectionRef: ref,
			children
		});
	}, "CollectionProvider");
	CollectionProvider.displayName = PROVIDER_NAME;
	const COLLECTION_SLOT_NAME = name + "CollectionSlot";
	const CollectionSlotImpl = createSlot(COLLECTION_SLOT_NAME);
	const CollectionSlot = import_react.forwardRef((props, forwardedRef) => {
		const { scope, children } = props;
		const context = useCollectionContext(COLLECTION_SLOT_NAME, scope);
		const composedRefs = useComposedRefs(forwardedRef, context.collectionRef);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionSlotImpl, {
			ref: composedRefs,
			children
		});
	});
	CollectionSlot.displayName = COLLECTION_SLOT_NAME;
	const ITEM_SLOT_NAME = name + "CollectionItemSlot";
	const ITEM_DATA_ATTR = "data-radix-collection-item";
	const CollectionItemSlotImpl = createSlot(ITEM_SLOT_NAME);
	const CollectionItemSlot = import_react.forwardRef((props, forwardedRef) => {
		const { scope, children, ...itemData } = props;
		const ref = import_react.useRef(null);
		const composedRefs = useComposedRefs(forwardedRef, ref);
		const context = useCollectionContext(ITEM_SLOT_NAME, scope);
		import_react.useEffect(() => {
			context.itemMap.set(ref, {
				ref,
				...itemData
			});
			return () => void context.itemMap.delete(ref);
		});
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionItemSlotImpl, {
			[ITEM_DATA_ATTR]: "",
			ref: composedRefs,
			children
		});
	});
	CollectionItemSlot.displayName = ITEM_SLOT_NAME;
	function useCollection(scope) {
		const context = useCollectionContext(name + "CollectionConsumer", scope);
		return import_react.useCallback(() => {
			const collectionNode = context.collectionRef.current;
			if (!collectionNode) return [];
			const orderedNodes = Array.from(collectionNode.querySelectorAll(`[${ITEM_DATA_ATTR}]`));
			return Array.from(context.itemMap.values()).sort((a, b) => orderedNodes.indexOf(a.ref.current) - orderedNodes.indexOf(b.ref.current));
		}, [context.collectionRef, context.itemMap]);
	}
	__name$1(useCollection, "useCollection");
	return [
		{
			Provider: CollectionProvider,
			Slot: CollectionSlot,
			ItemSlot: CollectionItemSlot
		},
		useCollection,
		createCollectionScope
	];
}
__name$1(createCollection, "createCollection");
var __instanciated = /* @__PURE__ */ new WeakMap();
var OrderedDict = class _OrderedDict extends Map {
	static {
		__name$1(this, "OrderedDict");
	}
	#keys;
	constructor(entries) {
		super(entries);
		this.#keys = [...super.keys()];
		__instanciated.set(this, true);
	}
	set(key, value) {
		if (__instanciated.get(this) && !this.has(key)) this.#keys.push(key);
		super.set(key, value);
		return this;
	}
	/**
	* Sets a key-value pair so that it ends up at the given index.
	* - Existing keys are moved
	* - Negative indices count from the end of the resulting dictionary, so
	*   inserting at -1 makes the item the last one, -2 the second to last, etc.
	* - Out-of-range indices are clamped
	*/
	insert(index, key, value) {
		const has = this.has(key);
		const finalSize = has ? this.size : this.size + 1;
		const relativeIndex = toSafeInteger(index);
		const targetIndex = relativeIndex >= 0 ? Math.min(relativeIndex, finalSize - 1) : Math.max(finalSize + relativeIndex, 0);
		if (has ? this.#keys.indexOf(key) === targetIndex : targetIndex === this.size) {
			this.set(key, value);
			return this;
		}
		const keys = this.#keys.filter((existingKey) => existingKey !== key);
		keys.splice(targetIndex, 0, key);
		const entries = keys.map((entryKey) => [entryKey, entryKey === key ? value : this.get(entryKey)]);
		this.clear();
		for (const [entryKey, entryValue] of entries) this.set(entryKey, entryValue);
		return this;
	}
	with(index, key, value) {
		const copy = new _OrderedDict(this);
		copy.insert(index, key, value);
		return copy;
	}
	before(key) {
		const index = this.#keys.indexOf(key) - 1;
		if (index < 0) return;
		return this.entryAt(index);
	}
	/**
	* Sets a new key-value pair at the position before the given key.
	*/
	setBefore(key, newKey, value) {
		const index = this.#keys.indexOf(key);
		if (index === -1) return this;
		const currentIndex = this.#keys.indexOf(newKey);
		const targetIndex = currentIndex !== -1 && currentIndex < index ? index - 1 : index;
		return this.insert(targetIndex, newKey, value);
	}
	after(key) {
		let index = this.#keys.indexOf(key);
		index = index === -1 || index === this.size - 1 ? -1 : index + 1;
		if (index === -1) return;
		return this.entryAt(index);
	}
	/**
	* Sets a new key-value pair at the position after the given key.
	*/
	setAfter(key, newKey, value) {
		const index = this.#keys.indexOf(key);
		if (index === -1) return this;
		const currentIndex = this.#keys.indexOf(newKey);
		const targetIndex = currentIndex !== -1 && currentIndex <= index ? index : index + 1;
		return this.insert(targetIndex, newKey, value);
	}
	first() {
		return this.entryAt(0);
	}
	last() {
		return this.entryAt(-1);
	}
	clear() {
		this.#keys = [];
		return super.clear();
	}
	delete(key) {
		const deleted = super.delete(key);
		if (deleted) this.#keys.splice(this.#keys.indexOf(key), 1);
		return deleted;
	}
	deleteAt(index) {
		const key = this.keyAt(index);
		if (key !== void 0) return this.delete(key);
		return false;
	}
	at(index) {
		const key = at(this.#keys, index);
		if (key !== void 0) return this.get(key);
	}
	entryAt(index) {
		const key = at(this.#keys, index);
		if (key !== void 0) return [key, this.get(key)];
	}
	indexOf(key) {
		return this.#keys.indexOf(key);
	}
	keyAt(index) {
		return at(this.#keys, index);
	}
	from(key, offset) {
		const index = this.indexOf(key);
		if (index === -1) return;
		let dest = index + offset;
		if (dest < 0) dest = 0;
		if (dest >= this.size) dest = this.size - 1;
		return this.at(dest);
	}
	keyFrom(key, offset) {
		const index = this.indexOf(key);
		if (index === -1) return;
		let dest = index + offset;
		if (dest < 0) dest = 0;
		if (dest >= this.size) dest = this.size - 1;
		return this.keyAt(dest);
	}
	find(predicate, thisArg) {
		let index = 0;
		for (const entry of this) {
			if (Reflect.apply(predicate, thisArg, [
				entry,
				index,
				this
			])) return entry;
			index++;
		}
	}
	findIndex(predicate, thisArg) {
		let index = 0;
		for (const entry of this) {
			if (Reflect.apply(predicate, thisArg, [
				entry,
				index,
				this
			])) return index;
			index++;
		}
		return -1;
	}
	filter(predicate, thisArg) {
		const entries = [];
		let index = 0;
		for (const entry of this) {
			if (Reflect.apply(predicate, thisArg, [
				entry,
				index,
				this
			])) entries.push(entry);
			index++;
		}
		return new _OrderedDict(entries);
	}
	map(callbackfn, thisArg) {
		const entries = [];
		let index = 0;
		for (const entry of this) {
			entries.push([entry[0], Reflect.apply(callbackfn, thisArg, [
				entry,
				index,
				this
			])]);
			index++;
		}
		return new _OrderedDict(entries);
	}
	reduce(...args) {
		const [callbackfn, initialValue] = args;
		const hasInitialValue = args.length > 1;
		if (!hasInitialValue && this.size === 0) throw new TypeError("Reduce of empty OrderedDict with no initial value");
		let index = 0;
		let accumulator = initialValue;
		for (const entry of this) {
			if (index === 0 && !hasInitialValue) accumulator = entry;
			else accumulator = Reflect.apply(callbackfn, this, [
				accumulator,
				entry,
				index,
				this
			]);
			index++;
		}
		return accumulator;
	}
	reduceRight(...args) {
		const [callbackfn, initialValue] = args;
		const hasInitialValue = args.length > 1;
		if (!hasInitialValue && this.size === 0) throw new TypeError("Reduce of empty OrderedDict with no initial value");
		let accumulator = initialValue;
		for (let index = this.size - 1; index >= 0; index--) {
			const entry = this.entryAt(index);
			if (index === this.size - 1 && !hasInitialValue) accumulator = entry;
			else accumulator = Reflect.apply(callbackfn, this, [
				accumulator,
				entry,
				index,
				this
			]);
		}
		return accumulator;
	}
	/**
	* Sorts the dictionary in place. This method mutates the dictionary and
	* returns a reference to the same object
	*
	* @param compareFn Function used to determine the order of the elements. It
	* is expected to return a negative value if the first argument is less than
	* the second argument, zero if they're equal, and a positive value otherwise.
	*/
	sort(compareFn) {
		if (typeof compareFn !== "function") throw new TypeError(`OrderedDict.sort requires a compare function`);
		const entries = [...this.entries()].sort(compareFn);
		this.clear();
		for (const [key, value] of entries) this.set(key, value);
		return this;
	}
	/**
	* Returns a copy of the dictionary with its elements sorted.
	*
	* @param compareFn Function used to determine the order of the elements. It
	* is expected to return a negative value if the first argument is less than
	* the second argument, zero if they're equal, and a positive value otherwise.
	*/
	toSorted(compareFn) {
		if (typeof compareFn !== "function") throw new TypeError(`OrderedDict.toSorted requires a compare function`);
		const entries = [...this.entries()].sort(compareFn);
		return new _OrderedDict(entries);
	}
	toReversed() {
		const reversed = new _OrderedDict();
		for (let index = this.size - 1; index >= 0; index--) {
			const key = this.keyAt(index);
			const element = this.get(key);
			reversed.set(key, element);
		}
		return reversed;
	}
	toSpliced(...args) {
		const entries = [...this.entries()];
		entries.splice(...args);
		return new _OrderedDict(entries);
	}
	slice(start, end) {
		const result = new _OrderedDict();
		for (const key of this.#keys.slice(start, end)) result.set(key, this.get(key));
		return result;
	}
	every(predicate, thisArg) {
		let index = 0;
		for (const entry of this) {
			if (!Reflect.apply(predicate, thisArg, [
				entry,
				index,
				this
			])) return false;
			index++;
		}
		return true;
	}
	some(predicate, thisArg) {
		let index = 0;
		for (const entry of this) {
			if (Reflect.apply(predicate, thisArg, [
				entry,
				index,
				this
			])) return true;
			index++;
		}
		return false;
	}
};
function at(array, index) {
	if ("at" in Array.prototype) return Array.prototype.at.call(array, index);
	const actualIndex = toSafeIndex(array, index);
	return actualIndex === -1 ? void 0 : array[actualIndex];
}
__name$1(at, "at");
function toSafeIndex(array, index) {
	const length = array.length;
	const relativeIndex = toSafeInteger(index);
	const actualIndex = relativeIndex >= 0 ? relativeIndex : length + relativeIndex;
	return actualIndex < 0 || actualIndex >= length ? -1 : actualIndex;
}
__name$1(toSafeIndex, "toSafeIndex");
function toSafeInteger(number) {
	return number !== number || number === 0 ? 0 : Math.trunc(number);
}
__name$1(toSafeInteger, "toSafeInteger");
// @__NO_SIDE_EFFECTS__
function createCollection2(name) {
	const PROVIDER_NAME = name + "CollectionProvider";
	const [createCollectionContext, createCollectionScope] = createContextScope(PROVIDER_NAME);
	const [CollectionStableContextProvider, useStableCollectionContext] = createCollectionContext(PROVIDER_NAME);
	CollectionStableContextProvider.displayName = name + "CollectionStableContextProvider";
	const [CollectionStatefulContextProvider, useStatefulCollectionContext] = createCollectionContext(PROVIDER_NAME);
	CollectionStatefulContextProvider.displayName = name + "CollectionStatefulContextProvider";
	const CollectionProvider = /* @__PURE__ */ __name$1(({ state, ...props }) => {
		return state ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionProviderImpl, {
			...props,
			state
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionInit, { ...props });
	}, "CollectionProvider");
	CollectionProvider.displayName = PROVIDER_NAME;
	const CollectionInit = /* @__PURE__ */ __name$1((props) => {
		const state = useInitCollection();
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionProviderImpl, {
			...props,
			state
		});
	}, "CollectionInit");
	CollectionInit.displayName = name + "CollectionInit";
	const CollectionProviderImpl = /* @__PURE__ */ __name$1((props) => {
		const { scope, children, state } = props;
		const ref = import_react.useRef(null);
		const [collectionElement, setCollectionElement] = import_react.useState(null);
		const composeRefs = useComposedRefs(ref, setCollectionElement);
		const [collection, setCollection] = state;
		const registryRef = import_react.useRef(new OrderedDict());
		const getCollection = import_react.useCallback(() => {
			const registry = registryRef.current;
			if (!isInDocumentOrder(registry)) registry.sort(sortByDocumentPosition);
			return registry;
		}, []);
		import_react.useEffect(() => {
			if (!collectionElement) return;
			const observer = getChildListObserver(() => {
				setCollection((map) => {
					const sorted = map.toSorted(sortByDocumentPosition);
					return sorted.some(([key], index) => map.keyAt(index) !== key) ? sorted : map;
				});
			});
			observer.observe(collectionElement, {
				childList: true,
				subtree: true
			});
			return () => {
				observer.disconnect();
			};
		}, [collectionElement, setCollection]);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionStableContextProvider, {
			scope,
			collectionElementRef: composeRefs,
			collectionElementRefObject: ref,
			getCollection,
			setCollection,
			registryRef,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionStatefulContextProvider, {
				scope,
				collectionElement,
				collection,
				children
			})
		});
	}, "CollectionProviderImpl");
	CollectionProviderImpl.displayName = name + "CollectionProviderImpl";
	const COLLECTION_SLOT_NAME = name + "CollectionSlot";
	const CollectionSlotImpl = createSlot(COLLECTION_SLOT_NAME);
	const CollectionSlot = import_react.forwardRef((props, forwardedRef) => {
		const { scope, children } = props;
		const context = useStableCollectionContext(COLLECTION_SLOT_NAME, scope);
		const composedRefs = useComposedRefs(forwardedRef, context.collectionElementRef);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionSlotImpl, {
			ref: composedRefs,
			children
		});
	});
	CollectionSlot.displayName = COLLECTION_SLOT_NAME;
	const ITEM_SLOT_NAME = name + "CollectionItemSlot";
	const ITEM_DATA_ATTR = "data-radix-collection-item";
	const CollectionItemSlotImpl = createSlot(ITEM_SLOT_NAME);
	const CollectionItemSlot = import_react.forwardRef((props, forwardedRef) => {
		const { scope, children, ...itemData } = props;
		const ref = import_react.useRef(null);
		const { setCollection, registryRef } = useStableCollectionContext(ITEM_SLOT_NAME, scope);
		const itemDataRef = import_react.useRef(itemData);
		if (!shallowEqual(itemDataRef.current, itemData)) itemDataRef.current = itemData;
		const memoizedItemData = itemDataRef.current;
		const registerElement = import_react.useCallback((node) => {
			const registry = registryRef.current;
			if (node) registry.set(node, {
				...itemDataRef.current,
				element: node
			});
			else if (ref.current) registry.delete(ref.current);
		}, [registryRef]);
		const composedRefs = useComposedRefs(forwardedRef, registerElement, ref);
		useLayoutEffect2(() => {
			const node = ref.current;
			const registry = registryRef.current;
			if (node && registry.has(node)) registry.set(node, {
				...memoizedItemData,
				element: node
			});
		}, [memoizedItemData, registryRef]);
		const registeredRef = import_react.useRef(null);
		import_react.useEffect(() => {
			const element = ref.current;
			const registered = registeredRef.current;
			if ((registered?.element ?? null) === element && (!element || registered?.itemData === memoizedItemData)) return;
			registeredRef.current = element ? {
				element,
				itemData: memoizedItemData
			} : null;
			setCollection((map) => {
				const next = new OrderedDict(map);
				if (registered && registered.element !== element) next.delete(registered.element);
				if (element) next.set(element, {
					...memoizedItemData,
					element
				});
				return next.sort(sortByDocumentPosition);
			});
		});
		import_react.useEffect(() => {
			return () => {
				const registered = registeredRef.current;
				registeredRef.current = null;
				if (!registered) return;
				setCollection((map) => {
					if (!map.has(registered.element)) return map;
					const next = new OrderedDict(map);
					next.delete(registered.element);
					return next;
				});
			};
		}, [setCollection]);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionItemSlotImpl, {
			[ITEM_DATA_ATTR]: "",
			ref: composedRefs,
			children
		});
	});
	CollectionItemSlot.displayName = ITEM_SLOT_NAME;
	function useInitCollection() {
		return import_react.useState(new OrderedDict());
	}
	__name$1(useInitCollection, "useInitCollection");
	function useCollection(scope) {
		const { collection } = useStatefulCollectionContext(name + "CollectionConsumer", scope);
		return collection;
	}
	__name$1(useCollection, "useCollection");
	function useGetCollection(scope) {
		const { getCollection } = useStableCollectionContext(name + "CollectionConsumer", scope);
		return getCollection;
	}
	__name$1(useGetCollection, "useGetCollection");
	return [{
		Provider: CollectionProvider,
		Slot: CollectionSlot,
		ItemSlot: CollectionItemSlot
	}, {
		createCollectionScope,
		useCollection,
		useGetCollection,
		useInitCollection
	}];
}
__name$1(createCollection2, "createCollection");
function shallowEqual(a, b) {
	if (a === b) return true;
	if (typeof a !== "object" || typeof b !== "object") return false;
	if (a == null || b == null) return false;
	const keysA = Object.keys(a);
	const keysB = Object.keys(b);
	if (keysA.length !== keysB.length) return false;
	for (const key of keysA) {
		if (!Object.prototype.hasOwnProperty.call(b, key)) return false;
		if (a[key] !== b[key]) return false;
	}
	return true;
}
__name$1(shallowEqual, "shallowEqual");
function isElementPreceding(a, b) {
	return !!(b.compareDocumentPosition(a) & Node.DOCUMENT_POSITION_PRECEDING);
}
__name$1(isElementPreceding, "isElementPreceding");
function isInDocumentOrder(dict) {
	let previous;
	for (const element of dict.keys()) {
		if (previous) {
			const position = previous.compareDocumentPosition(element);
			if (!(position & Node.DOCUMENT_POSITION_DISCONNECTED) && position & Node.DOCUMENT_POSITION_PRECEDING) return false;
		}
		previous = element;
	}
	return true;
}
__name$1(isInDocumentOrder, "isInDocumentOrder");
function sortByDocumentPosition(a, b) {
	return !a[1].element || !b[1].element ? 0 : isElementPreceding(a[1].element, b[1].element) ? -1 : 1;
}
__name$1(sortByDocumentPosition, "sortByDocumentPosition");
function getChildListObserver(callback) {
	return new MutationObserver((mutationsList) => {
		for (const mutation of mutationsList) if (mutation.type === "childList") {
			callback();
			return;
		}
	});
}
__name$1(getChildListObserver, "getChildListObserver");
//#endregion
//#region node_modules/@radix-ui/react-slider/dist/index.mjs
var dist_exports = /* @__PURE__ */ __exportAll({
	Range: () => SliderRange,
	Root: () => Slider,
	Slider: () => Slider,
	SliderRange: () => SliderRange,
	SliderThumb: () => SliderThumb,
	SliderTrack: () => SliderTrack,
	Thumb: () => SliderThumb,
	Track: () => SliderTrack,
	createSliderScope: () => createSliderScope,
	unstable_BubbleInput: () => SliderBubbleInput,
	unstable_SliderBubbleInput: () => SliderBubbleInput,
	unstable_SliderThumbProvider: () => SliderThumbProvider,
	unstable_SliderThumbTrigger: () => SliderThumbTrigger,
	unstable_ThumbProvider: () => SliderThumbProvider,
	unstable_ThumbTrigger: () => SliderThumbTrigger
});
var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", {
	value,
	configurable: true
});
var Orientation = {
	Vertical: "vertical",
	Horizontal: "horizontal"
};
var Direction = {
	LTR: "ltr",
	RTL: "rtl"
};
var PAGE_KEYS = ["PageUp", "PageDown"];
var ARROW_KEYS = [
	"ArrowUp",
	"ArrowDown",
	"ArrowLeft",
	"ArrowRight"
];
var BACK_KEYS = {
	"from-left": [
		"Home",
		"PageDown",
		"ArrowDown",
		"ArrowLeft"
	],
	"from-right": [
		"Home",
		"PageDown",
		"ArrowDown",
		"ArrowRight"
	],
	"from-bottom": [
		"Home",
		"PageDown",
		"ArrowDown",
		"ArrowLeft"
	],
	"from-top": [
		"Home",
		"PageDown",
		"ArrowUp",
		"ArrowLeft"
	]
};
var SLIDER_NAME = "Slider";
var [Collection, useCollection, createCollectionScope] = /* @__PURE__ */ createCollection(SLIDER_NAME);
var [createSliderContext, createSliderScope] = createContextScope(SLIDER_NAME, [createCollectionScope]);
var [SliderProvider, useSliderContext] = createSliderContext(SLIDER_NAME);
var Slider = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function Slider2(props, forwardedRef) {
	const { name, min = 0, max = 100, step = 1, orientation = Orientation.Horizontal, disabled = false, minStepsBetweenThumbs = 0, preserveThumbOrder = false, defaultValue = [min], value, onValueChange = /* @__PURE__ */ __name(() => {}, "onValueChange"), onValueCommit = /* @__PURE__ */ __name(() => {}, "onValueCommit"), inverted = false, form, ...sliderProps } = props;
	const thumbRefs = import_react.useRef(/* @__PURE__ */ new Set());
	const valueIndexToChangeRef = import_react.useRef(0);
	const isKeyboardInteractionRef = import_react.useRef(false);
	const [userRequestedValues, setUserRequestedValues] = import_react.useState(null);
	const SliderOrientation = orientation === Orientation.Horizontal ? SliderHorizontal : SliderVertical;
	const [control, setControl] = import_react.useState(null);
	const composedRefs = useComposedRefs(forwardedRef, setControl);
	const [values = [], setValues] = useControllableState({
		prop: value,
		defaultProp: defaultValue,
		onChange: /* @__PURE__ */ __name((value2) => {
			[...thumbRefs.current][valueIndexToChangeRef.current]?.focus({
				preventScroll: true,
				focusVisible: isKeyboardInteractionRef.current
			});
			isKeyboardInteractionRef.current = false;
			onValueChange(value2);
		}, "onChange")
	});
	const valuesBeforeSlideStartRef = import_react.useRef(values);
	const initialValuesRef = import_react.useRef(values);
	import_react.useEffect(() => {
		const associatedForm = form ? control?.ownerDocument.getElementById(form) : control?.closest("form");
		if (associatedForm instanceof HTMLFormElement) {
			const reset = /* @__PURE__ */ __name(() => setValues(initialValuesRef.current), "reset");
			associatedForm.addEventListener("reset", reset);
			return () => associatedForm.removeEventListener("reset", reset);
		}
	}, [
		control,
		form,
		setValues
	]);
	function handleSlideStart(value2) {
		updateValues(value2, getClosestValueIndex(values, value2));
	}
	__name(handleSlideStart, "handleSlideStart");
	function handleSlideMove(value2) {
		updateValues(value2, valueIndexToChangeRef.current);
	}
	__name(handleSlideMove, "handleSlideMove");
	function handleSlideEnd() {
		if (String(values) !== String(valuesBeforeSlideStartRef.current)) onValueCommit(values);
	}
	__name(handleSlideEnd, "handleSlideEnd");
	function updateValues(value2, atIndex, { commit } = { commit: false }) {
		const decimalCount = getDecimalCount(step);
		const nextValue = clamp(roundValue(Math.round((value2 - min) / step) * step + min, decimalCount), [min, max]);
		const minStepsDistance = minStepsBetweenThumbs * step;
		function getNextValues(prevValues) {
			const constrainedValue = preserveThumbOrder ? clamp(nextValue, [prevValues[atIndex - 1] === void 0 ? min : prevValues[atIndex - 1] + minStepsDistance, prevValues[atIndex + 1] === void 0 ? max : prevValues[atIndex + 1] - minStepsDistance]) : nextValue;
			const nextValues = getNextSortedValues(prevValues, constrainedValue, atIndex);
			if (!hasMinStepsBetweenValues(nextValues, minStepsDistance)) return null;
			return {
				nextValues,
				changedIndex: preserveThumbOrder ? atIndex : nextValues.indexOf(constrainedValue),
				hasChanged: String(nextValues) !== String(prevValues)
			};
		}
		__name(getNextValues, "getNextValues");
		const requested = getNextValues(values);
		if (requested?.hasChanged) setUserRequestedValues(requested.nextValues);
		setValues((prevValues = []) => {
			const next = getNextValues(prevValues);
			if (!next) return prevValues;
			valueIndexToChangeRef.current = next.changedIndex;
			if (next.hasChanged && commit) onValueCommit(next.nextValues);
			return next.hasChanged ? next.nextValues : prevValues;
		});
	}
	__name(updateValues, "updateValues");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderProvider, {
		scope: props.__scopeSlider,
		name,
		disabled,
		min,
		max,
		valueIndexToChangeRef,
		thumbs: thumbRefs.current,
		values,
		orientation,
		form,
		userRequestedValues,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Collection.Provider, {
			scope: props.__scopeSlider,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Collection.Slot, {
				scope: props.__scopeSlider,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderOrientation, {
					"aria-disabled": disabled,
					"data-disabled": disabled ? "" : void 0,
					...sliderProps,
					ref: composedRefs,
					onPointerDown: composeEventHandlers(sliderProps.onPointerDown, () => {
						if (!disabled) {
							valuesBeforeSlideStartRef.current = values;
							isKeyboardInteractionRef.current = false;
						}
					}),
					min,
					max,
					inverted,
					onSlideStart: disabled ? void 0 : handleSlideStart,
					onSlideMove: disabled ? void 0 : handleSlideMove,
					onSlideEnd: disabled ? void 0 : handleSlideEnd,
					onHomeKeyDown: () => {
						if (!disabled) {
							isKeyboardInteractionRef.current = true;
							updateValues(min, 0, { commit: true });
						}
					},
					onEndKeyDown: () => {
						if (!disabled) {
							isKeyboardInteractionRef.current = true;
							updateValues(max, values.length - 1, { commit: true });
						}
					},
					onStepKeyDown: ({ event, direction: stepDirection }) => {
						if (!disabled) {
							isKeyboardInteractionRef.current = true;
							const multiplier = PAGE_KEYS.includes(event.key) || event.shiftKey && ARROW_KEYS.includes(event.key) ? 10 : 1;
							const atIndex = valueIndexToChangeRef.current;
							const value2 = values[atIndex];
							updateValues(getNextStepValue(value2, {
								min,
								step,
								direction: stepDirection,
								multiplier
							}), atIndex, { commit: true });
						}
					}
				})
			})
		})
	});
}, "Slider"));
var [SliderOrientationProvider, useSliderOrientationContext] = createSliderContext(SLIDER_NAME, {
	startEdge: "left",
	endEdge: "right",
	size: "width",
	direction: 1
});
var SliderHorizontal = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function SliderHorizontal2(props, forwardedRef) {
	const { min, max, dir, inverted, onSlideStart, onSlideMove, onSlideEnd, onStepKeyDown, ...sliderProps } = props;
	const [slider, setSlider] = import_react.useState(null);
	const composedRefs = useComposedRefs(forwardedRef, setSlider);
	const rectRef = import_react.useRef(void 0);
	const direction = useDirection(dir);
	const isDirectionLTR = direction === Direction.LTR;
	const isSlidingFromLeft = isDirectionLTR && !inverted || !isDirectionLTR && inverted;
	function getValueFromPointer(pointerPosition) {
		const rect = rectRef.current || slider.getBoundingClientRect();
		const value = linearScale([0, rect.width], isSlidingFromLeft ? [min, max] : [max, min]);
		rectRef.current = rect;
		return value(pointerPosition - rect.left);
	}
	__name(getValueFromPointer, "getValueFromPointer");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderOrientationProvider, {
		scope: props.__scopeSlider,
		startEdge: isSlidingFromLeft ? "left" : "right",
		endEdge: isSlidingFromLeft ? "right" : "left",
		direction: isSlidingFromLeft ? 1 : -1,
		size: "width",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderImpl, {
			dir: direction,
			"data-orientation": "horizontal",
			...sliderProps,
			ref: composedRefs,
			style: {
				...sliderProps.style,
				"--radix-slider-thumb-transform": "translateX(-50%)"
			},
			onSlideStart: (event) => {
				const value = getValueFromPointer(event.clientX);
				onSlideStart?.(value);
			},
			onSlideMove: (event) => {
				const value = getValueFromPointer(event.clientX);
				onSlideMove?.(value);
			},
			onSlideEnd: () => {
				rectRef.current = void 0;
				onSlideEnd?.();
			},
			onStepKeyDown: (event) => {
				const isBackKey = BACK_KEYS[isSlidingFromLeft ? "from-left" : "from-right"].includes(event.key);
				onStepKeyDown?.({
					event,
					direction: isBackKey ? -1 : 1
				});
			}
		})
	});
}, "SliderHorizontal"));
var SliderVertical = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function SliderVertical2(props, forwardedRef) {
	const { min, max, inverted, onSlideStart, onSlideMove, onSlideEnd, onStepKeyDown, ...sliderProps } = props;
	const sliderRef = import_react.useRef(null);
	const ref = useComposedRefs(forwardedRef, sliderRef);
	const rectRef = import_react.useRef(void 0);
	const isSlidingFromBottom = !inverted;
	function getValueFromPointer(pointerPosition) {
		const rect = rectRef.current || sliderRef.current.getBoundingClientRect();
		const value = linearScale([0, rect.height], isSlidingFromBottom ? [max, min] : [min, max]);
		rectRef.current = rect;
		return value(pointerPosition - rect.top);
	}
	__name(getValueFromPointer, "getValueFromPointer");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderOrientationProvider, {
		scope: props.__scopeSlider,
		startEdge: isSlidingFromBottom ? "bottom" : "top",
		endEdge: isSlidingFromBottom ? "top" : "bottom",
		size: "height",
		direction: isSlidingFromBottom ? 1 : -1,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderImpl, {
			"data-orientation": "vertical",
			...sliderProps,
			ref,
			style: {
				...sliderProps.style,
				"--radix-slider-thumb-transform": "translateY(50%)"
			},
			onSlideStart: (event) => {
				const value = getValueFromPointer(event.clientY);
				onSlideStart?.(value);
			},
			onSlideMove: (event) => {
				const value = getValueFromPointer(event.clientY);
				onSlideMove?.(value);
			},
			onSlideEnd: () => {
				rectRef.current = void 0;
				onSlideEnd?.();
			},
			onStepKeyDown: (event) => {
				const isBackKey = BACK_KEYS[isSlidingFromBottom ? "from-bottom" : "from-top"].includes(event.key);
				onStepKeyDown?.({
					event,
					direction: isBackKey ? -1 : 1
				});
			}
		})
	});
}, "SliderVertical"));
var SliderImpl = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function SliderImpl2(props, forwardedRef) {
	const { __scopeSlider, onSlideStart, onSlideMove, onSlideEnd, onHomeKeyDown, onEndKeyDown, onStepKeyDown, ...sliderProps } = props;
	const context = useSliderContext(SLIDER_NAME, __scopeSlider);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.span, {
		...sliderProps,
		ref: forwardedRef,
		onKeyDown: composeEventHandlers(props.onKeyDown, (event) => {
			if (event.key === "Home") {
				onHomeKeyDown(event);
				event.preventDefault();
			} else if (event.key === "End") {
				onEndKeyDown(event);
				event.preventDefault();
			} else if (PAGE_KEYS.concat(ARROW_KEYS).includes(event.key)) {
				onStepKeyDown(event);
				event.preventDefault();
			}
		}),
		onPointerDown: composeEventHandlers(props.onPointerDown, (event) => {
			const target = event.target;
			target.setPointerCapture(event.pointerId);
			event.preventDefault();
			if (context.thumbs.has(target)) target.focus({
				preventScroll: true,
				focusVisible: false
			});
			else onSlideStart(event);
		}),
		onPointerMove: composeEventHandlers(props.onPointerMove, (event) => {
			if (event.target.hasPointerCapture(event.pointerId)) onSlideMove(event);
		}),
		onPointerUp: composeEventHandlers(props.onPointerUp, (event) => {
			const target = event.target;
			if (target.hasPointerCapture(event.pointerId)) {
				target.releasePointerCapture(event.pointerId);
				onSlideEnd(event);
			}
		})
	});
}, "SliderImpl"));
var TRACK_NAME = "SliderTrack";
var SliderTrack = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function SliderTrack2(props, forwardedRef) {
	const { __scopeSlider, ...trackProps } = props;
	const context = useSliderContext(TRACK_NAME, __scopeSlider);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.span, {
		"data-disabled": context.disabled ? "" : void 0,
		"data-orientation": context.orientation,
		...trackProps,
		ref: forwardedRef
	});
}, "SliderTrack"));
var RANGE_NAME = "SliderRange";
var SliderRange = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function SliderRange2(props, forwardedRef) {
	const { __scopeSlider, ...rangeProps } = props;
	const context = useSliderContext(RANGE_NAME, __scopeSlider);
	const orientation = useSliderOrientationContext(RANGE_NAME, __scopeSlider);
	const ref = import_react.useRef(null);
	const composedRefs = useComposedRefs(forwardedRef, ref);
	const valuesCount = context.values.length;
	const percentages = context.values.map((value) => convertValueToPercentage(value, context.min, context.max));
	const offsetStart = valuesCount > 1 ? Math.min(...percentages) : 0;
	const offsetEnd = 100 - Math.max(...percentages);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.span, {
		"data-orientation": context.orientation,
		"data-disabled": context.disabled ? "" : void 0,
		...rangeProps,
		ref: composedRefs,
		style: {
			...props.style,
			[orientation.startEdge]: offsetStart + "%",
			[orientation.endEdge]: offsetEnd + "%"
		}
	});
}, "SliderRange"));
var [SliderThumbContextProvider, useSliderThumbContext] = createSliderContext("SliderThumb");
var THUMB_PROVIDER_NAME = "SliderThumbProvider";
function SliderThumbProvider(props) {
	const { __scopeSlider, name, children, internal_do_not_use_render } = props;
	const context = useSliderContext(THUMB_PROVIDER_NAME, __scopeSlider);
	const getItems = useCollection(__scopeSlider);
	const [thumb, setThumb] = import_react.useState(null);
	const index = import_react.useMemo(() => thumb ? getItems().findIndex((item) => item.ref.current === thumb) : -1, [getItems, thumb]);
	const size = useSize(thumb);
	const isFormControl = thumb ? !!context.form || !!thumb.closest("form") : true;
	const value = context.values[index];
	const resolvedName = name ?? (context.name ? context.name + (context.values.length > 1 ? "[]" : "") : void 0);
	const percent = value === void 0 ? 0 : convertValueToPercentage(value, context.min, context.max);
	import_react.useEffect(() => {
		if (thumb) {
			context.thumbs.add(thumb);
			return () => {
				context.thumbs.delete(thumb);
			};
		}
	}, [thumb, context.thumbs]);
	const thumbContext = {
		value,
		name: resolvedName,
		form: context.form,
		isFormControl,
		index,
		thumb,
		onThumbChange: setThumb,
		percent,
		size
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumbContextProvider, {
		scope: __scopeSlider,
		...thumbContext,
		children: isFunction(internal_do_not_use_render) ? internal_do_not_use_render(thumbContext) : children
	});
}
__name(SliderThumbProvider, "SliderThumbProvider");
var THUMB_TRIGGER_NAME = "SliderThumbTrigger";
var SliderThumbTrigger = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function SliderThumbTrigger2(props, forwardedRef) {
	const { __scopeSlider, ...thumbProps } = props;
	const context = useSliderContext(THUMB_TRIGGER_NAME, __scopeSlider);
	const orientation = useSliderOrientationContext(THUMB_TRIGGER_NAME, __scopeSlider);
	const { index, value, percent, size, onThumbChange } = useSliderThumbContext(THUMB_TRIGGER_NAME, __scopeSlider);
	const composedRefs = useComposedRefs(forwardedRef, onThumbChange);
	const label = getLabel(index, context.values.length);
	const orientationSize = size?.[orientation.size];
	const thumbInBoundsOffset = orientationSize ? getThumbInBoundsOffset(orientationSize, percent, orientation.direction) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		style: {
			transform: "var(--radix-slider-thumb-transform)",
			position: "absolute",
			[orientation.startEdge]: `calc(${percent}% + ${thumbInBoundsOffset}px)`
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Collection.ItemSlot, {
			scope: __scopeSlider,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.span, {
				role: "slider",
				"aria-label": props["aria-label"] || label,
				"aria-valuemin": context.min,
				"aria-valuenow": value,
				"aria-valuemax": context.max,
				"aria-orientation": context.orientation,
				"data-orientation": context.orientation,
				"data-disabled": context.disabled ? "" : void 0,
				tabIndex: context.disabled ? void 0 : 0,
				...thumbProps,
				ref: composedRefs,
				style: value === void 0 ? { display: "none" } : props.style,
				onFocus: composeEventHandlers(props.onFocus, () => {
					context.valueIndexToChangeRef.current = index;
				})
			})
		})
	});
}, "SliderThumbTrigger"));
var SliderThumb = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function SliderThumb2(props, forwardedRef) {
	const { __scopeSlider, name, ...thumbProps } = props;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumbProvider, {
		__scopeSlider,
		name,
		internal_do_not_use_render: ({ index, isFormControl }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumbTrigger, {
			...thumbProps,
			ref: forwardedRef,
			__scopeSlider
		}), isFormControl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderBubbleInput, { __scopeSlider }, index) : null] })
	});
}, "SliderThumb"));
var BUBBLE_INPUT_NAME = "SliderBubbleInput";
var SliderBubbleInput = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function SliderBubbleInput2({ __scopeSlider, onInput, ...props }, forwardedRef) {
	const { index, value, name, form } = useSliderThumbContext(BUBBLE_INPUT_NAME, __scopeSlider);
	const { userRequestedValues } = useSliderContext(BUBBLE_INPUT_NAME, __scopeSlider);
	const ref = import_react.useRef(null);
	const composedRefs = useComposedRefs(ref, forwardedRef);
	const shouldStopInputPropagationRef = import_react.useRef(false);
	const prevValueRef = import_react.useRef(value);
	const handledUserRequestedValuesRef = import_react.useRef(userRequestedValues);
	const prevUserRequestedValuesRef = import_react.useRef(userRequestedValues);
	import_react.useEffect(() => {
		const input = ref.current;
		if (!input) return;
		const inputProto = window.HTMLInputElement.prototype;
		const setValue = Object.getOwnPropertyDescriptor(inputProto, "value").set;
		const prevValue = prevValueRef.current;
		const valueChanged = prevValue !== value;
		prevValueRef.current = value;
		const isUserRequestFromThisRender = userRequestedValues !== prevUserRequestedValuesRef.current;
		prevUserRequestedValuesRef.current = userRequestedValues;
		if (valueChanged && setValue) {
			const hasUnhandledUserRequest = userRequestedValues !== handledUserRequestedValuesRef.current;
			handledUserRequestedValuesRef.current = userRequestedValues;
			const requestedValue = userRequestedValues?.[index];
			shouldStopInputPropagationRef.current = !(hasUnhandledUserRequest && (isUserRequestFromThisRender && requestedValue !== prevValue || requestedValue === value));
			const event = new Event("input", { bubbles: true });
			setValue.call(input, value);
			input.dispatchEvent(event);
			shouldStopInputPropagationRef.current = false;
		}
	}, [
		index,
		value,
		userRequestedValues
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.input, {
		style: { display: "none" },
		name,
		form,
		...props,
		ref: composedRefs,
		defaultValue: value,
		onInput: composeEventHandlers(onInput, (event) => {
			if (shouldStopInputPropagationRef.current) event.stopPropagation();
		})
	});
}, "SliderBubbleInput"));
function getNextSortedValues(prevValues = [], nextValue, atIndex) {
	const nextValues = [...prevValues];
	nextValues[atIndex] = nextValue;
	return nextValues.sort((a, b) => a - b);
}
__name(getNextSortedValues, "getNextSortedValues");
function convertValueToPercentage(value, min, max) {
	return clamp(100 / (max - min) * (value - min), [0, 100]);
}
__name(convertValueToPercentage, "convertValueToPercentage");
function getLabel(index, totalValues) {
	if (totalValues > 2) return `Value ${index + 1} of ${totalValues}`;
	else if (totalValues === 2) return ["Minimum", "Maximum"][index];
	else return;
}
__name(getLabel, "getLabel");
function getClosestValueIndex(values, nextValue) {
	if (values.length === 1) return 0;
	const distances = values.map((value) => Math.abs(value - nextValue));
	const closestDistance = Math.min(...distances);
	return distances.indexOf(closestDistance);
}
__name(getClosestValueIndex, "getClosestValueIndex");
function getThumbInBoundsOffset(width, left, direction) {
	const halfWidth = width / 2;
	return (halfWidth - linearScale([0, 50], [0, halfWidth])(left) * direction) * direction;
}
__name(getThumbInBoundsOffset, "getThumbInBoundsOffset");
function getStepsBetweenValues(values) {
	return values.slice(0, -1).map((value, index) => values[index + 1] - value);
}
__name(getStepsBetweenValues, "getStepsBetweenValues");
function hasMinStepsBetweenValues(values, minStepsBetweenValues) {
	if (minStepsBetweenValues > 0) {
		const stepsBetweenValues = getStepsBetweenValues(values);
		return Math.min(...stepsBetweenValues) >= minStepsBetweenValues;
	}
	return true;
}
__name(hasMinStepsBetweenValues, "hasMinStepsBetweenValues");
function linearScale(input, output) {
	return (value) => {
		if (input[0] === input[1] || output[0] === output[1]) return output[0];
		const ratio = (output[1] - output[0]) / (input[1] - input[0]);
		return output[0] + ratio * (value - input[0]);
	};
}
__name(linearScale, "linearScale");
function getDecimalCount(value) {
	if (!Number.isFinite(value)) return 0;
	const str = value.toString();
	if (str.includes("e")) {
		const [coefficient, exponent] = str.split("e");
		const decimalPart2 = coefficient.split(".")[1] || "";
		const exponentNum = Number(exponent);
		return Math.max(0, decimalPart2.length - exponentNum);
	}
	const decimalPart = str.split(".")[1];
	return decimalPart ? decimalPart.length : 0;
}
__name(getDecimalCount, "getDecimalCount");
function roundValue(value, decimalCount) {
	const rounder = Math.pow(10, decimalCount);
	return Math.round(value * rounder) / rounder;
}
__name(roundValue, "roundValue");
function getNextStepValue(value, { min, step, direction, multiplier }) {
	const decimalCount = getDecimalCount(step);
	const stepsFromMin = (value - min) / step;
	const nearestSteps = Math.round(stepsFromMin);
	const isAligned = roundValue(nearestSteps * step + min, decimalCount) === roundValue(value, decimalCount);
	let nextSteps;
	if (isAligned) nextSteps = nearestSteps + multiplier * direction;
	else if (direction > 0) nextSteps = Math.ceil(stepsFromMin);
	else nextSteps = Math.floor(stepsFromMin);
	return roundValue(nextSteps * step + min, decimalCount);
}
__name(getNextStepValue, "getNextStepValue");
function isFunction(value) {
	return typeof value === "function";
}
__name(isFunction, "isFunction");
//#endregion
export { SliderThumbProvider as a, createSliderScope as c, createCollection2 as d, useSize as f, clamp as h, SliderThumb as i, dist_exports as l, useDirection as m, SliderBubbleInput as n, SliderThumbTrigger as o, dist_exports$1 as p, SliderRange as r, SliderTrack as s, Slider as t, createCollection as u };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGlzdC1ENnE4eEpGbi5qcyIsIm5hbWVzIjpbIl9fZGVmUHJvcCIsIl9fbmFtZSIsIl9fZGVmUHJvcCIsIl9fbmFtZSIsIkRpcmVjdGlvbiIsIl9fZGVmUHJvcCIsIl9fbmFtZSIsIl9fZGVmUHJvcCIsIl9fbmFtZSIsImNyZWF0ZUNvbnRleHRTY29wZTIiLCJ1c2VDb21wb3NlZFJlZnMyIiwiY3JlYXRlU2xvdDIiLCJGcmFnbWVudCJdLCJzb3VyY2VzIjpbIi4uLy4uL0ByYWRpeC11aS9udW1iZXIvZGlzdC9pbmRleC5tanMiLCIuLi8uLi9AcmFkaXgtdWkvcmVhY3QtZGlyZWN0aW9uL2Rpc3QvaW5kZXgubWpzIiwiLi4vLi4vQHJhZGl4LXVpL3JlYWN0LXVzZS1zaXplL2Rpc3QvaW5kZXgubWpzIiwiLi4vLi4vQHJhZGl4LXVpL3JlYWN0LWNvbGxlY3Rpb24vZGlzdC9pbmRleC5tanMiLCIuLi8uLi9AcmFkaXgtdWkvcmVhY3Qtc2xpZGVyL2Rpc3QvaW5kZXgubWpzIl0sInNvdXJjZXNDb250ZW50IjpbInZhciBfX2RlZlByb3AgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG52YXIgX19uYW1lID0gKHRhcmdldCwgdmFsdWUpID0+IF9fZGVmUHJvcCh0YXJnZXQsIFwibmFtZVwiLCB7IHZhbHVlLCBjb25maWd1cmFibGU6IHRydWUgfSk7XG5cbi8vIHNyYy9udW1iZXIudHNcbmZ1bmN0aW9uIGNsYW1wKHZhbHVlLCBbbWluLCBtYXhdKSB7XG4gIHJldHVybiBNYXRoLm1pbihtYXgsIE1hdGgubWF4KG1pbiwgdmFsdWUpKTtcbn1cbl9fbmFtZShjbGFtcCwgXCJjbGFtcFwiKTtcbmV4cG9ydCB7XG4gIGNsYW1wXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXgubWpzLm1hcFxuIiwiXCJ1c2UgY2xpZW50XCI7XG52YXIgX19kZWZQcm9wID0gT2JqZWN0LmRlZmluZVByb3BlcnR5O1xudmFyIF9fbmFtZSA9ICh0YXJnZXQsIHZhbHVlKSA9PiBfX2RlZlByb3AodGFyZ2V0LCBcIm5hbWVcIiwgeyB2YWx1ZSwgY29uZmlndXJhYmxlOiB0cnVlIH0pO1xuXG4vLyBzcmMvZGlyZWN0aW9uLnRzeFxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbnZhciBEaXJlY3Rpb24gPSB7XG4gIExUUjogXCJsdHJcIixcbiAgUlRMOiBcInJ0bFwiXG59O1xudmFyIERpcmVjdGlvbkNvbnRleHQgPSBSZWFjdC5jcmVhdGVDb250ZXh0KHZvaWQgMCk7XG52YXIgRGlyZWN0aW9uUHJvdmlkZXIgPSAvKiBAX19QVVJFX18gKi8gX19uYW1lKChwcm9wcykgPT4ge1xuICBjb25zdCB7IGRpciwgY2hpbGRyZW4gfSA9IHByb3BzO1xuICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChEaXJlY3Rpb25Db250ZXh0LlByb3ZpZGVyLCB7IHZhbHVlOiBkaXIsIGNoaWxkcmVuIH0pO1xufSwgXCJEaXJlY3Rpb25Qcm92aWRlclwiKTtcbmZ1bmN0aW9uIHVzZURpcmVjdGlvbihsb2NhbERpcikge1xuICBjb25zdCBnbG9iYWxEaXIgPSBSZWFjdC51c2VDb250ZXh0KERpcmVjdGlvbkNvbnRleHQpO1xuICByZXR1cm4gbG9jYWxEaXIgfHwgZ2xvYmFsRGlyIHx8IERpcmVjdGlvbi5MVFI7XG59XG5fX25hbWUodXNlRGlyZWN0aW9uLCBcInVzZURpcmVjdGlvblwiKTtcbmV4cG9ydCB7XG4gIERpcmVjdGlvblByb3ZpZGVyLFxuICBEaXJlY3Rpb25Qcm92aWRlciBhcyBQcm92aWRlcixcbiAgdXNlRGlyZWN0aW9uXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXgubWpzLm1hcFxuIiwidmFyIF9fZGVmUHJvcCA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eTtcbnZhciBfX25hbWUgPSAodGFyZ2V0LCB2YWx1ZSkgPT4gX19kZWZQcm9wKHRhcmdldCwgXCJuYW1lXCIsIHsgdmFsdWUsIGNvbmZpZ3VyYWJsZTogdHJ1ZSB9KTtcblxuLy8gc3JjL3VzZS1zaXplLnRzeFxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VMYXlvdXRFZmZlY3QgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LXVzZS1sYXlvdXQtZWZmZWN0XCI7XG5mdW5jdGlvbiB1c2VTaXplKGVsZW1lbnQpIHtcbiAgY29uc3QgW3NpemUsIHNldFNpemVdID0gUmVhY3QudXNlU3RhdGUodm9pZCAwKTtcbiAgdXNlTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAoZWxlbWVudCkge1xuICAgICAgc2V0U2l6ZSh7IHdpZHRoOiBlbGVtZW50Lm9mZnNldFdpZHRoLCBoZWlnaHQ6IGVsZW1lbnQub2Zmc2V0SGVpZ2h0IH0pO1xuICAgICAgbGV0IHJBRiA9IDA7XG4gICAgICBjb25zdCByZXNpemVPYnNlcnZlciA9IG5ldyBSZXNpemVPYnNlcnZlcigoZW50cmllcykgPT4ge1xuICAgICAgICBpZiAoIUFycmF5LmlzQXJyYXkoZW50cmllcykpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFlbnRyaWVzLmxlbmd0aCkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBlbnRyeSA9IGVudHJpZXNbMF07XG4gICAgICAgIHdpbmRvdy5jYW5jZWxBbmltYXRpb25GcmFtZShyQUYpO1xuICAgICAgICByQUYgPSB3aW5kb3cucmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpID0+IHtcbiAgICAgICAgICBsZXQgd2lkdGg7XG4gICAgICAgICAgbGV0IGhlaWdodDtcbiAgICAgICAgICBpZiAoXCJib3JkZXJCb3hTaXplXCIgaW4gZW50cnkpIHtcbiAgICAgICAgICAgIGNvbnN0IGJvcmRlclNpemVFbnRyeSA9IGVudHJ5W1wiYm9yZGVyQm94U2l6ZVwiXTtcbiAgICAgICAgICAgIGNvbnN0IGJvcmRlclNpemUgPSBBcnJheS5pc0FycmF5KGJvcmRlclNpemVFbnRyeSkgPyBib3JkZXJTaXplRW50cnlbMF0gOiBib3JkZXJTaXplRW50cnk7XG4gICAgICAgICAgICB3aWR0aCA9IGJvcmRlclNpemVbXCJpbmxpbmVTaXplXCJdO1xuICAgICAgICAgICAgaGVpZ2h0ID0gYm9yZGVyU2l6ZVtcImJsb2NrU2l6ZVwiXTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgd2lkdGggPSBlbGVtZW50Lm9mZnNldFdpZHRoO1xuICAgICAgICAgICAgaGVpZ2h0ID0gZWxlbWVudC5vZmZzZXRIZWlnaHQ7XG4gICAgICAgICAgfVxuICAgICAgICAgIHNldFNpemUoeyB3aWR0aCwgaGVpZ2h0IH0pO1xuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgICAgcmVzaXplT2JzZXJ2ZXIub2JzZXJ2ZShlbGVtZW50LCB7IGJveDogXCJib3JkZXItYm94XCIgfSk7XG4gICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICB3aW5kb3cuY2FuY2VsQW5pbWF0aW9uRnJhbWUockFGKTtcbiAgICAgICAgcmVzaXplT2JzZXJ2ZXIudW5vYnNlcnZlKGVsZW1lbnQpO1xuICAgICAgfTtcbiAgICB9IGVsc2Uge1xuICAgICAgc2V0U2l6ZSh2b2lkIDApO1xuICAgIH1cbiAgfSwgW2VsZW1lbnRdKTtcbiAgcmV0dXJuIHNpemU7XG59XG5fX25hbWUodXNlU2l6ZSwgXCJ1c2VTaXplXCIpO1xuZXhwb3J0IHtcbiAgdXNlU2l6ZVxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4Lm1qcy5tYXBcbiIsIlwidXNlIGNsaWVudFwiO1xudmFyIF9fZGVmUHJvcCA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eTtcbnZhciBfX25hbWUgPSAodGFyZ2V0LCB2YWx1ZSkgPT4gX19kZWZQcm9wKHRhcmdldCwgXCJuYW1lXCIsIHsgdmFsdWUsIGNvbmZpZ3VyYWJsZTogdHJ1ZSB9KTtcblxuLy8gc3JjL2NvbGxlY3Rpb24tbGVnYWN5LnRzeFxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBjcmVhdGVDb250ZXh0U2NvcGUgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LWNvbnRleHRcIjtcbmltcG9ydCB7IHVzZUNvbXBvc2VkUmVmcyB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtY29tcG9zZS1yZWZzXCI7XG5pbXBvcnQgeyBjcmVhdGVTbG90IH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC1zbG90XCI7XG5pbXBvcnQgeyBqc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiBjcmVhdGVDb2xsZWN0aW9uKG5hbWUpIHtcbiAgY29uc3QgUFJPVklERVJfTkFNRSA9IG5hbWUgKyBcIkNvbGxlY3Rpb25Qcm92aWRlclwiO1xuICBjb25zdCBbY3JlYXRlQ29sbGVjdGlvbkNvbnRleHQsIGNyZWF0ZUNvbGxlY3Rpb25TY29wZV0gPSBjcmVhdGVDb250ZXh0U2NvcGUoUFJPVklERVJfTkFNRSk7XG4gIGNvbnN0IFtDb2xsZWN0aW9uUHJvdmlkZXJJbXBsLCB1c2VDb2xsZWN0aW9uQ29udGV4dF0gPSBjcmVhdGVDb2xsZWN0aW9uQ29udGV4dChcbiAgICBQUk9WSURFUl9OQU1FLFxuICAgIHsgY29sbGVjdGlvblJlZjogeyBjdXJyZW50OiBudWxsIH0sIGl0ZW1NYXA6IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCkgfVxuICApO1xuICBjb25zdCBDb2xsZWN0aW9uUHJvdmlkZXIgPSAvKiBAX19QVVJFX18gKi8gX19uYW1lKChwcm9wcykgPT4ge1xuICAgIGNvbnN0IHsgc2NvcGUsIGNoaWxkcmVuIH0gPSBwcm9wcztcbiAgICBjb25zdCByZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gICAgY29uc3QgaXRlbU1hcCA9IFJlYWN0LnVzZVJlZigvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpKS5jdXJyZW50O1xuICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KENvbGxlY3Rpb25Qcm92aWRlckltcGwsIHsgc2NvcGUsIGl0ZW1NYXAsIGNvbGxlY3Rpb25SZWY6IHJlZiwgY2hpbGRyZW4gfSk7XG4gIH0sIFwiQ29sbGVjdGlvblByb3ZpZGVyXCIpO1xuICBDb2xsZWN0aW9uUHJvdmlkZXIuZGlzcGxheU5hbWUgPSBQUk9WSURFUl9OQU1FO1xuICBjb25zdCBDT0xMRUNUSU9OX1NMT1RfTkFNRSA9IG5hbWUgKyBcIkNvbGxlY3Rpb25TbG90XCI7XG4gIGNvbnN0IENvbGxlY3Rpb25TbG90SW1wbCA9IGNyZWF0ZVNsb3QoQ09MTEVDVElPTl9TTE9UX05BTUUpO1xuICBjb25zdCBDb2xsZWN0aW9uU2xvdCA9IFJlYWN0LmZvcndhcmRSZWYoXG4gICAgKHByb3BzLCBmb3J3YXJkZWRSZWYpID0+IHtcbiAgICAgIGNvbnN0IHsgc2NvcGUsIGNoaWxkcmVuIH0gPSBwcm9wcztcbiAgICAgIGNvbnN0IGNvbnRleHQgPSB1c2VDb2xsZWN0aW9uQ29udGV4dChDT0xMRUNUSU9OX1NMT1RfTkFNRSwgc2NvcGUpO1xuICAgICAgY29uc3QgY29tcG9zZWRSZWZzID0gdXNlQ29tcG9zZWRSZWZzKGZvcndhcmRlZFJlZiwgY29udGV4dC5jb2xsZWN0aW9uUmVmKTtcbiAgICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KENvbGxlY3Rpb25TbG90SW1wbCwgeyByZWY6IGNvbXBvc2VkUmVmcywgY2hpbGRyZW4gfSk7XG4gICAgfVxuICApO1xuICBDb2xsZWN0aW9uU2xvdC5kaXNwbGF5TmFtZSA9IENPTExFQ1RJT05fU0xPVF9OQU1FO1xuICBjb25zdCBJVEVNX1NMT1RfTkFNRSA9IG5hbWUgKyBcIkNvbGxlY3Rpb25JdGVtU2xvdFwiO1xuICBjb25zdCBJVEVNX0RBVEFfQVRUUiA9IFwiZGF0YS1yYWRpeC1jb2xsZWN0aW9uLWl0ZW1cIjtcbiAgY29uc3QgQ29sbGVjdGlvbkl0ZW1TbG90SW1wbCA9IGNyZWF0ZVNsb3QoSVRFTV9TTE9UX05BTUUpO1xuICBjb25zdCBDb2xsZWN0aW9uSXRlbVNsb3QgPSBSZWFjdC5mb3J3YXJkUmVmKFxuICAgIChwcm9wcywgZm9yd2FyZGVkUmVmKSA9PiB7XG4gICAgICBjb25zdCB7IHNjb3BlLCBjaGlsZHJlbiwgLi4uaXRlbURhdGEgfSA9IHByb3BzO1xuICAgICAgY29uc3QgcmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICAgICAgY29uc3QgY29tcG9zZWRSZWZzID0gdXNlQ29tcG9zZWRSZWZzKGZvcndhcmRlZFJlZiwgcmVmKTtcbiAgICAgIGNvbnN0IGNvbnRleHQgPSB1c2VDb2xsZWN0aW9uQ29udGV4dChJVEVNX1NMT1RfTkFNRSwgc2NvcGUpO1xuICAgICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29udGV4dC5pdGVtTWFwLnNldChyZWYsIHsgcmVmLCAuLi5pdGVtRGF0YSB9KTtcbiAgICAgICAgcmV0dXJuICgpID0+IHZvaWQgY29udGV4dC5pdGVtTWFwLmRlbGV0ZShyZWYpO1xuICAgICAgfSk7XG4gICAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChDb2xsZWN0aW9uSXRlbVNsb3RJbXBsLCB7IC4uLnsgW0lURU1fREFUQV9BVFRSXTogXCJcIiB9LCByZWY6IGNvbXBvc2VkUmVmcywgY2hpbGRyZW4gfSk7XG4gICAgfVxuICApO1xuICBDb2xsZWN0aW9uSXRlbVNsb3QuZGlzcGxheU5hbWUgPSBJVEVNX1NMT1RfTkFNRTtcbiAgZnVuY3Rpb24gdXNlQ29sbGVjdGlvbihzY29wZSkge1xuICAgIGNvbnN0IGNvbnRleHQgPSB1c2VDb2xsZWN0aW9uQ29udGV4dChuYW1lICsgXCJDb2xsZWN0aW9uQ29uc3VtZXJcIiwgc2NvcGUpO1xuICAgIGNvbnN0IGdldEl0ZW1zID0gUmVhY3QudXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgICAgY29uc3QgY29sbGVjdGlvbk5vZGUgPSBjb250ZXh0LmNvbGxlY3Rpb25SZWYuY3VycmVudDtcbiAgICAgIGlmICghY29sbGVjdGlvbk5vZGUpIHJldHVybiBbXTtcbiAgICAgIGNvbnN0IG9yZGVyZWROb2RlcyA9IEFycmF5LmZyb20oY29sbGVjdGlvbk5vZGUucXVlcnlTZWxlY3RvckFsbChgWyR7SVRFTV9EQVRBX0FUVFJ9XWApKTtcbiAgICAgIGNvbnN0IGl0ZW1zID0gQXJyYXkuZnJvbShjb250ZXh0Lml0ZW1NYXAudmFsdWVzKCkpO1xuICAgICAgY29uc3Qgb3JkZXJlZEl0ZW1zID0gaXRlbXMuc29ydChcbiAgICAgICAgKGEsIGIpID0+IG9yZGVyZWROb2Rlcy5pbmRleE9mKGEucmVmLmN1cnJlbnQpIC0gb3JkZXJlZE5vZGVzLmluZGV4T2YoYi5yZWYuY3VycmVudClcbiAgICAgICk7XG4gICAgICByZXR1cm4gb3JkZXJlZEl0ZW1zO1xuICAgIH0sIFtjb250ZXh0LmNvbGxlY3Rpb25SZWYsIGNvbnRleHQuaXRlbU1hcF0pO1xuICAgIHJldHVybiBnZXRJdGVtcztcbiAgfVxuICBfX25hbWUodXNlQ29sbGVjdGlvbiwgXCJ1c2VDb2xsZWN0aW9uXCIpO1xuICByZXR1cm4gW1xuICAgIHsgUHJvdmlkZXI6IENvbGxlY3Rpb25Qcm92aWRlciwgU2xvdDogQ29sbGVjdGlvblNsb3QsIEl0ZW1TbG90OiBDb2xsZWN0aW9uSXRlbVNsb3QgfSxcbiAgICB1c2VDb2xsZWN0aW9uLFxuICAgIGNyZWF0ZUNvbGxlY3Rpb25TY29wZVxuICBdO1xufVxuX19uYW1lKGNyZWF0ZUNvbGxlY3Rpb24sIFwiY3JlYXRlQ29sbGVjdGlvblwiKTtcblxuLy8gc3JjL2NvbGxlY3Rpb24udHN4XG5pbXBvcnQgKiBhcyBSZWFjdDIgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBjcmVhdGVDb250ZXh0U2NvcGUgYXMgY3JlYXRlQ29udGV4dFNjb3BlMiB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtY29udGV4dFwiO1xuaW1wb3J0IHsgdXNlQ29tcG9zZWRSZWZzIGFzIHVzZUNvbXBvc2VkUmVmczIgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LWNvbXBvc2UtcmVmc1wiO1xuaW1wb3J0IHsgY3JlYXRlU2xvdCBhcyBjcmVhdGVTbG90MiB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3Qtc2xvdFwiO1xuaW1wb3J0IHsgdXNlTGF5b3V0RWZmZWN0IH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC11c2UtbGF5b3V0LWVmZmVjdFwiO1xuXG4vLyBzcmMvb3JkZXJlZC1kaWN0aW9uYXJ5LnRzXG52YXIgX19pbnN0YW5jaWF0ZWQgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcbnZhciBPcmRlcmVkRGljdCA9IGNsYXNzIF9PcmRlcmVkRGljdCBleHRlbmRzIE1hcCB7XG4gIHN0YXRpYyB7XG4gICAgX19uYW1lKHRoaXMsIFwiT3JkZXJlZERpY3RcIik7XG4gIH1cbiAgI2tleXM7XG4gIGNvbnN0cnVjdG9yKGVudHJpZXMpIHtcbiAgICBzdXBlcihlbnRyaWVzKTtcbiAgICB0aGlzLiNrZXlzID0gWy4uLnN1cGVyLmtleXMoKV07XG4gICAgX19pbnN0YW5jaWF0ZWQuc2V0KHRoaXMsIHRydWUpO1xuICB9XG4gIHNldChrZXksIHZhbHVlKSB7XG4gICAgaWYgKF9faW5zdGFuY2lhdGVkLmdldCh0aGlzKSAmJiAhdGhpcy5oYXMoa2V5KSkge1xuICAgICAgdGhpcy4ja2V5cy5wdXNoKGtleSk7XG4gICAgfVxuICAgIHN1cGVyLnNldChrZXksIHZhbHVlKTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICAvKipcbiAgICogU2V0cyBhIGtleS12YWx1ZSBwYWlyIHNvIHRoYXQgaXQgZW5kcyB1cCBhdCB0aGUgZ2l2ZW4gaW5kZXguXG4gICAqIC0gRXhpc3Rpbmcga2V5cyBhcmUgbW92ZWRcbiAgICogLSBOZWdhdGl2ZSBpbmRpY2VzIGNvdW50IGZyb20gdGhlIGVuZCBvZiB0aGUgcmVzdWx0aW5nIGRpY3Rpb25hcnksIHNvXG4gICAqICAgaW5zZXJ0aW5nIGF0IC0xIG1ha2VzIHRoZSBpdGVtIHRoZSBsYXN0IG9uZSwgLTIgdGhlIHNlY29uZCB0byBsYXN0LCBldGMuXG4gICAqIC0gT3V0LW9mLXJhbmdlIGluZGljZXMgYXJlIGNsYW1wZWRcbiAgICovXG4gIGluc2VydChpbmRleCwga2V5LCB2YWx1ZSkge1xuICAgIGNvbnN0IGhhcyA9IHRoaXMuaGFzKGtleSk7XG4gICAgY29uc3QgZmluYWxTaXplID0gaGFzID8gdGhpcy5zaXplIDogdGhpcy5zaXplICsgMTtcbiAgICBjb25zdCByZWxhdGl2ZUluZGV4ID0gdG9TYWZlSW50ZWdlcihpbmRleCk7XG4gICAgY29uc3QgdGFyZ2V0SW5kZXggPSByZWxhdGl2ZUluZGV4ID49IDAgPyBNYXRoLm1pbihyZWxhdGl2ZUluZGV4LCBmaW5hbFNpemUgLSAxKSA6IE1hdGgubWF4KGZpbmFsU2l6ZSArIHJlbGF0aXZlSW5kZXgsIDApO1xuICAgIGlmIChoYXMgPyB0aGlzLiNrZXlzLmluZGV4T2Yoa2V5KSA9PT0gdGFyZ2V0SW5kZXggOiB0YXJnZXRJbmRleCA9PT0gdGhpcy5zaXplKSB7XG4gICAgICB0aGlzLnNldChrZXksIHZhbHVlKTtcbiAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBjb25zdCBrZXlzID0gdGhpcy4ja2V5cy5maWx0ZXIoKGV4aXN0aW5nS2V5KSA9PiBleGlzdGluZ0tleSAhPT0ga2V5KTtcbiAgICBrZXlzLnNwbGljZSh0YXJnZXRJbmRleCwgMCwga2V5KTtcbiAgICBjb25zdCBlbnRyaWVzID0ga2V5cy5tYXAoKGVudHJ5S2V5KSA9PiBbXG4gICAgICBlbnRyeUtleSxcbiAgICAgIGVudHJ5S2V5ID09PSBrZXkgPyB2YWx1ZSA6IHRoaXMuZ2V0KGVudHJ5S2V5KVxuICAgIF0pO1xuICAgIHRoaXMuY2xlYXIoKTtcbiAgICBmb3IgKGNvbnN0IFtlbnRyeUtleSwgZW50cnlWYWx1ZV0gb2YgZW50cmllcykge1xuICAgICAgdGhpcy5zZXQoZW50cnlLZXksIGVudHJ5VmFsdWUpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICB3aXRoKGluZGV4LCBrZXksIHZhbHVlKSB7XG4gICAgY29uc3QgY29weSA9IG5ldyBfT3JkZXJlZERpY3QodGhpcyk7XG4gICAgY29weS5pbnNlcnQoaW5kZXgsIGtleSwgdmFsdWUpO1xuICAgIHJldHVybiBjb3B5O1xuICB9XG4gIGJlZm9yZShrZXkpIHtcbiAgICBjb25zdCBpbmRleCA9IHRoaXMuI2tleXMuaW5kZXhPZihrZXkpIC0gMTtcbiAgICBpZiAoaW5kZXggPCAwKSB7XG4gICAgICByZXR1cm4gdm9pZCAwO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5lbnRyeUF0KGluZGV4KTtcbiAgfVxuICAvKipcbiAgICogU2V0cyBhIG5ldyBrZXktdmFsdWUgcGFpciBhdCB0aGUgcG9zaXRpb24gYmVmb3JlIHRoZSBnaXZlbiBrZXkuXG4gICAqL1xuICBzZXRCZWZvcmUoa2V5LCBuZXdLZXksIHZhbHVlKSB7XG4gICAgY29uc3QgaW5kZXggPSB0aGlzLiNrZXlzLmluZGV4T2Yoa2V5KTtcbiAgICBpZiAoaW5kZXggPT09IC0xKSB7XG4gICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgY29uc3QgY3VycmVudEluZGV4ID0gdGhpcy4ja2V5cy5pbmRleE9mKG5ld0tleSk7XG4gICAgY29uc3QgdGFyZ2V0SW5kZXggPSBjdXJyZW50SW5kZXggIT09IC0xICYmIGN1cnJlbnRJbmRleCA8IGluZGV4ID8gaW5kZXggLSAxIDogaW5kZXg7XG4gICAgcmV0dXJuIHRoaXMuaW5zZXJ0KHRhcmdldEluZGV4LCBuZXdLZXksIHZhbHVlKTtcbiAgfVxuICBhZnRlcihrZXkpIHtcbiAgICBsZXQgaW5kZXggPSB0aGlzLiNrZXlzLmluZGV4T2Yoa2V5KTtcbiAgICBpbmRleCA9IGluZGV4ID09PSAtMSB8fCBpbmRleCA9PT0gdGhpcy5zaXplIC0gMSA/IC0xIDogaW5kZXggKyAxO1xuICAgIGlmIChpbmRleCA9PT0gLTEpIHtcbiAgICAgIHJldHVybiB2b2lkIDA7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLmVudHJ5QXQoaW5kZXgpO1xuICB9XG4gIC8qKlxuICAgKiBTZXRzIGEgbmV3IGtleS12YWx1ZSBwYWlyIGF0IHRoZSBwb3NpdGlvbiBhZnRlciB0aGUgZ2l2ZW4ga2V5LlxuICAgKi9cbiAgc2V0QWZ0ZXIoa2V5LCBuZXdLZXksIHZhbHVlKSB7XG4gICAgY29uc3QgaW5kZXggPSB0aGlzLiNrZXlzLmluZGV4T2Yoa2V5KTtcbiAgICBpZiAoaW5kZXggPT09IC0xKSB7XG4gICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgY29uc3QgY3VycmVudEluZGV4ID0gdGhpcy4ja2V5cy5pbmRleE9mKG5ld0tleSk7XG4gICAgY29uc3QgdGFyZ2V0SW5kZXggPSBjdXJyZW50SW5kZXggIT09IC0xICYmIGN1cnJlbnRJbmRleCA8PSBpbmRleCA/IGluZGV4IDogaW5kZXggKyAxO1xuICAgIHJldHVybiB0aGlzLmluc2VydCh0YXJnZXRJbmRleCwgbmV3S2V5LCB2YWx1ZSk7XG4gIH1cbiAgZmlyc3QoKSB7XG4gICAgcmV0dXJuIHRoaXMuZW50cnlBdCgwKTtcbiAgfVxuICBsYXN0KCkge1xuICAgIHJldHVybiB0aGlzLmVudHJ5QXQoLTEpO1xuICB9XG4gIGNsZWFyKCkge1xuICAgIHRoaXMuI2tleXMgPSBbXTtcbiAgICByZXR1cm4gc3VwZXIuY2xlYXIoKTtcbiAgfVxuICBkZWxldGUoa2V5KSB7XG4gICAgY29uc3QgZGVsZXRlZCA9IHN1cGVyLmRlbGV0ZShrZXkpO1xuICAgIGlmIChkZWxldGVkKSB7XG4gICAgICB0aGlzLiNrZXlzLnNwbGljZSh0aGlzLiNrZXlzLmluZGV4T2Yoa2V5KSwgMSk7XG4gICAgfVxuICAgIHJldHVybiBkZWxldGVkO1xuICB9XG4gIGRlbGV0ZUF0KGluZGV4KSB7XG4gICAgY29uc3Qga2V5ID0gdGhpcy5rZXlBdChpbmRleCk7XG4gICAgaWYgKGtleSAhPT0gdm9pZCAwKSB7XG4gICAgICByZXR1cm4gdGhpcy5kZWxldGUoa2V5KTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGF0KGluZGV4KSB7XG4gICAgY29uc3Qga2V5ID0gYXQodGhpcy4ja2V5cywgaW5kZXgpO1xuICAgIGlmIChrZXkgIT09IHZvaWQgMCkge1xuICAgICAgcmV0dXJuIHRoaXMuZ2V0KGtleSk7XG4gICAgfVxuICB9XG4gIGVudHJ5QXQoaW5kZXgpIHtcbiAgICBjb25zdCBrZXkgPSBhdCh0aGlzLiNrZXlzLCBpbmRleCk7XG4gICAgaWYgKGtleSAhPT0gdm9pZCAwKSB7XG4gICAgICByZXR1cm4gW2tleSwgdGhpcy5nZXQoa2V5KV07XG4gICAgfVxuICB9XG4gIGluZGV4T2Yoa2V5KSB7XG4gICAgcmV0dXJuIHRoaXMuI2tleXMuaW5kZXhPZihrZXkpO1xuICB9XG4gIGtleUF0KGluZGV4KSB7XG4gICAgcmV0dXJuIGF0KHRoaXMuI2tleXMsIGluZGV4KTtcbiAgfVxuICBmcm9tKGtleSwgb2Zmc2V0KSB7XG4gICAgY29uc3QgaW5kZXggPSB0aGlzLmluZGV4T2Yoa2V5KTtcbiAgICBpZiAoaW5kZXggPT09IC0xKSB7XG4gICAgICByZXR1cm4gdm9pZCAwO1xuICAgIH1cbiAgICBsZXQgZGVzdCA9IGluZGV4ICsgb2Zmc2V0O1xuICAgIGlmIChkZXN0IDwgMCkgZGVzdCA9IDA7XG4gICAgaWYgKGRlc3QgPj0gdGhpcy5zaXplKSBkZXN0ID0gdGhpcy5zaXplIC0gMTtcbiAgICByZXR1cm4gdGhpcy5hdChkZXN0KTtcbiAgfVxuICBrZXlGcm9tKGtleSwgb2Zmc2V0KSB7XG4gICAgY29uc3QgaW5kZXggPSB0aGlzLmluZGV4T2Yoa2V5KTtcbiAgICBpZiAoaW5kZXggPT09IC0xKSB7XG4gICAgICByZXR1cm4gdm9pZCAwO1xuICAgIH1cbiAgICBsZXQgZGVzdCA9IGluZGV4ICsgb2Zmc2V0O1xuICAgIGlmIChkZXN0IDwgMCkgZGVzdCA9IDA7XG4gICAgaWYgKGRlc3QgPj0gdGhpcy5zaXplKSBkZXN0ID0gdGhpcy5zaXplIC0gMTtcbiAgICByZXR1cm4gdGhpcy5rZXlBdChkZXN0KTtcbiAgfVxuICBmaW5kKHByZWRpY2F0ZSwgdGhpc0FyZykge1xuICAgIGxldCBpbmRleCA9IDA7XG4gICAgZm9yIChjb25zdCBlbnRyeSBvZiB0aGlzKSB7XG4gICAgICBpZiAoUmVmbGVjdC5hcHBseShwcmVkaWNhdGUsIHRoaXNBcmcsIFtlbnRyeSwgaW5kZXgsIHRoaXNdKSkge1xuICAgICAgICByZXR1cm4gZW50cnk7XG4gICAgICB9XG4gICAgICBpbmRleCsrO1xuICAgIH1cbiAgICByZXR1cm4gdm9pZCAwO1xuICB9XG4gIGZpbmRJbmRleChwcmVkaWNhdGUsIHRoaXNBcmcpIHtcbiAgICBsZXQgaW5kZXggPSAwO1xuICAgIGZvciAoY29uc3QgZW50cnkgb2YgdGhpcykge1xuICAgICAgaWYgKFJlZmxlY3QuYXBwbHkocHJlZGljYXRlLCB0aGlzQXJnLCBbZW50cnksIGluZGV4LCB0aGlzXSkpIHtcbiAgICAgICAgcmV0dXJuIGluZGV4O1xuICAgICAgfVxuICAgICAgaW5kZXgrKztcbiAgICB9XG4gICAgcmV0dXJuIC0xO1xuICB9XG4gIGZpbHRlcihwcmVkaWNhdGUsIHRoaXNBcmcpIHtcbiAgICBjb25zdCBlbnRyaWVzID0gW107XG4gICAgbGV0IGluZGV4ID0gMDtcbiAgICBmb3IgKGNvbnN0IGVudHJ5IG9mIHRoaXMpIHtcbiAgICAgIGlmIChSZWZsZWN0LmFwcGx5KHByZWRpY2F0ZSwgdGhpc0FyZywgW2VudHJ5LCBpbmRleCwgdGhpc10pKSB7XG4gICAgICAgIGVudHJpZXMucHVzaChlbnRyeSk7XG4gICAgICB9XG4gICAgICBpbmRleCsrO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IF9PcmRlcmVkRGljdChlbnRyaWVzKTtcbiAgfVxuICBtYXAoY2FsbGJhY2tmbiwgdGhpc0FyZykge1xuICAgIGNvbnN0IGVudHJpZXMgPSBbXTtcbiAgICBsZXQgaW5kZXggPSAwO1xuICAgIGZvciAoY29uc3QgZW50cnkgb2YgdGhpcykge1xuICAgICAgZW50cmllcy5wdXNoKFtlbnRyeVswXSwgUmVmbGVjdC5hcHBseShjYWxsYmFja2ZuLCB0aGlzQXJnLCBbZW50cnksIGluZGV4LCB0aGlzXSldKTtcbiAgICAgIGluZGV4Kys7XG4gICAgfVxuICAgIHJldHVybiBuZXcgX09yZGVyZWREaWN0KGVudHJpZXMpO1xuICB9XG4gIHJlZHVjZSguLi5hcmdzKSB7XG4gICAgY29uc3QgW2NhbGxiYWNrZm4sIGluaXRpYWxWYWx1ZV0gPSBhcmdzO1xuICAgIGNvbnN0IGhhc0luaXRpYWxWYWx1ZSA9IGFyZ3MubGVuZ3RoID4gMTtcbiAgICBpZiAoIWhhc0luaXRpYWxWYWx1ZSAmJiB0aGlzLnNpemUgPT09IDApIHtcbiAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJSZWR1Y2Ugb2YgZW1wdHkgT3JkZXJlZERpY3Qgd2l0aCBubyBpbml0aWFsIHZhbHVlXCIpO1xuICAgIH1cbiAgICBsZXQgaW5kZXggPSAwO1xuICAgIGxldCBhY2N1bXVsYXRvciA9IGluaXRpYWxWYWx1ZTtcbiAgICBmb3IgKGNvbnN0IGVudHJ5IG9mIHRoaXMpIHtcbiAgICAgIGlmIChpbmRleCA9PT0gMCAmJiAhaGFzSW5pdGlhbFZhbHVlKSB7XG4gICAgICAgIGFjY3VtdWxhdG9yID0gZW50cnk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhY2N1bXVsYXRvciA9IFJlZmxlY3QuYXBwbHkoY2FsbGJhY2tmbiwgdGhpcywgW2FjY3VtdWxhdG9yLCBlbnRyeSwgaW5kZXgsIHRoaXNdKTtcbiAgICAgIH1cbiAgICAgIGluZGV4Kys7XG4gICAgfVxuICAgIHJldHVybiBhY2N1bXVsYXRvcjtcbiAgfVxuICByZWR1Y2VSaWdodCguLi5hcmdzKSB7XG4gICAgY29uc3QgW2NhbGxiYWNrZm4sIGluaXRpYWxWYWx1ZV0gPSBhcmdzO1xuICAgIGNvbnN0IGhhc0luaXRpYWxWYWx1ZSA9IGFyZ3MubGVuZ3RoID4gMTtcbiAgICBpZiAoIWhhc0luaXRpYWxWYWx1ZSAmJiB0aGlzLnNpemUgPT09IDApIHtcbiAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJSZWR1Y2Ugb2YgZW1wdHkgT3JkZXJlZERpY3Qgd2l0aCBubyBpbml0aWFsIHZhbHVlXCIpO1xuICAgIH1cbiAgICBsZXQgYWNjdW11bGF0b3IgPSBpbml0aWFsVmFsdWU7XG4gICAgZm9yIChsZXQgaW5kZXggPSB0aGlzLnNpemUgLSAxOyBpbmRleCA+PSAwOyBpbmRleC0tKSB7XG4gICAgICBjb25zdCBlbnRyeSA9IHRoaXMuZW50cnlBdChpbmRleCk7XG4gICAgICBpZiAoaW5kZXggPT09IHRoaXMuc2l6ZSAtIDEgJiYgIWhhc0luaXRpYWxWYWx1ZSkge1xuICAgICAgICBhY2N1bXVsYXRvciA9IGVudHJ5O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYWNjdW11bGF0b3IgPSBSZWZsZWN0LmFwcGx5KGNhbGxiYWNrZm4sIHRoaXMsIFthY2N1bXVsYXRvciwgZW50cnksIGluZGV4LCB0aGlzXSk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBhY2N1bXVsYXRvcjtcbiAgfVxuICAvKipcbiAgICogU29ydHMgdGhlIGRpY3Rpb25hcnkgaW4gcGxhY2UuIFRoaXMgbWV0aG9kIG11dGF0ZXMgdGhlIGRpY3Rpb25hcnkgYW5kXG4gICAqIHJldHVybnMgYSByZWZlcmVuY2UgdG8gdGhlIHNhbWUgb2JqZWN0XG4gICAqXG4gICAqIEBwYXJhbSBjb21wYXJlRm4gRnVuY3Rpb24gdXNlZCB0byBkZXRlcm1pbmUgdGhlIG9yZGVyIG9mIHRoZSBlbGVtZW50cy4gSXRcbiAgICogaXMgZXhwZWN0ZWQgdG8gcmV0dXJuIGEgbmVnYXRpdmUgdmFsdWUgaWYgdGhlIGZpcnN0IGFyZ3VtZW50IGlzIGxlc3MgdGhhblxuICAgKiB0aGUgc2Vjb25kIGFyZ3VtZW50LCB6ZXJvIGlmIHRoZXkncmUgZXF1YWwsIGFuZCBhIHBvc2l0aXZlIHZhbHVlIG90aGVyd2lzZS5cbiAgICovXG4gIHNvcnQoY29tcGFyZUZuKSB7XG4gICAgaWYgKHR5cGVvZiBjb21wYXJlRm4gIT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgT3JkZXJlZERpY3Quc29ydCByZXF1aXJlcyBhIGNvbXBhcmUgZnVuY3Rpb25gKTtcbiAgICB9XG4gICAgY29uc3QgZW50cmllcyA9IFsuLi50aGlzLmVudHJpZXMoKV0uc29ydChjb21wYXJlRm4pO1xuICAgIHRoaXMuY2xlYXIoKTtcbiAgICBmb3IgKGNvbnN0IFtrZXksIHZhbHVlXSBvZiBlbnRyaWVzKSB7XG4gICAgICB0aGlzLnNldChrZXksIHZhbHVlKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIFJldHVybnMgYSBjb3B5IG9mIHRoZSBkaWN0aW9uYXJ5IHdpdGggaXRzIGVsZW1lbnRzIHNvcnRlZC5cbiAgICpcbiAgICogQHBhcmFtIGNvbXBhcmVGbiBGdW5jdGlvbiB1c2VkIHRvIGRldGVybWluZSB0aGUgb3JkZXIgb2YgdGhlIGVsZW1lbnRzLiBJdFxuICAgKiBpcyBleHBlY3RlZCB0byByZXR1cm4gYSBuZWdhdGl2ZSB2YWx1ZSBpZiB0aGUgZmlyc3QgYXJndW1lbnQgaXMgbGVzcyB0aGFuXG4gICAqIHRoZSBzZWNvbmQgYXJndW1lbnQsIHplcm8gaWYgdGhleSdyZSBlcXVhbCwgYW5kIGEgcG9zaXRpdmUgdmFsdWUgb3RoZXJ3aXNlLlxuICAgKi9cbiAgdG9Tb3J0ZWQoY29tcGFyZUZuKSB7XG4gICAgaWYgKHR5cGVvZiBjb21wYXJlRm4gIT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgT3JkZXJlZERpY3QudG9Tb3J0ZWQgcmVxdWlyZXMgYSBjb21wYXJlIGZ1bmN0aW9uYCk7XG4gICAgfVxuICAgIGNvbnN0IGVudHJpZXMgPSBbLi4udGhpcy5lbnRyaWVzKCldLnNvcnQoY29tcGFyZUZuKTtcbiAgICByZXR1cm4gbmV3IF9PcmRlcmVkRGljdChlbnRyaWVzKTtcbiAgfVxuICB0b1JldmVyc2VkKCkge1xuICAgIGNvbnN0IHJldmVyc2VkID0gbmV3IF9PcmRlcmVkRGljdCgpO1xuICAgIGZvciAobGV0IGluZGV4ID0gdGhpcy5zaXplIC0gMTsgaW5kZXggPj0gMDsgaW5kZXgtLSkge1xuICAgICAgY29uc3Qga2V5ID0gdGhpcy5rZXlBdChpbmRleCk7XG4gICAgICBjb25zdCBlbGVtZW50ID0gdGhpcy5nZXQoa2V5KTtcbiAgICAgIHJldmVyc2VkLnNldChrZXksIGVsZW1lbnQpO1xuICAgIH1cbiAgICByZXR1cm4gcmV2ZXJzZWQ7XG4gIH1cbiAgdG9TcGxpY2VkKC4uLmFyZ3MpIHtcbiAgICBjb25zdCBlbnRyaWVzID0gWy4uLnRoaXMuZW50cmllcygpXTtcbiAgICBlbnRyaWVzLnNwbGljZSguLi5hcmdzKTtcbiAgICByZXR1cm4gbmV3IF9PcmRlcmVkRGljdChlbnRyaWVzKTtcbiAgfVxuICBzbGljZShzdGFydCwgZW5kKSB7XG4gICAgY29uc3QgcmVzdWx0ID0gbmV3IF9PcmRlcmVkRGljdCgpO1xuICAgIGZvciAoY29uc3Qga2V5IG9mIHRoaXMuI2tleXMuc2xpY2Uoc3RhcnQsIGVuZCkpIHtcbiAgICAgIHJlc3VsdC5zZXQoa2V5LCB0aGlzLmdldChrZXkpKTtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfVxuICBldmVyeShwcmVkaWNhdGUsIHRoaXNBcmcpIHtcbiAgICBsZXQgaW5kZXggPSAwO1xuICAgIGZvciAoY29uc3QgZW50cnkgb2YgdGhpcykge1xuICAgICAgaWYgKCFSZWZsZWN0LmFwcGx5KHByZWRpY2F0ZSwgdGhpc0FyZywgW2VudHJ5LCBpbmRleCwgdGhpc10pKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIGluZGV4Kys7XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIHNvbWUocHJlZGljYXRlLCB0aGlzQXJnKSB7XG4gICAgbGV0IGluZGV4ID0gMDtcbiAgICBmb3IgKGNvbnN0IGVudHJ5IG9mIHRoaXMpIHtcbiAgICAgIGlmIChSZWZsZWN0LmFwcGx5KHByZWRpY2F0ZSwgdGhpc0FyZywgW2VudHJ5LCBpbmRleCwgdGhpc10pKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgICAgaW5kZXgrKztcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59O1xuZnVuY3Rpb24gYXQoYXJyYXksIGluZGV4KSB7XG4gIGlmIChcImF0XCIgaW4gQXJyYXkucHJvdG90eXBlKSB7XG4gICAgcmV0dXJuIEFycmF5LnByb3RvdHlwZS5hdC5jYWxsKGFycmF5LCBpbmRleCk7XG4gIH1cbiAgY29uc3QgYWN0dWFsSW5kZXggPSB0b1NhZmVJbmRleChhcnJheSwgaW5kZXgpO1xuICByZXR1cm4gYWN0dWFsSW5kZXggPT09IC0xID8gdm9pZCAwIDogYXJyYXlbYWN0dWFsSW5kZXhdO1xufVxuX19uYW1lKGF0LCBcImF0XCIpO1xuZnVuY3Rpb24gdG9TYWZlSW5kZXgoYXJyYXksIGluZGV4KSB7XG4gIGNvbnN0IGxlbmd0aCA9IGFycmF5Lmxlbmd0aDtcbiAgY29uc3QgcmVsYXRpdmVJbmRleCA9IHRvU2FmZUludGVnZXIoaW5kZXgpO1xuICBjb25zdCBhY3R1YWxJbmRleCA9IHJlbGF0aXZlSW5kZXggPj0gMCA/IHJlbGF0aXZlSW5kZXggOiBsZW5ndGggKyByZWxhdGl2ZUluZGV4O1xuICByZXR1cm4gYWN0dWFsSW5kZXggPCAwIHx8IGFjdHVhbEluZGV4ID49IGxlbmd0aCA/IC0xIDogYWN0dWFsSW5kZXg7XG59XG5fX25hbWUodG9TYWZlSW5kZXgsIFwidG9TYWZlSW5kZXhcIik7XG5mdW5jdGlvbiB0b1NhZmVJbnRlZ2VyKG51bWJlcikge1xuICByZXR1cm4gbnVtYmVyICE9PSBudW1iZXIgfHwgbnVtYmVyID09PSAwID8gMCA6IE1hdGgudHJ1bmMobnVtYmVyKTtcbn1cbl9fbmFtZSh0b1NhZmVJbnRlZ2VyLCBcInRvU2FmZUludGVnZXJcIik7XG5cbi8vIHNyYy9jb2xsZWN0aW9uLnRzeFxuaW1wb3J0IHsganN4IGFzIGpzeDIgfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiBjcmVhdGVDb2xsZWN0aW9uMihuYW1lKSB7XG4gIGNvbnN0IFBST1ZJREVSX05BTUUgPSBuYW1lICsgXCJDb2xsZWN0aW9uUHJvdmlkZXJcIjtcbiAgY29uc3QgW2NyZWF0ZUNvbGxlY3Rpb25Db250ZXh0LCBjcmVhdGVDb2xsZWN0aW9uU2NvcGVdID0gY3JlYXRlQ29udGV4dFNjb3BlMihQUk9WSURFUl9OQU1FKTtcbiAgY29uc3QgW0NvbGxlY3Rpb25TdGFibGVDb250ZXh0UHJvdmlkZXIsIHVzZVN0YWJsZUNvbGxlY3Rpb25Db250ZXh0XSA9IGNyZWF0ZUNvbGxlY3Rpb25Db250ZXh0KFBST1ZJREVSX05BTUUpO1xuICBDb2xsZWN0aW9uU3RhYmxlQ29udGV4dFByb3ZpZGVyLmRpc3BsYXlOYW1lID0gbmFtZSArIFwiQ29sbGVjdGlvblN0YWJsZUNvbnRleHRQcm92aWRlclwiO1xuICBjb25zdCBbQ29sbGVjdGlvblN0YXRlZnVsQ29udGV4dFByb3ZpZGVyLCB1c2VTdGF0ZWZ1bENvbGxlY3Rpb25Db250ZXh0XSA9IGNyZWF0ZUNvbGxlY3Rpb25Db250ZXh0KFBST1ZJREVSX05BTUUpO1xuICBDb2xsZWN0aW9uU3RhdGVmdWxDb250ZXh0UHJvdmlkZXIuZGlzcGxheU5hbWUgPSBuYW1lICsgXCJDb2xsZWN0aW9uU3RhdGVmdWxDb250ZXh0UHJvdmlkZXJcIjtcbiAgY29uc3QgQ29sbGVjdGlvblByb3ZpZGVyID0gLyogQF9fUFVSRV9fICovIF9fbmFtZSgoeyBzdGF0ZSwgLi4ucHJvcHMgfSkgPT4ge1xuICAgIHJldHVybiBzdGF0ZSA/IC8qIEBfX1BVUkVfXyAqLyBqc3gyKENvbGxlY3Rpb25Qcm92aWRlckltcGwsIHsgLi4ucHJvcHMsIHN0YXRlIH0pIDogLyogQF9fUFVSRV9fICovIGpzeDIoQ29sbGVjdGlvbkluaXQsIHsgLi4ucHJvcHMgfSk7XG4gIH0sIFwiQ29sbGVjdGlvblByb3ZpZGVyXCIpO1xuICBDb2xsZWN0aW9uUHJvdmlkZXIuZGlzcGxheU5hbWUgPSBQUk9WSURFUl9OQU1FO1xuICBjb25zdCBDb2xsZWN0aW9uSW5pdCA9IC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoKHByb3BzKSA9PiB7XG4gICAgY29uc3Qgc3RhdGUgPSB1c2VJbml0Q29sbGVjdGlvbigpO1xuICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4MihDb2xsZWN0aW9uUHJvdmlkZXJJbXBsLCB7IC4uLnByb3BzLCBzdGF0ZSB9KTtcbiAgfSwgXCJDb2xsZWN0aW9uSW5pdFwiKTtcbiAgQ29sbGVjdGlvbkluaXQuZGlzcGxheU5hbWUgPSBuYW1lICsgXCJDb2xsZWN0aW9uSW5pdFwiO1xuICBjb25zdCBDb2xsZWN0aW9uUHJvdmlkZXJJbXBsID0gLyogQF9fUFVSRV9fICovIF9fbmFtZSgocHJvcHMpID0+IHtcbiAgICBjb25zdCB7IHNjb3BlLCBjaGlsZHJlbiwgc3RhdGUgfSA9IHByb3BzO1xuICAgIGNvbnN0IHJlZiA9IFJlYWN0Mi51c2VSZWYobnVsbCk7XG4gICAgY29uc3QgW2NvbGxlY3Rpb25FbGVtZW50LCBzZXRDb2xsZWN0aW9uRWxlbWVudF0gPSBSZWFjdDIudXNlU3RhdGUoXG4gICAgICBudWxsXG4gICAgKTtcbiAgICBjb25zdCBjb21wb3NlUmVmcyA9IHVzZUNvbXBvc2VkUmVmczIocmVmLCBzZXRDb2xsZWN0aW9uRWxlbWVudCk7XG4gICAgY29uc3QgW2NvbGxlY3Rpb24sIHNldENvbGxlY3Rpb25dID0gc3RhdGU7XG4gICAgY29uc3QgcmVnaXN0cnlSZWYgPSBSZWFjdDIudXNlUmVmKFxuICAgICAgbmV3IE9yZGVyZWREaWN0KClcbiAgICApO1xuICAgIGNvbnN0IGdldENvbGxlY3Rpb24gPSBSZWFjdDIudXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgICAgY29uc3QgcmVnaXN0cnkgPSByZWdpc3RyeVJlZi5jdXJyZW50O1xuICAgICAgaWYgKCFpc0luRG9jdW1lbnRPcmRlcihyZWdpc3RyeSkpIHtcbiAgICAgICAgcmVnaXN0cnkuc29ydChzb3J0QnlEb2N1bWVudFBvc2l0aW9uKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiByZWdpc3RyeTtcbiAgICB9LCBbXSk7XG4gICAgUmVhY3QyLnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICBpZiAoIWNvbGxlY3Rpb25FbGVtZW50KSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IG9ic2VydmVyID0gZ2V0Q2hpbGRMaXN0T2JzZXJ2ZXIoKCkgPT4ge1xuICAgICAgICBzZXRDb2xsZWN0aW9uKChtYXApID0+IHtcbiAgICAgICAgICBjb25zdCBzb3J0ZWQgPSBtYXAudG9Tb3J0ZWQoc29ydEJ5RG9jdW1lbnRQb3NpdGlvbik7XG4gICAgICAgICAgY29uc3Qgb3JkZXJDaGFuZ2VkID0gc29ydGVkLnNvbWUoKFtrZXldLCBpbmRleCkgPT4gbWFwLmtleUF0KGluZGV4KSAhPT0ga2V5KTtcbiAgICAgICAgICByZXR1cm4gb3JkZXJDaGFuZ2VkID8gc29ydGVkIDogbWFwO1xuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgICAgb2JzZXJ2ZXIub2JzZXJ2ZShjb2xsZWN0aW9uRWxlbWVudCwge1xuICAgICAgICBjaGlsZExpc3Q6IHRydWUsXG4gICAgICAgIHN1YnRyZWU6IHRydWVcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgb2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuICAgICAgfTtcbiAgICB9LCBbY29sbGVjdGlvbkVsZW1lbnQsIHNldENvbGxlY3Rpb25dKTtcbiAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeDIoXG4gICAgICBDb2xsZWN0aW9uU3RhYmxlQ29udGV4dFByb3ZpZGVyLFxuICAgICAge1xuICAgICAgICBzY29wZSxcbiAgICAgICAgY29sbGVjdGlvbkVsZW1lbnRSZWY6IGNvbXBvc2VSZWZzLFxuICAgICAgICBjb2xsZWN0aW9uRWxlbWVudFJlZk9iamVjdDogcmVmLFxuICAgICAgICBnZXRDb2xsZWN0aW9uLFxuICAgICAgICBzZXRDb2xsZWN0aW9uLFxuICAgICAgICByZWdpc3RyeVJlZixcbiAgICAgICAgY2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBqc3gyKFxuICAgICAgICAgIENvbGxlY3Rpb25TdGF0ZWZ1bENvbnRleHRQcm92aWRlcixcbiAgICAgICAgICB7XG4gICAgICAgICAgICBzY29wZSxcbiAgICAgICAgICAgIGNvbGxlY3Rpb25FbGVtZW50LFxuICAgICAgICAgICAgY29sbGVjdGlvbixcbiAgICAgICAgICAgIGNoaWxkcmVuXG4gICAgICAgICAgfVxuICAgICAgICApXG4gICAgICB9XG4gICAgKTtcbiAgfSwgXCJDb2xsZWN0aW9uUHJvdmlkZXJJbXBsXCIpO1xuICBDb2xsZWN0aW9uUHJvdmlkZXJJbXBsLmRpc3BsYXlOYW1lID0gbmFtZSArIFwiQ29sbGVjdGlvblByb3ZpZGVySW1wbFwiO1xuICBjb25zdCBDT0xMRUNUSU9OX1NMT1RfTkFNRSA9IG5hbWUgKyBcIkNvbGxlY3Rpb25TbG90XCI7XG4gIGNvbnN0IENvbGxlY3Rpb25TbG90SW1wbCA9IGNyZWF0ZVNsb3QyKENPTExFQ1RJT05fU0xPVF9OQU1FKTtcbiAgY29uc3QgQ29sbGVjdGlvblNsb3QgPSBSZWFjdDIuZm9yd2FyZFJlZihcbiAgICAocHJvcHMsIGZvcndhcmRlZFJlZikgPT4ge1xuICAgICAgY29uc3QgeyBzY29wZSwgY2hpbGRyZW4gfSA9IHByb3BzO1xuICAgICAgY29uc3QgY29udGV4dCA9IHVzZVN0YWJsZUNvbGxlY3Rpb25Db250ZXh0KENPTExFQ1RJT05fU0xPVF9OQU1FLCBzY29wZSk7XG4gICAgICBjb25zdCBjb21wb3NlZFJlZnMgPSB1c2VDb21wb3NlZFJlZnMyKGZvcndhcmRlZFJlZiwgY29udGV4dC5jb2xsZWN0aW9uRWxlbWVudFJlZik7XG4gICAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeDIoQ29sbGVjdGlvblNsb3RJbXBsLCB7IHJlZjogY29tcG9zZWRSZWZzLCBjaGlsZHJlbiB9KTtcbiAgICB9XG4gICk7XG4gIENvbGxlY3Rpb25TbG90LmRpc3BsYXlOYW1lID0gQ09MTEVDVElPTl9TTE9UX05BTUU7XG4gIGNvbnN0IElURU1fU0xPVF9OQU1FID0gbmFtZSArIFwiQ29sbGVjdGlvbkl0ZW1TbG90XCI7XG4gIGNvbnN0IElURU1fREFUQV9BVFRSID0gXCJkYXRhLXJhZGl4LWNvbGxlY3Rpb24taXRlbVwiO1xuICBjb25zdCBDb2xsZWN0aW9uSXRlbVNsb3RJbXBsID0gY3JlYXRlU2xvdDIoSVRFTV9TTE9UX05BTUUpO1xuICBjb25zdCBDb2xsZWN0aW9uSXRlbVNsb3QgPSBSZWFjdDIuZm9yd2FyZFJlZihcbiAgICAocHJvcHMsIGZvcndhcmRlZFJlZikgPT4ge1xuICAgICAgY29uc3QgeyBzY29wZSwgY2hpbGRyZW4sIC4uLml0ZW1EYXRhIH0gPSBwcm9wcztcbiAgICAgIGNvbnN0IHJlZiA9IFJlYWN0Mi51c2VSZWYobnVsbCk7XG4gICAgICBjb25zdCBjb250ZXh0ID0gdXNlU3RhYmxlQ29sbGVjdGlvbkNvbnRleHQoSVRFTV9TTE9UX05BTUUsIHNjb3BlKTtcbiAgICAgIGNvbnN0IHsgc2V0Q29sbGVjdGlvbiwgcmVnaXN0cnlSZWYgfSA9IGNvbnRleHQ7XG4gICAgICBjb25zdCBpdGVtRGF0YVJlZiA9IFJlYWN0Mi51c2VSZWYoaXRlbURhdGEpO1xuICAgICAgaWYgKCFzaGFsbG93RXF1YWwoaXRlbURhdGFSZWYuY3VycmVudCwgaXRlbURhdGEpKSB7XG4gICAgICAgIGl0ZW1EYXRhUmVmLmN1cnJlbnQgPSBpdGVtRGF0YTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IG1lbW9pemVkSXRlbURhdGEgPSBpdGVtRGF0YVJlZi5jdXJyZW50O1xuICAgICAgY29uc3QgcmVnaXN0ZXJFbGVtZW50ID0gUmVhY3QyLnVzZUNhbGxiYWNrKFxuICAgICAgICAobm9kZSkgPT4ge1xuICAgICAgICAgIGNvbnN0IHJlZ2lzdHJ5ID0gcmVnaXN0cnlSZWYuY3VycmVudDtcbiAgICAgICAgICBpZiAobm9kZSkge1xuICAgICAgICAgICAgcmVnaXN0cnkuc2V0KG5vZGUsIHtcbiAgICAgICAgICAgICAgLi4uaXRlbURhdGFSZWYuY3VycmVudCxcbiAgICAgICAgICAgICAgZWxlbWVudDogbm9kZVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfSBlbHNlIGlmIChyZWYuY3VycmVudCkge1xuICAgICAgICAgICAgcmVnaXN0cnkuZGVsZXRlKHJlZi5jdXJyZW50KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFtyZWdpc3RyeVJlZl1cbiAgICAgICk7XG4gICAgICBjb25zdCBjb21wb3NlZFJlZnMgPSB1c2VDb21wb3NlZFJlZnMyKGZvcndhcmRlZFJlZiwgcmVnaXN0ZXJFbGVtZW50LCByZWYpO1xuICAgICAgdXNlTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3Qgbm9kZSA9IHJlZi5jdXJyZW50O1xuICAgICAgICBjb25zdCByZWdpc3RyeSA9IHJlZ2lzdHJ5UmVmLmN1cnJlbnQ7XG4gICAgICAgIGlmIChub2RlICYmIHJlZ2lzdHJ5Lmhhcyhub2RlKSkge1xuICAgICAgICAgIHJlZ2lzdHJ5LnNldChub2RlLCB7IC4uLm1lbW9pemVkSXRlbURhdGEsIGVsZW1lbnQ6IG5vZGUgfSk7XG4gICAgICAgIH1cbiAgICAgIH0sIFttZW1vaXplZEl0ZW1EYXRhLCByZWdpc3RyeVJlZl0pO1xuICAgICAgY29uc3QgcmVnaXN0ZXJlZFJlZiA9IFJlYWN0Mi51c2VSZWYobnVsbCk7XG4gICAgICBSZWFjdDIudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgZWxlbWVudCA9IHJlZi5jdXJyZW50O1xuICAgICAgICBjb25zdCByZWdpc3RlcmVkID0gcmVnaXN0ZXJlZFJlZi5jdXJyZW50O1xuICAgICAgICBpZiAoKHJlZ2lzdGVyZWQ/LmVsZW1lbnQgPz8gbnVsbCkgPT09IGVsZW1lbnQgJiYgKCFlbGVtZW50IHx8IHJlZ2lzdGVyZWQ/Lml0ZW1EYXRhID09PSBtZW1vaXplZEl0ZW1EYXRhKSkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICByZWdpc3RlcmVkUmVmLmN1cnJlbnQgPSBlbGVtZW50ID8geyBlbGVtZW50LCBpdGVtRGF0YTogbWVtb2l6ZWRJdGVtRGF0YSB9IDogbnVsbDtcbiAgICAgICAgc2V0Q29sbGVjdGlvbigobWFwKSA9PiB7XG4gICAgICAgICAgY29uc3QgbmV4dCA9IG5ldyBPcmRlcmVkRGljdChtYXApO1xuICAgICAgICAgIGlmIChyZWdpc3RlcmVkICYmIHJlZ2lzdGVyZWQuZWxlbWVudCAhPT0gZWxlbWVudCkge1xuICAgICAgICAgICAgbmV4dC5kZWxldGUocmVnaXN0ZXJlZC5lbGVtZW50KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKGVsZW1lbnQpIHtcbiAgICAgICAgICAgIG5leHQuc2V0KGVsZW1lbnQsIHsgLi4ubWVtb2l6ZWRJdGVtRGF0YSwgZWxlbWVudCB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIG5leHQuc29ydChzb3J0QnlEb2N1bWVudFBvc2l0aW9uKTtcbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICAgIFJlYWN0Mi51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgIGNvbnN0IHJlZ2lzdGVyZWQgPSByZWdpc3RlcmVkUmVmLmN1cnJlbnQ7XG4gICAgICAgICAgcmVnaXN0ZXJlZFJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgICAgICBpZiAoIXJlZ2lzdGVyZWQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgICAgc2V0Q29sbGVjdGlvbigobWFwKSA9PiB7XG4gICAgICAgICAgICBpZiAoIW1hcC5oYXMocmVnaXN0ZXJlZC5lbGVtZW50KSkge1xuICAgICAgICAgICAgICByZXR1cm4gbWFwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgbmV4dCA9IG5ldyBPcmRlcmVkRGljdChtYXApO1xuICAgICAgICAgICAgbmV4dC5kZWxldGUocmVnaXN0ZXJlZC5lbGVtZW50KTtcbiAgICAgICAgICAgIHJldHVybiBuZXh0O1xuICAgICAgICAgIH0pO1xuICAgICAgICB9O1xuICAgICAgfSwgW3NldENvbGxlY3Rpb25dKTtcbiAgICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4MihDb2xsZWN0aW9uSXRlbVNsb3RJbXBsLCB7IC4uLnsgW0lURU1fREFUQV9BVFRSXTogXCJcIiB9LCByZWY6IGNvbXBvc2VkUmVmcywgY2hpbGRyZW4gfSk7XG4gICAgfVxuICApO1xuICBDb2xsZWN0aW9uSXRlbVNsb3QuZGlzcGxheU5hbWUgPSBJVEVNX1NMT1RfTkFNRTtcbiAgZnVuY3Rpb24gdXNlSW5pdENvbGxlY3Rpb24oKSB7XG4gICAgcmV0dXJuIFJlYWN0Mi51c2VTdGF0ZShuZXcgT3JkZXJlZERpY3QoKSk7XG4gIH1cbiAgX19uYW1lKHVzZUluaXRDb2xsZWN0aW9uLCBcInVzZUluaXRDb2xsZWN0aW9uXCIpO1xuICBmdW5jdGlvbiB1c2VDb2xsZWN0aW9uKHNjb3BlKSB7XG4gICAgY29uc3QgeyBjb2xsZWN0aW9uIH0gPSB1c2VTdGF0ZWZ1bENvbGxlY3Rpb25Db250ZXh0KG5hbWUgKyBcIkNvbGxlY3Rpb25Db25zdW1lclwiLCBzY29wZSk7XG4gICAgcmV0dXJuIGNvbGxlY3Rpb247XG4gIH1cbiAgX19uYW1lKHVzZUNvbGxlY3Rpb24sIFwidXNlQ29sbGVjdGlvblwiKTtcbiAgZnVuY3Rpb24gdXNlR2V0Q29sbGVjdGlvbihzY29wZSkge1xuICAgIGNvbnN0IHsgZ2V0Q29sbGVjdGlvbiB9ID0gdXNlU3RhYmxlQ29sbGVjdGlvbkNvbnRleHQobmFtZSArIFwiQ29sbGVjdGlvbkNvbnN1bWVyXCIsIHNjb3BlKTtcbiAgICByZXR1cm4gZ2V0Q29sbGVjdGlvbjtcbiAgfVxuICBfX25hbWUodXNlR2V0Q29sbGVjdGlvbiwgXCJ1c2VHZXRDb2xsZWN0aW9uXCIpO1xuICBjb25zdCBmdW5jdGlvbnMgPSB7XG4gICAgY3JlYXRlQ29sbGVjdGlvblNjb3BlLFxuICAgIHVzZUNvbGxlY3Rpb24sXG4gICAgdXNlR2V0Q29sbGVjdGlvbixcbiAgICB1c2VJbml0Q29sbGVjdGlvblxuICB9O1xuICByZXR1cm4gW1xuICAgIHsgUHJvdmlkZXI6IENvbGxlY3Rpb25Qcm92aWRlciwgU2xvdDogQ29sbGVjdGlvblNsb3QsIEl0ZW1TbG90OiBDb2xsZWN0aW9uSXRlbVNsb3QgfSxcbiAgICBmdW5jdGlvbnNcbiAgXTtcbn1cbl9fbmFtZShjcmVhdGVDb2xsZWN0aW9uMiwgXCJjcmVhdGVDb2xsZWN0aW9uXCIpO1xuZnVuY3Rpb24gc2hhbGxvd0VxdWFsKGEsIGIpIHtcbiAgaWYgKGEgPT09IGIpIHJldHVybiB0cnVlO1xuICBpZiAodHlwZW9mIGEgIT09IFwib2JqZWN0XCIgfHwgdHlwZW9mIGIgIT09IFwib2JqZWN0XCIpIHJldHVybiBmYWxzZTtcbiAgaWYgKGEgPT0gbnVsbCB8fCBiID09IG51bGwpIHJldHVybiBmYWxzZTtcbiAgY29uc3Qga2V5c0EgPSBPYmplY3Qua2V5cyhhKTtcbiAgY29uc3Qga2V5c0IgPSBPYmplY3Qua2V5cyhiKTtcbiAgaWYgKGtleXNBLmxlbmd0aCAhPT0ga2V5c0IubGVuZ3RoKSByZXR1cm4gZmFsc2U7XG4gIGZvciAoY29uc3Qga2V5IG9mIGtleXNBKSB7XG4gICAgaWYgKCFPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoYiwga2V5KSkgcmV0dXJuIGZhbHNlO1xuICAgIGlmIChhW2tleV0gIT09IGJba2V5XSkgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiB0cnVlO1xufVxuX19uYW1lKHNoYWxsb3dFcXVhbCwgXCJzaGFsbG93RXF1YWxcIik7XG5mdW5jdGlvbiBpc0VsZW1lbnRQcmVjZWRpbmcoYSwgYikge1xuICByZXR1cm4gISEoYi5jb21wYXJlRG9jdW1lbnRQb3NpdGlvbihhKSAmIE5vZGUuRE9DVU1FTlRfUE9TSVRJT05fUFJFQ0VESU5HKTtcbn1cbl9fbmFtZShpc0VsZW1lbnRQcmVjZWRpbmcsIFwiaXNFbGVtZW50UHJlY2VkaW5nXCIpO1xuZnVuY3Rpb24gaXNJbkRvY3VtZW50T3JkZXIoZGljdCkge1xuICBsZXQgcHJldmlvdXM7XG4gIGZvciAoY29uc3QgZWxlbWVudCBvZiBkaWN0LmtleXMoKSkge1xuICAgIGlmIChwcmV2aW91cykge1xuICAgICAgY29uc3QgcG9zaXRpb24gPSBwcmV2aW91cy5jb21wYXJlRG9jdW1lbnRQb3NpdGlvbihlbGVtZW50KTtcbiAgICAgIGlmICghKHBvc2l0aW9uICYgTm9kZS5ET0NVTUVOVF9QT1NJVElPTl9ESVNDT05ORUNURUQpICYmIHBvc2l0aW9uICYgTm9kZS5ET0NVTUVOVF9QT1NJVElPTl9QUkVDRURJTkcpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgIH1cbiAgICBwcmV2aW91cyA9IGVsZW1lbnQ7XG4gIH1cbiAgcmV0dXJuIHRydWU7XG59XG5fX25hbWUoaXNJbkRvY3VtZW50T3JkZXIsIFwiaXNJbkRvY3VtZW50T3JkZXJcIik7XG5mdW5jdGlvbiBzb3J0QnlEb2N1bWVudFBvc2l0aW9uKGEsIGIpIHtcbiAgcmV0dXJuICFhWzFdLmVsZW1lbnQgfHwgIWJbMV0uZWxlbWVudCA/IDAgOiBpc0VsZW1lbnRQcmVjZWRpbmcoYVsxXS5lbGVtZW50LCBiWzFdLmVsZW1lbnQpID8gLTEgOiAxO1xufVxuX19uYW1lKHNvcnRCeURvY3VtZW50UG9zaXRpb24sIFwic29ydEJ5RG9jdW1lbnRQb3NpdGlvblwiKTtcbmZ1bmN0aW9uIGdldENoaWxkTGlzdE9ic2VydmVyKGNhbGxiYWNrKSB7XG4gIGNvbnN0IG9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoKG11dGF0aW9uc0xpc3QpID0+IHtcbiAgICBmb3IgKGNvbnN0IG11dGF0aW9uIG9mIG11dGF0aW9uc0xpc3QpIHtcbiAgICAgIGlmIChtdXRhdGlvbi50eXBlID09PSBcImNoaWxkTGlzdFwiKSB7XG4gICAgICAgIGNhbGxiYWNrKCk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICB9XG4gIH0pO1xuICByZXR1cm4gb2JzZXJ2ZXI7XG59XG5fX25hbWUoZ2V0Q2hpbGRMaXN0T2JzZXJ2ZXIsIFwiZ2V0Q2hpbGRMaXN0T2JzZXJ2ZXJcIik7XG5leHBvcnQge1xuICBjcmVhdGVDb2xsZWN0aW9uLFxuICBjcmVhdGVDb2xsZWN0aW9uMiBhcyB1bnN0YWJsZV9jcmVhdGVDb2xsZWN0aW9uXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXgubWpzLm1hcFxuIiwiXCJ1c2UgY2xpZW50XCI7XG52YXIgX19kZWZQcm9wID0gT2JqZWN0LmRlZmluZVByb3BlcnR5O1xudmFyIF9fbmFtZSA9ICh0YXJnZXQsIHZhbHVlKSA9PiBfX2RlZlByb3AodGFyZ2V0LCBcIm5hbWVcIiwgeyB2YWx1ZSwgY29uZmlndXJhYmxlOiB0cnVlIH0pO1xuXG4vLyBzcmMvc2xpZGVyLnRzeFxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBjbGFtcCB9IGZyb20gXCJAcmFkaXgtdWkvbnVtYmVyXCI7XG5pbXBvcnQgeyBjb21wb3NlRXZlbnRIYW5kbGVycyB9IGZyb20gXCJAcmFkaXgtdWkvcHJpbWl0aXZlXCI7XG5pbXBvcnQgeyB1c2VDb21wb3NlZFJlZnMgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LWNvbXBvc2UtcmVmc1wiO1xuaW1wb3J0IHsgY3JlYXRlQ29udGV4dFNjb3BlIH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC1jb250ZXh0XCI7XG5pbXBvcnQgeyB1c2VDb250cm9sbGFibGVTdGF0ZSB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtdXNlLWNvbnRyb2xsYWJsZS1zdGF0ZVwiO1xuaW1wb3J0IHsgdXNlRGlyZWN0aW9uIH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC1kaXJlY3Rpb25cIjtcbmltcG9ydCB7IHVzZVNpemUgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LXVzZS1zaXplXCI7XG5pbXBvcnQgeyBQcmltaXRpdmUgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LXByaW1pdGl2ZVwiO1xuaW1wb3J0IHsgY3JlYXRlQ29sbGVjdGlvbiB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtY29sbGVjdGlvblwiO1xuaW1wb3J0IHsgRnJhZ21lbnQsIGpzeCwganN4cyB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xudmFyIE9yaWVudGF0aW9uID0ge1xuICBWZXJ0aWNhbDogXCJ2ZXJ0aWNhbFwiLFxuICBIb3Jpem9udGFsOiBcImhvcml6b250YWxcIlxufTtcbnZhciBEaXJlY3Rpb24gPSB7XG4gIExUUjogXCJsdHJcIixcbiAgUlRMOiBcInJ0bFwiXG59O1xudmFyIFBBR0VfS0VZUyA9IFtcIlBhZ2VVcFwiLCBcIlBhZ2VEb3duXCJdO1xudmFyIEFSUk9XX0tFWVMgPSBbXCJBcnJvd1VwXCIsIFwiQXJyb3dEb3duXCIsIFwiQXJyb3dMZWZ0XCIsIFwiQXJyb3dSaWdodFwiXTtcbnZhciBCQUNLX0tFWVMgPSB7XG4gIFwiZnJvbS1sZWZ0XCI6IFtcIkhvbWVcIiwgXCJQYWdlRG93blwiLCBcIkFycm93RG93blwiLCBcIkFycm93TGVmdFwiXSxcbiAgXCJmcm9tLXJpZ2h0XCI6IFtcIkhvbWVcIiwgXCJQYWdlRG93blwiLCBcIkFycm93RG93blwiLCBcIkFycm93UmlnaHRcIl0sXG4gIFwiZnJvbS1ib3R0b21cIjogW1wiSG9tZVwiLCBcIlBhZ2VEb3duXCIsIFwiQXJyb3dEb3duXCIsIFwiQXJyb3dMZWZ0XCJdLFxuICBcImZyb20tdG9wXCI6IFtcIkhvbWVcIiwgXCJQYWdlRG93blwiLCBcIkFycm93VXBcIiwgXCJBcnJvd0xlZnRcIl1cbn07XG52YXIgU0xJREVSX05BTUUgPSBcIlNsaWRlclwiO1xudmFyIFtDb2xsZWN0aW9uLCB1c2VDb2xsZWN0aW9uLCBjcmVhdGVDb2xsZWN0aW9uU2NvcGVdID0gY3JlYXRlQ29sbGVjdGlvbihTTElERVJfTkFNRSk7XG52YXIgW2NyZWF0ZVNsaWRlckNvbnRleHQsIGNyZWF0ZVNsaWRlclNjb3BlXSA9IGNyZWF0ZUNvbnRleHRTY29wZShTTElERVJfTkFNRSwgW1xuICBjcmVhdGVDb2xsZWN0aW9uU2NvcGVcbl0pO1xudmFyIFtTbGlkZXJQcm92aWRlciwgdXNlU2xpZGVyQ29udGV4dF0gPSBjcmVhdGVTbGlkZXJDb250ZXh0KFNMSURFUl9OQU1FKTtcbnZhciBTbGlkZXIgPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuZm9yd2FyZFJlZihcbiAgLy8gYmxhbmsgbGluZSB0byByZWR1Y2UgZGlmZiBub2lzZVxuICAvKiBAX19QVVJFX18gKi8gX19uYW1lKGZ1bmN0aW9uIFNsaWRlcjIocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICAgIGNvbnN0IHtcbiAgICAgIG5hbWUsXG4gICAgICBtaW4gPSAwLFxuICAgICAgbWF4ID0gMTAwLFxuICAgICAgc3RlcCA9IDEsXG4gICAgICBvcmllbnRhdGlvbiA9IE9yaWVudGF0aW9uLkhvcml6b250YWwsXG4gICAgICBkaXNhYmxlZCA9IGZhbHNlLFxuICAgICAgbWluU3RlcHNCZXR3ZWVuVGh1bWJzID0gMCxcbiAgICAgIHByZXNlcnZlVGh1bWJPcmRlciA9IGZhbHNlLFxuICAgICAgZGVmYXVsdFZhbHVlID0gW21pbl0sXG4gICAgICB2YWx1ZSxcbiAgICAgIG9uVmFsdWVDaGFuZ2UgPSAvKiBAX19QVVJFX18gKi8gX19uYW1lKCgpID0+IHtcbiAgICAgIH0sIFwib25WYWx1ZUNoYW5nZVwiKSxcbiAgICAgIG9uVmFsdWVDb21taXQgPSAvKiBAX19QVVJFX18gKi8gX19uYW1lKCgpID0+IHtcbiAgICAgIH0sIFwib25WYWx1ZUNvbW1pdFwiKSxcbiAgICAgIGludmVydGVkID0gZmFsc2UsXG4gICAgICBmb3JtLFxuICAgICAgLi4uc2xpZGVyUHJvcHNcbiAgICB9ID0gcHJvcHM7XG4gICAgY29uc3QgdGh1bWJSZWZzID0gUmVhY3QudXNlUmVmKC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCkpO1xuICAgIGNvbnN0IHZhbHVlSW5kZXhUb0NoYW5nZVJlZiA9IFJlYWN0LnVzZVJlZigwKTtcbiAgICBjb25zdCBpc0tleWJvYXJkSW50ZXJhY3Rpb25SZWYgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICAgIGNvbnN0IFt1c2VyUmVxdWVzdGVkVmFsdWVzLCBzZXRVc2VyUmVxdWVzdGVkVmFsdWVzXSA9IFJlYWN0LnVzZVN0YXRlKG51bGwpO1xuICAgIGNvbnN0IGlzSG9yaXpvbnRhbCA9IG9yaWVudGF0aW9uID09PSBPcmllbnRhdGlvbi5Ib3Jpem9udGFsO1xuICAgIGNvbnN0IFNsaWRlck9yaWVudGF0aW9uID0gaXNIb3Jpem9udGFsID8gU2xpZGVySG9yaXpvbnRhbCA6IFNsaWRlclZlcnRpY2FsO1xuICAgIGNvbnN0IFtjb250cm9sLCBzZXRDb250cm9sXSA9IFJlYWN0LnVzZVN0YXRlKG51bGwpO1xuICAgIGNvbnN0IGNvbXBvc2VkUmVmcyA9IHVzZUNvbXBvc2VkUmVmcyhmb3J3YXJkZWRSZWYsIHNldENvbnRyb2wpO1xuICAgIGNvbnN0IFt2YWx1ZXMgPSBbXSwgc2V0VmFsdWVzXSA9IHVzZUNvbnRyb2xsYWJsZVN0YXRlKHtcbiAgICAgIHByb3A6IHZhbHVlLFxuICAgICAgZGVmYXVsdFByb3A6IGRlZmF1bHRWYWx1ZSxcbiAgICAgIG9uQ2hhbmdlOiAvKiBAX19QVVJFX18gKi8gX19uYW1lKCh2YWx1ZTIpID0+IHtcbiAgICAgICAgY29uc3QgdGh1bWJzID0gWy4uLnRodW1iUmVmcy5jdXJyZW50XTtcbiAgICAgICAgdGh1bWJzW3ZhbHVlSW5kZXhUb0NoYW5nZVJlZi5jdXJyZW50XT8uZm9jdXMoe1xuICAgICAgICAgIHByZXZlbnRTY3JvbGw6IHRydWUsXG4gICAgICAgICAgZm9jdXNWaXNpYmxlOiBpc0tleWJvYXJkSW50ZXJhY3Rpb25SZWYuY3VycmVudFxuICAgICAgICB9KTtcbiAgICAgICAgaXNLZXlib2FyZEludGVyYWN0aW9uUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgb25WYWx1ZUNoYW5nZSh2YWx1ZTIpO1xuICAgICAgfSwgXCJvbkNoYW5nZVwiKVxuICAgIH0pO1xuICAgIGNvbnN0IHZhbHVlc0JlZm9yZVNsaWRlU3RhcnRSZWYgPSBSZWFjdC51c2VSZWYodmFsdWVzKTtcbiAgICBjb25zdCBpbml0aWFsVmFsdWVzUmVmID0gUmVhY3QudXNlUmVmKHZhbHVlcyk7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgIGNvbnN0IGFzc29jaWF0ZWRGb3JtID0gZm9ybSA/IGNvbnRyb2w/Lm93bmVyRG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoZm9ybSkgOiBjb250cm9sPy5jbG9zZXN0KFwiZm9ybVwiKTtcbiAgICAgIGlmIChhc3NvY2lhdGVkRm9ybSBpbnN0YW5jZW9mIEhUTUxGb3JtRWxlbWVudCkge1xuICAgICAgICBjb25zdCByZXNldCA9IC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoKCkgPT4gc2V0VmFsdWVzKGluaXRpYWxWYWx1ZXNSZWYuY3VycmVudCksIFwicmVzZXRcIik7XG4gICAgICAgIGFzc29jaWF0ZWRGb3JtLmFkZEV2ZW50TGlzdGVuZXIoXCJyZXNldFwiLCByZXNldCk7XG4gICAgICAgIHJldHVybiAoKSA9PiBhc3NvY2lhdGVkRm9ybS5yZW1vdmVFdmVudExpc3RlbmVyKFwicmVzZXRcIiwgcmVzZXQpO1xuICAgICAgfVxuICAgIH0sIFtjb250cm9sLCBmb3JtLCBzZXRWYWx1ZXNdKTtcbiAgICBmdW5jdGlvbiBoYW5kbGVTbGlkZVN0YXJ0KHZhbHVlMikge1xuICAgICAgY29uc3QgY2xvc2VzdEluZGV4ID0gZ2V0Q2xvc2VzdFZhbHVlSW5kZXgodmFsdWVzLCB2YWx1ZTIpO1xuICAgICAgdXBkYXRlVmFsdWVzKHZhbHVlMiwgY2xvc2VzdEluZGV4KTtcbiAgICB9XG4gICAgX19uYW1lKGhhbmRsZVNsaWRlU3RhcnQsIFwiaGFuZGxlU2xpZGVTdGFydFwiKTtcbiAgICBmdW5jdGlvbiBoYW5kbGVTbGlkZU1vdmUodmFsdWUyKSB7XG4gICAgICB1cGRhdGVWYWx1ZXModmFsdWUyLCB2YWx1ZUluZGV4VG9DaGFuZ2VSZWYuY3VycmVudCk7XG4gICAgfVxuICAgIF9fbmFtZShoYW5kbGVTbGlkZU1vdmUsIFwiaGFuZGxlU2xpZGVNb3ZlXCIpO1xuICAgIGZ1bmN0aW9uIGhhbmRsZVNsaWRlRW5kKCkge1xuICAgICAgY29uc3QgaGFzQ2hhbmdlZCA9IFN0cmluZyh2YWx1ZXMpICE9PSBTdHJpbmcodmFsdWVzQmVmb3JlU2xpZGVTdGFydFJlZi5jdXJyZW50KTtcbiAgICAgIGlmIChoYXNDaGFuZ2VkKSBvblZhbHVlQ29tbWl0KHZhbHVlcyk7XG4gICAgfVxuICAgIF9fbmFtZShoYW5kbGVTbGlkZUVuZCwgXCJoYW5kbGVTbGlkZUVuZFwiKTtcbiAgICBmdW5jdGlvbiB1cGRhdGVWYWx1ZXModmFsdWUyLCBhdEluZGV4LCB7IGNvbW1pdCB9ID0geyBjb21taXQ6IGZhbHNlIH0pIHtcbiAgICAgIGNvbnN0IGRlY2ltYWxDb3VudCA9IGdldERlY2ltYWxDb3VudChzdGVwKTtcbiAgICAgIGNvbnN0IHNuYXBUb1N0ZXAgPSByb3VuZFZhbHVlKE1hdGgucm91bmQoKHZhbHVlMiAtIG1pbikgLyBzdGVwKSAqIHN0ZXAgKyBtaW4sIGRlY2ltYWxDb3VudCk7XG4gICAgICBjb25zdCBuZXh0VmFsdWUgPSBjbGFtcChzbmFwVG9TdGVwLCBbbWluLCBtYXhdKTtcbiAgICAgIGNvbnN0IG1pblN0ZXBzRGlzdGFuY2UgPSBtaW5TdGVwc0JldHdlZW5UaHVtYnMgKiBzdGVwO1xuICAgICAgZnVuY3Rpb24gZ2V0TmV4dFZhbHVlcyhwcmV2VmFsdWVzKSB7XG4gICAgICAgIGNvbnN0IGNvbnN0cmFpbmVkVmFsdWUgPSBwcmVzZXJ2ZVRodW1iT3JkZXIgPyBjbGFtcChuZXh0VmFsdWUsIFtcbiAgICAgICAgICBwcmV2VmFsdWVzW2F0SW5kZXggLSAxXSA9PT0gdm9pZCAwID8gbWluIDogcHJldlZhbHVlc1thdEluZGV4IC0gMV0gKyBtaW5TdGVwc0Rpc3RhbmNlLFxuICAgICAgICAgIHByZXZWYWx1ZXNbYXRJbmRleCArIDFdID09PSB2b2lkIDAgPyBtYXggOiBwcmV2VmFsdWVzW2F0SW5kZXggKyAxXSAtIG1pblN0ZXBzRGlzdGFuY2VcbiAgICAgICAgXSkgOiBuZXh0VmFsdWU7XG4gICAgICAgIGNvbnN0IG5leHRWYWx1ZXMgPSBnZXROZXh0U29ydGVkVmFsdWVzKHByZXZWYWx1ZXMsIGNvbnN0cmFpbmVkVmFsdWUsIGF0SW5kZXgpO1xuICAgICAgICBpZiAoIWhhc01pblN0ZXBzQmV0d2VlblZhbHVlcyhuZXh0VmFsdWVzLCBtaW5TdGVwc0Rpc3RhbmNlKSkge1xuICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgbmV4dFZhbHVlcyxcbiAgICAgICAgICBjaGFuZ2VkSW5kZXg6IHByZXNlcnZlVGh1bWJPcmRlciA/IGF0SW5kZXggOiBuZXh0VmFsdWVzLmluZGV4T2YoY29uc3RyYWluZWRWYWx1ZSksXG4gICAgICAgICAgaGFzQ2hhbmdlZDogU3RyaW5nKG5leHRWYWx1ZXMpICE9PSBTdHJpbmcocHJldlZhbHVlcylcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIF9fbmFtZShnZXROZXh0VmFsdWVzLCBcImdldE5leHRWYWx1ZXNcIik7XG4gICAgICBjb25zdCByZXF1ZXN0ZWQgPSBnZXROZXh0VmFsdWVzKHZhbHVlcyk7XG4gICAgICBpZiAocmVxdWVzdGVkPy5oYXNDaGFuZ2VkKSB7XG4gICAgICAgIHNldFVzZXJSZXF1ZXN0ZWRWYWx1ZXMocmVxdWVzdGVkLm5leHRWYWx1ZXMpO1xuICAgICAgfVxuICAgICAgc2V0VmFsdWVzKChwcmV2VmFsdWVzID0gW10pID0+IHtcbiAgICAgICAgY29uc3QgbmV4dCA9IGdldE5leHRWYWx1ZXMocHJldlZhbHVlcyk7XG4gICAgICAgIGlmICghbmV4dCkge1xuICAgICAgICAgIHJldHVybiBwcmV2VmFsdWVzO1xuICAgICAgICB9XG4gICAgICAgIHZhbHVlSW5kZXhUb0NoYW5nZVJlZi5jdXJyZW50ID0gbmV4dC5jaGFuZ2VkSW5kZXg7XG4gICAgICAgIGlmIChuZXh0Lmhhc0NoYW5nZWQgJiYgY29tbWl0KSB7XG4gICAgICAgICAgb25WYWx1ZUNvbW1pdChuZXh0Lm5leHRWYWx1ZXMpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBuZXh0Lmhhc0NoYW5nZWQgPyBuZXh0Lm5leHRWYWx1ZXMgOiBwcmV2VmFsdWVzO1xuICAgICAgfSk7XG4gICAgfVxuICAgIF9fbmFtZSh1cGRhdGVWYWx1ZXMsIFwidXBkYXRlVmFsdWVzXCIpO1xuICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFxuICAgICAgU2xpZGVyUHJvdmlkZXIsXG4gICAgICB7XG4gICAgICAgIHNjb3BlOiBwcm9wcy5fX3Njb3BlU2xpZGVyLFxuICAgICAgICBuYW1lLFxuICAgICAgICBkaXNhYmxlZCxcbiAgICAgICAgbWluLFxuICAgICAgICBtYXgsXG4gICAgICAgIHZhbHVlSW5kZXhUb0NoYW5nZVJlZixcbiAgICAgICAgdGh1bWJzOiB0aHVtYlJlZnMuY3VycmVudCxcbiAgICAgICAgdmFsdWVzLFxuICAgICAgICBvcmllbnRhdGlvbixcbiAgICAgICAgZm9ybSxcbiAgICAgICAgdXNlclJlcXVlc3RlZFZhbHVlcyxcbiAgICAgICAgY2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBqc3goQ29sbGVjdGlvbi5Qcm92aWRlciwgeyBzY29wZTogcHJvcHMuX19zY29wZVNsaWRlciwgY2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBqc3goQ29sbGVjdGlvbi5TbG90LCB7IHNjb3BlOiBwcm9wcy5fX3Njb3BlU2xpZGVyLCBjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGpzeChcbiAgICAgICAgICBTbGlkZXJPcmllbnRhdGlvbixcbiAgICAgICAgICB7XG4gICAgICAgICAgICBcImFyaWEtZGlzYWJsZWRcIjogZGlzYWJsZWQsXG4gICAgICAgICAgICBcImRhdGEtZGlzYWJsZWRcIjogZGlzYWJsZWQgPyBcIlwiIDogdm9pZCAwLFxuICAgICAgICAgICAgLi4uc2xpZGVyUHJvcHMsXG4gICAgICAgICAgICByZWY6IGNvbXBvc2VkUmVmcyxcbiAgICAgICAgICAgIG9uUG9pbnRlckRvd246IGNvbXBvc2VFdmVudEhhbmRsZXJzKHNsaWRlclByb3BzLm9uUG9pbnRlckRvd24sICgpID0+IHtcbiAgICAgICAgICAgICAgaWYgKCFkaXNhYmxlZCkge1xuICAgICAgICAgICAgICAgIHZhbHVlc0JlZm9yZVNsaWRlU3RhcnRSZWYuY3VycmVudCA9IHZhbHVlcztcbiAgICAgICAgICAgICAgICBpc0tleWJvYXJkSW50ZXJhY3Rpb25SZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG1pbixcbiAgICAgICAgICAgIG1heCxcbiAgICAgICAgICAgIGludmVydGVkLFxuICAgICAgICAgICAgb25TbGlkZVN0YXJ0OiBkaXNhYmxlZCA/IHZvaWQgMCA6IGhhbmRsZVNsaWRlU3RhcnQsXG4gICAgICAgICAgICBvblNsaWRlTW92ZTogZGlzYWJsZWQgPyB2b2lkIDAgOiBoYW5kbGVTbGlkZU1vdmUsXG4gICAgICAgICAgICBvblNsaWRlRW5kOiBkaXNhYmxlZCA/IHZvaWQgMCA6IGhhbmRsZVNsaWRlRW5kLFxuICAgICAgICAgICAgb25Ib21lS2V5RG93bjogKCkgPT4ge1xuICAgICAgICAgICAgICBpZiAoIWRpc2FibGVkKSB7XG4gICAgICAgICAgICAgICAgaXNLZXlib2FyZEludGVyYWN0aW9uUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICAgICAgICAgIHVwZGF0ZVZhbHVlcyhtaW4sIDAsIHsgY29tbWl0OiB0cnVlIH0pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgb25FbmRLZXlEb3duOiAoKSA9PiB7XG4gICAgICAgICAgICAgIGlmICghZGlzYWJsZWQpIHtcbiAgICAgICAgICAgICAgICBpc0tleWJvYXJkSW50ZXJhY3Rpb25SZWYuY3VycmVudCA9IHRydWU7XG4gICAgICAgICAgICAgICAgdXBkYXRlVmFsdWVzKG1heCwgdmFsdWVzLmxlbmd0aCAtIDEsIHsgY29tbWl0OiB0cnVlIH0pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgb25TdGVwS2V5RG93bjogKHsgZXZlbnQsIGRpcmVjdGlvbjogc3RlcERpcmVjdGlvbiB9KSA9PiB7XG4gICAgICAgICAgICAgIGlmICghZGlzYWJsZWQpIHtcbiAgICAgICAgICAgICAgICBpc0tleWJvYXJkSW50ZXJhY3Rpb25SZWYuY3VycmVudCA9IHRydWU7XG4gICAgICAgICAgICAgICAgY29uc3QgaXNQYWdlS2V5ID0gUEFHRV9LRVlTLmluY2x1ZGVzKGV2ZW50LmtleSk7XG4gICAgICAgICAgICAgICAgY29uc3QgaXNTa2lwS2V5ID0gaXNQYWdlS2V5IHx8IGV2ZW50LnNoaWZ0S2V5ICYmIEFSUk9XX0tFWVMuaW5jbHVkZXMoZXZlbnQua2V5KTtcbiAgICAgICAgICAgICAgICBjb25zdCBtdWx0aXBsaWVyID0gaXNTa2lwS2V5ID8gMTAgOiAxO1xuICAgICAgICAgICAgICAgIGNvbnN0IGF0SW5kZXggPSB2YWx1ZUluZGV4VG9DaGFuZ2VSZWYuY3VycmVudDtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWx1ZTIgPSB2YWx1ZXNbYXRJbmRleF07XG4gICAgICAgICAgICAgICAgY29uc3QgbmV4dFZhbHVlID0gZ2V0TmV4dFN0ZXBWYWx1ZSh2YWx1ZTIsIHtcbiAgICAgICAgICAgICAgICAgIG1pbixcbiAgICAgICAgICAgICAgICAgIHN0ZXAsXG4gICAgICAgICAgICAgICAgICBkaXJlY3Rpb246IHN0ZXBEaXJlY3Rpb24sXG4gICAgICAgICAgICAgICAgICBtdWx0aXBsaWVyXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgdXBkYXRlVmFsdWVzKG5leHRWYWx1ZSwgYXRJbmRleCwgeyBjb21taXQ6IHRydWUgfSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICkgfSkgfSlcbiAgICAgIH1cbiAgICApO1xuICB9LCBcIlNsaWRlclwiKVxuKTtcbnZhciBbU2xpZGVyT3JpZW50YXRpb25Qcm92aWRlciwgdXNlU2xpZGVyT3JpZW50YXRpb25Db250ZXh0XSA9IGNyZWF0ZVNsaWRlckNvbnRleHQoU0xJREVSX05BTUUsIHtcbiAgc3RhcnRFZGdlOiBcImxlZnRcIixcbiAgZW5kRWRnZTogXCJyaWdodFwiLFxuICBzaXplOiBcIndpZHRoXCIsXG4gIGRpcmVjdGlvbjogMVxufSk7XG52YXIgU2xpZGVySG9yaXpvbnRhbCA9IC8qIEBfX1BVUkVfXyAqLyBSZWFjdC5mb3J3YXJkUmVmKFxuICAvLyBibGFuayBsaW5lIHRvIHJlZHVjZSBkaWZmIG5vaXNlXG4gIC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoZnVuY3Rpb24gU2xpZGVySG9yaXpvbnRhbDIocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICAgIGNvbnN0IHtcbiAgICAgIG1pbixcbiAgICAgIG1heCxcbiAgICAgIGRpcixcbiAgICAgIGludmVydGVkLFxuICAgICAgb25TbGlkZVN0YXJ0LFxuICAgICAgb25TbGlkZU1vdmUsXG4gICAgICBvblNsaWRlRW5kLFxuICAgICAgb25TdGVwS2V5RG93bixcbiAgICAgIC4uLnNsaWRlclByb3BzXG4gICAgfSA9IHByb3BzO1xuICAgIGNvbnN0IFtzbGlkZXIsIHNldFNsaWRlcl0gPSBSZWFjdC51c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBjb21wb3NlZFJlZnMgPSB1c2VDb21wb3NlZFJlZnMoZm9yd2FyZGVkUmVmLCBzZXRTbGlkZXIpO1xuICAgIGNvbnN0IHJlY3RSZWYgPSBSZWFjdC51c2VSZWYodm9pZCAwKTtcbiAgICBjb25zdCBkaXJlY3Rpb24gPSB1c2VEaXJlY3Rpb24oZGlyKTtcbiAgICBjb25zdCBpc0RpcmVjdGlvbkxUUiA9IGRpcmVjdGlvbiA9PT0gRGlyZWN0aW9uLkxUUjtcbiAgICBjb25zdCBpc1NsaWRpbmdGcm9tTGVmdCA9IGlzRGlyZWN0aW9uTFRSICYmICFpbnZlcnRlZCB8fCAhaXNEaXJlY3Rpb25MVFIgJiYgaW52ZXJ0ZWQ7XG4gICAgZnVuY3Rpb24gZ2V0VmFsdWVGcm9tUG9pbnRlcihwb2ludGVyUG9zaXRpb24pIHtcbiAgICAgIGNvbnN0IHJlY3QgPSByZWN0UmVmLmN1cnJlbnQgfHwgc2xpZGVyLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgICAgY29uc3QgaW5wdXQgPSBbMCwgcmVjdC53aWR0aF07XG4gICAgICBjb25zdCBvdXRwdXQgPSBpc1NsaWRpbmdGcm9tTGVmdCA/IFttaW4sIG1heF0gOiBbbWF4LCBtaW5dO1xuICAgICAgY29uc3QgdmFsdWUgPSBsaW5lYXJTY2FsZShpbnB1dCwgb3V0cHV0KTtcbiAgICAgIHJlY3RSZWYuY3VycmVudCA9IHJlY3Q7XG4gICAgICByZXR1cm4gdmFsdWUocG9pbnRlclBvc2l0aW9uIC0gcmVjdC5sZWZ0KTtcbiAgICB9XG4gICAgX19uYW1lKGdldFZhbHVlRnJvbVBvaW50ZXIsIFwiZ2V0VmFsdWVGcm9tUG9pbnRlclwiKTtcbiAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChcbiAgICAgIFNsaWRlck9yaWVudGF0aW9uUHJvdmlkZXIsXG4gICAgICB7XG4gICAgICAgIHNjb3BlOiBwcm9wcy5fX3Njb3BlU2xpZGVyLFxuICAgICAgICBzdGFydEVkZ2U6IGlzU2xpZGluZ0Zyb21MZWZ0ID8gXCJsZWZ0XCIgOiBcInJpZ2h0XCIsXG4gICAgICAgIGVuZEVkZ2U6IGlzU2xpZGluZ0Zyb21MZWZ0ID8gXCJyaWdodFwiIDogXCJsZWZ0XCIsXG4gICAgICAgIGRpcmVjdGlvbjogaXNTbGlkaW5nRnJvbUxlZnQgPyAxIDogLTEsXG4gICAgICAgIHNpemU6IFwid2lkdGhcIixcbiAgICAgICAgY2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBqc3goXG4gICAgICAgICAgU2xpZGVySW1wbCxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBkaXI6IGRpcmVjdGlvbixcbiAgICAgICAgICAgIFwiZGF0YS1vcmllbnRhdGlvblwiOiBcImhvcml6b250YWxcIixcbiAgICAgICAgICAgIC4uLnNsaWRlclByb3BzLFxuICAgICAgICAgICAgcmVmOiBjb21wb3NlZFJlZnMsXG4gICAgICAgICAgICBzdHlsZToge1xuICAgICAgICAgICAgICAuLi5zbGlkZXJQcm9wcy5zdHlsZSxcbiAgICAgICAgICAgICAgXCItLXJhZGl4LXNsaWRlci10aHVtYi10cmFuc2Zvcm1cIjogXCJ0cmFuc2xhdGVYKC01MCUpXCJcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBvblNsaWRlU3RhcnQ6IChldmVudCkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCB2YWx1ZSA9IGdldFZhbHVlRnJvbVBvaW50ZXIoZXZlbnQuY2xpZW50WCk7XG4gICAgICAgICAgICAgIG9uU2xpZGVTdGFydD8uKHZhbHVlKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBvblNsaWRlTW92ZTogKGV2ZW50KSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gZ2V0VmFsdWVGcm9tUG9pbnRlcihldmVudC5jbGllbnRYKTtcbiAgICAgICAgICAgICAgb25TbGlkZU1vdmU/Lih2YWx1ZSk7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgb25TbGlkZUVuZDogKCkgPT4ge1xuICAgICAgICAgICAgICByZWN0UmVmLmN1cnJlbnQgPSB2b2lkIDA7XG4gICAgICAgICAgICAgIG9uU2xpZGVFbmQ/LigpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIG9uU3RlcEtleURvd246IChldmVudCkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBzbGlkZURpcmVjdGlvbiA9IGlzU2xpZGluZ0Zyb21MZWZ0ID8gXCJmcm9tLWxlZnRcIiA6IFwiZnJvbS1yaWdodFwiO1xuICAgICAgICAgICAgICBjb25zdCBpc0JhY2tLZXkgPSBCQUNLX0tFWVNbc2xpZGVEaXJlY3Rpb25dLmluY2x1ZGVzKGV2ZW50LmtleSk7XG4gICAgICAgICAgICAgIG9uU3RlcEtleURvd24/Lih7IGV2ZW50LCBkaXJlY3Rpb246IGlzQmFja0tleSA/IC0xIDogMSB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIClcbiAgICAgIH1cbiAgICApO1xuICB9LCBcIlNsaWRlckhvcml6b250YWxcIilcbik7XG52YXIgU2xpZGVyVmVydGljYWwgPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuZm9yd2FyZFJlZihcbiAgLyogQF9fUFVSRV9fICovIF9fbmFtZShmdW5jdGlvbiBTbGlkZXJWZXJ0aWNhbDIocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICAgIGNvbnN0IHtcbiAgICAgIG1pbixcbiAgICAgIG1heCxcbiAgICAgIGludmVydGVkLFxuICAgICAgb25TbGlkZVN0YXJ0LFxuICAgICAgb25TbGlkZU1vdmUsXG4gICAgICBvblNsaWRlRW5kLFxuICAgICAgb25TdGVwS2V5RG93bixcbiAgICAgIC4uLnNsaWRlclByb3BzXG4gICAgfSA9IHByb3BzO1xuICAgIGNvbnN0IHNsaWRlclJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgICBjb25zdCByZWYgPSB1c2VDb21wb3NlZFJlZnMoZm9yd2FyZGVkUmVmLCBzbGlkZXJSZWYpO1xuICAgIGNvbnN0IHJlY3RSZWYgPSBSZWFjdC51c2VSZWYodm9pZCAwKTtcbiAgICBjb25zdCBpc1NsaWRpbmdGcm9tQm90dG9tID0gIWludmVydGVkO1xuICAgIGZ1bmN0aW9uIGdldFZhbHVlRnJvbVBvaW50ZXIocG9pbnRlclBvc2l0aW9uKSB7XG4gICAgICBjb25zdCByZWN0ID0gcmVjdFJlZi5jdXJyZW50IHx8IHNsaWRlclJlZi5jdXJyZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgICAgY29uc3QgaW5wdXQgPSBbMCwgcmVjdC5oZWlnaHRdO1xuICAgICAgY29uc3Qgb3V0cHV0ID0gaXNTbGlkaW5nRnJvbUJvdHRvbSA/IFttYXgsIG1pbl0gOiBbbWluLCBtYXhdO1xuICAgICAgY29uc3QgdmFsdWUgPSBsaW5lYXJTY2FsZShpbnB1dCwgb3V0cHV0KTtcbiAgICAgIHJlY3RSZWYuY3VycmVudCA9IHJlY3Q7XG4gICAgICByZXR1cm4gdmFsdWUocG9pbnRlclBvc2l0aW9uIC0gcmVjdC50b3ApO1xuICAgIH1cbiAgICBfX25hbWUoZ2V0VmFsdWVGcm9tUG9pbnRlciwgXCJnZXRWYWx1ZUZyb21Qb2ludGVyXCIpO1xuICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFxuICAgICAgU2xpZGVyT3JpZW50YXRpb25Qcm92aWRlcixcbiAgICAgIHtcbiAgICAgICAgc2NvcGU6IHByb3BzLl9fc2NvcGVTbGlkZXIsXG4gICAgICAgIHN0YXJ0RWRnZTogaXNTbGlkaW5nRnJvbUJvdHRvbSA/IFwiYm90dG9tXCIgOiBcInRvcFwiLFxuICAgICAgICBlbmRFZGdlOiBpc1NsaWRpbmdGcm9tQm90dG9tID8gXCJ0b3BcIiA6IFwiYm90dG9tXCIsXG4gICAgICAgIHNpemU6IFwiaGVpZ2h0XCIsXG4gICAgICAgIGRpcmVjdGlvbjogaXNTbGlkaW5nRnJvbUJvdHRvbSA/IDEgOiAtMSxcbiAgICAgICAgY2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBqc3goXG4gICAgICAgICAgU2xpZGVySW1wbCxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBcImRhdGEtb3JpZW50YXRpb25cIjogXCJ2ZXJ0aWNhbFwiLFxuICAgICAgICAgICAgLi4uc2xpZGVyUHJvcHMsXG4gICAgICAgICAgICByZWYsXG4gICAgICAgICAgICBzdHlsZToge1xuICAgICAgICAgICAgICAuLi5zbGlkZXJQcm9wcy5zdHlsZSxcbiAgICAgICAgICAgICAgXCItLXJhZGl4LXNsaWRlci10aHVtYi10cmFuc2Zvcm1cIjogXCJ0cmFuc2xhdGVZKDUwJSlcIlxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIG9uU2xpZGVTdGFydDogKGV2ZW50KSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gZ2V0VmFsdWVGcm9tUG9pbnRlcihldmVudC5jbGllbnRZKTtcbiAgICAgICAgICAgICAgb25TbGlkZVN0YXJ0Py4odmFsdWUpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIG9uU2xpZGVNb3ZlOiAoZXZlbnQpID0+IHtcbiAgICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBnZXRWYWx1ZUZyb21Qb2ludGVyKGV2ZW50LmNsaWVudFkpO1xuICAgICAgICAgICAgICBvblNsaWRlTW92ZT8uKHZhbHVlKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBvblNsaWRlRW5kOiAoKSA9PiB7XG4gICAgICAgICAgICAgIHJlY3RSZWYuY3VycmVudCA9IHZvaWQgMDtcbiAgICAgICAgICAgICAgb25TbGlkZUVuZD8uKCk7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgb25TdGVwS2V5RG93bjogKGV2ZW50KSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IHNsaWRlRGlyZWN0aW9uID0gaXNTbGlkaW5nRnJvbUJvdHRvbSA/IFwiZnJvbS1ib3R0b21cIiA6IFwiZnJvbS10b3BcIjtcbiAgICAgICAgICAgICAgY29uc3QgaXNCYWNrS2V5ID0gQkFDS19LRVlTW3NsaWRlRGlyZWN0aW9uXS5pbmNsdWRlcyhldmVudC5rZXkpO1xuICAgICAgICAgICAgICBvblN0ZXBLZXlEb3duPy4oeyBldmVudCwgZGlyZWN0aW9uOiBpc0JhY2tLZXkgPyAtMSA6IDEgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICApXG4gICAgICB9XG4gICAgKTtcbiAgfSwgXCJTbGlkZXJWZXJ0aWNhbFwiKVxuKTtcbnZhciBTbGlkZXJJbXBsID0gLyogQF9fUFVSRV9fICovIFJlYWN0LmZvcndhcmRSZWYoXG4gIC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoZnVuY3Rpb24gU2xpZGVySW1wbDIocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICAgIGNvbnN0IHtcbiAgICAgIF9fc2NvcGVTbGlkZXIsXG4gICAgICBvblNsaWRlU3RhcnQsXG4gICAgICBvblNsaWRlTW92ZSxcbiAgICAgIG9uU2xpZGVFbmQsXG4gICAgICBvbkhvbWVLZXlEb3duLFxuICAgICAgb25FbmRLZXlEb3duLFxuICAgICAgb25TdGVwS2V5RG93bixcbiAgICAgIC4uLnNsaWRlclByb3BzXG4gICAgfSA9IHByb3BzO1xuICAgIGNvbnN0IGNvbnRleHQgPSB1c2VTbGlkZXJDb250ZXh0KFNMSURFUl9OQU1FLCBfX3Njb3BlU2xpZGVyKTtcbiAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChcbiAgICAgIFByaW1pdGl2ZS5zcGFuLFxuICAgICAge1xuICAgICAgICAuLi5zbGlkZXJQcm9wcyxcbiAgICAgICAgcmVmOiBmb3J3YXJkZWRSZWYsXG4gICAgICAgIG9uS2V5RG93bjogY29tcG9zZUV2ZW50SGFuZGxlcnMocHJvcHMub25LZXlEb3duLCAoZXZlbnQpID0+IHtcbiAgICAgICAgICBpZiAoZXZlbnQua2V5ID09PSBcIkhvbWVcIikge1xuICAgICAgICAgICAgb25Ib21lS2V5RG93bihldmVudCk7XG4gICAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIH0gZWxzZSBpZiAoZXZlbnQua2V5ID09PSBcIkVuZFwiKSB7XG4gICAgICAgICAgICBvbkVuZEtleURvd24oZXZlbnQpO1xuICAgICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKFBBR0VfS0VZUy5jb25jYXQoQVJST1dfS0VZUykuaW5jbHVkZXMoZXZlbnQua2V5KSkge1xuICAgICAgICAgICAgb25TdGVwS2V5RG93bihldmVudCk7XG4gICAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSksXG4gICAgICAgIG9uUG9pbnRlckRvd246IGNvbXBvc2VFdmVudEhhbmRsZXJzKHByb3BzLm9uUG9pbnRlckRvd24sIChldmVudCkgPT4ge1xuICAgICAgICAgIGNvbnN0IHRhcmdldCA9IGV2ZW50LnRhcmdldDtcbiAgICAgICAgICB0YXJnZXQuc2V0UG9pbnRlckNhcHR1cmUoZXZlbnQucG9pbnRlcklkKTtcbiAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIGlmIChjb250ZXh0LnRodW1icy5oYXModGFyZ2V0KSkge1xuICAgICAgICAgICAgdGFyZ2V0LmZvY3VzKHsgcHJldmVudFNjcm9sbDogdHJ1ZSwgZm9jdXNWaXNpYmxlOiBmYWxzZSB9KTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgb25TbGlkZVN0YXJ0KGV2ZW50KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pLFxuICAgICAgICBvblBvaW50ZXJNb3ZlOiBjb21wb3NlRXZlbnRIYW5kbGVycyhwcm9wcy5vblBvaW50ZXJNb3ZlLCAoZXZlbnQpID0+IHtcbiAgICAgICAgICBjb25zdCB0YXJnZXQgPSBldmVudC50YXJnZXQ7XG4gICAgICAgICAgaWYgKHRhcmdldC5oYXNQb2ludGVyQ2FwdHVyZShldmVudC5wb2ludGVySWQpKSBvblNsaWRlTW92ZShldmVudCk7XG4gICAgICAgIH0pLFxuICAgICAgICBvblBvaW50ZXJVcDogY29tcG9zZUV2ZW50SGFuZGxlcnMocHJvcHMub25Qb2ludGVyVXAsIChldmVudCkgPT4ge1xuICAgICAgICAgIGNvbnN0IHRhcmdldCA9IGV2ZW50LnRhcmdldDtcbiAgICAgICAgICBpZiAodGFyZ2V0Lmhhc1BvaW50ZXJDYXB0dXJlKGV2ZW50LnBvaW50ZXJJZCkpIHtcbiAgICAgICAgICAgIHRhcmdldC5yZWxlYXNlUG9pbnRlckNhcHR1cmUoZXZlbnQucG9pbnRlcklkKTtcbiAgICAgICAgICAgIG9uU2xpZGVFbmQoZXZlbnQpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSlcbiAgICAgIH1cbiAgICApO1xuICB9LCBcIlNsaWRlckltcGxcIilcbik7XG52YXIgVFJBQ0tfTkFNRSA9IFwiU2xpZGVyVHJhY2tcIjtcbnZhciBTbGlkZXJUcmFjayA9IC8qIEBfX1BVUkVfXyAqLyBSZWFjdC5mb3J3YXJkUmVmKFxuICAvKiBAX19QVVJFX18gKi8gX19uYW1lKGZ1bmN0aW9uIFNsaWRlclRyYWNrMihwcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gICAgY29uc3QgeyBfX3Njb3BlU2xpZGVyLCAuLi50cmFja1Byb3BzIH0gPSBwcm9wcztcbiAgICBjb25zdCBjb250ZXh0ID0gdXNlU2xpZGVyQ29udGV4dChUUkFDS19OQU1FLCBfX3Njb3BlU2xpZGVyKTtcbiAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChcbiAgICAgIFByaW1pdGl2ZS5zcGFuLFxuICAgICAge1xuICAgICAgICBcImRhdGEtZGlzYWJsZWRcIjogY29udGV4dC5kaXNhYmxlZCA/IFwiXCIgOiB2b2lkIDAsXG4gICAgICAgIFwiZGF0YS1vcmllbnRhdGlvblwiOiBjb250ZXh0Lm9yaWVudGF0aW9uLFxuICAgICAgICAuLi50cmFja1Byb3BzLFxuICAgICAgICByZWY6IGZvcndhcmRlZFJlZlxuICAgICAgfVxuICAgICk7XG4gIH0sIFwiU2xpZGVyVHJhY2tcIilcbik7XG52YXIgUkFOR0VfTkFNRSA9IFwiU2xpZGVyUmFuZ2VcIjtcbnZhciBTbGlkZXJSYW5nZSA9IC8qIEBfX1BVUkVfXyAqLyBSZWFjdC5mb3J3YXJkUmVmKFxuICAvKiBAX19QVVJFX18gKi8gX19uYW1lKGZ1bmN0aW9uIFNsaWRlclJhbmdlMihwcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gICAgY29uc3QgeyBfX3Njb3BlU2xpZGVyLCAuLi5yYW5nZVByb3BzIH0gPSBwcm9wcztcbiAgICBjb25zdCBjb250ZXh0ID0gdXNlU2xpZGVyQ29udGV4dChSQU5HRV9OQU1FLCBfX3Njb3BlU2xpZGVyKTtcbiAgICBjb25zdCBvcmllbnRhdGlvbiA9IHVzZVNsaWRlck9yaWVudGF0aW9uQ29udGV4dChSQU5HRV9OQU1FLCBfX3Njb3BlU2xpZGVyKTtcbiAgICBjb25zdCByZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gICAgY29uc3QgY29tcG9zZWRSZWZzID0gdXNlQ29tcG9zZWRSZWZzKGZvcndhcmRlZFJlZiwgcmVmKTtcbiAgICBjb25zdCB2YWx1ZXNDb3VudCA9IGNvbnRleHQudmFsdWVzLmxlbmd0aDtcbiAgICBjb25zdCBwZXJjZW50YWdlcyA9IGNvbnRleHQudmFsdWVzLm1hcChcbiAgICAgICh2YWx1ZSkgPT4gY29udmVydFZhbHVlVG9QZXJjZW50YWdlKHZhbHVlLCBjb250ZXh0Lm1pbiwgY29udGV4dC5tYXgpXG4gICAgKTtcbiAgICBjb25zdCBvZmZzZXRTdGFydCA9IHZhbHVlc0NvdW50ID4gMSA/IE1hdGgubWluKC4uLnBlcmNlbnRhZ2VzKSA6IDA7XG4gICAgY29uc3Qgb2Zmc2V0RW5kID0gMTAwIC0gTWF0aC5tYXgoLi4ucGVyY2VudGFnZXMpO1xuICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFxuICAgICAgUHJpbWl0aXZlLnNwYW4sXG4gICAgICB7XG4gICAgICAgIFwiZGF0YS1vcmllbnRhdGlvblwiOiBjb250ZXh0Lm9yaWVudGF0aW9uLFxuICAgICAgICBcImRhdGEtZGlzYWJsZWRcIjogY29udGV4dC5kaXNhYmxlZCA/IFwiXCIgOiB2b2lkIDAsXG4gICAgICAgIC4uLnJhbmdlUHJvcHMsXG4gICAgICAgIHJlZjogY29tcG9zZWRSZWZzLFxuICAgICAgICBzdHlsZToge1xuICAgICAgICAgIC4uLnByb3BzLnN0eWxlLFxuICAgICAgICAgIFtvcmllbnRhdGlvbi5zdGFydEVkZ2VdOiBvZmZzZXRTdGFydCArIFwiJVwiLFxuICAgICAgICAgIFtvcmllbnRhdGlvbi5lbmRFZGdlXTogb2Zmc2V0RW5kICsgXCIlXCJcbiAgICAgICAgfVxuICAgICAgfVxuICAgICk7XG4gIH0sIFwiU2xpZGVyUmFuZ2VcIilcbik7XG52YXIgVEhVTUJfTkFNRSA9IFwiU2xpZGVyVGh1bWJcIjtcbnZhciBbU2xpZGVyVGh1bWJDb250ZXh0UHJvdmlkZXIsIHVzZVNsaWRlclRodW1iQ29udGV4dF0gPSBjcmVhdGVTbGlkZXJDb250ZXh0KFRIVU1CX05BTUUpO1xudmFyIFRIVU1CX1BST1ZJREVSX05BTUUgPSBcIlNsaWRlclRodW1iUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIFNsaWRlclRodW1iUHJvdmlkZXIocHJvcHMpIHtcbiAgY29uc3Qge1xuICAgIF9fc2NvcGVTbGlkZXIsXG4gICAgbmFtZSxcbiAgICBjaGlsZHJlbixcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yIGludGVybmFsIHJlbmRlciBwcm9wXG4gICAgaW50ZXJuYWxfZG9fbm90X3VzZV9yZW5kZXJcbiAgfSA9IHByb3BzO1xuICBjb25zdCBjb250ZXh0ID0gdXNlU2xpZGVyQ29udGV4dChUSFVNQl9QUk9WSURFUl9OQU1FLCBfX3Njb3BlU2xpZGVyKTtcbiAgY29uc3QgZ2V0SXRlbXMgPSB1c2VDb2xsZWN0aW9uKF9fc2NvcGVTbGlkZXIpO1xuICBjb25zdCBbdGh1bWIsIHNldFRodW1iXSA9IFJlYWN0LnVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBpbmRleCA9IFJlYWN0LnVzZU1lbW8oXG4gICAgKCkgPT4gdGh1bWIgPyBnZXRJdGVtcygpLmZpbmRJbmRleCgoaXRlbSkgPT4gaXRlbS5yZWYuY3VycmVudCA9PT0gdGh1bWIpIDogLTEsXG4gICAgW2dldEl0ZW1zLCB0aHVtYl1cbiAgKTtcbiAgY29uc3Qgc2l6ZSA9IHVzZVNpemUodGh1bWIpO1xuICBjb25zdCBpc0Zvcm1Db250cm9sID0gdGh1bWIgPyAhIWNvbnRleHQuZm9ybSB8fCAhIXRodW1iLmNsb3Nlc3QoXCJmb3JtXCIpIDogdHJ1ZTtcbiAgY29uc3QgdmFsdWUgPSBjb250ZXh0LnZhbHVlc1tpbmRleF07XG4gIGNvbnN0IHJlc29sdmVkTmFtZSA9IG5hbWUgPz8gKGNvbnRleHQubmFtZSA/IGNvbnRleHQubmFtZSArIChjb250ZXh0LnZhbHVlcy5sZW5ndGggPiAxID8gXCJbXVwiIDogXCJcIikgOiB2b2lkIDApO1xuICBjb25zdCBwZXJjZW50ID0gdmFsdWUgPT09IHZvaWQgMCA/IDAgOiBjb252ZXJ0VmFsdWVUb1BlcmNlbnRhZ2UodmFsdWUsIGNvbnRleHQubWluLCBjb250ZXh0Lm1heCk7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHRodW1iKSB7XG4gICAgICBjb250ZXh0LnRodW1icy5hZGQodGh1bWIpO1xuICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgY29udGV4dC50aHVtYnMuZGVsZXRlKHRodW1iKTtcbiAgICAgIH07XG4gICAgfVxuICB9LCBbdGh1bWIsIGNvbnRleHQudGh1bWJzXSk7XG4gIGNvbnN0IHRodW1iQ29udGV4dCA9IHtcbiAgICB2YWx1ZSxcbiAgICBuYW1lOiByZXNvbHZlZE5hbWUsXG4gICAgZm9ybTogY29udGV4dC5mb3JtLFxuICAgIGlzRm9ybUNvbnRyb2wsXG4gICAgaW5kZXgsXG4gICAgdGh1bWIsXG4gICAgb25UaHVtYkNoYW5nZTogc2V0VGh1bWIsXG4gICAgcGVyY2VudCxcbiAgICBzaXplXG4gIH07XG4gIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFNsaWRlclRodW1iQ29udGV4dFByb3ZpZGVyLCB7IHNjb3BlOiBfX3Njb3BlU2xpZGVyLCAuLi50aHVtYkNvbnRleHQsIGNoaWxkcmVuOiBpc0Z1bmN0aW9uKGludGVybmFsX2RvX25vdF91c2VfcmVuZGVyKSA/IGludGVybmFsX2RvX25vdF91c2VfcmVuZGVyKHRodW1iQ29udGV4dCkgOiBjaGlsZHJlbiB9KTtcbn1cbl9fbmFtZShTbGlkZXJUaHVtYlByb3ZpZGVyLCBcIlNsaWRlclRodW1iUHJvdmlkZXJcIik7XG52YXIgVEhVTUJfVFJJR0dFUl9OQU1FID0gXCJTbGlkZXJUaHVtYlRyaWdnZXJcIjtcbnZhciBTbGlkZXJUaHVtYlRyaWdnZXIgPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuZm9yd2FyZFJlZihcbiAgLy8gYmxhbmsgbGluZSB0byByZWR1Y2UgZGlmZiBub2lzZVxuICAvKiBAX19QVVJFX18gKi8gX19uYW1lKGZ1bmN0aW9uIFNsaWRlclRodW1iVHJpZ2dlcjIocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICAgIGNvbnN0IHsgX19zY29wZVNsaWRlciwgLi4udGh1bWJQcm9wcyB9ID0gcHJvcHM7XG4gICAgY29uc3QgY29udGV4dCA9IHVzZVNsaWRlckNvbnRleHQoVEhVTUJfVFJJR0dFUl9OQU1FLCBfX3Njb3BlU2xpZGVyKTtcbiAgICBjb25zdCBvcmllbnRhdGlvbiA9IHVzZVNsaWRlck9yaWVudGF0aW9uQ29udGV4dChUSFVNQl9UUklHR0VSX05BTUUsIF9fc2NvcGVTbGlkZXIpO1xuICAgIGNvbnN0IHsgaW5kZXgsIHZhbHVlLCBwZXJjZW50LCBzaXplLCBvblRodW1iQ2hhbmdlIH0gPSB1c2VTbGlkZXJUaHVtYkNvbnRleHQoXG4gICAgICBUSFVNQl9UUklHR0VSX05BTUUsXG4gICAgICBfX3Njb3BlU2xpZGVyXG4gICAgKTtcbiAgICBjb25zdCBjb21wb3NlZFJlZnMgPSB1c2VDb21wb3NlZFJlZnMoZm9yd2FyZGVkUmVmLCBvblRodW1iQ2hhbmdlKTtcbiAgICBjb25zdCBsYWJlbCA9IGdldExhYmVsKGluZGV4LCBjb250ZXh0LnZhbHVlcy5sZW5ndGgpO1xuICAgIGNvbnN0IG9yaWVudGF0aW9uU2l6ZSA9IHNpemU/LltvcmllbnRhdGlvbi5zaXplXTtcbiAgICBjb25zdCB0aHVtYkluQm91bmRzT2Zmc2V0ID0gb3JpZW50YXRpb25TaXplID8gZ2V0VGh1bWJJbkJvdW5kc09mZnNldChvcmllbnRhdGlvblNpemUsIHBlcmNlbnQsIG9yaWVudGF0aW9uLmRpcmVjdGlvbikgOiAwO1xuICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFxuICAgICAgXCJzcGFuXCIsXG4gICAgICB7XG4gICAgICAgIHN0eWxlOiB7XG4gICAgICAgICAgdHJhbnNmb3JtOiBcInZhcigtLXJhZGl4LXNsaWRlci10aHVtYi10cmFuc2Zvcm0pXCIsXG4gICAgICAgICAgcG9zaXRpb246IFwiYWJzb2x1dGVcIixcbiAgICAgICAgICBbb3JpZW50YXRpb24uc3RhcnRFZGdlXTogYGNhbGMoJHtwZXJjZW50fSUgKyAke3RodW1iSW5Cb3VuZHNPZmZzZXR9cHgpYFxuICAgICAgICB9LFxuICAgICAgICBjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGpzeChDb2xsZWN0aW9uLkl0ZW1TbG90LCB7IHNjb3BlOiBfX3Njb3BlU2xpZGVyLCBjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGpzeChcbiAgICAgICAgICBQcmltaXRpdmUuc3BhbixcbiAgICAgICAgICB7XG4gICAgICAgICAgICByb2xlOiBcInNsaWRlclwiLFxuICAgICAgICAgICAgXCJhcmlhLWxhYmVsXCI6IHByb3BzW1wiYXJpYS1sYWJlbFwiXSB8fCBsYWJlbCxcbiAgICAgICAgICAgIFwiYXJpYS12YWx1ZW1pblwiOiBjb250ZXh0Lm1pbixcbiAgICAgICAgICAgIFwiYXJpYS12YWx1ZW5vd1wiOiB2YWx1ZSxcbiAgICAgICAgICAgIFwiYXJpYS12YWx1ZW1heFwiOiBjb250ZXh0Lm1heCxcbiAgICAgICAgICAgIFwiYXJpYS1vcmllbnRhdGlvblwiOiBjb250ZXh0Lm9yaWVudGF0aW9uLFxuICAgICAgICAgICAgXCJkYXRhLW9yaWVudGF0aW9uXCI6IGNvbnRleHQub3JpZW50YXRpb24sXG4gICAgICAgICAgICBcImRhdGEtZGlzYWJsZWRcIjogY29udGV4dC5kaXNhYmxlZCA/IFwiXCIgOiB2b2lkIDAsXG4gICAgICAgICAgICB0YWJJbmRleDogY29udGV4dC5kaXNhYmxlZCA/IHZvaWQgMCA6IDAsXG4gICAgICAgICAgICAuLi50aHVtYlByb3BzLFxuICAgICAgICAgICAgcmVmOiBjb21wb3NlZFJlZnMsXG4gICAgICAgICAgICBzdHlsZTogdmFsdWUgPT09IHZvaWQgMCA/IHsgZGlzcGxheTogXCJub25lXCIgfSA6IHByb3BzLnN0eWxlLFxuICAgICAgICAgICAgb25Gb2N1czogY29tcG9zZUV2ZW50SGFuZGxlcnMocHJvcHMub25Gb2N1cywgKCkgPT4ge1xuICAgICAgICAgICAgICBjb250ZXh0LnZhbHVlSW5kZXhUb0NoYW5nZVJlZi5jdXJyZW50ID0gaW5kZXg7XG4gICAgICAgICAgICB9KVxuICAgICAgICAgIH1cbiAgICAgICAgKSB9KVxuICAgICAgfVxuICAgICk7XG4gIH0sIFwiU2xpZGVyVGh1bWJUcmlnZ2VyXCIpXG4pO1xudmFyIFNsaWRlclRodW1iID0gLyogQF9fUFVSRV9fICovIFJlYWN0LmZvcndhcmRSZWYoXG4gIC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoZnVuY3Rpb24gU2xpZGVyVGh1bWIyKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgICBjb25zdCB7IF9fc2NvcGVTbGlkZXIsIG5hbWUsIC4uLnRodW1iUHJvcHMgfSA9IHByb3BzO1xuICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFxuICAgICAgU2xpZGVyVGh1bWJQcm92aWRlcixcbiAgICAgIHtcbiAgICAgICAgX19zY29wZVNsaWRlcixcbiAgICAgICAgbmFtZSxcbiAgICAgICAgaW50ZXJuYWxfZG9fbm90X3VzZV9yZW5kZXI6ICh7IGluZGV4LCBpc0Zvcm1Db250cm9sIH0pID0+IC8qIEBfX1BVUkVfXyAqLyBqc3hzKEZyYWdtZW50LCB7IGNoaWxkcmVuOiBbXG4gICAgICAgICAgLyogQF9fUFVSRV9fICovIGpzeChcbiAgICAgICAgICAgIFNsaWRlclRodW1iVHJpZ2dlcixcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgLi4udGh1bWJQcm9wcyxcbiAgICAgICAgICAgICAgcmVmOiBmb3J3YXJkZWRSZWYsXG4gICAgICAgICAgICAgIF9fc2NvcGVTbGlkZXJcbiAgICAgICAgICAgIH1cbiAgICAgICAgICApLFxuICAgICAgICAgIGlzRm9ybUNvbnRyb2wgPyAvKiBAX19QVVJFX18gKi8ganN4KFxuICAgICAgICAgICAgU2xpZGVyQnViYmxlSW5wdXQsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIF9fc2NvcGVTbGlkZXJcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBpbmRleFxuICAgICAgICAgICkgOiBudWxsXG4gICAgICAgIF0gfSlcbiAgICAgIH1cbiAgICApO1xuICB9LCBcIlNsaWRlclRodW1iXCIpXG4pO1xudmFyIEJVQkJMRV9JTlBVVF9OQU1FID0gXCJTbGlkZXJCdWJibGVJbnB1dFwiO1xudmFyIFNsaWRlckJ1YmJsZUlucHV0ID0gLyogQF9fUFVSRV9fICovIFJlYWN0LmZvcndhcmRSZWYoXG4gIC8vIGJsYW5rIGxpbmUgdG8gcmVkdWNlIGRpZmYgbm9pc2VcbiAgLyogQF9fUFVSRV9fICovIF9fbmFtZShmdW5jdGlvbiBTbGlkZXJCdWJibGVJbnB1dDIoeyBfX3Njb3BlU2xpZGVyLCBvbklucHV0LCAuLi5wcm9wcyB9LCBmb3J3YXJkZWRSZWYpIHtcbiAgICBjb25zdCB7IGluZGV4LCB2YWx1ZSwgbmFtZSwgZm9ybSB9ID0gdXNlU2xpZGVyVGh1bWJDb250ZXh0KEJVQkJMRV9JTlBVVF9OQU1FLCBfX3Njb3BlU2xpZGVyKTtcbiAgICBjb25zdCB7IHVzZXJSZXF1ZXN0ZWRWYWx1ZXMgfSA9IHVzZVNsaWRlckNvbnRleHQoQlVCQkxFX0lOUFVUX05BTUUsIF9fc2NvcGVTbGlkZXIpO1xuICAgIGNvbnN0IHJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgICBjb25zdCBjb21wb3NlZFJlZnMgPSB1c2VDb21wb3NlZFJlZnMocmVmLCBmb3J3YXJkZWRSZWYpO1xuICAgIGNvbnN0IHNob3VsZFN0b3BJbnB1dFByb3BhZ2F0aW9uUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgICBjb25zdCBwcmV2VmFsdWVSZWYgPSBSZWFjdC51c2VSZWYodmFsdWUpO1xuICAgIGNvbnN0IGhhbmRsZWRVc2VyUmVxdWVzdGVkVmFsdWVzUmVmID0gUmVhY3QudXNlUmVmKHVzZXJSZXF1ZXN0ZWRWYWx1ZXMpO1xuICAgIGNvbnN0IHByZXZVc2VyUmVxdWVzdGVkVmFsdWVzUmVmID0gUmVhY3QudXNlUmVmKHVzZXJSZXF1ZXN0ZWRWYWx1ZXMpO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICBjb25zdCBpbnB1dCA9IHJlZi5jdXJyZW50O1xuICAgICAgaWYgKCFpbnB1dCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCBpbnB1dFByb3RvID0gd2luZG93LkhUTUxJbnB1dEVsZW1lbnQucHJvdG90eXBlO1xuICAgICAgY29uc3QgZGVzY3JpcHRvciA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoaW5wdXRQcm90bywgXCJ2YWx1ZVwiKTtcbiAgICAgIGNvbnN0IHNldFZhbHVlID0gZGVzY3JpcHRvci5zZXQ7XG4gICAgICBjb25zdCBwcmV2VmFsdWUgPSBwcmV2VmFsdWVSZWYuY3VycmVudDtcbiAgICAgIGNvbnN0IHZhbHVlQ2hhbmdlZCA9IHByZXZWYWx1ZSAhPT0gdmFsdWU7XG4gICAgICBwcmV2VmFsdWVSZWYuY3VycmVudCA9IHZhbHVlO1xuICAgICAgY29uc3QgaXNVc2VyUmVxdWVzdEZyb21UaGlzUmVuZGVyID0gdXNlclJlcXVlc3RlZFZhbHVlcyAhPT0gcHJldlVzZXJSZXF1ZXN0ZWRWYWx1ZXNSZWYuY3VycmVudDtcbiAgICAgIHByZXZVc2VyUmVxdWVzdGVkVmFsdWVzUmVmLmN1cnJlbnQgPSB1c2VyUmVxdWVzdGVkVmFsdWVzO1xuICAgICAgaWYgKHZhbHVlQ2hhbmdlZCAmJiBzZXRWYWx1ZSkge1xuICAgICAgICBjb25zdCBoYXNVbmhhbmRsZWRVc2VyUmVxdWVzdCA9IHVzZXJSZXF1ZXN0ZWRWYWx1ZXMgIT09IGhhbmRsZWRVc2VyUmVxdWVzdGVkVmFsdWVzUmVmLmN1cnJlbnQ7XG4gICAgICAgIGhhbmRsZWRVc2VyUmVxdWVzdGVkVmFsdWVzUmVmLmN1cnJlbnQgPSB1c2VyUmVxdWVzdGVkVmFsdWVzO1xuICAgICAgICBjb25zdCByZXF1ZXN0ZWRWYWx1ZSA9IHVzZXJSZXF1ZXN0ZWRWYWx1ZXM/LltpbmRleF07XG4gICAgICAgIGNvbnN0IGlzVXNlckludGVyYWN0aW9uID0gaGFzVW5oYW5kbGVkVXNlclJlcXVlc3QgJiYgKGlzVXNlclJlcXVlc3RGcm9tVGhpc1JlbmRlciAmJiByZXF1ZXN0ZWRWYWx1ZSAhPT0gcHJldlZhbHVlIHx8IHJlcXVlc3RlZFZhbHVlID09PSB2YWx1ZSk7XG4gICAgICAgIHNob3VsZFN0b3BJbnB1dFByb3BhZ2F0aW9uUmVmLmN1cnJlbnQgPSAhaXNVc2VySW50ZXJhY3Rpb247XG4gICAgICAgIGNvbnN0IGV2ZW50ID0gbmV3IEV2ZW50KFwiaW5wdXRcIiwgeyBidWJibGVzOiB0cnVlIH0pO1xuICAgICAgICBzZXRWYWx1ZS5jYWxsKGlucHV0LCB2YWx1ZSk7XG4gICAgICAgIGlucHV0LmRpc3BhdGNoRXZlbnQoZXZlbnQpO1xuICAgICAgICBzaG91bGRTdG9wSW5wdXRQcm9wYWdhdGlvblJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICB9XG4gICAgfSwgW2luZGV4LCB2YWx1ZSwgdXNlclJlcXVlc3RlZFZhbHVlc10pO1xuICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFxuICAgICAgUHJpbWl0aXZlLmlucHV0LFxuICAgICAge1xuICAgICAgICBzdHlsZTogeyBkaXNwbGF5OiBcIm5vbmVcIiB9LFxuICAgICAgICBuYW1lLFxuICAgICAgICBmb3JtLFxuICAgICAgICAuLi5wcm9wcyxcbiAgICAgICAgcmVmOiBjb21wb3NlZFJlZnMsXG4gICAgICAgIGRlZmF1bHRWYWx1ZTogdmFsdWUsXG4gICAgICAgIG9uSW5wdXQ6IGNvbXBvc2VFdmVudEhhbmRsZXJzKG9uSW5wdXQsIChldmVudCkgPT4ge1xuICAgICAgICAgIGlmIChzaG91bGRTdG9wSW5wdXRQcm9wYWdhdGlvblJlZi5jdXJyZW50KSB7XG4gICAgICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pXG4gICAgICB9XG4gICAgKTtcbiAgfSwgXCJTbGlkZXJCdWJibGVJbnB1dFwiKVxuKTtcbmZ1bmN0aW9uIGdldE5leHRTb3J0ZWRWYWx1ZXMocHJldlZhbHVlcyA9IFtdLCBuZXh0VmFsdWUsIGF0SW5kZXgpIHtcbiAgY29uc3QgbmV4dFZhbHVlcyA9IFsuLi5wcmV2VmFsdWVzXTtcbiAgbmV4dFZhbHVlc1thdEluZGV4XSA9IG5leHRWYWx1ZTtcbiAgcmV0dXJuIG5leHRWYWx1ZXMuc29ydCgoYSwgYikgPT4gYSAtIGIpO1xufVxuX19uYW1lKGdldE5leHRTb3J0ZWRWYWx1ZXMsIFwiZ2V0TmV4dFNvcnRlZFZhbHVlc1wiKTtcbmZ1bmN0aW9uIGNvbnZlcnRWYWx1ZVRvUGVyY2VudGFnZSh2YWx1ZSwgbWluLCBtYXgpIHtcbiAgY29uc3QgbWF4U3RlcHMgPSBtYXggLSBtaW47XG4gIGNvbnN0IHBlcmNlbnRQZXJTdGVwID0gMTAwIC8gbWF4U3RlcHM7XG4gIGNvbnN0IHBlcmNlbnRhZ2UgPSBwZXJjZW50UGVyU3RlcCAqICh2YWx1ZSAtIG1pbik7XG4gIHJldHVybiBjbGFtcChwZXJjZW50YWdlLCBbMCwgMTAwXSk7XG59XG5fX25hbWUoY29udmVydFZhbHVlVG9QZXJjZW50YWdlLCBcImNvbnZlcnRWYWx1ZVRvUGVyY2VudGFnZVwiKTtcbmZ1bmN0aW9uIGdldExhYmVsKGluZGV4LCB0b3RhbFZhbHVlcykge1xuICBpZiAodG90YWxWYWx1ZXMgPiAyKSB7XG4gICAgcmV0dXJuIGBWYWx1ZSAke2luZGV4ICsgMX0gb2YgJHt0b3RhbFZhbHVlc31gO1xuICB9IGVsc2UgaWYgKHRvdGFsVmFsdWVzID09PSAyKSB7XG4gICAgcmV0dXJuIFtcIk1pbmltdW1cIiwgXCJNYXhpbXVtXCJdW2luZGV4XTtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gdm9pZCAwO1xuICB9XG59XG5fX25hbWUoZ2V0TGFiZWwsIFwiZ2V0TGFiZWxcIik7XG5mdW5jdGlvbiBnZXRDbG9zZXN0VmFsdWVJbmRleCh2YWx1ZXMsIG5leHRWYWx1ZSkge1xuICBpZiAodmFsdWVzLmxlbmd0aCA9PT0gMSkgcmV0dXJuIDA7XG4gIGNvbnN0IGRpc3RhbmNlcyA9IHZhbHVlcy5tYXAoKHZhbHVlKSA9PiBNYXRoLmFicyh2YWx1ZSAtIG5leHRWYWx1ZSkpO1xuICBjb25zdCBjbG9zZXN0RGlzdGFuY2UgPSBNYXRoLm1pbiguLi5kaXN0YW5jZXMpO1xuICByZXR1cm4gZGlzdGFuY2VzLmluZGV4T2YoY2xvc2VzdERpc3RhbmNlKTtcbn1cbl9fbmFtZShnZXRDbG9zZXN0VmFsdWVJbmRleCwgXCJnZXRDbG9zZXN0VmFsdWVJbmRleFwiKTtcbmZ1bmN0aW9uIGdldFRodW1iSW5Cb3VuZHNPZmZzZXQod2lkdGgsIGxlZnQsIGRpcmVjdGlvbikge1xuICBjb25zdCBoYWxmV2lkdGggPSB3aWR0aCAvIDI7XG4gIGNvbnN0IGhhbGZQZXJjZW50ID0gNTA7XG4gIGNvbnN0IG9mZnNldCA9IGxpbmVhclNjYWxlKFswLCBoYWxmUGVyY2VudF0sIFswLCBoYWxmV2lkdGhdKTtcbiAgcmV0dXJuIChoYWxmV2lkdGggLSBvZmZzZXQobGVmdCkgKiBkaXJlY3Rpb24pICogZGlyZWN0aW9uO1xufVxuX19uYW1lKGdldFRodW1iSW5Cb3VuZHNPZmZzZXQsIFwiZ2V0VGh1bWJJbkJvdW5kc09mZnNldFwiKTtcbmZ1bmN0aW9uIGdldFN0ZXBzQmV0d2VlblZhbHVlcyh2YWx1ZXMpIHtcbiAgcmV0dXJuIHZhbHVlcy5zbGljZSgwLCAtMSkubWFwKCh2YWx1ZSwgaW5kZXgpID0+IHZhbHVlc1tpbmRleCArIDFdIC0gdmFsdWUpO1xufVxuX19uYW1lKGdldFN0ZXBzQmV0d2VlblZhbHVlcywgXCJnZXRTdGVwc0JldHdlZW5WYWx1ZXNcIik7XG5mdW5jdGlvbiBoYXNNaW5TdGVwc0JldHdlZW5WYWx1ZXModmFsdWVzLCBtaW5TdGVwc0JldHdlZW5WYWx1ZXMpIHtcbiAgaWYgKG1pblN0ZXBzQmV0d2VlblZhbHVlcyA+IDApIHtcbiAgICBjb25zdCBzdGVwc0JldHdlZW5WYWx1ZXMgPSBnZXRTdGVwc0JldHdlZW5WYWx1ZXModmFsdWVzKTtcbiAgICBjb25zdCBhY3R1YWxNaW5TdGVwc0JldHdlZW5WYWx1ZXMgPSBNYXRoLm1pbiguLi5zdGVwc0JldHdlZW5WYWx1ZXMpO1xuICAgIHJldHVybiBhY3R1YWxNaW5TdGVwc0JldHdlZW5WYWx1ZXMgPj0gbWluU3RlcHNCZXR3ZWVuVmFsdWVzO1xuICB9XG4gIHJldHVybiB0cnVlO1xufVxuX19uYW1lKGhhc01pblN0ZXBzQmV0d2VlblZhbHVlcywgXCJoYXNNaW5TdGVwc0JldHdlZW5WYWx1ZXNcIik7XG5mdW5jdGlvbiBsaW5lYXJTY2FsZShpbnB1dCwgb3V0cHV0KSB7XG4gIHJldHVybiAodmFsdWUpID0+IHtcbiAgICBpZiAoaW5wdXRbMF0gPT09IGlucHV0WzFdIHx8IG91dHB1dFswXSA9PT0gb3V0cHV0WzFdKSByZXR1cm4gb3V0cHV0WzBdO1xuICAgIGNvbnN0IHJhdGlvID0gKG91dHB1dFsxXSAtIG91dHB1dFswXSkgLyAoaW5wdXRbMV0gLSBpbnB1dFswXSk7XG4gICAgcmV0dXJuIG91dHB1dFswXSArIHJhdGlvICogKHZhbHVlIC0gaW5wdXRbMF0pO1xuICB9O1xufVxuX19uYW1lKGxpbmVhclNjYWxlLCBcImxpbmVhclNjYWxlXCIpO1xuZnVuY3Rpb24gZ2V0RGVjaW1hbENvdW50KHZhbHVlKSB7XG4gIGlmICghTnVtYmVyLmlzRmluaXRlKHZhbHVlKSkgcmV0dXJuIDA7XG4gIGNvbnN0IHN0ciA9IHZhbHVlLnRvU3RyaW5nKCk7XG4gIGlmIChzdHIuaW5jbHVkZXMoXCJlXCIpKSB7XG4gICAgY29uc3QgW2NvZWZmaWNpZW50LCBleHBvbmVudF0gPSBzdHIuc3BsaXQoXCJlXCIpO1xuICAgIGNvbnN0IGRlY2ltYWxQYXJ0MiA9IGNvZWZmaWNpZW50LnNwbGl0KFwiLlwiKVsxXSB8fCBcIlwiO1xuICAgIGNvbnN0IGV4cG9uZW50TnVtID0gTnVtYmVyKGV4cG9uZW50KTtcbiAgICByZXR1cm4gTWF0aC5tYXgoMCwgZGVjaW1hbFBhcnQyLmxlbmd0aCAtIGV4cG9uZW50TnVtKTtcbiAgfVxuICBjb25zdCBkZWNpbWFsUGFydCA9IHN0ci5zcGxpdChcIi5cIilbMV07XG4gIHJldHVybiBkZWNpbWFsUGFydCA/IGRlY2ltYWxQYXJ0Lmxlbmd0aCA6IDA7XG59XG5fX25hbWUoZ2V0RGVjaW1hbENvdW50LCBcImdldERlY2ltYWxDb3VudFwiKTtcbmZ1bmN0aW9uIHJvdW5kVmFsdWUodmFsdWUsIGRlY2ltYWxDb3VudCkge1xuICBjb25zdCByb3VuZGVyID0gTWF0aC5wb3coMTAsIGRlY2ltYWxDb3VudCk7XG4gIHJldHVybiBNYXRoLnJvdW5kKHZhbHVlICogcm91bmRlcikgLyByb3VuZGVyO1xufVxuX19uYW1lKHJvdW5kVmFsdWUsIFwicm91bmRWYWx1ZVwiKTtcbmZ1bmN0aW9uIGdldE5leHRTdGVwVmFsdWUodmFsdWUsIHtcbiAgbWluLFxuICBzdGVwLFxuICBkaXJlY3Rpb24sXG4gIG11bHRpcGxpZXJcbn0pIHtcbiAgY29uc3QgZGVjaW1hbENvdW50ID0gZ2V0RGVjaW1hbENvdW50KHN0ZXApO1xuICBjb25zdCBzdGVwc0Zyb21NaW4gPSAodmFsdWUgLSBtaW4pIC8gc3RlcDtcbiAgY29uc3QgbmVhcmVzdFN0ZXBzID0gTWF0aC5yb3VuZChzdGVwc0Zyb21NaW4pO1xuICBjb25zdCBpc0FsaWduZWQgPSByb3VuZFZhbHVlKG5lYXJlc3RTdGVwcyAqIHN0ZXAgKyBtaW4sIGRlY2ltYWxDb3VudCkgPT09IHJvdW5kVmFsdWUodmFsdWUsIGRlY2ltYWxDb3VudCk7XG4gIGxldCBuZXh0U3RlcHM7XG4gIGlmIChpc0FsaWduZWQpIHtcbiAgICBuZXh0U3RlcHMgPSBuZWFyZXN0U3RlcHMgKyBtdWx0aXBsaWVyICogZGlyZWN0aW9uO1xuICB9IGVsc2UgaWYgKGRpcmVjdGlvbiA+IDApIHtcbiAgICBuZXh0U3RlcHMgPSBNYXRoLmNlaWwoc3RlcHNGcm9tTWluKTtcbiAgfSBlbHNlIHtcbiAgICBuZXh0U3RlcHMgPSBNYXRoLmZsb29yKHN0ZXBzRnJvbU1pbik7XG4gIH1cbiAgcmV0dXJuIHJvdW5kVmFsdWUobmV4dFN0ZXBzICogc3RlcCArIG1pbiwgZGVjaW1hbENvdW50KTtcbn1cbl9fbmFtZShnZXROZXh0U3RlcFZhbHVlLCBcImdldE5leHRTdGVwVmFsdWVcIik7XG5mdW5jdGlvbiBpc0Z1bmN0aW9uKHZhbHVlKSB7XG4gIHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwiZnVuY3Rpb25cIjtcbn1cbl9fbmFtZShpc0Z1bmN0aW9uLCBcImlzRnVuY3Rpb25cIik7XG5leHBvcnQge1xuICBTbGlkZXJSYW5nZSBhcyBSYW5nZSxcbiAgU2xpZGVyIGFzIFJvb3QsXG4gIFNsaWRlcixcbiAgU2xpZGVyUmFuZ2UsXG4gIFNsaWRlclRodW1iLFxuICBTbGlkZXJUcmFjayxcbiAgU2xpZGVyVGh1bWIgYXMgVGh1bWIsXG4gIFNsaWRlclRyYWNrIGFzIFRyYWNrLFxuICBjcmVhdGVTbGlkZXJTY29wZSxcbiAgU2xpZGVyQnViYmxlSW5wdXQgYXMgdW5zdGFibGVfQnViYmxlSW5wdXQsXG4gIFNsaWRlckJ1YmJsZUlucHV0IGFzIHVuc3RhYmxlX1NsaWRlckJ1YmJsZUlucHV0LFxuICBTbGlkZXJUaHVtYlByb3ZpZGVyIGFzIHVuc3RhYmxlX1NsaWRlclRodW1iUHJvdmlkZXIsXG4gIFNsaWRlclRodW1iVHJpZ2dlciBhcyB1bnN0YWJsZV9TbGlkZXJUaHVtYlRyaWdnZXIsXG4gIFNsaWRlclRodW1iUHJvdmlkZXIgYXMgdW5zdGFibGVfVGh1bWJQcm92aWRlcixcbiAgU2xpZGVyVGh1bWJUcmlnZ2VyIGFzIHVuc3RhYmxlX1RodW1iVHJpZ2dlclxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4Lm1qcy5tYXBcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBLElBQUlBLGNBQVksT0FBTztBQUN2QixJQUFJQyxZQUFVLFFBQVEsVUFBVUQsWUFBVSxRQUFRLFFBQVE7Q0FBRTtDQUFPLGNBQWM7QUFBSyxDQUFDO0FBR3ZGLFNBQVMsTUFBTSxPQUFPLENBQUMsS0FBSyxNQUFNO0NBQ2hDLE9BQU8sS0FBSyxJQUFJLEtBQUssS0FBSyxJQUFJLEtBQUssS0FBSyxDQUFDO0FBQzNDO0FBQ0FDLFNBQU8sT0FBTyxPQUFPOzs7Ozs7Ozs7QUNOckIsSUFBSUMsY0FBWSxPQUFPO0FBQ3ZCLElBQUlDLFlBQVUsUUFBUSxVQUFVRCxZQUFVLFFBQVEsUUFBUTtDQUFFO0NBQU8sY0FBYztBQUFLLENBQUM7QUFLdkYsSUFBSUUsY0FBWTtDQUNkLEtBQUs7Q0FDTCxLQUFLO0FBQ1A7QUFDQSxJQUFJLG1CQUFBLGFBQXlCLGNBQWMsS0FBSyxDQUFDO0FBQ2pELElBQUksb0JBQW9DLDBCQUFRLFVBQVU7Q0FDeEQsTUFBTSxFQUFFLEtBQUssYUFBYTtDQUMxQixPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxpQkFBaUIsVUFBVTtFQUFFLE9BQU87RUFBSztDQUFTLENBQUM7QUFDaEYsR0FBRyxtQkFBbUI7QUFDdEIsU0FBUyxhQUFhLFVBQVU7Q0FDOUIsTUFBTSxZQUFBLGFBQWtCLFdBQVcsZ0JBQWdCO0NBQ25ELE9BQU8sWUFBWSxhQUFhQSxZQUFVO0FBQzVDO0FBQ0FELFNBQU8sY0FBYyxjQUFjOzs7QUNwQm5DLElBQUlFLGNBQVksT0FBTztBQUN2QixJQUFJQyxZQUFVLFFBQVEsVUFBVUQsWUFBVSxRQUFRLFFBQVE7Q0FBRTtDQUFPLGNBQWM7QUFBSyxDQUFDO0FBS3ZGLFNBQVMsUUFBUSxTQUFTO0NBQ3hCLE1BQU0sQ0FBQyxNQUFNLFdBQUEsYUFBaUIsU0FBUyxLQUFLLENBQUM7Q0FDN0MsdUJBQXNCO0VBQ3BCLElBQUksU0FBUztHQUNYLFFBQVE7SUFBRSxPQUFPLFFBQVE7SUFBYSxRQUFRLFFBQVE7R0FBYSxDQUFDO0dBQ3BFLElBQUksTUFBTTtHQUNWLE1BQU0saUJBQWlCLElBQUksZ0JBQWdCLFlBQVk7SUFDckQsSUFBSSxDQUFDLE1BQU0sUUFBUSxPQUFPLEdBQ3hCO0lBRUYsSUFBSSxDQUFDLFFBQVEsUUFDWDtJQUVGLE1BQU0sUUFBUSxRQUFRO0lBQ3RCLE9BQU8scUJBQXFCLEdBQUc7SUFDL0IsTUFBTSxPQUFPLDRCQUE0QjtLQUN2QyxJQUFJO0tBQ0osSUFBSTtLQUNKLElBQUksbUJBQW1CLE9BQU87TUFDNUIsTUFBTSxrQkFBa0IsTUFBTTtNQUM5QixNQUFNLGFBQWEsTUFBTSxRQUFRLGVBQWUsSUFBSSxnQkFBZ0IsS0FBSztNQUN6RSxRQUFRLFdBQVc7TUFDbkIsU0FBUyxXQUFXO0tBQ3RCLE9BQU87TUFDTCxRQUFRLFFBQVE7TUFDaEIsU0FBUyxRQUFRO0tBQ25CO0tBQ0EsUUFBUTtNQUFFO01BQU87S0FBTyxDQUFDO0lBQzNCLENBQUM7R0FDSCxDQUFDO0dBQ0QsZUFBZSxRQUFRLFNBQVMsRUFBRSxLQUFLLGFBQWEsQ0FBQztHQUNyRCxhQUFhO0lBQ1gsT0FBTyxxQkFBcUIsR0FBRztJQUMvQixlQUFlLFVBQVUsT0FBTztHQUNsQztFQUNGLE9BQ0UsUUFBUSxLQUFLLENBQUM7Q0FFbEIsR0FBRyxDQUFDLE9BQU8sQ0FBQztDQUNaLE9BQU87QUFDVDtBQUNBQyxTQUFPLFNBQVMsU0FBUzs7O0FDOUN6QixJQUFJQyxjQUFZLE9BQU87QUFDdkIsSUFBSUMsWUFBVSxRQUFRLFVBQVVELFlBQVUsUUFBUSxRQUFRO0NBQUU7Q0FBTyxjQUFjO0FBQUssQ0FBQzs7QUFTdkYsU0FBUyxpQkFBaUIsTUFBTTtDQUM5QixNQUFNLGdCQUFnQixPQUFPO0NBQzdCLE1BQU0sQ0FBQyx5QkFBeUIseUJBQXlCLG1CQUFtQixhQUFhO0NBQ3pGLE1BQU0sQ0FBQyx3QkFBd0Isd0JBQXdCLHdCQUNyRCxlQUNBO0VBQUUsZUFBZSxFQUFFLFNBQVMsS0FBSztFQUFHLHlCQUF5QixJQUFJLElBQUk7Q0FBRSxDQUN6RTtDQUNBLE1BQU0scUJBQXFDLDBCQUFRLFVBQVU7RUFDM0QsTUFBTSxFQUFFLE9BQU8sYUFBYTtFQUM1QixNQUFNLE1BQUEsYUFBWSxPQUFPLElBQUk7RUFDN0IsTUFBTSxVQUFBLGFBQWdCLHVCQUF1QixJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7RUFDeEQsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksd0JBQXdCO0dBQUU7R0FBTztHQUFTLGVBQWU7R0FBSztFQUFTLENBQUM7Q0FDckcsR0FBRyxvQkFBb0I7Q0FDdkIsbUJBQW1CLGNBQWM7Q0FDakMsTUFBTSx1QkFBdUIsT0FBTztDQUNwQyxNQUFNLHFCQUFxQixXQUFXLG9CQUFvQjtDQUMxRCxNQUFNLGlCQUFBLGFBQXVCLFlBQzFCLE9BQU8saUJBQWlCO0VBQ3ZCLE1BQU0sRUFBRSxPQUFPLGFBQWE7RUFDNUIsTUFBTSxVQUFVLHFCQUFxQixzQkFBc0IsS0FBSztFQUNoRSxNQUFNLGVBQWUsZ0JBQWdCLGNBQWMsUUFBUSxhQUFhO0VBQ3hFLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLG9CQUFvQjtHQUFFLEtBQUs7R0FBYztFQUFTLENBQUM7Q0FDaEYsQ0FDRjtDQUNBLGVBQWUsY0FBYztDQUM3QixNQUFNLGlCQUFpQixPQUFPO0NBQzlCLE1BQU0saUJBQWlCO0NBQ3ZCLE1BQU0seUJBQXlCLFdBQVcsY0FBYztDQUN4RCxNQUFNLHFCQUFBLGFBQTJCLFlBQzlCLE9BQU8saUJBQWlCO0VBQ3ZCLE1BQU0sRUFBRSxPQUFPLFVBQVUsR0FBRyxhQUFhO0VBQ3pDLE1BQU0sTUFBQSxhQUFZLE9BQU8sSUFBSTtFQUM3QixNQUFNLGVBQWUsZ0JBQWdCLGNBQWMsR0FBRztFQUN0RCxNQUFNLFVBQVUscUJBQXFCLGdCQUFnQixLQUFLO0VBQzFELGFBQU0sZ0JBQWdCO0dBQ3BCLFFBQVEsUUFBUSxJQUFJLEtBQUs7SUFBRTtJQUFLLEdBQUc7R0FBUyxDQUFDO0dBQzdDLGFBQWEsS0FBSyxRQUFRLFFBQVEsT0FBTyxHQUFHO0VBQzlDLENBQUM7RUFDRCxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSx3QkFBd0I7SUFBUSxpQkFBaUI7R0FBTSxLQUFLO0dBQWM7RUFBUyxDQUFDO0NBQ2pILENBQ0Y7Q0FDQSxtQkFBbUIsY0FBYztDQUNqQyxTQUFTLGNBQWMsT0FBTztFQUM1QixNQUFNLFVBQVUscUJBQXFCLE9BQU8sc0JBQXNCLEtBQUs7RUFXdkUsT0FBQSxhQVZ1QixrQkFBa0I7R0FDdkMsTUFBTSxpQkFBaUIsUUFBUSxjQUFjO0dBQzdDLElBQUksQ0FBQyxnQkFBZ0IsT0FBTyxDQUFDO0dBQzdCLE1BQU0sZUFBZSxNQUFNLEtBQUssZUFBZSxpQkFBaUIsSUFBSSxlQUFlLEVBQUUsQ0FBQztHQUt0RixPQUpjLE1BQU0sS0FBSyxRQUFRLFFBQVEsT0FBTyxDQUN2QixDQUFDLENBQUMsTUFDeEIsR0FBRyxNQUFNLGFBQWEsUUFBUSxFQUFFLElBQUksT0FBTyxJQUFJLGFBQWEsUUFBUSxFQUFFLElBQUksT0FBTyxDQUVsRTtFQUNwQixHQUFHLENBQUMsUUFBUSxlQUFlLFFBQVEsT0FBTyxDQUM1QjtDQUNoQjtDQUNBLFNBQU8sZUFBZSxlQUFlO0NBQ3JDLE9BQU87RUFDTDtHQUFFLFVBQVU7R0FBb0IsTUFBTTtHQUFnQixVQUFVO0VBQW1CO0VBQ25GO0VBQ0E7Q0FDRjtBQUNGO0FBQ0FDLFNBQU8sa0JBQWtCLGtCQUFrQjtBQVUzQyxJQUFJLGlDQUFpQyxJQUFJLFFBQVE7QUFDakQsSUFBSSxjQUFjLE1BQU0scUJBQXFCLElBQUk7Q0FDL0M7RUFDRSxTQUFPLE1BQU0sYUFBYTtDQUM1QjtDQUNBO0NBQ0EsWUFBWSxTQUFTO0VBQ25CLE1BQU0sT0FBTztFQUNiLEtBQUssUUFBUSxDQUFDLEdBQUcsTUFBTSxLQUFLLENBQUM7RUFDN0IsZUFBZSxJQUFJLE1BQU0sSUFBSTtDQUMvQjtDQUNBLElBQUksS0FBSyxPQUFPO0VBQ2QsSUFBSSxlQUFlLElBQUksSUFBSSxLQUFLLENBQUMsS0FBSyxJQUFJLEdBQUcsR0FDM0MsS0FBSyxNQUFNLEtBQUssR0FBRztFQUVyQixNQUFNLElBQUksS0FBSyxLQUFLO0VBQ3BCLE9BQU87Q0FDVDs7Ozs7Ozs7Q0FRQSxPQUFPLE9BQU8sS0FBSyxPQUFPO0VBQ3hCLE1BQU0sTUFBTSxLQUFLLElBQUksR0FBRztFQUN4QixNQUFNLFlBQVksTUFBTSxLQUFLLE9BQU8sS0FBSyxPQUFPO0VBQ2hELE1BQU0sZ0JBQWdCLGNBQWMsS0FBSztFQUN6QyxNQUFNLGNBQWMsaUJBQWlCLElBQUksS0FBSyxJQUFJLGVBQWUsWUFBWSxDQUFDLElBQUksS0FBSyxJQUFJLFlBQVksZUFBZSxDQUFDO0VBQ3ZILElBQUksTUFBTSxLQUFLLE1BQU0sUUFBUSxHQUFHLE1BQU0sY0FBYyxnQkFBZ0IsS0FBSyxNQUFNO0dBQzdFLEtBQUssSUFBSSxLQUFLLEtBQUs7R0FDbkIsT0FBTztFQUNUO0VBQ0EsTUFBTSxPQUFPLEtBQUssTUFBTSxRQUFRLGdCQUFnQixnQkFBZ0IsR0FBRztFQUNuRSxLQUFLLE9BQU8sYUFBYSxHQUFHLEdBQUc7RUFDL0IsTUFBTSxVQUFVLEtBQUssS0FBSyxhQUFhLENBQ3JDLFVBQ0EsYUFBYSxNQUFNLFFBQVEsS0FBSyxJQUFJLFFBQVEsQ0FDOUMsQ0FBQztFQUNELEtBQUssTUFBTTtFQUNYLEtBQUssTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUNuQyxLQUFLLElBQUksVUFBVSxVQUFVO0VBRS9CLE9BQU87Q0FDVDtDQUNBLEtBQUssT0FBTyxLQUFLLE9BQU87RUFDdEIsTUFBTSxPQUFPLElBQUksYUFBYSxJQUFJO0VBQ2xDLEtBQUssT0FBTyxPQUFPLEtBQUssS0FBSztFQUM3QixPQUFPO0NBQ1Q7Q0FDQSxPQUFPLEtBQUs7RUFDVixNQUFNLFFBQVEsS0FBSyxNQUFNLFFBQVEsR0FBRyxJQUFJO0VBQ3hDLElBQUksUUFBUSxHQUNWO0VBRUYsT0FBTyxLQUFLLFFBQVEsS0FBSztDQUMzQjs7OztDQUlBLFVBQVUsS0FBSyxRQUFRLE9BQU87RUFDNUIsTUFBTSxRQUFRLEtBQUssTUFBTSxRQUFRLEdBQUc7RUFDcEMsSUFBSSxVQUFVLElBQ1osT0FBTztFQUVULE1BQU0sZUFBZSxLQUFLLE1BQU0sUUFBUSxNQUFNO0VBQzlDLE1BQU0sY0FBYyxpQkFBaUIsTUFBTSxlQUFlLFFBQVEsUUFBUSxJQUFJO0VBQzlFLE9BQU8sS0FBSyxPQUFPLGFBQWEsUUFBUSxLQUFLO0NBQy9DO0NBQ0EsTUFBTSxLQUFLO0VBQ1QsSUFBSSxRQUFRLEtBQUssTUFBTSxRQUFRLEdBQUc7RUFDbEMsUUFBUSxVQUFVLE1BQU0sVUFBVSxLQUFLLE9BQU8sSUFBSSxLQUFLLFFBQVE7RUFDL0QsSUFBSSxVQUFVLElBQ1o7RUFFRixPQUFPLEtBQUssUUFBUSxLQUFLO0NBQzNCOzs7O0NBSUEsU0FBUyxLQUFLLFFBQVEsT0FBTztFQUMzQixNQUFNLFFBQVEsS0FBSyxNQUFNLFFBQVEsR0FBRztFQUNwQyxJQUFJLFVBQVUsSUFDWixPQUFPO0VBRVQsTUFBTSxlQUFlLEtBQUssTUFBTSxRQUFRLE1BQU07RUFDOUMsTUFBTSxjQUFjLGlCQUFpQixNQUFNLGdCQUFnQixRQUFRLFFBQVEsUUFBUTtFQUNuRixPQUFPLEtBQUssT0FBTyxhQUFhLFFBQVEsS0FBSztDQUMvQztDQUNBLFFBQVE7RUFDTixPQUFPLEtBQUssUUFBUSxDQUFDO0NBQ3ZCO0NBQ0EsT0FBTztFQUNMLE9BQU8sS0FBSyxRQUFRLEVBQUU7Q0FDeEI7Q0FDQSxRQUFRO0VBQ04sS0FBSyxRQUFRLENBQUM7RUFDZCxPQUFPLE1BQU0sTUFBTTtDQUNyQjtDQUNBLE9BQU8sS0FBSztFQUNWLE1BQU0sVUFBVSxNQUFNLE9BQU8sR0FBRztFQUNoQyxJQUFJLFNBQ0YsS0FBSyxNQUFNLE9BQU8sS0FBSyxNQUFNLFFBQVEsR0FBRyxHQUFHLENBQUM7RUFFOUMsT0FBTztDQUNUO0NBQ0EsU0FBUyxPQUFPO0VBQ2QsTUFBTSxNQUFNLEtBQUssTUFBTSxLQUFLO0VBQzVCLElBQUksUUFBUSxLQUFLLEdBQ2YsT0FBTyxLQUFLLE9BQU8sR0FBRztFQUV4QixPQUFPO0NBQ1Q7Q0FDQSxHQUFHLE9BQU87RUFDUixNQUFNLE1BQU0sR0FBRyxLQUFLLE9BQU8sS0FBSztFQUNoQyxJQUFJLFFBQVEsS0FBSyxHQUNmLE9BQU8sS0FBSyxJQUFJLEdBQUc7Q0FFdkI7Q0FDQSxRQUFRLE9BQU87RUFDYixNQUFNLE1BQU0sR0FBRyxLQUFLLE9BQU8sS0FBSztFQUNoQyxJQUFJLFFBQVEsS0FBSyxHQUNmLE9BQU8sQ0FBQyxLQUFLLEtBQUssSUFBSSxHQUFHLENBQUM7Q0FFOUI7Q0FDQSxRQUFRLEtBQUs7RUFDWCxPQUFPLEtBQUssTUFBTSxRQUFRLEdBQUc7Q0FDL0I7Q0FDQSxNQUFNLE9BQU87RUFDWCxPQUFPLEdBQUcsS0FBSyxPQUFPLEtBQUs7Q0FDN0I7Q0FDQSxLQUFLLEtBQUssUUFBUTtFQUNoQixNQUFNLFFBQVEsS0FBSyxRQUFRLEdBQUc7RUFDOUIsSUFBSSxVQUFVLElBQ1o7RUFFRixJQUFJLE9BQU8sUUFBUTtFQUNuQixJQUFJLE9BQU8sR0FBRyxPQUFPO0VBQ3JCLElBQUksUUFBUSxLQUFLLE1BQU0sT0FBTyxLQUFLLE9BQU87RUFDMUMsT0FBTyxLQUFLLEdBQUcsSUFBSTtDQUNyQjtDQUNBLFFBQVEsS0FBSyxRQUFRO0VBQ25CLE1BQU0sUUFBUSxLQUFLLFFBQVEsR0FBRztFQUM5QixJQUFJLFVBQVUsSUFDWjtFQUVGLElBQUksT0FBTyxRQUFRO0VBQ25CLElBQUksT0FBTyxHQUFHLE9BQU87RUFDckIsSUFBSSxRQUFRLEtBQUssTUFBTSxPQUFPLEtBQUssT0FBTztFQUMxQyxPQUFPLEtBQUssTUFBTSxJQUFJO0NBQ3hCO0NBQ0EsS0FBSyxXQUFXLFNBQVM7RUFDdkIsSUFBSSxRQUFRO0VBQ1osS0FBSyxNQUFNLFNBQVMsTUFBTTtHQUN4QixJQUFJLFFBQVEsTUFBTSxXQUFXLFNBQVM7SUFBQztJQUFPO0lBQU87R0FBSSxDQUFDLEdBQ3hELE9BQU87R0FFVDtFQUNGO0NBRUY7Q0FDQSxVQUFVLFdBQVcsU0FBUztFQUM1QixJQUFJLFFBQVE7RUFDWixLQUFLLE1BQU0sU0FBUyxNQUFNO0dBQ3hCLElBQUksUUFBUSxNQUFNLFdBQVcsU0FBUztJQUFDO0lBQU87SUFBTztHQUFJLENBQUMsR0FDeEQsT0FBTztHQUVUO0VBQ0Y7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxPQUFPLFdBQVcsU0FBUztFQUN6QixNQUFNLFVBQVUsQ0FBQztFQUNqQixJQUFJLFFBQVE7RUFDWixLQUFLLE1BQU0sU0FBUyxNQUFNO0dBQ3hCLElBQUksUUFBUSxNQUFNLFdBQVcsU0FBUztJQUFDO0lBQU87SUFBTztHQUFJLENBQUMsR0FDeEQsUUFBUSxLQUFLLEtBQUs7R0FFcEI7RUFDRjtFQUNBLE9BQU8sSUFBSSxhQUFhLE9BQU87Q0FDakM7Q0FDQSxJQUFJLFlBQVksU0FBUztFQUN2QixNQUFNLFVBQVUsQ0FBQztFQUNqQixJQUFJLFFBQVE7RUFDWixLQUFLLE1BQU0sU0FBUyxNQUFNO0dBQ3hCLFFBQVEsS0FBSyxDQUFDLE1BQU0sSUFBSSxRQUFRLE1BQU0sWUFBWSxTQUFTO0lBQUM7SUFBTztJQUFPO0dBQUksQ0FBQyxDQUFDLENBQUM7R0FDakY7RUFDRjtFQUNBLE9BQU8sSUFBSSxhQUFhLE9BQU87Q0FDakM7Q0FDQSxPQUFPLEdBQUcsTUFBTTtFQUNkLE1BQU0sQ0FBQyxZQUFZLGdCQUFnQjtFQUNuQyxNQUFNLGtCQUFrQixLQUFLLFNBQVM7RUFDdEMsSUFBSSxDQUFDLG1CQUFtQixLQUFLLFNBQVMsR0FDcEMsTUFBTSxJQUFJLFVBQVUsbURBQW1EO0VBRXpFLElBQUksUUFBUTtFQUNaLElBQUksY0FBYztFQUNsQixLQUFLLE1BQU0sU0FBUyxNQUFNO0dBQ3hCLElBQUksVUFBVSxLQUFLLENBQUMsaUJBQ2xCLGNBQWM7UUFFZCxjQUFjLFFBQVEsTUFBTSxZQUFZLE1BQU07SUFBQztJQUFhO0lBQU87SUFBTztHQUFJLENBQUM7R0FFakY7RUFDRjtFQUNBLE9BQU87Q0FDVDtDQUNBLFlBQVksR0FBRyxNQUFNO0VBQ25CLE1BQU0sQ0FBQyxZQUFZLGdCQUFnQjtFQUNuQyxNQUFNLGtCQUFrQixLQUFLLFNBQVM7RUFDdEMsSUFBSSxDQUFDLG1CQUFtQixLQUFLLFNBQVMsR0FDcEMsTUFBTSxJQUFJLFVBQVUsbURBQW1EO0VBRXpFLElBQUksY0FBYztFQUNsQixLQUFLLElBQUksUUFBUSxLQUFLLE9BQU8sR0FBRyxTQUFTLEdBQUcsU0FBUztHQUNuRCxNQUFNLFFBQVEsS0FBSyxRQUFRLEtBQUs7R0FDaEMsSUFBSSxVQUFVLEtBQUssT0FBTyxLQUFLLENBQUMsaUJBQzlCLGNBQWM7UUFFZCxjQUFjLFFBQVEsTUFBTSxZQUFZLE1BQU07SUFBQztJQUFhO0lBQU87SUFBTztHQUFJLENBQUM7RUFFbkY7RUFDQSxPQUFPO0NBQ1Q7Ozs7Ozs7OztDQVNBLEtBQUssV0FBVztFQUNkLElBQUksT0FBTyxjQUFjLFlBQ3ZCLE1BQU0sSUFBSSxVQUFVLDhDQUE4QztFQUVwRSxNQUFNLFVBQVUsQ0FBQyxHQUFHLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVM7RUFDbEQsS0FBSyxNQUFNO0VBQ1gsS0FBSyxNQUFNLENBQUMsS0FBSyxVQUFVLFNBQ3pCLEtBQUssSUFBSSxLQUFLLEtBQUs7RUFFckIsT0FBTztDQUNUOzs7Ozs7OztDQVFBLFNBQVMsV0FBVztFQUNsQixJQUFJLE9BQU8sY0FBYyxZQUN2QixNQUFNLElBQUksVUFBVSxrREFBa0Q7RUFFeEUsTUFBTSxVQUFVLENBQUMsR0FBRyxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTO0VBQ2xELE9BQU8sSUFBSSxhQUFhLE9BQU87Q0FDakM7Q0FDQSxhQUFhO0VBQ1gsTUFBTSxXQUFXLElBQUksYUFBYTtFQUNsQyxLQUFLLElBQUksUUFBUSxLQUFLLE9BQU8sR0FBRyxTQUFTLEdBQUcsU0FBUztHQUNuRCxNQUFNLE1BQU0sS0FBSyxNQUFNLEtBQUs7R0FDNUIsTUFBTSxVQUFVLEtBQUssSUFBSSxHQUFHO0dBQzVCLFNBQVMsSUFBSSxLQUFLLE9BQU87RUFDM0I7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxVQUFVLEdBQUcsTUFBTTtFQUNqQixNQUFNLFVBQVUsQ0FBQyxHQUFHLEtBQUssUUFBUSxDQUFDO0VBQ2xDLFFBQVEsT0FBTyxHQUFHLElBQUk7RUFDdEIsT0FBTyxJQUFJLGFBQWEsT0FBTztDQUNqQztDQUNBLE1BQU0sT0FBTyxLQUFLO0VBQ2hCLE1BQU0sU0FBUyxJQUFJLGFBQWE7RUFDaEMsS0FBSyxNQUFNLE9BQU8sS0FBSyxNQUFNLE1BQU0sT0FBTyxHQUFHLEdBQzNDLE9BQU8sSUFBSSxLQUFLLEtBQUssSUFBSSxHQUFHLENBQUM7RUFFL0IsT0FBTztDQUNUO0NBQ0EsTUFBTSxXQUFXLFNBQVM7RUFDeEIsSUFBSSxRQUFRO0VBQ1osS0FBSyxNQUFNLFNBQVMsTUFBTTtHQUN4QixJQUFJLENBQUMsUUFBUSxNQUFNLFdBQVcsU0FBUztJQUFDO0lBQU87SUFBTztHQUFJLENBQUMsR0FDekQsT0FBTztHQUVUO0VBQ0Y7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxLQUFLLFdBQVcsU0FBUztFQUN2QixJQUFJLFFBQVE7RUFDWixLQUFLLE1BQU0sU0FBUyxNQUFNO0dBQ3hCLElBQUksUUFBUSxNQUFNLFdBQVcsU0FBUztJQUFDO0lBQU87SUFBTztHQUFJLENBQUMsR0FDeEQsT0FBTztHQUVUO0VBQ0Y7RUFDQSxPQUFPO0NBQ1Q7QUFDRjtBQUNBLFNBQVMsR0FBRyxPQUFPLE9BQU87Q0FDeEIsSUFBSSxRQUFRLE1BQU0sV0FDaEIsT0FBTyxNQUFNLFVBQVUsR0FBRyxLQUFLLE9BQU8sS0FBSztDQUU3QyxNQUFNLGNBQWMsWUFBWSxPQUFPLEtBQUs7Q0FDNUMsT0FBTyxnQkFBZ0IsS0FBSyxLQUFLLElBQUksTUFBTTtBQUM3QztBQUNBQSxTQUFPLElBQUksSUFBSTtBQUNmLFNBQVMsWUFBWSxPQUFPLE9BQU87Q0FDakMsTUFBTSxTQUFTLE1BQU07Q0FDckIsTUFBTSxnQkFBZ0IsY0FBYyxLQUFLO0NBQ3pDLE1BQU0sY0FBYyxpQkFBaUIsSUFBSSxnQkFBZ0IsU0FBUztDQUNsRSxPQUFPLGNBQWMsS0FBSyxlQUFlLFNBQVMsS0FBSztBQUN6RDtBQUNBQSxTQUFPLGFBQWEsYUFBYTtBQUNqQyxTQUFTLGNBQWMsUUFBUTtDQUM3QixPQUFPLFdBQVcsVUFBVSxXQUFXLElBQUksSUFBSSxLQUFLLE1BQU0sTUFBTTtBQUNsRTtBQUNBQSxTQUFPLGVBQWUsZUFBZTs7QUFLckMsU0FBUyxrQkFBa0IsTUFBTTtDQUMvQixNQUFNLGdCQUFnQixPQUFPO0NBQzdCLE1BQU0sQ0FBQyx5QkFBeUIseUJBQXlCQyxtQkFBb0IsYUFBYTtDQUMxRixNQUFNLENBQUMsaUNBQWlDLDhCQUE4Qix3QkFBd0IsYUFBYTtDQUMzRyxnQ0FBZ0MsY0FBYyxPQUFPO0NBQ3JELE1BQU0sQ0FBQyxtQ0FBbUMsZ0NBQWdDLHdCQUF3QixhQUFhO0NBQy9HLGtDQUFrQyxjQUFjLE9BQU87Q0FDdkQsTUFBTSxxQkFBcUMsMEJBQVEsRUFBRSxPQUFPLEdBQUcsWUFBWTtFQUN6RSxPQUFPLFFBQXdCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLHdCQUF3QjtHQUFFLEdBQUc7R0FBTztFQUFNLENBQUMsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssZ0JBQWdCLEVBQUUsR0FBRyxNQUFNLENBQUM7Q0FDdEksR0FBRyxvQkFBb0I7Q0FDdkIsbUJBQW1CLGNBQWM7Q0FDakMsTUFBTSxpQkFBaUMsMEJBQVEsVUFBVTtFQUN2RCxNQUFNLFFBQVEsa0JBQWtCO0VBQ2hDLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLHdCQUF3QjtHQUFFLEdBQUc7R0FBTztFQUFNLENBQUM7Q0FDekUsR0FBRyxnQkFBZ0I7Q0FDbkIsZUFBZSxjQUFjLE9BQU87Q0FDcEMsTUFBTSx5QkFBeUMsMEJBQVEsVUFBVTtFQUMvRCxNQUFNLEVBQUUsT0FBTyxVQUFVLFVBQVU7RUFDbkMsTUFBTSxNQUFBLGFBQWEsT0FBTyxJQUFJO0VBQzlCLE1BQU0sQ0FBQyxtQkFBbUIsd0JBQUEsYUFBK0IsU0FDdkQsSUFDRjtFQUNBLE1BQU0sY0FBY0MsZ0JBQWlCLEtBQUssb0JBQW9CO0VBQzlELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQjtFQUNwQyxNQUFNLGNBQUEsYUFBcUIsT0FDekIsSUFBSSxZQUFZLENBQ2xCO0VBQ0EsTUFBTSxnQkFBQSxhQUF1QixrQkFBa0I7R0FDN0MsTUFBTSxXQUFXLFlBQVk7R0FDN0IsSUFBSSxDQUFDLGtCQUFrQixRQUFRLEdBQzdCLFNBQVMsS0FBSyxzQkFBc0I7R0FFdEMsT0FBTztFQUNULEdBQUcsQ0FBQyxDQUFDO0VBQ0wsYUFBTyxnQkFBZ0I7R0FDckIsSUFBSSxDQUFDLG1CQUNIO0dBRUYsTUFBTSxXQUFXLDJCQUEyQjtJQUMxQyxlQUFlLFFBQVE7S0FDckIsTUFBTSxTQUFTLElBQUksU0FBUyxzQkFBc0I7S0FFbEQsT0FEcUIsT0FBTyxNQUFNLENBQUMsTUFBTSxVQUFVLElBQUksTUFBTSxLQUFLLE1BQU0sR0FDdEQsSUFBSSxTQUFTO0lBQ2pDLENBQUM7R0FDSCxDQUFDO0dBQ0QsU0FBUyxRQUFRLG1CQUFtQjtJQUNsQyxXQUFXO0lBQ1gsU0FBUztHQUNYLENBQUM7R0FDRCxhQUFhO0lBQ1gsU0FBUyxXQUFXO0dBQ3RCO0VBQ0YsR0FBRyxDQUFDLG1CQUFtQixhQUFhLENBQUM7RUFDckMsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQ3JCLGlDQUNBO0dBQ0U7R0FDQSxzQkFBc0I7R0FDdEIsNEJBQTRCO0dBQzVCO0dBQ0E7R0FDQTtHQUNBLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUN4QixtQ0FDQTtJQUNFO0lBQ0E7SUFDQTtJQUNBO0dBQ0YsQ0FDRjtFQUNGLENBQ0Y7Q0FDRixHQUFHLHdCQUF3QjtDQUMzQix1QkFBdUIsY0FBYyxPQUFPO0NBQzVDLE1BQU0sdUJBQXVCLE9BQU87Q0FDcEMsTUFBTSxxQkFBcUJDLFdBQVksb0JBQW9CO0NBQzNELE1BQU0saUJBQUEsYUFBd0IsWUFDM0IsT0FBTyxpQkFBaUI7RUFDdkIsTUFBTSxFQUFFLE9BQU8sYUFBYTtFQUM1QixNQUFNLFVBQVUsMkJBQTJCLHNCQUFzQixLQUFLO0VBQ3RFLE1BQU0sZUFBZUQsZ0JBQWlCLGNBQWMsUUFBUSxvQkFBb0I7RUFDaEYsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssb0JBQW9CO0dBQUUsS0FBSztHQUFjO0VBQVMsQ0FBQztDQUNqRixDQUNGO0NBQ0EsZUFBZSxjQUFjO0NBQzdCLE1BQU0saUJBQWlCLE9BQU87Q0FDOUIsTUFBTSxpQkFBaUI7Q0FDdkIsTUFBTSx5QkFBeUJDLFdBQVksY0FBYztDQUN6RCxNQUFNLHFCQUFBLGFBQTRCLFlBQy9CLE9BQU8saUJBQWlCO0VBQ3ZCLE1BQU0sRUFBRSxPQUFPLFVBQVUsR0FBRyxhQUFhO0VBQ3pDLE1BQU0sTUFBQSxhQUFhLE9BQU8sSUFBSTtFQUU5QixNQUFNLEVBQUUsZUFBZSxnQkFEUCwyQkFBMkIsZ0JBQWdCLEtBQ2Q7RUFDN0MsTUFBTSxjQUFBLGFBQXFCLE9BQU8sUUFBUTtFQUMxQyxJQUFJLENBQUMsYUFBYSxZQUFZLFNBQVMsUUFBUSxHQUM3QyxZQUFZLFVBQVU7RUFFeEIsTUFBTSxtQkFBbUIsWUFBWTtFQUNyQyxNQUFNLGtCQUFBLGFBQXlCLGFBQzVCLFNBQVM7R0FDUixNQUFNLFdBQVcsWUFBWTtHQUM3QixJQUFJLE1BQ0YsU0FBUyxJQUFJLE1BQU07SUFDakIsR0FBRyxZQUFZO0lBQ2YsU0FBUztHQUNYLENBQUM7UUFDSSxJQUFJLElBQUksU0FDYixTQUFTLE9BQU8sSUFBSSxPQUFPO0VBRS9CLEdBQ0EsQ0FBQyxXQUFXLENBQ2Q7RUFDQSxNQUFNLGVBQWVELGdCQUFpQixjQUFjLGlCQUFpQixHQUFHO0VBQ3hFLHVCQUFzQjtHQUNwQixNQUFNLE9BQU8sSUFBSTtHQUNqQixNQUFNLFdBQVcsWUFBWTtHQUM3QixJQUFJLFFBQVEsU0FBUyxJQUFJLElBQUksR0FDM0IsU0FBUyxJQUFJLE1BQU07SUFBRSxHQUFHO0lBQWtCLFNBQVM7R0FBSyxDQUFDO0VBRTdELEdBQUcsQ0FBQyxrQkFBa0IsV0FBVyxDQUFDO0VBQ2xDLE1BQU0sZ0JBQUEsYUFBdUIsT0FBTyxJQUFJO0VBQ3hDLGFBQU8sZ0JBQWdCO0dBQ3JCLE1BQU0sVUFBVSxJQUFJO0dBQ3BCLE1BQU0sYUFBYSxjQUFjO0dBQ2pDLEtBQUssWUFBWSxXQUFXLFVBQVUsWUFBWSxDQUFDLFdBQVcsWUFBWSxhQUFhLG1CQUNyRjtHQUVGLGNBQWMsVUFBVSxVQUFVO0lBQUU7SUFBUyxVQUFVO0dBQWlCLElBQUk7R0FDNUUsZUFBZSxRQUFRO0lBQ3JCLE1BQU0sT0FBTyxJQUFJLFlBQVksR0FBRztJQUNoQyxJQUFJLGNBQWMsV0FBVyxZQUFZLFNBQ3ZDLEtBQUssT0FBTyxXQUFXLE9BQU87SUFFaEMsSUFBSSxTQUNGLEtBQUssSUFBSSxTQUFTO0tBQUUsR0FBRztLQUFrQjtJQUFRLENBQUM7SUFFcEQsT0FBTyxLQUFLLEtBQUssc0JBQXNCO0dBQ3pDLENBQUM7RUFDSCxDQUFDO0VBQ0QsYUFBTyxnQkFBZ0I7R0FDckIsYUFBYTtJQUNYLE1BQU0sYUFBYSxjQUFjO0lBQ2pDLGNBQWMsVUFBVTtJQUN4QixJQUFJLENBQUMsWUFDSDtJQUVGLGVBQWUsUUFBUTtLQUNyQixJQUFJLENBQUMsSUFBSSxJQUFJLFdBQVcsT0FBTyxHQUM3QixPQUFPO0tBRVQsTUFBTSxPQUFPLElBQUksWUFBWSxHQUFHO0tBQ2hDLEtBQUssT0FBTyxXQUFXLE9BQU87S0FDOUIsT0FBTztJQUNULENBQUM7R0FDSDtFQUNGLEdBQUcsQ0FBQyxhQUFhLENBQUM7RUFDbEIsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssd0JBQXdCO0lBQVEsaUJBQWlCO0dBQU0sS0FBSztHQUFjO0VBQVMsQ0FBQztDQUNsSCxDQUNGO0NBQ0EsbUJBQW1CLGNBQWM7Q0FDakMsU0FBUyxvQkFBb0I7RUFDM0IsT0FBQSxhQUFjLFNBQVMsSUFBSSxZQUFZLENBQUM7Q0FDMUM7Q0FDQSxTQUFPLG1CQUFtQixtQkFBbUI7Q0FDN0MsU0FBUyxjQUFjLE9BQU87RUFDNUIsTUFBTSxFQUFFLGVBQWUsNkJBQTZCLE9BQU8sc0JBQXNCLEtBQUs7RUFDdEYsT0FBTztDQUNUO0NBQ0EsU0FBTyxlQUFlLGVBQWU7Q0FDckMsU0FBUyxpQkFBaUIsT0FBTztFQUMvQixNQUFNLEVBQUUsa0JBQWtCLDJCQUEyQixPQUFPLHNCQUFzQixLQUFLO0VBQ3ZGLE9BQU87Q0FDVDtDQUNBLFNBQU8sa0JBQWtCLGtCQUFrQjtDQU8zQyxPQUFPLENBQ0w7RUFBRSxVQUFVO0VBQW9CLE1BQU07RUFBZ0IsVUFBVTtDQUFtQixHQUNuRjtFQVBBO0VBQ0E7RUFDQTtFQUNBO0NBSVEsQ0FDVjtBQUNGO0FBQ0FGLFNBQU8sbUJBQW1CLGtCQUFrQjtBQUM1QyxTQUFTLGFBQWEsR0FBRyxHQUFHO0NBQzFCLElBQUksTUFBTSxHQUFHLE9BQU87Q0FDcEIsSUFBSSxPQUFPLE1BQU0sWUFBWSxPQUFPLE1BQU0sVUFBVSxPQUFPO0NBQzNELElBQUksS0FBSyxRQUFRLEtBQUssTUFBTSxPQUFPO0NBQ25DLE1BQU0sUUFBUSxPQUFPLEtBQUssQ0FBQztDQUMzQixNQUFNLFFBQVEsT0FBTyxLQUFLLENBQUM7Q0FDM0IsSUFBSSxNQUFNLFdBQVcsTUFBTSxRQUFRLE9BQU87Q0FDMUMsS0FBSyxNQUFNLE9BQU8sT0FBTztFQUN2QixJQUFJLENBQUMsT0FBTyxVQUFVLGVBQWUsS0FBSyxHQUFHLEdBQUcsR0FBRyxPQUFPO0VBQzFELElBQUksRUFBRSxTQUFTLEVBQUUsTUFBTSxPQUFPO0NBQ2hDO0NBQ0EsT0FBTztBQUNUO0FBQ0FBLFNBQU8sY0FBYyxjQUFjO0FBQ25DLFNBQVMsbUJBQW1CLEdBQUcsR0FBRztDQUNoQyxPQUFPLENBQUMsRUFBRSxFQUFFLHdCQUF3QixDQUFDLElBQUksS0FBSztBQUNoRDtBQUNBQSxTQUFPLG9CQUFvQixvQkFBb0I7QUFDL0MsU0FBUyxrQkFBa0IsTUFBTTtDQUMvQixJQUFJO0NBQ0osS0FBSyxNQUFNLFdBQVcsS0FBSyxLQUFLLEdBQUc7RUFDakMsSUFBSSxVQUFVO0dBQ1osTUFBTSxXQUFXLFNBQVMsd0JBQXdCLE9BQU87R0FDekQsSUFBSSxFQUFFLFdBQVcsS0FBSyxtQ0FBbUMsV0FBVyxLQUFLLDZCQUN2RSxPQUFPO0VBRVg7RUFDQSxXQUFXO0NBQ2I7Q0FDQSxPQUFPO0FBQ1Q7QUFDQUEsU0FBTyxtQkFBbUIsbUJBQW1CO0FBQzdDLFNBQVMsdUJBQXVCLEdBQUcsR0FBRztDQUNwQyxPQUFPLENBQUMsRUFBRSxFQUFFLENBQUMsV0FBVyxDQUFDLEVBQUUsRUFBRSxDQUFDLFVBQVUsSUFBSSxtQkFBbUIsRUFBRSxFQUFFLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FBQyxPQUFPLElBQUksS0FBSztBQUNwRztBQUNBQSxTQUFPLHdCQUF3Qix3QkFBd0I7QUFDdkQsU0FBUyxxQkFBcUIsVUFBVTtDQVN0QyxPQUFPLElBUmMsa0JBQWtCLGtCQUFrQjtFQUN2RCxLQUFLLE1BQU0sWUFBWSxlQUNyQixJQUFJLFNBQVMsU0FBUyxhQUFhO0dBQ2pDLFNBQVM7R0FDVDtFQUNGO0NBRUosQ0FDYztBQUNoQjtBQUNBQSxTQUFPLHNCQUFzQixzQkFBc0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbm9CbkQsSUFBSSxZQUFZLE9BQU87QUFDdkIsSUFBSSxVQUFVLFFBQVEsVUFBVSxVQUFVLFFBQVEsUUFBUTtDQUFFO0NBQU8sY0FBYztBQUFLLENBQUM7QUFjdkYsSUFBSSxjQUFjO0NBQ2hCLFVBQVU7Q0FDVixZQUFZO0FBQ2Q7QUFDQSxJQUFJLFlBQVk7Q0FDZCxLQUFLO0NBQ0wsS0FBSztBQUNQO0FBQ0EsSUFBSSxZQUFZLENBQUMsVUFBVSxVQUFVO0FBQ3JDLElBQUksYUFBYTtDQUFDO0NBQVc7Q0FBYTtDQUFhO0FBQVk7QUFDbkUsSUFBSSxZQUFZO0NBQ2QsYUFBYTtFQUFDO0VBQVE7RUFBWTtFQUFhO0NBQVc7Q0FDMUQsY0FBYztFQUFDO0VBQVE7RUFBWTtFQUFhO0NBQVk7Q0FDNUQsZUFBZTtFQUFDO0VBQVE7RUFBWTtFQUFhO0NBQVc7Q0FDNUQsWUFBWTtFQUFDO0VBQVE7RUFBWTtFQUFXO0NBQVc7QUFDekQ7QUFDQSxJQUFJLGNBQWM7QUFDbEIsSUFBSSxDQUFDLFlBQVksZUFBZSx5QkFBeUIsaUNBQWlCLFdBQVc7QUFDckYsSUFBSSxDQUFDLHFCQUFxQixxQkFBcUIsbUJBQW1CLGFBQWEsQ0FDN0UscUJBQ0YsQ0FBQztBQUNELElBQUksQ0FBQyxnQkFBZ0Isb0JBQW9CLG9CQUFvQixXQUFXO0FBQ3hFLElBQUksU0FBeUIsNkJBQU0sV0FFakIsdUJBQU8sU0FBUyxRQUFRLE9BQU8sY0FBYztDQUMzRCxNQUFNLEVBQ0osTUFDQSxNQUFNLEdBQ04sTUFBTSxLQUNOLE9BQU8sR0FDUCxjQUFjLFlBQVksWUFDMUIsV0FBVyxPQUNYLHdCQUF3QixHQUN4QixxQkFBcUIsT0FDckIsZUFBZSxDQUFDLEdBQUcsR0FDbkIsT0FDQSxnQkFBZ0MsNkJBQWEsQ0FDN0MsR0FBRyxlQUFlLEdBQ2xCLGdCQUFnQyw2QkFBYSxDQUM3QyxHQUFHLGVBQWUsR0FDbEIsV0FBVyxPQUNYLE1BQ0EsR0FBRyxnQkFDRDtDQUNKLE1BQU0sWUFBQSxhQUFrQix1QkFBdUIsSUFBSSxJQUFJLENBQUM7Q0FDeEQsTUFBTSx3QkFBQSxhQUE4QixPQUFPLENBQUM7Q0FDNUMsTUFBTSwyQkFBQSxhQUFpQyxPQUFPLEtBQUs7Q0FDbkQsTUFBTSxDQUFDLHFCQUFxQiwwQkFBQSxhQUFnQyxTQUFTLElBQUk7Q0FFekUsTUFBTSxvQkFEZSxnQkFBZ0IsWUFBWSxhQUNSLG1CQUFtQjtDQUM1RCxNQUFNLENBQUMsU0FBUyxjQUFBLGFBQW9CLFNBQVMsSUFBSTtDQUNqRCxNQUFNLGVBQWUsZ0JBQWdCLGNBQWMsVUFBVTtDQUM3RCxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsYUFBYSxxQkFBcUI7RUFDcEQsTUFBTTtFQUNOLGFBQWE7RUFDYixVQUEwQix3QkFBUSxXQUFXO0dBRTNDLENBRGdCLEdBQUcsVUFBVSxPQUN4QixDQUFDLENBQUMsc0JBQXNCLFFBQVEsRUFBRSxNQUFNO0lBQzNDLGVBQWU7SUFDZixjQUFjLHlCQUF5QjtHQUN6QyxDQUFDO0dBQ0QseUJBQXlCLFVBQVU7R0FDbkMsY0FBYyxNQUFNO0VBQ3RCLEdBQUcsVUFBVTtDQUNmLENBQUM7Q0FDRCxNQUFNLDRCQUFBLGFBQWtDLE9BQU8sTUFBTTtDQUNyRCxNQUFNLG1CQUFBLGFBQXlCLE9BQU8sTUFBTTtDQUM1QyxhQUFNLGdCQUFnQjtFQUNwQixNQUFNLGlCQUFpQixPQUFPLFNBQVMsY0FBYyxlQUFlLElBQUksSUFBSSxTQUFTLFFBQVEsTUFBTTtFQUNuRyxJQUFJLDBCQUEwQixpQkFBaUI7R0FDN0MsTUFBTSxRQUF3Qiw2QkFBYSxVQUFVLGlCQUFpQixPQUFPLEdBQUcsT0FBTztHQUN2RixlQUFlLGlCQUFpQixTQUFTLEtBQUs7R0FDOUMsYUFBYSxlQUFlLG9CQUFvQixTQUFTLEtBQUs7RUFDaEU7Q0FDRixHQUFHO0VBQUM7RUFBUztFQUFNO0NBQVMsQ0FBQztDQUM3QixTQUFTLGlCQUFpQixRQUFRO0VBRWhDLGFBQWEsUUFEUSxxQkFBcUIsUUFBUSxNQUNsQixDQUFDO0NBQ25DO0NBQ0EsT0FBTyxrQkFBa0Isa0JBQWtCO0NBQzNDLFNBQVMsZ0JBQWdCLFFBQVE7RUFDL0IsYUFBYSxRQUFRLHNCQUFzQixPQUFPO0NBQ3BEO0NBQ0EsT0FBTyxpQkFBaUIsaUJBQWlCO0NBQ3pDLFNBQVMsaUJBQWlCO0VBRXhCLElBRG1CLE9BQU8sTUFBTSxNQUFNLE9BQU8sMEJBQTBCLE9BQU8sR0FDOUQsY0FBYyxNQUFNO0NBQ3RDO0NBQ0EsT0FBTyxnQkFBZ0IsZ0JBQWdCO0NBQ3ZDLFNBQVMsYUFBYSxRQUFRLFNBQVMsRUFBRSxXQUFXLEVBQUUsUUFBUSxNQUFNLEdBQUc7RUFDckUsTUFBTSxlQUFlLGdCQUFnQixJQUFJO0VBRXpDLE1BQU0sWUFBWSxNQURDLFdBQVcsS0FBSyxPQUFPLFNBQVMsT0FBTyxJQUFJLElBQUksT0FBTyxLQUFLLFlBQ3RELEdBQVksQ0FBQyxLQUFLLEdBQUcsQ0FBQztFQUM5QyxNQUFNLG1CQUFtQix3QkFBd0I7RUFDakQsU0FBUyxjQUFjLFlBQVk7R0FDakMsTUFBTSxtQkFBbUIscUJBQXFCLE1BQU0sV0FBVyxDQUM3RCxXQUFXLFVBQVUsT0FBTyxLQUFLLElBQUksTUFBTSxXQUFXLFVBQVUsS0FBSyxrQkFDckUsV0FBVyxVQUFVLE9BQU8sS0FBSyxJQUFJLE1BQU0sV0FBVyxVQUFVLEtBQUssZ0JBQ3ZFLENBQUMsSUFBSTtHQUNMLE1BQU0sYUFBYSxvQkFBb0IsWUFBWSxrQkFBa0IsT0FBTztHQUM1RSxJQUFJLENBQUMseUJBQXlCLFlBQVksZ0JBQWdCLEdBQ3hELE9BQU87R0FFVCxPQUFPO0lBQ0w7SUFDQSxjQUFjLHFCQUFxQixVQUFVLFdBQVcsUUFBUSxnQkFBZ0I7SUFDaEYsWUFBWSxPQUFPLFVBQVUsTUFBTSxPQUFPLFVBQVU7R0FDdEQ7RUFDRjtFQUNBLE9BQU8sZUFBZSxlQUFlO0VBQ3JDLE1BQU0sWUFBWSxjQUFjLE1BQU07RUFDdEMsSUFBSSxXQUFXLFlBQ2IsdUJBQXVCLFVBQVUsVUFBVTtFQUU3QyxXQUFXLGFBQWEsQ0FBQyxNQUFNO0dBQzdCLE1BQU0sT0FBTyxjQUFjLFVBQVU7R0FDckMsSUFBSSxDQUFDLE1BQ0gsT0FBTztHQUVULHNCQUFzQixVQUFVLEtBQUs7R0FDckMsSUFBSSxLQUFLLGNBQWMsUUFDckIsY0FBYyxLQUFLLFVBQVU7R0FFL0IsT0FBTyxLQUFLLGFBQWEsS0FBSyxhQUFhO0VBQzdDLENBQUM7Q0FDSDtDQUNBLE9BQU8sY0FBYyxjQUFjO0NBQ25DLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUNyQixnQkFDQTtFQUNFLE9BQU8sTUFBTTtFQUNiO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxRQUFRLFVBQVU7RUFDbEI7RUFDQTtFQUNBO0VBQ0E7RUFDQSxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxXQUFXLFVBQVU7R0FBRSxPQUFPLE1BQU07R0FBZSxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxXQUFXLE1BQU07SUFBRSxPQUFPLE1BQU07SUFBZSxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FDdEwsbUJBQ0E7S0FDRSxpQkFBaUI7S0FDakIsaUJBQWlCLFdBQVcsS0FBSyxLQUFLO0tBQ3RDLEdBQUc7S0FDSCxLQUFLO0tBQ0wsZUFBZSxxQkFBcUIsWUFBWSxxQkFBcUI7TUFDbkUsSUFBSSxDQUFDLFVBQVU7T0FDYiwwQkFBMEIsVUFBVTtPQUNwQyx5QkFBeUIsVUFBVTtNQUNyQztLQUNGLENBQUM7S0FDRDtLQUNBO0tBQ0E7S0FDQSxjQUFjLFdBQVcsS0FBSyxJQUFJO0tBQ2xDLGFBQWEsV0FBVyxLQUFLLElBQUk7S0FDakMsWUFBWSxXQUFXLEtBQUssSUFBSTtLQUNoQyxxQkFBcUI7TUFDbkIsSUFBSSxDQUFDLFVBQVU7T0FDYix5QkFBeUIsVUFBVTtPQUNuQyxhQUFhLEtBQUssR0FBRyxFQUFFLFFBQVEsS0FBSyxDQUFDO01BQ3ZDO0tBQ0Y7S0FDQSxvQkFBb0I7TUFDbEIsSUFBSSxDQUFDLFVBQVU7T0FDYix5QkFBeUIsVUFBVTtPQUNuQyxhQUFhLEtBQUssT0FBTyxTQUFTLEdBQUcsRUFBRSxRQUFRLEtBQUssQ0FBQztNQUN2RDtLQUNGO0tBQ0EsZ0JBQWdCLEVBQUUsT0FBTyxXQUFXLG9CQUFvQjtNQUN0RCxJQUFJLENBQUMsVUFBVTtPQUNiLHlCQUF5QixVQUFVO09BR25DLE1BQU0sYUFGWSxVQUFVLFNBQVMsTUFBTSxHQUNqQixLQUFLLE1BQU0sWUFBWSxXQUFXLFNBQVMsTUFBTSxHQUFHLElBQy9DLEtBQUs7T0FDcEMsTUFBTSxVQUFVLHNCQUFzQjtPQUN0QyxNQUFNLFNBQVMsT0FBTztPQU90QixhQU5rQixpQkFBaUIsUUFBUTtRQUN6QztRQUNBO1FBQ0EsV0FBVztRQUNYO09BQ0YsQ0FDcUIsR0FBRyxTQUFTLEVBQUUsUUFBUSxLQUFLLENBQUM7TUFDbkQ7S0FDRjtJQUNGLENBQ0Y7R0FBRSxDQUFDO0VBQUUsQ0FBQztDQUNSLENBQ0Y7QUFDRixHQUFHLFFBQVEsQ0FDYjtBQUNBLElBQUksQ0FBQywyQkFBMkIsK0JBQStCLG9CQUFvQixhQUFhO0NBQzlGLFdBQVc7Q0FDWCxTQUFTO0NBQ1QsTUFBTTtDQUNOLFdBQVc7QUFDYixDQUFDO0FBQ0QsSUFBSSxtQkFBbUMsNkJBQU0sV0FFM0IsdUJBQU8sU0FBUyxrQkFBa0IsT0FBTyxjQUFjO0NBQ3JFLE1BQU0sRUFDSixLQUNBLEtBQ0EsS0FDQSxVQUNBLGNBQ0EsYUFDQSxZQUNBLGVBQ0EsR0FBRyxnQkFDRDtDQUNKLE1BQU0sQ0FBQyxRQUFRLGFBQUEsYUFBbUIsU0FBUyxJQUFJO0NBQy9DLE1BQU0sZUFBZSxnQkFBZ0IsY0FBYyxTQUFTO0NBQzVELE1BQU0sVUFBQSxhQUFnQixPQUFPLEtBQUssQ0FBQztDQUNuQyxNQUFNLFlBQVksYUFBYSxHQUFHO0NBQ2xDLE1BQU0saUJBQWlCLGNBQWMsVUFBVTtDQUMvQyxNQUFNLG9CQUFvQixrQkFBa0IsQ0FBQyxZQUFZLENBQUMsa0JBQWtCO0NBQzVFLFNBQVMsb0JBQW9CLGlCQUFpQjtFQUM1QyxNQUFNLE9BQU8sUUFBUSxXQUFXLE9BQU8sc0JBQXNCO0VBRzdELE1BQU0sUUFBUSxZQUFZLENBRlgsR0FBRyxLQUFLLEtBRU8sR0FEZixvQkFBb0IsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUNsQjtFQUN2QyxRQUFRLFVBQVU7RUFDbEIsT0FBTyxNQUFNLGtCQUFrQixLQUFLLElBQUk7Q0FDMUM7Q0FDQSxPQUFPLHFCQUFxQixxQkFBcUI7Q0FDakQsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQ3JCLDJCQUNBO0VBQ0UsT0FBTyxNQUFNO0VBQ2IsV0FBVyxvQkFBb0IsU0FBUztFQUN4QyxTQUFTLG9CQUFvQixVQUFVO0VBQ3ZDLFdBQVcsb0JBQW9CLElBQUk7RUFDbkMsTUFBTTtFQUNOLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUN4QixZQUNBO0dBQ0UsS0FBSztHQUNMLG9CQUFvQjtHQUNwQixHQUFHO0dBQ0gsS0FBSztHQUNMLE9BQU87SUFDTCxHQUFHLFlBQVk7SUFDZixrQ0FBa0M7R0FDcEM7R0FDQSxlQUFlLFVBQVU7SUFDdkIsTUFBTSxRQUFRLG9CQUFvQixNQUFNLE9BQU87SUFDL0MsZUFBZSxLQUFLO0dBQ3RCO0dBQ0EsY0FBYyxVQUFVO0lBQ3RCLE1BQU0sUUFBUSxvQkFBb0IsTUFBTSxPQUFPO0lBQy9DLGNBQWMsS0FBSztHQUNyQjtHQUNBLGtCQUFrQjtJQUNoQixRQUFRLFVBQVUsS0FBSztJQUN2QixhQUFhO0dBQ2Y7R0FDQSxnQkFBZ0IsVUFBVTtJQUV4QixNQUFNLFlBQVksVUFESyxvQkFBb0IsY0FBYyxhQUNkLENBQUMsU0FBUyxNQUFNLEdBQUc7SUFDOUQsZ0JBQWdCO0tBQUU7S0FBTyxXQUFXLFlBQVksS0FBSztJQUFFLENBQUM7R0FDMUQ7RUFDRixDQUNGO0NBQ0YsQ0FDRjtBQUNGLEdBQUcsa0JBQWtCLENBQ3ZCO0FBQ0EsSUFBSSxpQkFBaUMsNkJBQU0sV0FDekIsdUJBQU8sU0FBUyxnQkFBZ0IsT0FBTyxjQUFjO0NBQ25FLE1BQU0sRUFDSixLQUNBLEtBQ0EsVUFDQSxjQUNBLGFBQ0EsWUFDQSxlQUNBLEdBQUcsZ0JBQ0Q7Q0FDSixNQUFNLFlBQUEsYUFBa0IsT0FBTyxJQUFJO0NBQ25DLE1BQU0sTUFBTSxnQkFBZ0IsY0FBYyxTQUFTO0NBQ25ELE1BQU0sVUFBQSxhQUFnQixPQUFPLEtBQUssQ0FBQztDQUNuQyxNQUFNLHNCQUFzQixDQUFDO0NBQzdCLFNBQVMsb0JBQW9CLGlCQUFpQjtFQUM1QyxNQUFNLE9BQU8sUUFBUSxXQUFXLFVBQVUsUUFBUSxzQkFBc0I7RUFHeEUsTUFBTSxRQUFRLFlBQVksQ0FGWCxHQUFHLEtBQUssTUFFTyxHQURmLHNCQUFzQixDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxHQUFHLENBQ3BCO0VBQ3ZDLFFBQVEsVUFBVTtFQUNsQixPQUFPLE1BQU0sa0JBQWtCLEtBQUssR0FBRztDQUN6QztDQUNBLE9BQU8scUJBQXFCLHFCQUFxQjtDQUNqRCxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FDckIsMkJBQ0E7RUFDRSxPQUFPLE1BQU07RUFDYixXQUFXLHNCQUFzQixXQUFXO0VBQzVDLFNBQVMsc0JBQXNCLFFBQVE7RUFDdkMsTUFBTTtFQUNOLFdBQVcsc0JBQXNCLElBQUk7RUFDckMsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQ3hCLFlBQ0E7R0FDRSxvQkFBb0I7R0FDcEIsR0FBRztHQUNIO0dBQ0EsT0FBTztJQUNMLEdBQUcsWUFBWTtJQUNmLGtDQUFrQztHQUNwQztHQUNBLGVBQWUsVUFBVTtJQUN2QixNQUFNLFFBQVEsb0JBQW9CLE1BQU0sT0FBTztJQUMvQyxlQUFlLEtBQUs7R0FDdEI7R0FDQSxjQUFjLFVBQVU7SUFDdEIsTUFBTSxRQUFRLG9CQUFvQixNQUFNLE9BQU87SUFDL0MsY0FBYyxLQUFLO0dBQ3JCO0dBQ0Esa0JBQWtCO0lBQ2hCLFFBQVEsVUFBVSxLQUFLO0lBQ3ZCLGFBQWE7R0FDZjtHQUNBLGdCQUFnQixVQUFVO0lBRXhCLE1BQU0sWUFBWSxVQURLLHNCQUFzQixnQkFBZ0IsV0FDbEIsQ0FBQyxTQUFTLE1BQU0sR0FBRztJQUM5RCxnQkFBZ0I7S0FBRTtLQUFPLFdBQVcsWUFBWSxLQUFLO0lBQUUsQ0FBQztHQUMxRDtFQUNGLENBQ0Y7Q0FDRixDQUNGO0FBQ0YsR0FBRyxnQkFBZ0IsQ0FDckI7QUFDQSxJQUFJLGFBQTZCLDZCQUFNLFdBQ3JCLHVCQUFPLFNBQVMsWUFBWSxPQUFPLGNBQWM7Q0FDL0QsTUFBTSxFQUNKLGVBQ0EsY0FDQSxhQUNBLFlBQ0EsZUFDQSxjQUNBLGVBQ0EsR0FBRyxnQkFDRDtDQUNKLE1BQU0sVUFBVSxpQkFBaUIsYUFBYSxhQUFhO0NBQzNELE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUNyQixVQUFVLE1BQ1Y7RUFDRSxHQUFHO0VBQ0gsS0FBSztFQUNMLFdBQVcscUJBQXFCLE1BQU0sWUFBWSxVQUFVO0dBQzFELElBQUksTUFBTSxRQUFRLFFBQVE7SUFDeEIsY0FBYyxLQUFLO0lBQ25CLE1BQU0sZUFBZTtHQUN2QixPQUFPLElBQUksTUFBTSxRQUFRLE9BQU87SUFDOUIsYUFBYSxLQUFLO0lBQ2xCLE1BQU0sZUFBZTtHQUN2QixPQUFPLElBQUksVUFBVSxPQUFPLFVBQVUsQ0FBQyxDQUFDLFNBQVMsTUFBTSxHQUFHLEdBQUc7SUFDM0QsY0FBYyxLQUFLO0lBQ25CLE1BQU0sZUFBZTtHQUN2QjtFQUNGLENBQUM7RUFDRCxlQUFlLHFCQUFxQixNQUFNLGdCQUFnQixVQUFVO0dBQ2xFLE1BQU0sU0FBUyxNQUFNO0dBQ3JCLE9BQU8sa0JBQWtCLE1BQU0sU0FBUztHQUN4QyxNQUFNLGVBQWU7R0FDckIsSUFBSSxRQUFRLE9BQU8sSUFBSSxNQUFNLEdBQzNCLE9BQU8sTUFBTTtJQUFFLGVBQWU7SUFBTSxjQUFjO0dBQU0sQ0FBQztRQUV6RCxhQUFhLEtBQUs7RUFFdEIsQ0FBQztFQUNELGVBQWUscUJBQXFCLE1BQU0sZ0JBQWdCLFVBQVU7R0FFbEUsSUFEZSxNQUFNLE9BQ1Ysa0JBQWtCLE1BQU0sU0FBUyxHQUFHLFlBQVksS0FBSztFQUNsRSxDQUFDO0VBQ0QsYUFBYSxxQkFBcUIsTUFBTSxjQUFjLFVBQVU7R0FDOUQsTUFBTSxTQUFTLE1BQU07R0FDckIsSUFBSSxPQUFPLGtCQUFrQixNQUFNLFNBQVMsR0FBRztJQUM3QyxPQUFPLHNCQUFzQixNQUFNLFNBQVM7SUFDNUMsV0FBVyxLQUFLO0dBQ2xCO0VBQ0YsQ0FBQztDQUNILENBQ0Y7QUFDRixHQUFHLFlBQVksQ0FDakI7QUFDQSxJQUFJLGFBQWE7QUFDakIsSUFBSSxjQUE4Qiw2QkFBTSxXQUN0Qix1QkFBTyxTQUFTLGFBQWEsT0FBTyxjQUFjO0NBQ2hFLE1BQU0sRUFBRSxlQUFlLEdBQUcsZUFBZTtDQUN6QyxNQUFNLFVBQVUsaUJBQWlCLFlBQVksYUFBYTtDQUMxRCxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FDckIsVUFBVSxNQUNWO0VBQ0UsaUJBQWlCLFFBQVEsV0FBVyxLQUFLLEtBQUs7RUFDOUMsb0JBQW9CLFFBQVE7RUFDNUIsR0FBRztFQUNILEtBQUs7Q0FDUCxDQUNGO0FBQ0YsR0FBRyxhQUFhLENBQ2xCO0FBQ0EsSUFBSSxhQUFhO0FBQ2pCLElBQUksY0FBOEIsNkJBQU0sV0FDdEIsdUJBQU8sU0FBUyxhQUFhLE9BQU8sY0FBYztDQUNoRSxNQUFNLEVBQUUsZUFBZSxHQUFHLGVBQWU7Q0FDekMsTUFBTSxVQUFVLGlCQUFpQixZQUFZLGFBQWE7Q0FDMUQsTUFBTSxjQUFjLDRCQUE0QixZQUFZLGFBQWE7Q0FDekUsTUFBTSxNQUFBLGFBQVksT0FBTyxJQUFJO0NBQzdCLE1BQU0sZUFBZSxnQkFBZ0IsY0FBYyxHQUFHO0NBQ3RELE1BQU0sY0FBYyxRQUFRLE9BQU87Q0FDbkMsTUFBTSxjQUFjLFFBQVEsT0FBTyxLQUNoQyxVQUFVLHlCQUF5QixPQUFPLFFBQVEsS0FBSyxRQUFRLEdBQUcsQ0FDckU7Q0FDQSxNQUFNLGNBQWMsY0FBYyxJQUFJLEtBQUssSUFBSSxHQUFHLFdBQVcsSUFBSTtDQUNqRSxNQUFNLFlBQVksTUFBTSxLQUFLLElBQUksR0FBRyxXQUFXO0NBQy9DLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUNyQixVQUFVLE1BQ1Y7RUFDRSxvQkFBb0IsUUFBUTtFQUM1QixpQkFBaUIsUUFBUSxXQUFXLEtBQUssS0FBSztFQUM5QyxHQUFHO0VBQ0gsS0FBSztFQUNMLE9BQU87R0FDTCxHQUFHLE1BQU07SUFDUixZQUFZLFlBQVksY0FBYztJQUN0QyxZQUFZLFVBQVUsWUFBWTtFQUNyQztDQUNGLENBQ0Y7QUFDRixHQUFHLGFBQWEsQ0FDbEI7QUFFQSxJQUFJLENBQUMsNEJBQTRCLHlCQUF5QixvQkFBb0IsYUFBVTtBQUN4RixJQUFJLHNCQUFzQjtBQUMxQixTQUFTLG9CQUFvQixPQUFPO0NBQ2xDLE1BQU0sRUFDSixlQUNBLE1BQ0EsVUFFQSwrQkFDRTtDQUNKLE1BQU0sVUFBVSxpQkFBaUIscUJBQXFCLGFBQWE7Q0FDbkUsTUFBTSxXQUFXLGNBQWMsYUFBYTtDQUM1QyxNQUFNLENBQUMsT0FBTyxZQUFBLGFBQWtCLFNBQVMsSUFBSTtDQUM3QyxNQUFNLFFBQUEsYUFBYyxjQUNaLFFBQVEsU0FBUyxDQUFDLENBQUMsV0FBVyxTQUFTLEtBQUssSUFBSSxZQUFZLEtBQUssSUFBSSxJQUMzRSxDQUFDLFVBQVUsS0FBSyxDQUNsQjtDQUNBLE1BQU0sT0FBTyxRQUFRLEtBQUs7Q0FDMUIsTUFBTSxnQkFBZ0IsUUFBUSxDQUFDLENBQUMsUUFBUSxRQUFRLENBQUMsQ0FBQyxNQUFNLFFBQVEsTUFBTSxJQUFJO0NBQzFFLE1BQU0sUUFBUSxRQUFRLE9BQU87Q0FDN0IsTUFBTSxlQUFlLFNBQVMsUUFBUSxPQUFPLFFBQVEsUUFBUSxRQUFRLE9BQU8sU0FBUyxJQUFJLE9BQU8sTUFBTSxLQUFLO0NBQzNHLE1BQU0sVUFBVSxVQUFVLEtBQUssSUFBSSxJQUFJLHlCQUF5QixPQUFPLFFBQVEsS0FBSyxRQUFRLEdBQUc7Q0FDL0YsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxPQUFPO0dBQ1QsUUFBUSxPQUFPLElBQUksS0FBSztHQUN4QixhQUFhO0lBQ1gsUUFBUSxPQUFPLE9BQU8sS0FBSztHQUM3QjtFQUNGO0NBQ0YsR0FBRyxDQUFDLE9BQU8sUUFBUSxNQUFNLENBQUM7Q0FDMUIsTUFBTSxlQUFlO0VBQ25CO0VBQ0EsTUFBTTtFQUNOLE1BQU0sUUFBUTtFQUNkO0VBQ0E7RUFDQTtFQUNBLGVBQWU7RUFDZjtFQUNBO0NBQ0Y7Q0FDQSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSw0QkFBNEI7RUFBRSxPQUFPO0VBQWUsR0FBRztFQUFjLFVBQVUsV0FBVywwQkFBMEIsSUFBSSwyQkFBMkIsWUFBWSxJQUFJO0NBQVMsQ0FBQztBQUMxTTtBQUNBLE9BQU8scUJBQXFCLHFCQUFxQjtBQUNqRCxJQUFJLHFCQUFxQjtBQUN6QixJQUFJLHFCQUFxQyw2QkFBTSxXQUU3Qix1QkFBTyxTQUFTLG9CQUFvQixPQUFPLGNBQWM7Q0FDdkUsTUFBTSxFQUFFLGVBQWUsR0FBRyxlQUFlO0NBQ3pDLE1BQU0sVUFBVSxpQkFBaUIsb0JBQW9CLGFBQWE7Q0FDbEUsTUFBTSxjQUFjLDRCQUE0QixvQkFBb0IsYUFBYTtDQUNqRixNQUFNLEVBQUUsT0FBTyxPQUFPLFNBQVMsTUFBTSxrQkFBa0Isc0JBQ3JELG9CQUNBLGFBQ0Y7Q0FDQSxNQUFNLGVBQWUsZ0JBQWdCLGNBQWMsYUFBYTtDQUNoRSxNQUFNLFFBQVEsU0FBUyxPQUFPLFFBQVEsT0FBTyxNQUFNO0NBQ25ELE1BQU0sa0JBQWtCLE9BQU8sWUFBWTtDQUMzQyxNQUFNLHNCQUFzQixrQkFBa0IsdUJBQXVCLGlCQUFpQixTQUFTLFlBQVksU0FBUyxJQUFJO0NBQ3hILE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUNyQixRQUNBO0VBQ0UsT0FBTztHQUNMLFdBQVc7R0FDWCxVQUFVO0lBQ1QsWUFBWSxZQUFZLFFBQVEsUUFBUSxNQUFNLG9CQUFvQjtFQUNyRTtFQUNBLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFdBQVcsVUFBVTtHQUFFLE9BQU87R0FBZSxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FDbkcsVUFBVSxNQUNWO0lBQ0UsTUFBTTtJQUNOLGNBQWMsTUFBTSxpQkFBaUI7SUFDckMsaUJBQWlCLFFBQVE7SUFDekIsaUJBQWlCO0lBQ2pCLGlCQUFpQixRQUFRO0lBQ3pCLG9CQUFvQixRQUFRO0lBQzVCLG9CQUFvQixRQUFRO0lBQzVCLGlCQUFpQixRQUFRLFdBQVcsS0FBSyxLQUFLO0lBQzlDLFVBQVUsUUFBUSxXQUFXLEtBQUssSUFBSTtJQUN0QyxHQUFHO0lBQ0gsS0FBSztJQUNMLE9BQU8sVUFBVSxLQUFLLElBQUksRUFBRSxTQUFTLE9BQU8sSUFBSSxNQUFNO0lBQ3RELFNBQVMscUJBQXFCLE1BQU0sZUFBZTtLQUNqRCxRQUFRLHNCQUFzQixVQUFVO0lBQzFDLENBQUM7R0FDSCxDQUNGO0VBQUUsQ0FBQztDQUNMLENBQ0Y7QUFDRixHQUFHLG9CQUFvQixDQUN6QjtBQUNBLElBQUksY0FBOEIsNkJBQU0sV0FDdEIsdUJBQU8sU0FBUyxhQUFhLE9BQU8sY0FBYztDQUNoRSxNQUFNLEVBQUUsZUFBZSxNQUFNLEdBQUcsZUFBZTtDQUMvQyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FDckIscUJBQ0E7RUFDRTtFQUNBO0VBQ0EsNkJBQTZCLEVBQUUsT0FBTyxvQkFBb0MsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUtJLG1CQUFBQSxVQUFVLEVBQUUsVUFBVSxDQUNuRixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FDZCxvQkFDQTtHQUNFLEdBQUc7R0FDSCxLQUFLO0dBQ0w7RUFDRixDQUNGLEdBQ0EsZ0JBQWdDLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUM5QixtQkFDQSxFQUNFLGNBQ0YsR0FDQSxLQUNGLElBQUksSUFDTixFQUFFLENBQUM7Q0FDTCxDQUNGO0FBQ0YsR0FBRyxhQUFhLENBQ2xCO0FBQ0EsSUFBSSxvQkFBb0I7QUFDeEIsSUFBSSxvQkFBb0MsNkJBQU0sV0FFNUIsdUJBQU8sU0FBUyxtQkFBbUIsRUFBRSxlQUFlLFNBQVMsR0FBRyxTQUFTLGNBQWM7Q0FDckcsTUFBTSxFQUFFLE9BQU8sT0FBTyxNQUFNLFNBQVMsc0JBQXNCLG1CQUFtQixhQUFhO0NBQzNGLE1BQU0sRUFBRSx3QkFBd0IsaUJBQWlCLG1CQUFtQixhQUFhO0NBQ2pGLE1BQU0sTUFBQSxhQUFZLE9BQU8sSUFBSTtDQUM3QixNQUFNLGVBQWUsZ0JBQWdCLEtBQUssWUFBWTtDQUN0RCxNQUFNLGdDQUFBLGFBQXNDLE9BQU8sS0FBSztDQUN4RCxNQUFNLGVBQUEsYUFBcUIsT0FBTyxLQUFLO0NBQ3ZDLE1BQU0sZ0NBQUEsYUFBc0MsT0FBTyxtQkFBbUI7Q0FDdEUsTUFBTSw2QkFBQSxhQUFtQyxPQUFPLG1CQUFtQjtDQUNuRSxhQUFNLGdCQUFnQjtFQUNwQixNQUFNLFFBQVEsSUFBSTtFQUNsQixJQUFJLENBQUMsT0FDSDtFQUVGLE1BQU0sYUFBYSxPQUFPLGlCQUFpQjtFQUUzQyxNQUFNLFdBRGEsT0FBTyx5QkFBeUIsWUFBWSxPQUNyQyxDQUFDLENBQUM7RUFDNUIsTUFBTSxZQUFZLGFBQWE7RUFDL0IsTUFBTSxlQUFlLGNBQWM7RUFDbkMsYUFBYSxVQUFVO0VBQ3ZCLE1BQU0sOEJBQThCLHdCQUF3QiwyQkFBMkI7RUFDdkYsMkJBQTJCLFVBQVU7RUFDckMsSUFBSSxnQkFBZ0IsVUFBVTtHQUM1QixNQUFNLDBCQUEwQix3QkFBd0IsOEJBQThCO0dBQ3RGLDhCQUE4QixVQUFVO0dBQ3hDLE1BQU0saUJBQWlCLHNCQUFzQjtHQUU3Qyw4QkFBOEIsVUFBVSxFQURkLDRCQUE0QiwrQkFBK0IsbUJBQW1CLGFBQWEsbUJBQW1CO0dBRXhJLE1BQU0sUUFBUSxJQUFJLE1BQU0sU0FBUyxFQUFFLFNBQVMsS0FBSyxDQUFDO0dBQ2xELFNBQVMsS0FBSyxPQUFPLEtBQUs7R0FDMUIsTUFBTSxjQUFjLEtBQUs7R0FDekIsOEJBQThCLFVBQVU7RUFDMUM7Q0FDRixHQUFHO0VBQUM7RUFBTztFQUFPO0NBQW1CLENBQUM7Q0FDdEMsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQ3JCLFVBQVUsT0FDVjtFQUNFLE9BQU8sRUFBRSxTQUFTLE9BQU87RUFDekI7RUFDQTtFQUNBLEdBQUc7RUFDSCxLQUFLO0VBQ0wsY0FBYztFQUNkLFNBQVMscUJBQXFCLFVBQVUsVUFBVTtHQUNoRCxJQUFJLDhCQUE4QixTQUNoQyxNQUFNLGdCQUFnQjtFQUUxQixDQUFDO0NBQ0gsQ0FDRjtBQUNGLEdBQUcsbUJBQW1CLENBQ3hCO0FBQ0EsU0FBUyxvQkFBb0IsYUFBYSxDQUFDLEdBQUcsV0FBVyxTQUFTO0NBQ2hFLE1BQU0sYUFBYSxDQUFDLEdBQUcsVUFBVTtDQUNqQyxXQUFXLFdBQVc7Q0FDdEIsT0FBTyxXQUFXLE1BQU0sR0FBRyxNQUFNLElBQUksQ0FBQztBQUN4QztBQUNBLE9BQU8scUJBQXFCLHFCQUFxQjtBQUNqRCxTQUFTLHlCQUF5QixPQUFPLEtBQUssS0FBSztDQUlqRCxPQUFPLE1BRmdCLE9BRE4sTUFBTSxRQUVjLFFBQVEsTUFDcEIsQ0FBQyxHQUFHLEdBQUcsQ0FBQztBQUNuQztBQUNBLE9BQU8sMEJBQTBCLDBCQUEwQjtBQUMzRCxTQUFTLFNBQVMsT0FBTyxhQUFhO0NBQ3BDLElBQUksY0FBYyxHQUNoQixPQUFPLFNBQVMsUUFBUSxFQUFFLE1BQU07TUFDM0IsSUFBSSxnQkFBZ0IsR0FDekIsT0FBTyxDQUFDLFdBQVcsU0FBUyxDQUFDLENBQUM7TUFFOUI7QUFFSjtBQUNBLE9BQU8sVUFBVSxVQUFVO0FBQzNCLFNBQVMscUJBQXFCLFFBQVEsV0FBVztDQUMvQyxJQUFJLE9BQU8sV0FBVyxHQUFHLE9BQU87Q0FDaEMsTUFBTSxZQUFZLE9BQU8sS0FBSyxVQUFVLEtBQUssSUFBSSxRQUFRLFNBQVMsQ0FBQztDQUNuRSxNQUFNLGtCQUFrQixLQUFLLElBQUksR0FBRyxTQUFTO0NBQzdDLE9BQU8sVUFBVSxRQUFRLGVBQWU7QUFDMUM7QUFDQSxPQUFPLHNCQUFzQixzQkFBc0I7QUFDbkQsU0FBUyx1QkFBdUIsT0FBTyxNQUFNLFdBQVc7Q0FDdEQsTUFBTSxZQUFZLFFBQVE7Q0FHMUIsUUFBUSxZQURPLFlBQVksQ0FBQyxHQUFHLEVBQVcsR0FBRyxDQUFDLEdBQUcsU0FBUyxDQUNqQyxDQUFDLENBQUMsSUFBSSxJQUFJLGFBQWE7QUFDbEQ7QUFDQSxPQUFPLHdCQUF3Qix3QkFBd0I7QUFDdkQsU0FBUyxzQkFBc0IsUUFBUTtDQUNyQyxPQUFPLE9BQU8sTUFBTSxHQUFHLEVBQUUsQ0FBQyxDQUFDLEtBQUssT0FBTyxVQUFVLE9BQU8sUUFBUSxLQUFLLEtBQUs7QUFDNUU7QUFDQSxPQUFPLHVCQUF1Qix1QkFBdUI7QUFDckQsU0FBUyx5QkFBeUIsUUFBUSx1QkFBdUI7Q0FDL0QsSUFBSSx3QkFBd0IsR0FBRztFQUM3QixNQUFNLHFCQUFxQixzQkFBc0IsTUFBTTtFQUV2RCxPQURvQyxLQUFLLElBQUksR0FBRyxrQkFDZixLQUFLO0NBQ3hDO0NBQ0EsT0FBTztBQUNUO0FBQ0EsT0FBTywwQkFBMEIsMEJBQTBCO0FBQzNELFNBQVMsWUFBWSxPQUFPLFFBQVE7Q0FDbEMsUUFBUSxVQUFVO0VBQ2hCLElBQUksTUFBTSxPQUFPLE1BQU0sTUFBTSxPQUFPLE9BQU8sT0FBTyxJQUFJLE9BQU8sT0FBTztFQUNwRSxNQUFNLFNBQVMsT0FBTyxLQUFLLE9BQU8sT0FBTyxNQUFNLEtBQUssTUFBTTtFQUMxRCxPQUFPLE9BQU8sS0FBSyxTQUFTLFFBQVEsTUFBTTtDQUM1QztBQUNGO0FBQ0EsT0FBTyxhQUFhLGFBQWE7QUFDakMsU0FBUyxnQkFBZ0IsT0FBTztDQUM5QixJQUFJLENBQUMsT0FBTyxTQUFTLEtBQUssR0FBRyxPQUFPO0NBQ3BDLE1BQU0sTUFBTSxNQUFNLFNBQVM7Q0FDM0IsSUFBSSxJQUFJLFNBQVMsR0FBRyxHQUFHO0VBQ3JCLE1BQU0sQ0FBQyxhQUFhLFlBQVksSUFBSSxNQUFNLEdBQUc7RUFDN0MsTUFBTSxlQUFlLFlBQVksTUFBTSxHQUFHLENBQUMsQ0FBQyxNQUFNO0VBQ2xELE1BQU0sY0FBYyxPQUFPLFFBQVE7RUFDbkMsT0FBTyxLQUFLLElBQUksR0FBRyxhQUFhLFNBQVMsV0FBVztDQUN0RDtDQUNBLE1BQU0sY0FBYyxJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUM7Q0FDbkMsT0FBTyxjQUFjLFlBQVksU0FBUztBQUM1QztBQUNBLE9BQU8saUJBQWlCLGlCQUFpQjtBQUN6QyxTQUFTLFdBQVcsT0FBTyxjQUFjO0NBQ3ZDLE1BQU0sVUFBVSxLQUFLLElBQUksSUFBSSxZQUFZO0NBQ3pDLE9BQU8sS0FBSyxNQUFNLFFBQVEsT0FBTyxJQUFJO0FBQ3ZDO0FBQ0EsT0FBTyxZQUFZLFlBQVk7QUFDL0IsU0FBUyxpQkFBaUIsT0FBTyxFQUMvQixLQUNBLE1BQ0EsV0FDQSxjQUNDO0NBQ0QsTUFBTSxlQUFlLGdCQUFnQixJQUFJO0NBQ3pDLE1BQU0sZ0JBQWdCLFFBQVEsT0FBTztDQUNyQyxNQUFNLGVBQWUsS0FBSyxNQUFNLFlBQVk7Q0FDNUMsTUFBTSxZQUFZLFdBQVcsZUFBZSxPQUFPLEtBQUssWUFBWSxNQUFNLFdBQVcsT0FBTyxZQUFZO0NBQ3hHLElBQUk7Q0FDSixJQUFJLFdBQ0YsWUFBWSxlQUFlLGFBQWE7TUFDbkMsSUFBSSxZQUFZLEdBQ3JCLFlBQVksS0FBSyxLQUFLLFlBQVk7TUFFbEMsWUFBWSxLQUFLLE1BQU0sWUFBWTtDQUVyQyxPQUFPLFdBQVcsWUFBWSxPQUFPLEtBQUssWUFBWTtBQUN4RDtBQUNBLE9BQU8sa0JBQWtCLGtCQUFrQjtBQUMzQyxTQUFTLFdBQVcsT0FBTztDQUN6QixPQUFPLE9BQU8sVUFBVTtBQUMxQjtBQUNBLE9BQU8sWUFBWSxZQUFZIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyLDMsNF19
import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SidebarFilters.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=7abeec5e";
import { Slider } from "/src/components/ui/slider.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { FormSelect } from "/src/components/FormSelect.tsx?t=1792164282123";
import { Input } from "/src/components/ui/input.tsx";
import { Dialog, DialogContent, DialogTitle, DialogDescription, DialogTrigger } from "/src/components/ui/dialog.tsx?t=1792166201444";
import { parseEthToBigInt } from "/src/lib/decimal.ts";
import { Sheet, SheetContent, SheetTitle, SheetDescription, SheetClose } from "/src/components/ui/sheet.tsx";
import { useMediaQuery } from "/src/lib/use-media-query.ts";
var _jsxFileName = "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/SidebarFilters.tsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7abeec5e";
var _s = $RefreshSig$();
export const SidebarFilters = ({ mobileOpen = false, onMobileOpenChange, collections, networks, selectedCollection = "", selectedNetwork = "", minPrice = "0.02", maxPrice = "12.30", onSelectCollection, onSelectNetwork, onPriceChange, onClearFilters, selectedSort = "recent", onSortChange }) => {
	_s();
	const mobile = useMediaQuery("(max-width: 767px)");
	const exactMin = minPrice || "0.02";
	const exactMax = maxPrice || "12.30";
	const source = `${exactMin}/${exactMax}`;
	const [rangeDraft, setRangeDraft] = useState({
		source,
		value: [exactMin, exactMax]
	});
	const range = rangeDraft.source === source ? rangeDraft.value : [exactMin, exactMax];
	const [priceError, setPriceError] = useState("");
	const [priceEditorOpen, setPriceEditorOpen] = useState(false);
	// The slider has 0.01 ETH steps; exact strings remain intact until it is moved.
	const sliderRange = range.map((value) => Math.max(0, Math.min(15, Number(value) || 0)));
	const setSliderRange = (value) => setRangeDraft({
		source,
		value: value.map((amount) => amount.toFixed(2))
	});
	const hasActiveFilters = Boolean(selectedCollection || selectedNetwork || minPrice && minPrice !== "0.02" || maxPrice && maxPrice !== "12.30");
	const handleApply = () => {
		try {
			if (parseEthToBigInt(range[0]) < 0n || parseEthToBigInt(range[0]) > parseEthToBigInt(range[1])) throw new Error();
			setPriceError("");
			onPriceChange(range[0].trim(), range[1].trim());
			return true;
		} catch {
			setPriceError("Informe uma faixa válida, com até 18 casas decimais e mínimo menor ou igual ao máximo.");
			return false;
		}
	};
	const formatEthLabel = (value) => value.replace(".", ",");
	const panel = /* @__PURE__ */ _jsxDEV("div", {
		className: "filter-panel flex flex-col gap-6 rounded-xl border border-[#3F2319] bg-[#241612] p-5 shadow-lg",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-between border-b border-[#3F2319] pb-3",
				children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "font-mono text-base font-bold uppercase tracking-wider text-[#F5F1EB]",
					children: "Filtros"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 73,
					columnNumber: 11
				}, this), hasActiveFilters && /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: onClearFilters,
					className: "font-mono text-xs text-[#E89B55] hover:underline cursor-pointer",
					children: "Limpar todos"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 77,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 72,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col gap-3",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "font-mono text-sm font-bold text-[#F5F1EB]",
					children: "Coleções"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 89,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("ul", {
					className: "flex flex-col gap-1.5 font-mono text-xs",
					children: collections.map((col) => {
						const isSelected = selectedCollection.toLowerCase() === col.name.toLowerCase();
						return /* @__PURE__ */ _jsxDEV("li", {
							role: "button",
							tabIndex: 0,
							"aria-pressed": isSelected,
							onKeyDown: (event) => {
								if (event.key === "Enter" || event.key === " ") {
									event.preventDefault();
									onSelectCollection(isSelected ? "" : col.name);
								}
							},
							onClick: () => onSelectCollection(isSelected ? "" : col.name),
							className: `flex cursor-pointer items-center justify-between py-1 transition-colors hover:text-[#E89B55] ${isSelected ? "font-bold text-[#E89B55]" : "text-[#CFB28C]"}`,
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "truncate",
								children: col.name
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 110,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-bold",
								children: [
									"(",
									col.count,
									")"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 111,
								columnNumber: 19
							}, this)]
						}, col.name, true, {
							fileName: _jsxFileName,
							lineNumber: 94,
							columnNumber: 17
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 90,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 88,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col gap-3 border-t border-[#3F2319] pt-4",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "font-mono text-sm font-bold text-[#F5F1EB]",
					children: "Faixa de preço"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 120,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col gap-3 px-1 pt-1",
					children: [
						/* @__PURE__ */ _jsxDEV(Slider, {
							min: 0,
							max: 15,
							step: .01,
							value: sliderRange,
							onValueChange: (val) => setSliderRange(val),
							className: "my-1"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 123,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between pt-1",
							children: /* @__PURE__ */ _jsxDEV(Dialog, {
								open: priceEditorOpen,
								onOpenChange: setPriceEditorOpen,
								children: [/* @__PURE__ */ _jsxDEV(DialogTrigger, {
									className: "price-range-trigger font-mono text-xs text-[#F5F1EB] text-left",
									title: "Editar os valores exatos",
									"aria-label": "Editar faixa de preço",
									children: [
										"Preço: ",
										formatEthLabel(range[0]),
										" - ",
										formatEthLabel(range[1]),
										" ETH"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 134,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV(DialogContent, {
									className: mobile ? "z-[170]" : undefined,
									overlayClassName: mobile ? "z-[160]" : undefined,
									children: [
										/* @__PURE__ */ _jsxDEV(DialogTitle, { children: "Faixa de preço em ETH" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 136,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV(DialogDescription, { children: "Informe valores exatos com até 18 casas decimais. O controle deslizante usa passos de 0,01 ETH." }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 136,
											columnNumber: 67
										}, this),
										/* @__PURE__ */ _jsxDEV("form", {
											onSubmit: (event) => {
												event.preventDefault();
												if (handleApply()) setPriceEditorOpen(false);
											},
											className: "space-y-4",
											children: [
												/* @__PURE__ */ _jsxDEV("label", {
													className: "block text-sm",
													children: ["Preço mínimo em ETH", /* @__PURE__ */ _jsxDEV(Input, {
														value: range[0],
														inputMode: "decimal",
														"aria-invalid": !!priceError,
														"aria-describedby": priceError ? "price-range-error" : undefined,
														onChange: (event) => setRangeDraft({
															source,
															value: [event.target.value, range[1]]
														})
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 138,
														columnNumber: 73
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 138,
													columnNumber: 21
												}, this),
												/* @__PURE__ */ _jsxDEV("label", {
													className: "block text-sm",
													children: ["Preço máximo em ETH", /* @__PURE__ */ _jsxDEV(Input, {
														value: range[1],
														inputMode: "decimal",
														"aria-invalid": !!priceError,
														"aria-describedby": priceError ? "price-range-error" : undefined,
														onChange: (event) => setRangeDraft({
															source,
															value: [range[0], event.target.value]
														})
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 139,
														columnNumber: 73
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 139,
													columnNumber: 21
												}, this),
												priceError && /* @__PURE__ */ _jsxDEV("p", {
													id: "price-range-error",
													role: "alert",
													className: "text-xs text-[#E89B55]",
													children: priceError
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 140,
													columnNumber: 36
												}, this),
												/* @__PURE__ */ _jsxDEV(Button, {
													type: "submit",
													children: "Aplicar faixa"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 141,
													columnNumber: 21
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 137,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 135,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 133,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 132,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(Button, {
							type: "button",
							onClick: handleApply,
							className: "mt-1 h-9 w-full bg-[#D28A4C] hover:bg-[#E89B55] text-[#140D0A] font-mono text-xs font-bold uppercase tracking-wider rounded-[6px]",
							children: "Aplicar"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 147,
							columnNumber: 13
						}, this),
						priceError && !priceEditorOpen && /* @__PURE__ */ _jsxDEV("p", {
							role: "alert",
							className: "text-xs text-[#E89B55]",
							children: priceError
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 154,
							columnNumber: 48
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 122,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 119,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col gap-3 border-t border-[#3F2319] pt-4",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "font-mono text-sm font-bold text-[#F5F1EB]",
					children: "Rede"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 160,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("ul", {
					className: "flex flex-col gap-1.5 font-mono text-xs",
					children: networks.map((net) => {
						const isSelected = selectedNetwork.toLowerCase() === net.name.toLowerCase();
						return /* @__PURE__ */ _jsxDEV("li", {
							role: "button",
							tabIndex: 0,
							"aria-pressed": isSelected,
							onKeyDown: (event) => {
								if (event.key === "Enter" || event.key === " ") {
									event.preventDefault();
									onSelectNetwork(isSelected ? "" : net.name);
								}
							},
							onClick: () => onSelectNetwork(isSelected ? "" : net.name),
							className: `flex cursor-pointer items-center justify-between py-1 transition-colors hover:text-[#E89B55] ${isSelected ? "font-bold text-[#E89B55]" : "text-[#CFB28C]"}`,
							children: [/* @__PURE__ */ _jsxDEV("span", { children: net.name }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 181,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-bold",
								children: [
									"(",
									net.count,
									")"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 182,
								columnNumber: 19
							}, this)]
						}, net.name, true, {
							fileName: _jsxFileName,
							lineNumber: 165,
							columnNumber: 17
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 161,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 159,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "md:hidden",
				children: [/* @__PURE__ */ _jsxDEV("label", {
					htmlFor: "mobile-sort",
					children: "Ordenar por"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 188,
					columnNumber: 36
				}, this), /* @__PURE__ */ _jsxDEV(FormSelect, {
					id: "mobile-sort",
					"aria-label": "Ordenar NFTs",
					value: selectedSort,
					onValueChange: (value) => onSortChange?.(value),
					className: "mt-2",
					options: [
						{
							value: "recent",
							label: "Mais recentes"
						},
						{
							value: "price_asc",
							label: "Menor preço"
						},
						{
							value: "price_desc",
							label: "Maior preço"
						}
					]
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 188,
					columnNumber: 84
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 188,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 70,
		columnNumber: 7
	}, this);
	return /* @__PURE__ */ _jsxDEV("aside", {
		className: "catalog-filters flex w-full flex-col gap-4 md:w-[280px] lg:w-[310px]",
		children: [mobile ? /* @__PURE__ */ _jsxDEV(Sheet, {
			open: mobileOpen,
			onOpenChange: onMobileOpenChange,
			children: /* @__PURE__ */ _jsxDEV(SheetContent, {
				side: "bottom",
				className: "mobile-filters-sheet z-[100] max-h-[calc(100dvh-24px)] overflow-y-auto rounded-t-3xl",
				onCloseAutoFocus: (event) => {
					event.preventDefault();
					requestAnimationFrame(() => document.querySelector("[aria-label=\"Filtros do catálogo\"]")?.focus());
				},
				children: [
					/* @__PURE__ */ _jsxDEV(SheetTitle, { children: "Filtros do catálogo" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 195,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(SheetDescription, { children: "Combine coleção, rede, preço e ordenação." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 195,
						columnNumber: 55
					}, this),
					panel,
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between gap-4 pt-4",
						children: [/* @__PURE__ */ _jsxDEV(Button, {
							variant: "outline",
							onClick: onClearFilters,
							children: "Limpar filtros"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 197,
							columnNumber: 73
						}, this), /* @__PURE__ */ _jsxDEV(SheetClose, {
							asChild: true,
							children: /* @__PURE__ */ _jsxDEV(Button, { children: "Ver resultados" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 197,
								columnNumber: 167
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 197,
							columnNumber: 147
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 197,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 194,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 193,
			columnNumber: 17
		}, this) : panel, /* @__PURE__ */ _jsxDEV("a", {
			className: "featured-nft",
			href: "/nfts/nft-2",
			children: [
				/* @__PURE__ */ _jsxDEV("strong", { children: "NFT EM DESTAQUE" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 200,
					columnNumber: 54
				}, this),
				/* @__PURE__ */ _jsxDEV("span", { children: "OFERTA LIMITADA" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 200,
					columnNumber: 86
				}, this),
				/* @__PURE__ */ _jsxDEV("img", {
					src: "/assets/images/featured-banner.webp",
					alt: "Sage Nomad em destaque"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 200,
					columnNumber: 114
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 200,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 192,
		columnNumber: 5
	}, this);
};
_s(SidebarFilters, "ZYQvZEXPD7KdM5nVR9cfd6TAqHc=", false, function() {
	return [useMediaQuery];
});
_c = SidebarFilters;
var _c;
$RefreshReg$(_c, "SidebarFilters");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/SidebarFilters.tsx?t=1792166201444";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/SidebarFilters.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/SidebarFilters.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/SidebarFilters.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLGNBQWM7QUFDdkIsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsYUFBYTtBQUN0QixTQUFTLFFBQVEsZUFBZSxhQUFhLG1CQUFtQixxQkFBcUI7QUFDckYsU0FBUyx3QkFBd0I7QUFDakMsU0FBUyxPQUFPLGNBQWMsWUFBWSxrQkFBa0Isa0JBQWtCO0FBQzlFLFNBQVMscUJBQXFCOzs7O0FBbUI5QixPQUFPLE1BQU0sa0JBQWlELEVBQzVELGFBQWEsT0FDYixvQkFDQSxhQUNBLFVBQ0EscUJBQXFCLElBQ3JCLGtCQUFrQixJQUNsQixXQUFXLFFBQ1gsV0FBVyxTQUNYLG9CQUNBLGlCQUNBLGVBQ0EsZ0JBQ0EsZUFBZSxVQUNmLG1CQUNJOztDQUNKLE1BQU0sU0FBUyxjQUFjLG9CQUFvQjtDQUNqRCxNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLFNBQVMsR0FBRyxTQUFTLEdBQUc7Q0FDOUIsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVM7RUFBRTtFQUFRLE9BQU8sQ0FBQyxVQUFVLFFBQVE7Q0FBRSxDQUFDO0NBQ3BGLE1BQU0sUUFBUSxXQUFXLFdBQVcsU0FBUyxXQUFXLFFBQVEsQ0FBQyxVQUFVLFFBQVE7Q0FDbkYsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsRUFBRTtDQUMvQyxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLEtBQUs7O0NBRTVELE1BQU0sY0FBYyxNQUFNLEtBQUksVUFBUyxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksSUFBSSxPQUFPLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQztDQUNwRixNQUFNLGtCQUFrQixVQUFvQixjQUFjO0VBQUU7RUFBUSxPQUFPLE1BQU0sS0FBSSxXQUFVLE9BQU8sUUFBUSxDQUFDLENBQUM7Q0FBRSxDQUFDO0NBRW5ILE1BQU0sbUJBQW1CLFFBQ3ZCLHNCQUFzQixtQkFBb0IsWUFBWSxhQUFhLFVBQVksWUFBWSxhQUFhLE9BQzFHO0NBRUEsTUFBTSxvQkFBb0I7RUFDeEIsSUFBSTtHQUNGLElBQUksaUJBQWlCLE1BQU0sRUFBRSxJQUFJLE1BQU0saUJBQWlCLE1BQU0sRUFBRSxJQUFJLGlCQUFpQixNQUFNLEVBQUUsR0FBRyxNQUFNLElBQUksTUFBTTtHQUNoSCxjQUFjLEVBQUU7R0FBRyxjQUFjLE1BQU0sRUFBRSxDQUFDLEtBQUssR0FBRyxNQUFNLEVBQUUsQ0FBQyxLQUFLLENBQUM7R0FBRyxPQUFPO0VBQzdFLFFBQVE7R0FBRSxjQUFjLHdGQUF3RjtHQUFHLE9BQU87RUFBTTtDQUNsSTtDQUVBLE1BQU0sa0JBQWtCLFVBQWtCLE1BQU0sUUFBUSxLQUFLLEdBQUc7Q0FFaEUsTUFBTSxRQUNGLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBd0U7SUFFbEY7Ozs7Y0FDSCxvQkFDQyx3QkFBQyxVQUFEO0tBQ0UsTUFBSztLQUNMLFNBQVM7S0FDVCxXQUFVO2VBQ1g7SUFFTzs7OztZQUVQOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBNkM7SUFBWTs7OztjQUN2RSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUNYLFlBQVksS0FBSyxRQUFRO01BQ3hCLE1BQU0sYUFBYSxtQkFBbUIsWUFBWSxNQUFNLElBQUksS0FBSyxZQUFZO01BQzdFLE9BQ0Usd0JBQUMsTUFBRDtPQUVFLE1BQUs7T0FDTCxVQUFVO09BQ1YsZ0JBQWM7T0FDZCxZQUFXLFVBQVM7UUFDbEIsSUFBSSxNQUFNLFFBQVEsV0FBVyxNQUFNLFFBQVEsS0FBSztTQUM5QyxNQUFNLGVBQWU7U0FDckIsbUJBQW1CLGFBQWEsS0FBSyxJQUFJLElBQUk7UUFDL0M7T0FDRjtPQUNBLGVBQWUsbUJBQW1CLGFBQWEsS0FBSyxJQUFJLElBQUk7T0FDNUQsV0FBVyxnR0FDVCxhQUFhLDZCQUE2QjtpQkFiOUMsQ0FnQkUsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQVksSUFBSTtPQUFXOzs7O2lCQUMzQyx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEI7U0FBNEI7U0FBRSxJQUFJO1NBQU07UUFBTzs7Ozs7ZUFDN0M7U0FqQkcsSUFBSTs7OzthQWlCUDtLQUVSLENBQUM7SUFDQzs7OztZQUNEOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBNkM7SUFBa0I7Ozs7Y0FFN0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLFFBQUQ7T0FDRSxLQUFLO09BQ0wsS0FBSztPQUNMLE1BQU07T0FDTixPQUFPO09BQ1AsZ0JBQWdCLFFBQVEsZUFBZSxHQUFHO09BQzFDLFdBQVU7TUFDWDs7Ozs7TUFFRCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxRQUFEO1FBQVEsTUFBTTtRQUFpQixjQUFjO2tCQUE3QyxDQUNFLHdCQUFDLGVBQUQ7U0FBZSxXQUFVO1NBQWlFLE9BQU07U0FBMkIsY0FBVzttQkFBdEk7VUFBOEo7VUFBUSxlQUFlLE1BQU0sRUFBRTtVQUFFO1VBQUksZUFBZSxNQUFNLEVBQUU7VUFBRTtTQUFtQjs7Ozs7a0JBQy9PLHdCQUFDLGVBQUQ7U0FBZSxXQUFXLFNBQVMsWUFBWTtTQUFXLGtCQUFrQixTQUFTLFlBQVk7bUJBQWpHO1VBQ0Usd0JBQUMsYUFBRCxZQUFhLHdCQUFrQzs7Ozs7VUFBQyx3QkFBQyxtQkFBRCxZQUFtQixrR0FBa0g7Ozs7O1VBQ3JMLHdCQUFDLFFBQUQ7V0FBTSxXQUFVLFVBQVM7WUFBRSxNQUFNLGVBQWU7WUFBRyxJQUFJLFlBQVksR0FBRyxtQkFBbUIsS0FBSztXQUFFO1dBQUcsV0FBVTtxQkFBN0c7WUFDRSx3QkFBQyxTQUFEO2FBQU8sV0FBVTt1QkFBakIsQ0FBaUMsdUJBQW1CLHdCQUFDLE9BQUQ7Y0FBTyxPQUFPLE1BQU07Y0FBSSxXQUFVO2NBQVUsZ0JBQWMsQ0FBQyxDQUFDO2NBQVksb0JBQWtCLGFBQWEsc0JBQXNCO2NBQVcsV0FBVSxVQUFTLGNBQWM7ZUFBRTtlQUFRLE9BQU8sQ0FBQyxNQUFNLE9BQU8sT0FBTyxNQUFNLEVBQUU7Y0FBRSxDQUFDO2FBQUk7Ozs7cUJBQVE7Ozs7OztZQUMxUix3QkFBQyxTQUFEO2FBQU8sV0FBVTt1QkFBakIsQ0FBaUMsdUJBQW1CLHdCQUFDLE9BQUQ7Y0FBTyxPQUFPLE1BQU07Y0FBSSxXQUFVO2NBQVUsZ0JBQWMsQ0FBQyxDQUFDO2NBQVksb0JBQWtCLGFBQWEsc0JBQXNCO2NBQVcsV0FBVSxVQUFTLGNBQWM7ZUFBRTtlQUFRLE9BQU8sQ0FBQyxNQUFNLElBQUksTUFBTSxPQUFPLEtBQUs7Y0FBRSxDQUFDO2FBQUk7Ozs7cUJBQVE7Ozs7OztZQUN6UixjQUFjLHdCQUFDLEtBQUQ7YUFBRyxJQUFHO2FBQW9CLE1BQUs7YUFBUSxXQUFVO3VCQUEwQjtZQUFjOzs7OztZQUN4Ryx3QkFBQyxRQUFEO2FBQVEsTUFBSzt1QkFBUztZQUFxQjs7Ozs7V0FDdkM7Ozs7OztTQUNPOzs7OztnQkFDVDs7Ozs7O01BQ0w7Ozs7O01BRUwsd0JBQUMsUUFBRDtPQUNFLE1BQUs7T0FDTCxTQUFTO09BQ1QsV0FBVTtpQkFDWDtNQUVPOzs7OztNQUNQLGNBQWMsQ0FBQyxtQkFBbUIsd0JBQUMsS0FBRDtPQUFHLE1BQUs7T0FBUSxXQUFVO2lCQUEwQjtNQUFjOzs7OztLQUNsRzs7Ozs7WUFDRjs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQTZDO0lBQVE7Ozs7Y0FDbkUsd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFDWCxTQUFTLEtBQUssUUFBUTtNQUNyQixNQUFNLGFBQWEsZ0JBQWdCLFlBQVksTUFBTSxJQUFJLEtBQUssWUFBWTtNQUMxRSxPQUNFLHdCQUFDLE1BQUQ7T0FFRSxNQUFLO09BQ0wsVUFBVTtPQUNWLGdCQUFjO09BQ2QsWUFBVyxVQUFTO1FBQ2xCLElBQUksTUFBTSxRQUFRLFdBQVcsTUFBTSxRQUFRLEtBQUs7U0FDOUMsTUFBTSxlQUFlO1NBQ3JCLGdCQUFnQixhQUFhLEtBQUssSUFBSSxJQUFJO1FBQzVDO09BQ0Y7T0FDQSxlQUFlLGdCQUFnQixhQUFhLEtBQUssSUFBSSxJQUFJO09BQ3pELFdBQVcsZ0dBQ1QsYUFBYSw2QkFBNkI7aUJBYjlDLENBZ0JFLHdCQUFDLFFBQUQsWUFBTyxJQUFJLEtBQVc7Ozs7aUJBQ3RCLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQjtTQUE0QjtTQUFFLElBQUk7U0FBTTtRQUFPOzs7OztlQUM3QztTQWpCRyxJQUFJOzs7O2FBaUJQO0tBRVIsQ0FBQztJQUNDOzs7O1lBQ0Q7Ozs7OztHQUNMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FBMkIsd0JBQUMsU0FBRDtLQUFPLFNBQVE7ZUFBYztJQUFrQjs7OztjQUFDLHdCQUFDLFlBQUQ7S0FBWSxJQUFHO0tBQWMsY0FBVztLQUFlLE9BQU87S0FBYyxnQkFBZSxVQUFTLGVBQWUsS0FBOEM7S0FBRyxXQUFVO0tBQU8sU0FBUztNQUFDO09BQUUsT0FBTztPQUFVLE9BQU87TUFBZ0I7TUFBRztPQUFFLE9BQU87T0FBYSxPQUFPO01BQWM7TUFBRztPQUFFLE9BQU87T0FBYyxPQUFPO01BQWM7S0FBQztJQUFJOzs7O1lBQU07Ozs7OztFQUN6Wjs7Ozs7O0NBRVQsT0FDRSx3QkFBQyxTQUFEO0VBQU8sV0FBVTtZQUFqQixDQUNHLFNBQVMsd0JBQUMsT0FBRDtHQUFPLE1BQU07R0FBWSxjQUFjO2FBQy9DLHdCQUFDLGNBQUQ7SUFBYyxNQUFLO0lBQVMsV0FBVTtJQUF1RixtQkFBa0IsVUFBUztLQUFFLE1BQU0sZUFBZTtLQUFHLDRCQUE0QixTQUFTLGNBQWlDLHNDQUFvQyxDQUFDLEVBQUUsTUFBTSxDQUFDO0lBQUU7Y0FBeFM7S0FDRSx3QkFBQyxZQUFELFlBQVksc0JBQStCOzs7OztLQUFDLHdCQUFDLGtCQUFELFlBQWtCLDRDQUEyRDs7Ozs7S0FDeEg7S0FDRCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUE4RCx3QkFBQyxRQUFEO09BQVEsU0FBUTtPQUFVLFNBQVM7aUJBQWdCO01BQXNCOzs7O2dCQUFDLHdCQUFDLFlBQUQ7T0FBWTtpQkFBUSx3QkFBQyxRQUFELFlBQVEsaUJBQXNCOzs7OztNQUFhOzs7O2NBQU07Ozs7OztJQUNqTTs7Ozs7O0VBQ1Q7Ozs7YUFBSSxPQUNYLHdCQUFDLEtBQUQ7R0FBRyxXQUFVO0dBQWUsTUFBSzthQUFqQztJQUErQyx3QkFBQyxVQUFELFlBQVEsa0JBQXVCOzs7OztJQUFDLHdCQUFDLFFBQUQsWUFBTSxrQkFBcUI7Ozs7O0lBQUMsd0JBQUMsT0FBRDtLQUFLLEtBQUk7S0FBc0MsS0FBSTtJQUEwQjs7Ozs7R0FBSTs7Ozs7VUFDdkw7Ozs7OztBQUVYIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlNpZGViYXJGaWx0ZXJzLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgU2xpZGVyIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL3NsaWRlcidcclxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbidcclxuaW1wb3J0IHsgRm9ybVNlbGVjdCB9IGZyb20gJ0AvY29tcG9uZW50cy9Gb3JtU2VsZWN0J1xyXG5pbXBvcnQgeyBJbnB1dCB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9pbnB1dCdcclxuaW1wb3J0IHsgRGlhbG9nLCBEaWFsb2dDb250ZW50LCBEaWFsb2dUaXRsZSwgRGlhbG9nRGVzY3JpcHRpb24sIERpYWxvZ1RyaWdnZXIgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvZGlhbG9nJ1xyXG5pbXBvcnQgeyBwYXJzZUV0aFRvQmlnSW50IH0gZnJvbSAnQC9saWIvZGVjaW1hbCdcclxuaW1wb3J0IHsgU2hlZXQsIFNoZWV0Q29udGVudCwgU2hlZXRUaXRsZSwgU2hlZXREZXNjcmlwdGlvbiwgU2hlZXRDbG9zZSB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9zaGVldCdcclxuaW1wb3J0IHsgdXNlTWVkaWFRdWVyeSB9IGZyb20gJ0AvbGliL3VzZS1tZWRpYS1xdWVyeSdcclxuXHJcbmludGVyZmFjZSBTaWRlYmFyRmlsdGVyc1Byb3BzIHtcclxuICBtb2JpbGVPcGVuPzogYm9vbGVhblxyXG4gIG9uTW9iaWxlT3BlbkNoYW5nZT86IChvcGVuOiBib29sZWFuKSA9PiB2b2lkXHJcbiAgY29sbGVjdGlvbnM6IHsgbmFtZTogc3RyaW5nOyBjb3VudDogbnVtYmVyIH1bXVxyXG4gIG5ldHdvcmtzOiB7IG5hbWU6IHN0cmluZzsgY291bnQ6IG51bWJlciB9W11cclxuICBzZWxlY3RlZENvbGxlY3Rpb24/OiBzdHJpbmdcclxuICBzZWxlY3RlZE5ldHdvcms/OiBzdHJpbmdcclxuICBtaW5QcmljZT86IHN0cmluZ1xyXG4gIG1heFByaWNlPzogc3RyaW5nXHJcbiAgb25TZWxlY3RDb2xsZWN0aW9uOiAoY29sOiBzdHJpbmcpID0+IHZvaWRcclxuICBvblNlbGVjdE5ldHdvcms6IChuZXQ6IHN0cmluZykgPT4gdm9pZFxyXG4gIG9uUHJpY2VDaGFuZ2U6IChtaW46IHN0cmluZywgbWF4OiBzdHJpbmcpID0+IHZvaWRcclxuICBvbkNsZWFyRmlsdGVyczogKCkgPT4gdm9pZFxyXG4gIHNlbGVjdGVkU29ydD86IHN0cmluZ1xyXG4gIG9uU29ydENoYW5nZT86ICh2YWx1ZTogJ3JlY2VudCcgfCAncHJpY2VfYXNjJyB8ICdwcmljZV9kZXNjJykgPT4gdm9pZFxyXG59XHJcblxyXG5leHBvcnQgY29uc3QgU2lkZWJhckZpbHRlcnM6IFJlYWN0LkZDPFNpZGViYXJGaWx0ZXJzUHJvcHM+ID0gKHtcclxuICBtb2JpbGVPcGVuID0gZmFsc2UsXHJcbiAgb25Nb2JpbGVPcGVuQ2hhbmdlLFxyXG4gIGNvbGxlY3Rpb25zLFxyXG4gIG5ldHdvcmtzLFxyXG4gIHNlbGVjdGVkQ29sbGVjdGlvbiA9ICcnLFxyXG4gIHNlbGVjdGVkTmV0d29yayA9ICcnLFxyXG4gIG1pblByaWNlID0gJzAuMDInLFxyXG4gIG1heFByaWNlID0gJzEyLjMwJyxcclxuICBvblNlbGVjdENvbGxlY3Rpb24sXHJcbiAgb25TZWxlY3ROZXR3b3JrLFxyXG4gIG9uUHJpY2VDaGFuZ2UsXHJcbiAgb25DbGVhckZpbHRlcnMsXHJcbiAgc2VsZWN0ZWRTb3J0ID0gJ3JlY2VudCcsXHJcbiAgb25Tb3J0Q2hhbmdlLFxyXG59KSA9PiB7XHJcbiAgY29uc3QgbW9iaWxlID0gdXNlTWVkaWFRdWVyeSgnKG1heC13aWR0aDogNzY3cHgpJylcclxuICBjb25zdCBleGFjdE1pbiA9IG1pblByaWNlIHx8ICcwLjAyJ1xyXG4gIGNvbnN0IGV4YWN0TWF4ID0gbWF4UHJpY2UgfHwgJzEyLjMwJ1xyXG4gIGNvbnN0IHNvdXJjZSA9IGAke2V4YWN0TWlufS8ke2V4YWN0TWF4fWBcclxuICBjb25zdCBbcmFuZ2VEcmFmdCwgc2V0UmFuZ2VEcmFmdF0gPSB1c2VTdGF0ZSh7IHNvdXJjZSwgdmFsdWU6IFtleGFjdE1pbiwgZXhhY3RNYXhdIH0pXHJcbiAgY29uc3QgcmFuZ2UgPSByYW5nZURyYWZ0LnNvdXJjZSA9PT0gc291cmNlID8gcmFuZ2VEcmFmdC52YWx1ZSA6IFtleGFjdE1pbiwgZXhhY3RNYXhdXHJcbiAgY29uc3QgW3ByaWNlRXJyb3IsIHNldFByaWNlRXJyb3JdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW3ByaWNlRWRpdG9yT3Blbiwgc2V0UHJpY2VFZGl0b3JPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gIC8vIFRoZSBzbGlkZXIgaGFzIDAuMDEgRVRIIHN0ZXBzOyBleGFjdCBzdHJpbmdzIHJlbWFpbiBpbnRhY3QgdW50aWwgaXQgaXMgbW92ZWQuXHJcbiAgY29uc3Qgc2xpZGVyUmFuZ2UgPSByYW5nZS5tYXAodmFsdWUgPT4gTWF0aC5tYXgoMCwgTWF0aC5taW4oMTUsIE51bWJlcih2YWx1ZSkgfHwgMCkpKVxyXG4gIGNvbnN0IHNldFNsaWRlclJhbmdlID0gKHZhbHVlOiBudW1iZXJbXSkgPT4gc2V0UmFuZ2VEcmFmdCh7IHNvdXJjZSwgdmFsdWU6IHZhbHVlLm1hcChhbW91bnQgPT4gYW1vdW50LnRvRml4ZWQoMikpIH0pXHJcblxyXG4gIGNvbnN0IGhhc0FjdGl2ZUZpbHRlcnMgPSBCb29sZWFuKFxyXG4gICAgc2VsZWN0ZWRDb2xsZWN0aW9uIHx8IHNlbGVjdGVkTmV0d29yayB8fCAobWluUHJpY2UgJiYgbWluUHJpY2UgIT09ICcwLjAyJykgfHwgKG1heFByaWNlICYmIG1heFByaWNlICE9PSAnMTIuMzAnKVxyXG4gIClcclxuXHJcbiAgY29uc3QgaGFuZGxlQXBwbHkgPSAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBpZiAocGFyc2VFdGhUb0JpZ0ludChyYW5nZVswXSkgPCAwbiB8fCBwYXJzZUV0aFRvQmlnSW50KHJhbmdlWzBdKSA+IHBhcnNlRXRoVG9CaWdJbnQocmFuZ2VbMV0pKSB0aHJvdyBuZXcgRXJyb3IoKVxyXG4gICAgICBzZXRQcmljZUVycm9yKCcnKTsgb25QcmljZUNoYW5nZShyYW5nZVswXS50cmltKCksIHJhbmdlWzFdLnRyaW0oKSk7IHJldHVybiB0cnVlXHJcbiAgICB9IGNhdGNoIHsgc2V0UHJpY2VFcnJvcignSW5mb3JtZSB1bWEgZmFpeGEgdsOhbGlkYSwgY29tIGF0w6kgMTggY2FzYXMgZGVjaW1haXMgZSBtw61uaW1vIG1lbm9yIG91IGlndWFsIGFvIG3DoXhpbW8uJyk7IHJldHVybiBmYWxzZSB9XHJcbiAgfVxyXG5cclxuICBjb25zdCBmb3JtYXRFdGhMYWJlbCA9ICh2YWx1ZTogc3RyaW5nKSA9PiB2YWx1ZS5yZXBsYWNlKCcuJywgJywnKVxyXG5cclxuICBjb25zdCBwYW5lbCA9IChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaWx0ZXItcGFuZWwgZmxleCBmbGV4LWNvbCBnYXAtNiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItWyMzRjIzMTldIGJnLVsjMjQxNjEyXSBwLTUgc2hhZG93LWxnXCI+XHJcbiAgICAgICAgey8qIEhlYWRlciAmIFJlc2V0ICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1bIzNGMjMxOV0gcGItM1wiPlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LWJhc2UgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LVsjRjVGMUVCXVwiPlxyXG4gICAgICAgICAgICBGaWx0cm9zXHJcbiAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAge2hhc0FjdGl2ZUZpbHRlcnMgJiYgKFxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17b25DbGVhckZpbHRlcnN9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQteHMgdGV4dC1bI0U4OUI1NV0gaG92ZXI6dW5kZXJsaW5lIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIExpbXBhciB0b2Rvc1xyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBDb2xsZWN0aW9ucyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTNcIj5cclxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1zbSBmb250LWJvbGQgdGV4dC1bI0Y1RjFFQl1cIj5Db2xlw6fDtWVzPC9oMz5cclxuICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xLjUgZm9udC1tb25vIHRleHQteHNcIj5cclxuICAgICAgICAgICAge2NvbGxlY3Rpb25zLm1hcCgoY29sKSA9PiB7XHJcbiAgICAgICAgICAgICAgY29uc3QgaXNTZWxlY3RlZCA9IHNlbGVjdGVkQ29sbGVjdGlvbi50b0xvd2VyQ2FzZSgpID09PSBjb2wubmFtZS50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgIDxsaVxyXG4gICAgICAgICAgICAgICAgICBrZXk9e2NvbC5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICByb2xlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgdGFiSW5kZXg9ezB9XHJcbiAgICAgICAgICAgICAgICAgIGFyaWEtcHJlc3NlZD17aXNTZWxlY3RlZH1cclxuICAgICAgICAgICAgICAgICAgb25LZXlEb3duPXtldmVudCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGV2ZW50LmtleSA9PT0gJ0VudGVyJyB8fCBldmVudC5rZXkgPT09ICcgJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25TZWxlY3RDb2xsZWN0aW9uKGlzU2VsZWN0ZWQgPyAnJyA6IGNvbC5uYW1lKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25TZWxlY3RDb2xsZWN0aW9uKGlzU2VsZWN0ZWQgPyAnJyA6IGNvbC5uYW1lKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBjdXJzb3ItcG9pbnRlciBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB5LTEgdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6dGV4dC1bI0U4OUI1NV0gJHtcclxuICAgICAgICAgICAgICAgICAgICBpc1NlbGVjdGVkID8gJ2ZvbnQtYm9sZCB0ZXh0LVsjRTg5QjU1XScgOiAndGV4dC1bI0NGQjI4Q10nXHJcbiAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZVwiPntjb2wubmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZFwiPih7Y29sLmNvdW50fSk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICA8L3VsPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogRHVhbC1UaHVtYiBQcmljZSBSYW5nZSBTbGlkZXIgbWF0Y2hpbmcgRmlnbWEgNzA0ODU6MzU3ICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMyBib3JkZXItdCBib3JkZXItWyMzRjIzMTldIHB0LTRcIj5cclxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1zbSBmb250LWJvbGQgdGV4dC1bI0Y1RjFFQl1cIj5GYWl4YSBkZSBwcmXDp288L2gzPlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMyBweC0xIHB0LTFcIj5cclxuICAgICAgICAgICAgPFNsaWRlclxyXG4gICAgICAgICAgICAgIG1pbj17MC4wfVxyXG4gICAgICAgICAgICAgIG1heD17MTUuMH1cclxuICAgICAgICAgICAgICBzdGVwPXswLjAxfVxyXG4gICAgICAgICAgICAgIHZhbHVlPXtzbGlkZXJSYW5nZX1cclxuICAgICAgICAgICAgICBvblZhbHVlQ2hhbmdlPXsodmFsKSA9PiBzZXRTbGlkZXJSYW5nZSh2YWwpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm15LTFcIlxyXG4gICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHQtMVwiPlxyXG4gICAgICAgICAgICAgIDxEaWFsb2cgb3Blbj17cHJpY2VFZGl0b3JPcGVufSBvbk9wZW5DaGFuZ2U9e3NldFByaWNlRWRpdG9yT3Blbn0+XHJcbiAgICAgICAgICAgICAgICA8RGlhbG9nVHJpZ2dlciBjbGFzc05hbWU9XCJwcmljZS1yYW5nZS10cmlnZ2VyIGZvbnQtbW9ubyB0ZXh0LXhzIHRleHQtWyNGNUYxRUJdIHRleHQtbGVmdFwiIHRpdGxlPVwiRWRpdGFyIG9zIHZhbG9yZXMgZXhhdG9zXCIgYXJpYS1sYWJlbD1cIkVkaXRhciBmYWl4YSBkZSBwcmXDp29cIj5QcmXDp286IHtmb3JtYXRFdGhMYWJlbChyYW5nZVswXSl9IC0ge2Zvcm1hdEV0aExhYmVsKHJhbmdlWzFdKX0gRVRIPC9EaWFsb2dUcmlnZ2VyPlxyXG4gICAgICAgICAgICAgICAgPERpYWxvZ0NvbnRlbnQgY2xhc3NOYW1lPXttb2JpbGUgPyAnei1bMTcwXScgOiB1bmRlZmluZWR9IG92ZXJsYXlDbGFzc05hbWU9e21vYmlsZSA/ICd6LVsxNjBdJyA6IHVuZGVmaW5lZH0+XHJcbiAgICAgICAgICAgICAgICAgIDxEaWFsb2dUaXRsZT5GYWl4YSBkZSBwcmXDp28gZW0gRVRIPC9EaWFsb2dUaXRsZT48RGlhbG9nRGVzY3JpcHRpb24+SW5mb3JtZSB2YWxvcmVzIGV4YXRvcyBjb20gYXTDqSAxOCBjYXNhcyBkZWNpbWFpcy4gTyBjb250cm9sZSBkZXNsaXphbnRlIHVzYSBwYXNzb3MgZGUgMCwwMSBFVEguPC9EaWFsb2dEZXNjcmlwdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2V2ZW50ID0+IHsgZXZlbnQucHJldmVudERlZmF1bHQoKTsgaWYgKGhhbmRsZUFwcGx5KCkpIHNldFByaWNlRWRpdG9yT3BlbihmYWxzZSkgfX0gY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc21cIj5QcmXDp28gbcOtbmltbyBlbSBFVEg8SW5wdXQgdmFsdWU9e3JhbmdlWzBdfSBpbnB1dE1vZGU9XCJkZWNpbWFsXCIgYXJpYS1pbnZhbGlkPXshIXByaWNlRXJyb3J9IGFyaWEtZGVzY3JpYmVkYnk9e3ByaWNlRXJyb3IgPyAncHJpY2UtcmFuZ2UtZXJyb3InIDogdW5kZWZpbmVkfSBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0UmFuZ2VEcmFmdCh7IHNvdXJjZSwgdmFsdWU6IFtldmVudC50YXJnZXQudmFsdWUsIHJhbmdlWzFdXSB9KX0gLz48L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtXCI+UHJlw6dvIG3DoXhpbW8gZW0gRVRIPElucHV0IHZhbHVlPXtyYW5nZVsxXX0gaW5wdXRNb2RlPVwiZGVjaW1hbFwiIGFyaWEtaW52YWxpZD17ISFwcmljZUVycm9yfSBhcmlhLWRlc2NyaWJlZGJ5PXtwcmljZUVycm9yID8gJ3ByaWNlLXJhbmdlLWVycm9yJyA6IHVuZGVmaW5lZH0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldFJhbmdlRHJhZnQoeyBzb3VyY2UsIHZhbHVlOiBbcmFuZ2VbMF0sIGV2ZW50LnRhcmdldC52YWx1ZV0gfSl9IC8+PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICB7cHJpY2VFcnJvciAmJiA8cCBpZD1cInByaWNlLXJhbmdlLWVycm9yXCIgcm9sZT1cImFsZXJ0XCIgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LVsjRTg5QjU1XVwiPntwcmljZUVycm9yfTwvcD59XHJcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwic3VibWl0XCI+QXBsaWNhciBmYWl4YTwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICAgICA8L0RpYWxvZ0NvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgPC9EaWFsb2c+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUFwcGx5fVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTEgaC05IHctZnVsbCBiZy1bI0QyOEE0Q10gaG92ZXI6YmctWyNFODlCNTVdIHRleHQtWyMxNDBEMEFdIGZvbnQtbW9ubyB0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgcm91bmRlZC1bNnB4XVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBBcGxpY2FyXHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICB7cHJpY2VFcnJvciAmJiAhcHJpY2VFZGl0b3JPcGVuICYmIDxwIHJvbGU9XCJhbGVydFwiIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1bI0U4OUI1NV1cIj57cHJpY2VFcnJvcn08L3A+fVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBOZXR3b3JrICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMyBib3JkZXItdCBib3JkZXItWyMzRjIzMTldIHB0LTRcIj5cclxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1zbSBmb250LWJvbGQgdGV4dC1bI0Y1RjFFQl1cIj5SZWRlPC9oMz5cclxuICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xLjUgZm9udC1tb25vIHRleHQteHNcIj5cclxuICAgICAgICAgICAge25ldHdvcmtzLm1hcCgobmV0KSA9PiB7XHJcbiAgICAgICAgICAgICAgY29uc3QgaXNTZWxlY3RlZCA9IHNlbGVjdGVkTmV0d29yay50b0xvd2VyQ2FzZSgpID09PSBuZXQubmFtZS50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgIDxsaVxyXG4gICAgICAgICAgICAgICAgICBrZXk9e25ldC5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICByb2xlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgdGFiSW5kZXg9ezB9XHJcbiAgICAgICAgICAgICAgICAgIGFyaWEtcHJlc3NlZD17aXNTZWxlY3RlZH1cclxuICAgICAgICAgICAgICAgICAgb25LZXlEb3duPXtldmVudCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGV2ZW50LmtleSA9PT0gJ0VudGVyJyB8fCBldmVudC5rZXkgPT09ICcgJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25TZWxlY3ROZXR3b3JrKGlzU2VsZWN0ZWQgPyAnJyA6IG5ldC5uYW1lKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25TZWxlY3ROZXR3b3JrKGlzU2VsZWN0ZWQgPyAnJyA6IG5ldC5uYW1lKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBjdXJzb3ItcG9pbnRlciBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB5LTEgdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6dGV4dC1bI0U4OUI1NV0gJHtcclxuICAgICAgICAgICAgICAgICAgICBpc1NlbGVjdGVkID8gJ2ZvbnQtYm9sZCB0ZXh0LVsjRTg5QjU1XScgOiAndGV4dC1bI0NGQjI4Q10nXHJcbiAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8c3Bhbj57bmV0Lm5hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGRcIj4oe25ldC5jb3VudH0pPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgPC91bD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmhpZGRlblwiPjxsYWJlbCBodG1sRm9yPVwibW9iaWxlLXNvcnRcIj5PcmRlbmFyIHBvcjwvbGFiZWw+PEZvcm1TZWxlY3QgaWQ9XCJtb2JpbGUtc29ydFwiIGFyaWEtbGFiZWw9XCJPcmRlbmFyIE5GVHNcIiB2YWx1ZT17c2VsZWN0ZWRTb3J0fSBvblZhbHVlQ2hhbmdlPXt2YWx1ZSA9PiBvblNvcnRDaGFuZ2U/Lih2YWx1ZSBhcyAncmVjZW50JyB8ICdwcmljZV9hc2MnIHwgJ3ByaWNlX2Rlc2MnKX0gY2xhc3NOYW1lPVwibXQtMlwiIG9wdGlvbnM9e1t7IHZhbHVlOiAncmVjZW50JywgbGFiZWw6ICdNYWlzIHJlY2VudGVzJyB9LCB7IHZhbHVlOiAncHJpY2VfYXNjJywgbGFiZWw6ICdNZW5vciBwcmXDp28nIH0sIHsgdmFsdWU6ICdwcmljZV9kZXNjJywgbGFiZWw6ICdNYWlvciBwcmXDp28nIH1dfSAvPjwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICApXHJcbiAgcmV0dXJuIChcclxuICAgIDxhc2lkZSBjbGFzc05hbWU9XCJjYXRhbG9nLWZpbHRlcnMgZmxleCB3LWZ1bGwgZmxleC1jb2wgZ2FwLTQgbWQ6dy1bMjgwcHhdIGxnOnctWzMxMHB4XVwiPlxyXG4gICAgICB7bW9iaWxlID8gPFNoZWV0IG9wZW49e21vYmlsZU9wZW59IG9uT3BlbkNoYW5nZT17b25Nb2JpbGVPcGVuQ2hhbmdlfT5cclxuICAgICAgICA8U2hlZXRDb250ZW50IHNpZGU9XCJib3R0b21cIiBjbGFzc05hbWU9XCJtb2JpbGUtZmlsdGVycy1zaGVldCB6LVsxMDBdIG1heC1oLVtjYWxjKDEwMGR2aC0yNHB4KV0gb3ZlcmZsb3cteS1hdXRvIHJvdW5kZWQtdC0zeGxcIiBvbkNsb3NlQXV0b0ZvY3VzPXtldmVudCA9PiB7IGV2ZW50LnByZXZlbnREZWZhdWx0KCk7IHJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yPEhUTUxCdXR0b25FbGVtZW50PignW2FyaWEtbGFiZWw9XCJGaWx0cm9zIGRvIGNhdMOhbG9nb1wiXScpPy5mb2N1cygpKSB9fT5cclxuICAgICAgICAgIDxTaGVldFRpdGxlPkZpbHRyb3MgZG8gY2F0w6Fsb2dvPC9TaGVldFRpdGxlPjxTaGVldERlc2NyaXB0aW9uPkNvbWJpbmUgY29sZcOnw6NvLCByZWRlLCBwcmXDp28gZSBvcmRlbmHDp8Ojby48L1NoZWV0RGVzY3JpcHRpb24+XHJcbiAgICAgICAgICB7cGFuZWx9XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNCBwdC00XCI+PEJ1dHRvbiB2YXJpYW50PVwib3V0bGluZVwiIG9uQ2xpY2s9e29uQ2xlYXJGaWx0ZXJzfT5MaW1wYXIgZmlsdHJvczwvQnV0dG9uPjxTaGVldENsb3NlIGFzQ2hpbGQ+PEJ1dHRvbj5WZXIgcmVzdWx0YWRvczwvQnV0dG9uPjwvU2hlZXRDbG9zZT48L2Rpdj5cclxuICAgICAgICA8L1NoZWV0Q29udGVudD5cclxuICAgICAgPC9TaGVldD4gOiBwYW5lbH1cclxuICAgICAgPGEgY2xhc3NOYW1lPVwiZmVhdHVyZWQtbmZ0XCIgaHJlZj1cIi9uZnRzL25mdC0yXCI+PHN0cm9uZz5ORlQgRU0gREVTVEFRVUU8L3N0cm9uZz48c3Bhbj5PRkVSVEEgTElNSVRBREE8L3NwYW4+PGltZyBzcmM9XCIvYXNzZXRzL2ltYWdlcy9mZWF0dXJlZC1iYW5uZXIud2VicFwiIGFsdD1cIlNhZ2UgTm9tYWQgZW0gZGVzdGFxdWVcIiAvPjwvYT5cclxuICAgIDwvYXNpZGU+XHJcbiAgKVxyXG59XHJcbiJdfQ==
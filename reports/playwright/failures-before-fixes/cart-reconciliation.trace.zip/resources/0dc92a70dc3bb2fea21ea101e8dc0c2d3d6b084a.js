import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/FormSelect.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "/src/components/ui/select.tsx";
var _jsxFileName = "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/FormSelect.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7abeec5e";
export function FormSelect({ value, onValueChange, options, placeholder, disabled, ...props }) {
	return /* @__PURE__ */ _jsxDEV(Select, {
		value,
		onValueChange,
		disabled,
		children: [/* @__PURE__ */ _jsxDEV(SelectTrigger, {
			...props,
			children: /* @__PURE__ */ _jsxDEV(SelectValue, { placeholder }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 31
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 18,
			columnNumber: 5
		}, this), /* @__PURE__ */ _jsxDEV(SelectContent, {
			position: "popper",
			align: "start",
			children: options.map((option) => /* @__PURE__ */ _jsxDEV(SelectItem, {
				value: option.value,
				children: option.label
			}, option.value, false, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 30
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 19,
			columnNumber: 5
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 17,
		columnNumber: 10
	}, this);
}
_c = FormSelect;
var _c;
$RefreshReg$(_c, "FormSelect");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/FormSelect.tsx?t=1792164282123";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/FormSelect.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/FormSelect.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/FormSelect.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxRQUFRLGVBQWUsWUFBWSxlQUFlLG1CQUFtQjs7O0FBZTlFLE9BQU8sU0FBUyxXQUFXLEVBQUUsT0FBTyxlQUFlLFNBQVMsYUFBYSxVQUFVLEdBQUcsU0FBMEI7Q0FDOUcsT0FBTyx3QkFBQyxRQUFEO0VBQWU7RUFBc0I7RUFBeUI7WUFBOUQsQ0FDTCx3QkFBQyxlQUFEO0dBQWUsR0FBSTthQUFPLHdCQUFDLGFBQUQsRUFBMEIsWUFBYzs7Ozs7RUFBZ0I7Ozs7WUFDbEYsd0JBQUMsZUFBRDtHQUFlLFVBQVM7R0FBUyxPQUFNO2FBQ3BDLFFBQVEsS0FBSSxXQUFVLHdCQUFDLFlBQUQ7SUFBK0IsT0FBTyxPQUFPO2NBQVEsT0FBTztHQUFrQixHQUE3RCxPQUFPOzs7O1VBQXNELENBQUM7RUFDekY7Ozs7VUFDVDs7Ozs7O0FBQ1YiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRm9ybVNlbGVjdC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU2VsZWN0LCBTZWxlY3RDb250ZW50LCBTZWxlY3RJdGVtLCBTZWxlY3RUcmlnZ2VyLCBTZWxlY3RWYWx1ZSB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9zZWxlY3QnXG5cbnR5cGUgRm9ybVNlbGVjdFByb3BzID0ge1xuICBpZD86IHN0cmluZ1xuICB2YWx1ZTogc3RyaW5nXG4gIG9uVmFsdWVDaGFuZ2U6ICh2YWx1ZTogc3RyaW5nKSA9PiB2b2lkXG4gIG9wdGlvbnM6IHJlYWRvbmx5IHsgdmFsdWU6IHN0cmluZzsgbGFiZWw6IHN0cmluZyB9W11cbiAgY2xhc3NOYW1lPzogc3RyaW5nXG4gICdhcmlhLWxhYmVsJz86IHN0cmluZ1xuICAnYXJpYS1kZXNjcmliZWRieSc/OiBzdHJpbmdcbiAgJ2FyaWEtaW52YWxpZCc/OiBib29sZWFuXG4gIGRpc2FibGVkPzogYm9vbGVhblxuICBwbGFjZWhvbGRlcj86IHN0cmluZ1xufVxuXG5leHBvcnQgZnVuY3Rpb24gRm9ybVNlbGVjdCh7IHZhbHVlLCBvblZhbHVlQ2hhbmdlLCBvcHRpb25zLCBwbGFjZWhvbGRlciwgZGlzYWJsZWQsIC4uLnByb3BzIH06IEZvcm1TZWxlY3RQcm9wcykge1xuICByZXR1cm4gPFNlbGVjdCB2YWx1ZT17dmFsdWV9IG9uVmFsdWVDaGFuZ2U9e29uVmFsdWVDaGFuZ2V9IGRpc2FibGVkPXtkaXNhYmxlZH0+XG4gICAgPFNlbGVjdFRyaWdnZXIgey4uLnByb3BzfT48U2VsZWN0VmFsdWUgcGxhY2Vob2xkZXI9e3BsYWNlaG9sZGVyfSAvPjwvU2VsZWN0VHJpZ2dlcj5cbiAgICA8U2VsZWN0Q29udGVudCBwb3NpdGlvbj1cInBvcHBlclwiIGFsaWduPVwic3RhcnRcIj5cbiAgICAgIHtvcHRpb25zLm1hcChvcHRpb24gPT4gPFNlbGVjdEl0ZW0ga2V5PXtvcHRpb24udmFsdWV9IHZhbHVlPXtvcHRpb24udmFsdWV9PntvcHRpb24ubGFiZWx9PC9TZWxlY3RJdGVtPil9XG4gICAgPC9TZWxlY3RDb250ZW50PlxuICA8L1NlbGVjdD5cbn1cbiJdfQ==
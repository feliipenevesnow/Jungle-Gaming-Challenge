import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CouponForm.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=7abeec5e";
import { useMutation, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=281272ec";
import { api } from "/src/lib/axios.ts?t=1792164562494";
import { apiErrorMessage } from "/src/lib/api-error.ts";
import { Button } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
var _jsxFileName = "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/CouponForm.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7abeec5e";
var _s = $RefreshSig$();
export function CouponForm({ code, invalidReason }) {
	_s();
	const [input, setInput] = useState("");
	const queryClient = useQueryClient();
	const mutation = useMutation({
		mutationFn: (value) => value === null ? api.delete("/cart/coupon") : api.put("/cart/coupon", { code: value }),
		onSuccess: async () => {
			setInput("");
			await Promise.all([
				queryClient.invalidateQueries({ queryKey: ["cart"] }),
				queryClient.invalidateQueries({ queryKey: ["cart-quote"] }),
				queryClient.invalidateQueries({ queryKey: ["checkout-quote"] })
			]);
		}
	});
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "coupon-form space-y-2",
		children: [
			code ? /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-between gap-2 text-xs text-[#E89B55]",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					role: "status",
					children: [
						"Cupom ",
						/* @__PURE__ */ _jsxDEV("strong", { children: code }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 26,
							columnNumber: 33
						}, this),
						" ",
						invalidReason ? "indisponível" : "aplicado!"
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 7
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					disabled: mutation.isPending,
					onClick: () => mutation.mutate(null),
					className: "underline",
					children: "Remover cupom"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 27,
					columnNumber: 7
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 13
			}, this) : /* @__PURE__ */ _jsxDEV("form", {
				onSubmit: (event) => {
					event.preventDefault();
					if (input.trim()) mutation.mutate(input.trim().toUpperCase());
				},
				className: "flex",
				children: [/* @__PURE__ */ _jsxDEV(Input, {
					"aria-label": "Código promocional",
					required: true,
					placeholder: "Digite o código promocional...",
					value: input,
					onChange: (event) => setInput(event.target.value),
					className: "h-10 min-w-0 rounded-r-none text-xs"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 29,
					columnNumber: 7
				}, this), /* @__PURE__ */ _jsxDEV(Button, {
					type: "submit",
					disabled: mutation.isPending,
					className: "h-10 rounded-l-none bg-[#D28A4C] text-[#140D0A]",
					children: mutation.isPending ? "Aplicando..." : "Aplicar"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 7
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 14
			}, this),
			invalidReason && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				className: "text-xs text-[#E89B55]",
				children: invalidReason
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 23
			}, this),
			mutation.isError && /* @__PURE__ */ _jsxDEV("p", {
				id: "coupon-error",
				role: "alert",
				className: "text-xs text-[#F0805F]",
				children: apiErrorMessage(mutation.error, "Não foi possível atualizar o cupom. Tente novamente.")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 26
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 24,
		columnNumber: 10
	}, this);
}
_s(CouponForm, "5vuZ4lqEU3s/dRN34jGuwHlt9+c=", false, function() {
	return [useQueryClient, useMutation];
});
_c = CouponForm;
var _c;
$RefreshReg$(_c, "CouponForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/CouponForm.tsx?t=1792164562494";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/CouponForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/CouponForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/CouponForm.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxhQUFhLHNCQUFzQjtBQUM1QyxTQUFTLFdBQVc7QUFDcEIsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsYUFBYTs7OztBQUV0QixPQUFPLFNBQVMsV0FBVyxFQUFFLE1BQU0saUJBQTREOztDQUM3RixNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLGNBQWMsZUFBZTtDQUNuQyxNQUFNLFdBQVcsWUFBWTtFQUMzQixhQUFhLFVBQXlCLFVBQVUsT0FDNUMsSUFBSSxPQUFPLGNBQWMsSUFDekIsSUFBSSxJQUFJLGdCQUFnQixFQUFFLE1BQU0sTUFBTSxDQUFDO0VBQzNDLFdBQVcsWUFBWTtHQUNyQixTQUFTLEVBQUU7R0FDWCxNQUFNLFFBQVEsSUFBSTtJQUNoQixZQUFZLGtCQUFrQixFQUFFLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztJQUNwRCxZQUFZLGtCQUFrQixFQUFFLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUMxRCxZQUFZLGtCQUFrQixFQUFFLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO0dBQ2hFLENBQUM7RUFDSDtDQUNGLENBQUM7Q0FDRCxPQUFPLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDSixPQUFPLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDTix3QkFBQyxRQUFEO0tBQU0sTUFBSztlQUFYO01BQW9CO01BQU0sd0JBQUMsVUFBRCxZQUFTLEtBQWE7Ozs7O01BQUM7TUFBRSxnQkFBZ0IsaUJBQWlCO0tBQWtCOzs7OztjQUN0Ryx3QkFBQyxVQUFEO0tBQVEsTUFBSztLQUFTLFVBQVUsU0FBUztLQUFXLGVBQWUsU0FBUyxPQUFPLElBQUk7S0FBRyxXQUFVO2VBQVk7SUFBcUI7Ozs7WUFDbEk7Ozs7O2NBQUksd0JBQUMsUUFBRDtJQUFNLFdBQVUsVUFBUztLQUFFLE1BQU0sZUFBZTtLQUFHLElBQUksTUFBTSxLQUFLLEdBQUcsU0FBUyxPQUFPLE1BQU0sS0FBSyxDQUFDLENBQUMsWUFBWSxDQUFDO0lBQUU7SUFBRyxXQUFVO2NBQTlILENBQ1Asd0JBQUMsT0FBRDtLQUFPLGNBQVc7S0FBcUI7S0FBUyxhQUFZO0tBQWlDLE9BQU87S0FBTyxXQUFVLFVBQVMsU0FBUyxNQUFNLE9BQU8sS0FBSztLQUFHLFdBQVU7SUFBdUM7Ozs7Y0FDN00sd0JBQUMsUUFBRDtLQUFRLE1BQUs7S0FBUyxVQUFVLFNBQVM7S0FBVyxXQUFVO2VBQW1ELFNBQVMsWUFBWSxpQkFBaUI7SUFBa0I7Ozs7WUFDcks7Ozs7OztHQUNMLGlCQUFpQix3QkFBQyxLQUFEO0lBQUcsTUFBSztJQUFRLFdBQVU7Y0FBMEI7R0FBaUI7Ozs7O0dBQ3RGLFNBQVMsV0FBVyx3QkFBQyxLQUFEO0lBQUcsSUFBRztJQUFlLE1BQUs7SUFBUSxXQUFVO2NBQTBCLGdCQUFnQixTQUFTLE9BQU8sc0RBQXNEO0dBQUs7Ozs7O0VBQ25MOzs7Ozs7QUFDUCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJDb3Vwb25Gb3JtLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXHJcbmltcG9ydCB7IGFwaSB9IGZyb20gJ0AvbGliL2F4aW9zJ1xyXG5pbXBvcnQgeyBhcGlFcnJvck1lc3NhZ2UgfSBmcm9tICdAL2xpYi9hcGktZXJyb3InXHJcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJy4vdWkvYnV0dG9uJ1xyXG5pbXBvcnQgeyBJbnB1dCB9IGZyb20gJy4vdWkvaW5wdXQnXHJcblxyXG5leHBvcnQgZnVuY3Rpb24gQ291cG9uRm9ybSh7IGNvZGUsIGludmFsaWRSZWFzb24gfTogeyBjb2RlPzogc3RyaW5nOyBpbnZhbGlkUmVhc29uPzogc3RyaW5nIH0pIHtcclxuICBjb25zdCBbaW5wdXQsIHNldElucHV0XSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKVxyXG4gIGNvbnN0IG11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKHZhbHVlOiBzdHJpbmcgfCBudWxsKSA9PiB2YWx1ZSA9PT0gbnVsbFxyXG4gICAgICA/IGFwaS5kZWxldGUoJy9jYXJ0L2NvdXBvbicpXHJcbiAgICAgIDogYXBpLnB1dCgnL2NhcnQvY291cG9uJywgeyBjb2RlOiB2YWx1ZSB9KSxcclxuICAgIG9uU3VjY2VzczogYXN5bmMgKCkgPT4ge1xyXG4gICAgICBzZXRJbnB1dCgnJylcclxuICAgICAgYXdhaXQgUHJvbWlzZS5hbGwoW1xyXG4gICAgICAgIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFsnY2FydCddIH0pLFxyXG4gICAgICAgIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFsnY2FydC1xdW90ZSddIH0pLFxyXG4gICAgICAgIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFsnY2hlY2tvdXQtcXVvdGUnXSB9KSxcclxuICAgICAgXSlcclxuICAgIH0sXHJcbiAgfSlcclxuICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJjb3Vwb24tZm9ybSBzcGFjZS15LTJcIj5cclxuICAgIHtjb2RlID8gPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTIgdGV4dC14cyB0ZXh0LVsjRTg5QjU1XVwiPlxyXG4gICAgICA8c3BhbiByb2xlPVwic3RhdHVzXCI+Q3Vwb20gPHN0cm9uZz57Y29kZX08L3N0cm9uZz4ge2ludmFsaWRSZWFzb24gPyAnaW5kaXNwb27DrXZlbCcgOiAnYXBsaWNhZG8hJ308L3NwYW4+XHJcbiAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGRpc2FibGVkPXttdXRhdGlvbi5pc1BlbmRpbmd9IG9uQ2xpY2s9eygpID0+IG11dGF0aW9uLm11dGF0ZShudWxsKX0gY2xhc3NOYW1lPVwidW5kZXJsaW5lXCI+UmVtb3ZlciBjdXBvbTwvYnV0dG9uPlxyXG4gICAgPC9kaXY+IDogPGZvcm0gb25TdWJtaXQ9e2V2ZW50ID0+IHsgZXZlbnQucHJldmVudERlZmF1bHQoKTsgaWYgKGlucHV0LnRyaW0oKSkgbXV0YXRpb24ubXV0YXRlKGlucHV0LnRyaW0oKS50b1VwcGVyQ2FzZSgpKSB9fSBjbGFzc05hbWU9XCJmbGV4XCI+XHJcbiAgICAgIDxJbnB1dCBhcmlhLWxhYmVsPVwiQ8OzZGlnbyBwcm9tb2Npb25hbFwiIHJlcXVpcmVkIHBsYWNlaG9sZGVyPVwiRGlnaXRlIG8gY8OzZGlnbyBwcm9tb2Npb25hbC4uLlwiIHZhbHVlPXtpbnB1dH0gb25DaGFuZ2U9e2V2ZW50ID0+IHNldElucHV0KGV2ZW50LnRhcmdldC52YWx1ZSl9IGNsYXNzTmFtZT1cImgtMTAgbWluLXctMCByb3VuZGVkLXItbm9uZSB0ZXh0LXhzXCIgLz5cclxuICAgICAgPEJ1dHRvbiB0eXBlPVwic3VibWl0XCIgZGlzYWJsZWQ9e211dGF0aW9uLmlzUGVuZGluZ30gY2xhc3NOYW1lPVwiaC0xMCByb3VuZGVkLWwtbm9uZSBiZy1bI0QyOEE0Q10gdGV4dC1bIzE0MEQwQV1cIj57bXV0YXRpb24uaXNQZW5kaW5nID8gJ0FwbGljYW5kby4uLicgOiAnQXBsaWNhcid9PC9CdXR0b24+XHJcbiAgICA8L2Zvcm0+fVxyXG4gICAge2ludmFsaWRSZWFzb24gJiYgPHAgcm9sZT1cImFsZXJ0XCIgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LVsjRTg5QjU1XVwiPntpbnZhbGlkUmVhc29ufTwvcD59XHJcbiAgICB7bXV0YXRpb24uaXNFcnJvciAmJiA8cCBpZD1cImNvdXBvbi1lcnJvclwiIHJvbGU9XCJhbGVydFwiIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1bI0YwODA1Rl1cIj57YXBpRXJyb3JNZXNzYWdlKG11dGF0aW9uLmVycm9yLCAnTsOjbyBmb2kgcG9zc8OtdmVsIGF0dWFsaXphciBvIGN1cG9tLiBUZW50ZSBub3ZhbWVudGUuJyl9PC9wPn1cclxuICA8L2Rpdj5cclxufVxyXG4iXX0=
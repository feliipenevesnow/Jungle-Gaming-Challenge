import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/button.tsx");const React = ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(__vite__cjsImport0_react, 1);const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=7abeec5e";
import { Slot } from "/node_modules/.vite/deps/@radix-ui_react-slot.js?v=95b8dbfb";
import { cva } from "/node_modules/.vite/deps/class-variance-authority.js?v=c618c6bd";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/ui/button.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7abeec5e";
const buttonVariants = cva("inline-flex items-center justify-center whitespace-nowrap rounded-md font-mono text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D28A4C] focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 select-none cursor-pointer", {
	variants: {
		variant: {
			default: "bg-[#D28A4C] text-[#140D0A] font-bold hover:bg-[#E89B55] active:bg-[#B3723B]",
			destructive: "bg-[#F0805F] text-white hover:bg-[#F0805F]/90 active:bg-[#F0805F]/80",
			outline: "border border-[#3F2319] bg-transparent text-[#F5F1EB] hover:bg-[#2F1D15] hover:border-[#D28A4C]",
			secondary: "bg-[#2F1D15] text-[#F5F1EB] hover:bg-[#3F2319]",
			ghost: "text-[#CFB28C] hover:bg-[#2F1D15] hover:text-[#F5F1EB]",
			link: "text-[#D28A4C] underline-offset-4 hover:underline"
		},
		size: {
			default: "h-10 px-4 py-2",
			sm: "h-8 rounded-md px-3 text-xs",
			lg: "h-11 rounded-md px-8 text-base font-bold",
			icon: "h-9 w-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
const Button = React.forwardRef(_c = ({ className, variant, size, asChild = false, ...props }, ref) => {
	const Comp = asChild ? Slot : "button";
	return /* @__PURE__ */ _jsxDEV(Comp, {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 48,
		columnNumber: 7
	}, this);
});
_c2 = Button;
Button.displayName = "Button";
export { Button, buttonVariants };
var _c, _c2;
$RefreshReg$(_c, "Button$React.forwardRef");
$RefreshReg$(_c2, "Button");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/button.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/ui/button.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/ui/button.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/ui/button.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsWUFBWSxXQUFXO0FBQ3ZCLFNBQVMsWUFBWTtBQUNyQixTQUFTLFdBQThCO0FBQ3ZDLFNBQVMsVUFBVTs7O0FBRW5CLE1BQU0saUJBQWlCLElBQ3JCLDZTQUNBO0NBQ0UsVUFBVTtFQUNSLFNBQVM7R0FDUCxTQUNFO0dBQ0YsYUFDRTtHQUNGLFNBQ0U7R0FDRixXQUNFO0dBQ0YsT0FDRTtHQUNGLE1BQ0U7RUFDSjtFQUNBLE1BQU07R0FDSixTQUFTO0dBQ1QsSUFBSTtHQUNKLElBQUk7R0FDSixNQUFNO0VBQ1I7Q0FDRjtDQUNBLGlCQUFpQjtFQUNmLFNBQVM7RUFDVCxNQUFNO0NBQ1I7QUFDRixDQUNGO0FBUUEsTUFBTSxTQUFTLE1BQU0saUJBQ2xCLEVBQUUsV0FBVyxTQUFTLE1BQU0sVUFBVSxPQUFPLEdBQUcsU0FBUyxRQUFRO0NBQ2hFLE1BQU0sT0FBTyxVQUFVLE9BQU87Q0FDOUIsT0FDRSx3QkFBQyxNQUFEO0VBQ0UsV0FBVyxHQUFHLGVBQWU7R0FBRTtHQUFTO0dBQU07RUFBVSxDQUFDLENBQUM7RUFDckQ7RUFDTCxHQUFJO0NBQ0w7Ozs7O0FBRUwsQ0FDRjs7QUFDQSxPQUFPLGNBQWM7QUFFckIsU0FBUyxRQUFRIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImJ1dHRvbi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IFNsb3QgfSBmcm9tICdAcmFkaXgtdWkvcmVhY3Qtc2xvdCdcclxuaW1wb3J0IHsgY3ZhLCB0eXBlIFZhcmlhbnRQcm9wcyB9IGZyb20gJ2NsYXNzLXZhcmlhbmNlLWF1dGhvcml0eSdcclxuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi91dGlscydcclxuXHJcbmNvbnN0IGJ1dHRvblZhcmlhbnRzID0gY3ZhKFxyXG4gICdpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgd2hpdGVzcGFjZS1ub3dyYXAgcm91bmRlZC1tZCBmb250LW1vbm8gdGV4dC1zbSBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWNvbG9ycyBmb2N1cy12aXNpYmxlOm91dGxpbmUtbm9uZSBmb2N1cy12aXNpYmxlOnJpbmctMiBmb2N1cy12aXNpYmxlOnJpbmctWyNEMjhBNENdIGZvY3VzLXZpc2libGU6cmluZy1vZmZzZXQtMiBkaXNhYmxlZDpwb2ludGVyLWV2ZW50cy1ub25lIGRpc2FibGVkOm9wYWNpdHktNTAgc2VsZWN0LW5vbmUgY3Vyc29yLXBvaW50ZXInLFxyXG4gIHtcclxuICAgIHZhcmlhbnRzOiB7XHJcbiAgICAgIHZhcmlhbnQ6IHtcclxuICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgJ2JnLVsjRDI4QTRDXSB0ZXh0LVsjMTQwRDBBXSBmb250LWJvbGQgaG92ZXI6YmctWyNFODlCNTVdIGFjdGl2ZTpiZy1bI0IzNzIzQl0nLFxyXG4gICAgICAgIGRlc3RydWN0aXZlOlxyXG4gICAgICAgICAgJ2JnLVsjRjA4MDVGXSB0ZXh0LXdoaXRlIGhvdmVyOmJnLVsjRjA4MDVGXS85MCBhY3RpdmU6YmctWyNGMDgwNUZdLzgwJyxcclxuICAgICAgICBvdXRsaW5lOlxyXG4gICAgICAgICAgJ2JvcmRlciBib3JkZXItWyMzRjIzMTldIGJnLXRyYW5zcGFyZW50IHRleHQtWyNGNUYxRUJdIGhvdmVyOmJnLVsjMkYxRDE1XSBob3Zlcjpib3JkZXItWyNEMjhBNENdJyxcclxuICAgICAgICBzZWNvbmRhcnk6XHJcbiAgICAgICAgICAnYmctWyMyRjFEMTVdIHRleHQtWyNGNUYxRUJdIGhvdmVyOmJnLVsjM0YyMzE5XScsXHJcbiAgICAgICAgZ2hvc3Q6XHJcbiAgICAgICAgICAndGV4dC1bI0NGQjI4Q10gaG92ZXI6YmctWyMyRjFEMTVdIGhvdmVyOnRleHQtWyNGNUYxRUJdJyxcclxuICAgICAgICBsaW5rOlxyXG4gICAgICAgICAgJ3RleHQtWyNEMjhBNENdIHVuZGVybGluZS1vZmZzZXQtNCBob3Zlcjp1bmRlcmxpbmUnLFxyXG4gICAgICB9LFxyXG4gICAgICBzaXplOiB7XHJcbiAgICAgICAgZGVmYXVsdDogJ2gtMTAgcHgtNCBweS0yJyxcclxuICAgICAgICBzbTogJ2gtOCByb3VuZGVkLW1kIHB4LTMgdGV4dC14cycsXHJcbiAgICAgICAgbGc6ICdoLTExIHJvdW5kZWQtbWQgcHgtOCB0ZXh0LWJhc2UgZm9udC1ib2xkJyxcclxuICAgICAgICBpY29uOiAnaC05IHctOScsXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgZGVmYXVsdFZhcmlhbnRzOiB7XHJcbiAgICAgIHZhcmlhbnQ6ICdkZWZhdWx0JyxcclxuICAgICAgc2l6ZTogJ2RlZmF1bHQnLFxyXG4gICAgfSxcclxuICB9XHJcbilcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgQnV0dG9uUHJvcHNcclxuICBleHRlbmRzIFJlYWN0LkJ1dHRvbkhUTUxBdHRyaWJ1dGVzPEhUTUxCdXR0b25FbGVtZW50PixcclxuICAgIFZhcmlhbnRQcm9wczx0eXBlb2YgYnV0dG9uVmFyaWFudHM+IHtcclxuICBhc0NoaWxkPzogYm9vbGVhblxyXG59XHJcblxyXG5jb25zdCBCdXR0b24gPSBSZWFjdC5mb3J3YXJkUmVmPEhUTUxCdXR0b25FbGVtZW50LCBCdXR0b25Qcm9wcz4oXHJcbiAgKHsgY2xhc3NOYW1lLCB2YXJpYW50LCBzaXplLCBhc0NoaWxkID0gZmFsc2UsIC4uLnByb3BzIH0sIHJlZikgPT4ge1xyXG4gICAgY29uc3QgQ29tcCA9IGFzQ2hpbGQgPyBTbG90IDogJ2J1dHRvbidcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxDb21wXHJcbiAgICAgICAgY2xhc3NOYW1lPXtjbihidXR0b25WYXJpYW50cyh7IHZhcmlhbnQsIHNpemUsIGNsYXNzTmFtZSB9KSl9XHJcbiAgICAgICAgcmVmPXtyZWZ9XHJcbiAgICAgICAgey4uLnByb3BzfVxyXG4gICAgICAvPlxyXG4gICAgKVxyXG4gIH1cclxuKVxyXG5CdXR0b24uZGlzcGxheU5hbWUgPSAnQnV0dG9uJ1xyXG5cclxuZXhwb3J0IHsgQnV0dG9uLCBidXR0b25WYXJpYW50cyB9XHJcbiJdfQ==
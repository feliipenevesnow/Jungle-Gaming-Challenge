import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Hero.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { ArrowRight } from "/node_modules/.vite/deps/lucide-react.js?v=c7b96d59";
var _jsxFileName = "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/Hero.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7abeec5e";
export function Hero() {
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "hero",
		"aria-label": "Destaque Kurio",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "hero-copy",
				children: [
					/* @__PURE__ */ _jsxDEV("p", {
						className: "hero-welcome",
						children: "Bem-vindo à Kurio"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 5,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("h1", { children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "hero-desktop-title",
						children: [
							"SEJA DONO DO FUTURO",
							/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 6,
								columnNumber: 67
							}, this),
							"DA ARTE DIGITAL"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 6,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "hero-mobile-title",
						children: [
							"SEJA DONO DA",
							/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 6,
								columnNumber: 143
							}, this),
							"CULTURA DIGITAL"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 6,
						columnNumber: 95
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 6,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "hero-description",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "hero-desktop-title",
							children: "Descubra NFTs selecionados de criadores emergentes e consagrados. Colecione arte digital rara, apoie artistas e tenha uma parte da cultura da internet."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 7,
							columnNumber: 39
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "hero-mobile-title",
							children: "Descubra NFTs selecionados de criadores do mundo todo."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 7,
							columnNumber: 234
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 7,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV("a", {
						href: "#catalogo",
						className: "hero-cta",
						children: ["EXPLORAR ", /* @__PURE__ */ _jsxDEV(ArrowRight, { size: 16 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 8,
							columnNumber: 57
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 8,
						columnNumber: 7
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 4,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "hero-art",
				children: [/* @__PURE__ */ _jsxDEV("img", {
					src: "/assets/images/hero-nft.webp",
					alt: "Emerald Ape, destaque da coleção Kurio",
					fetchPriority: "high"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 10,
					columnNumber: 31
				}, this), /* @__PURE__ */ _jsxDEV("img", {
					className: "hero-mini",
					src: "/assets/images/sage-nomad.webp",
					alt: ""
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 10,
					columnNumber: 139
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 10,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "hero-dots",
				"aria-hidden": "true",
				children: [
					/* @__PURE__ */ _jsxDEV("i", {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 11,
						columnNumber: 51
					}, this),
					/* @__PURE__ */ _jsxDEV("i", {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 11,
						columnNumber: 56
					}, this),
					/* @__PURE__ */ _jsxDEV("i", {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 11,
						columnNumber: 61
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 5
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 3,
		columnNumber: 10
	}, this);
}
_c = Hero;
var _c;
$RefreshReg$(_c, "Hero");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Hero.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/Hero.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/Hero.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/Hero.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7OztBQUMzQixPQUFPLFNBQVMsT0FBTztDQUNyQixPQUFPLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO0VBQU8sY0FBVztZQUFyQztHQUNMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBZTtLQUFvQjs7Ozs7S0FDaEQsd0JBQUMsTUFBRCxhQUFJLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFoQjtPQUFxQztPQUFtQix3QkFBQyxNQUFELENBQUs7Ozs7O09BQUM7TUFBcUI7Ozs7O2VBQUMsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWhCO09BQW9DO09BQVksd0JBQUMsTUFBRCxDQUFLOzs7OztPQUFDO01BQXFCOzs7OzthQUFLOzs7OztLQUN4Syx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYixDQUFnQyx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBcUI7TUFBNko7Ozs7Z0JBQUMsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQW9CO01BQTREOzs7O2NBQUk7Ozs7OztLQUN2VSx3QkFBQyxLQUFEO01BQUcsTUFBSztNQUFZLFdBQVU7Z0JBQTlCLENBQXlDLGFBQVMsd0JBQUMsWUFBRCxFQUFZLE1BQU0sR0FBSzs7OztjQUFJOzs7Ozs7SUFDMUU7Ozs7OztHQUNMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FBMEIsd0JBQUMsT0FBRDtLQUFLLEtBQUk7S0FBK0IsS0FBSTtLQUF5QyxlQUFjO0lBQVE7Ozs7Y0FBQyx3QkFBQyxPQUFEO0tBQUssV0FBVTtLQUFZLEtBQUk7S0FBaUMsS0FBSTtJQUFJOzs7O1lBQU07Ozs7OztHQUNwTix3QkFBQyxPQUFEO0lBQUssV0FBVTtJQUFZLGVBQVk7Y0FBdkM7S0FBOEMsd0JBQUMsS0FBRCxDQUFJOzs7OztLQUFDLHdCQUFDLEtBQUQsQ0FBSTs7Ozs7S0FBQyx3QkFBQyxLQUFELENBQUk7Ozs7O0lBQU07Ozs7OztFQUMzRDs7Ozs7O0FBQ1giLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSGVyby50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQXJyb3dSaWdodCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcclxuZXhwb3J0IGZ1bmN0aW9uIEhlcm8oKSB7XHJcbiAgcmV0dXJuIDxzZWN0aW9uIGNsYXNzTmFtZT1cImhlcm9cIiBhcmlhLWxhYmVsPVwiRGVzdGFxdWUgS3VyaW9cIj5cclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVyby1jb3B5XCI+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cImhlcm8td2VsY29tZVwiPkJlbS12aW5kbyDDoCBLdXJpbzwvcD5cclxuICAgICAgPGgxPjxzcGFuIGNsYXNzTmFtZT1cImhlcm8tZGVza3RvcC10aXRsZVwiPlNFSkEgRE9OTyBETyBGVVRVUk88YnIgLz5EQSBBUlRFIERJR0lUQUw8L3NwYW4+PHNwYW4gY2xhc3NOYW1lPVwiaGVyby1tb2JpbGUtdGl0bGVcIj5TRUpBIERPTk8gREE8YnIgLz5DVUxUVVJBIERJR0lUQUw8L3NwYW4+PC9oMT5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwiaGVyby1kZXNjcmlwdGlvblwiPjxzcGFuIGNsYXNzTmFtZT1cImhlcm8tZGVza3RvcC10aXRsZVwiPkRlc2N1YnJhIE5GVHMgc2VsZWNpb25hZG9zIGRlIGNyaWFkb3JlcyBlbWVyZ2VudGVzIGUgY29uc2FncmFkb3MuIENvbGVjaW9uZSBhcnRlIGRpZ2l0YWwgcmFyYSwgYXBvaWUgYXJ0aXN0YXMgZSB0ZW5oYSB1bWEgcGFydGUgZGEgY3VsdHVyYSBkYSBpbnRlcm5ldC48L3NwYW4+PHNwYW4gY2xhc3NOYW1lPVwiaGVyby1tb2JpbGUtdGl0bGVcIj5EZXNjdWJyYSBORlRzIHNlbGVjaW9uYWRvcyBkZSBjcmlhZG9yZXMgZG8gbXVuZG8gdG9kby48L3NwYW4+PC9wPlxyXG4gICAgICA8YSBocmVmPVwiI2NhdGFsb2dvXCIgY2xhc3NOYW1lPVwiaGVyby1jdGFcIj5FWFBMT1JBUiA8QXJyb3dSaWdodCBzaXplPXsxNn0gLz48L2E+XHJcbiAgICA8L2Rpdj5cclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVyby1hcnRcIj48aW1nIHNyYz1cIi9hc3NldHMvaW1hZ2VzL2hlcm8tbmZ0LndlYnBcIiBhbHQ9XCJFbWVyYWxkIEFwZSwgZGVzdGFxdWUgZGEgY29sZcOnw6NvIEt1cmlvXCIgZmV0Y2hQcmlvcml0eT1cImhpZ2hcIiAvPjxpbWcgY2xhc3NOYW1lPVwiaGVyby1taW5pXCIgc3JjPVwiL2Fzc2V0cy9pbWFnZXMvc2FnZS1ub21hZC53ZWJwXCIgYWx0PVwiXCIgLz48L2Rpdj5cclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVyby1kb3RzXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+PGkgLz48aSAvPjxpIC8+PC9kaXY+XHJcbiAgPC9zZWN0aW9uPlxyXG59XHJcbiJdfQ==
import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/HomePage.tsx");const lazy = __vite__cjsImport1_react["lazy"]; const Suspense = __vite__cjsImport1_react["Suspense"]; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"]; const useCallback = __vite__cjsImport1_react["useCallback"];const _jsxDEV = __vite__cjsImport13_react_jsxDevRuntime["jsxDEV"];import { catalogQuery } from "/src/lib/catalog-query.ts?t=1792165426699";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=7abeec5e";
import { useSearch, useNavigate } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=23b60560";
import { useQuery, useMutation, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=281272ec";
import { useFavorites } from "/src/lib/favorites.ts?t=1792166201444";
import { UnavailableAction } from "/src/components/ActionNotice.tsx?t=1792166201444";
import { Hero } from "/src/components/Hero.tsx";
import { NFTCard } from "/src/components/NFTCard.tsx";
import { NFTSkeleton } from "/src/components/NFTSkeleton.tsx?t=1792165205066";
import { useMediaQuery } from "/src/lib/use-media-query.ts";
import { api } from "/src/lib/axios.ts?t=1792164562494";
import { subscribeToNftUpdates } from "/src/lib/socket.ts?t=1792164137833";
import { ArrowRight, Search, SlidersHorizontal } from "/node_modules/.vite/deps/lucide-react.js?v=c7b96d59";
var _jsxFileName = "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/HomePage.tsx";
import __vite__cjsImport13_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7abeec5e";
var _s = $RefreshSig$();
const SidebarFilters = lazy(_c = () => import("/src/components/SidebarFilters.tsx?t=1792166201444").then((module) => ({ default: module.SidebarFilters })));
_c2 = SidebarFilters;
const FormSelect = lazy(_c3 = () => import("/src/components/FormSelect.tsx?t=1792164282123").then((module) => ({ default: module.FormSelect })));
_c4 = FormSelect;
export function HomePage() {
	_s();
	const mobile = useMediaQuery("(max-width: 767px)");
	const queryClient = useQueryClient();
	const searchParams = useSearch({ strict: false });
	const navigate = useNavigate({ from: "/" });
	const { search = "", collection = "", network = "", minPrice = "", maxPrice = "", tab = "all", sort = "recent", page = 1 } = searchParams;
	// Local state for instant input responsiveness before committing to URL
	const [filtersOpen, setFiltersOpen] = useState(false);
	const [searchDraft, setSearchDraft] = useState({
		source: search,
		value: search
	});
	const searchInput = searchDraft.source === search ? searchDraft.value : search;
	const setSearchInput = (value) => setSearchDraft({
		source: search,
		value
	});
	// Helper to update URL search params with page reset
	const updateFilters = useCallback((newParams, resetPage = true) => {
		navigate({ search: (prev) => {
			const next = {
				...prev,
				...newParams,
				page: resetPage ? 1 : newParams.page ?? prev.page ?? 1
			};
			// Clean empty or undefined values from query string
			const cleaned = {};
			for (const [k, v] of Object.entries(next)) {
				if (v !== undefined && v !== "" && v !== null) {
					cleaned[k] = v;
				}
			}
			return cleaned;
		} });
	}, [navigate]);
	// Query NFTs from API based on URL search params
	const { data, isLoading, isFetching, isError, refetch } = useQuery(catalogQuery(searchParams));
	// Real-time Socket.IO subscription
	useEffect(() => {
		const unsubscribe = subscribeToNftUpdates((event) => {
			console.log("[Home Realtime] NFT updated via socket:", event);
			queryClient.setQueriesData({ queryKey: ["nfts"] }, (old) => {
				if (!old) return old;
				return {
					...old,
					items: old.items.map((item) => item.id === event.resourceId ? {
						...item,
						priceEth: event.priceEth,
						availableQuantity: event.availableQuantity,
						version: event.version
					} : item)
				};
			});
		});
		return () => {
			unsubscribe();
		};
	}, [queryClient]);
	const { favoriteIds, toggleFavorite, isUpdating } = useFavorites();
	const handleToggleFavorite = (id) => {
		const nft = data?.items.find((item) => item.id === id);
		if (nft) toggleFavorite(nft);
	};
	// Real Add to Cart Mutation
	const addToCartMutation = useMutation({
		mutationFn: async (nft) => {
			await api.post("/cart/items", {
				nftId: nft.id,
				quantity: 1,
				edition: nft.edition || "1/50"
			});
		},
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["cart"] });
		}
	});
	const handleAddToCart = (nft) => {
		addToCartMutation.mutate(nft);
	};
	const handleClearFilters = () => {
		updateFilters({
			collection: undefined,
			network: undefined,
			minPrice: undefined,
			maxPrice: undefined,
			search: undefined
		});
		setSearchInput("");
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "home-page bg-[#140D0A] text-[#F5F1EB]",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mobile-search",
				children: [/* @__PURE__ */ _jsxDEV("form", {
					onSubmit: (e) => {
						e.preventDefault();
						updateFilters({ search: searchInput });
					},
					children: [/* @__PURE__ */ _jsxDEV(Search, { size: 21 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 136,
						columnNumber: 123
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						"aria-label": "Buscar coleções",
						placeholder: "Explorar coleções",
						value: searchInput,
						onChange: (e) => setSearchInput(e.target.value)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 136,
						columnNumber: 143
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 136,
					columnNumber: 38
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					disabled: isLoading,
					"aria-label": "Filtros do catálogo",
					"aria-expanded": filtersOpen,
					onClick: () => setFiltersOpen(!filtersOpen),
					children: /* @__PURE__ */ _jsxDEV(SlidersHorizontal, { size: 22 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 136,
						columnNumber: 422
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 136,
					columnNumber: 287
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 136,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Hero, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 138,
				columnNumber: 7
			}, this),
			addToCartMutation.isError && /* @__PURE__ */ _jsxDEV("p", {
				className: "page-width text-[#F0805F]",
				role: "alert",
				children: "Não foi possível adicionar o NFT. Confira o estoque e tente novamente."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 140,
				columnNumber: 37
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				id: "catalogo",
				"aria-busy": isFetching,
				className: "catalog-section mx-auto max-w-[1240px] px-4 py-16 md:px-8",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col gap-10 md:flex-row",
					children: [(!mobile || filtersOpen) && /* @__PURE__ */ _jsxDEV(Suspense, {
						fallback: /* @__PURE__ */ _jsxDEV("aside", {
							className: "catalog-filters",
							"aria-label": "Carregando filtros",
							"aria-busy": "true",
							children: /* @__PURE__ */ _jsxDEV("div", { className: "filter-panel skeleton-shimmer h-[720px]" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 145,
								columnNumber: 144
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 145,
							columnNumber: 60
						}, this),
						children: /* @__PURE__ */ _jsxDEV(SidebarFilters, {
							mobileOpen: filtersOpen,
							onMobileOpenChange: setFiltersOpen,
							collections: data?.collections || [],
							networks: data?.networks || [],
							selectedCollection: collection,
							selectedNetwork: network,
							minPrice,
							maxPrice,
							onSelectCollection: (col) => updateFilters({ collection: col }),
							onSelectNetwork: (net) => updateFilters({ network: net }),
							onPriceChange: (min, max) => updateFilters({
								minPrice: min,
								maxPrice: max
							}),
							onClearFilters: handleClearFilters,
							selectedSort: sort,
							onSortChange: (value) => updateFilters({ sort: value })
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 145,
							columnNumber: 213
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 145,
						columnNumber: 40
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "catalog-content flex flex-1 flex-col gap-8",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "catalog-toolbar flex flex-col gap-4 border-b border-[#3F2319] pb-4",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "catalog-search relative w-full sm:max-w-md",
									children: [/* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										"aria-label": "Buscar NFTs",
										placeholder: "Buscar por nome, edição, coleção...",
										value: searchInput,
										onChange: (e) => setSearchInput(e.target.value),
										onKeyDown: (e) => {
											if (e.key === "Enter") {
												updateFilters({ search: searchInput });
											}
										},
										onBlur: () => {
											if (searchInput !== search) {
												updateFilters({ search: searchInput });
											}
										},
										className: "w-full rounded-md border border-[#3F2319] bg-[#241612] py-2 pl-9 pr-3 font-mono text-xs text-[#F5F1EB] placeholder:text-[#CFB28C]/60 focus:border-[#D28A4C] focus:outline-none"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 167,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV(Search, { className: "pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-[#CFB28C]" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 185,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 166,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex flex-wrap items-center justify-between gap-4",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "catalog-tabs flex items-center gap-6 font-mono text-sm",
										children: [
											/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => updateFilters({ tab: "all" }),
												className: `pb-2 transition-colors cursor-pointer ${tab === "all" ? "border-b-2 border-[#D28A4C] font-bold text-[#E89B55]" : "text-[#F5F1EB] hover:text-[#E89B55]"}`,
												children: "Todos os NFTs"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 191,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => updateFilters({ tab: "new" }),
												className: `pb-2 transition-colors cursor-pointer ${tab === "new" ? "border-b-2 border-[#D28A4C] font-bold text-[#E89B55]" : "text-[#F5F1EB] hover:text-[#E89B55]"}`,
												children: "Novos lançamentos"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 202,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => updateFilters({ tab: "trending" }),
												className: `pb-2 transition-colors cursor-pointer ${tab === "trending" ? "border-b-2 border-[#D28A4C] font-bold text-[#E89B55]" : "text-[#F5F1EB] hover:text-[#E89B55]"}`,
												children: "Em alta"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 213,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 190,
										columnNumber: 17
									}, this), !mobile && /* @__PURE__ */ _jsxDEV("div", {
										className: "catalog-sort flex items-center gap-2 font-mono text-xs text-[#CFB28C]",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: "Ordenar por:" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 228,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "relative",
											children: /* @__PURE__ */ _jsxDEV(Suspense, {
												fallback: /* @__PURE__ */ _jsxDEV("span", {
													className: "catalog-sort-trigger",
													children: "Listados recentemente"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 230,
													columnNumber: 41
												}, this),
												children: /* @__PURE__ */ _jsxDEV(FormSelect, {
													"aria-label": "Ordenar NFTs",
													value: sort,
													onValueChange: (value) => updateFilters({ sort: value }),
													className: "catalog-sort-trigger",
													options: [
														{
															value: "recent",
															label: "Listados recentemente"
														},
														{
															value: "price_asc",
															label: "Menor preço"
														},
														{
															value: "price_desc",
															label: "Maior preço"
														}
													]
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 230,
													columnNumber: 110
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 230,
												columnNumber: 21
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 229,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 227,
										columnNumber: 29
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 188,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 165,
								columnNumber: 13
							}, this),
							isLoading ? /* @__PURE__ */ _jsxDEV("div", {
								className: "nft-grid grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3",
								role: "status",
								"aria-label": "Carregando catálogo",
								children: Array.from({ length: 9 }).map((_, i) => /* @__PURE__ */ _jsxDEV(NFTSkeleton, {}, i, false, {
									fileName: _jsxFileName,
									lineNumber: 245,
									columnNumber: 19
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 243,
								columnNumber: 15
							}, this) : isError ? /* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col items-center justify-center rounded-xl border border-[#3F2319] bg-[#241612] p-12 text-center font-mono",
								children: [
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-base font-bold text-[#E89B55]",
										children: "Falha ao carregar o catálogo de NFTs."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 250,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "mt-1 text-xs text-[#CFB28C]",
										children: "Ocorreu um erro na requisição com o mock da API."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 253,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => refetch(),
										className: "mt-4 rounded bg-[#D28A4C] px-5 py-2 text-xs font-bold text-[#140D0A] hover:bg-[#E89B55] cursor-pointer",
										children: "Tentar novamente"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 256,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 249,
								columnNumber: 15
							}, this) : data?.items.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col items-center justify-center rounded-xl border border-[#3F2319] bg-[#241612] p-12 text-center font-mono",
								children: [
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-base font-bold text-[#E89B55]",
										children: "Nenhum NFT encontrado com os filtros selecionados."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 266,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "mt-1 text-xs text-[#CFB28C]",
										children: "Tente alterar os termos da busca ou limpar os filtros."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 269,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: handleClearFilters,
										className: "mt-4 rounded bg-[#D28A4C] px-5 py-2 text-xs font-bold text-[#140D0A] hover:bg-[#E89B55] cursor-pointer",
										children: "Limpar filtros"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 272,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 265,
								columnNumber: 15
							}, this) : /* @__PURE__ */ _jsxDEV("div", {
								className: "nft-grid grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 justify-items-center",
								children: data?.items.map((nft, index) => /* @__PURE__ */ _jsxDEV(NFTCard, {
									nft,
									eager: index < 2,
									isFavorite: favoriteIds.includes(nft.id),
									isFavoritePending: isUpdating,
									onToggleFavorite: handleToggleFavorite,
									onAddToCart: handleAddToCart,
									onSelect: (id) => {
										navigate({
											to: "/nfts/$id",
											params: { id }
										});
									}
								}, nft.id, false, {
									fileName: _jsxFileName,
									lineNumber: 283,
									columnNumber: 19
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 281,
								columnNumber: 15
							}, this),
							data && data.totalPages > 1 && /* @__PURE__ */ _jsxDEV("div", {
								className: "catalog-pagination mt-8 flex items-center justify-center gap-2",
								children: Array.from({ length: data.totalPages }).map((_, index) => {
									const pageNum = index + 1;
									const isActive = page === pageNum;
									return /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => updateFilters({ page: pageNum }, false),
										className: `flex h-9 w-9 items-center justify-center rounded border font-mono text-sm font-bold transition-colors cursor-pointer ${isActive ? "border-[#D28A4C] bg-[#D28A4C] text-[#140D0A]" : "border-[#3F2319] bg-[#241612] text-[#F5F1EB] hover:border-[#D28A4C]"}`,
										children: pageNum
									}, pageNum, false, {
										fileName: _jsxFileName,
										lineNumber: 307,
										columnNumber: 21
									}, this);
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 302,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 163,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 143,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 142,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				id: "promos",
				className: "mx-auto max-w-[1240px] px-4 py-8 md:px-8",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 gap-8 md:grid-cols-2",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col-reverse items-center justify-between gap-6 rounded-2xl border border-[#3F2319] bg-[#241612] p-8 sm:flex-row",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-1 flex-col gap-3 font-mono",
							children: [
								/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-xl font-bold text-[#F5F1EB]",
									children: "Lançamentos gênesis de edição limitada"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 333,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs leading-relaxed text-[#CFB28C]",
									children: "Colecione edições escassas diretamente dos criadores antes da revelação pública."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 336,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("a", {
									href: "#catalogo",
									className: "mt-2 inline-flex w-fit items-center gap-2 rounded bg-[#D28A4C] px-5 py-2 text-xs font-bold text-[#140D0A] transition-colors hover:bg-[#E89B55]",
									children: ["Explorar ", /* @__PURE__ */ _jsxDEV(ArrowRight, { className: "h-3.5 w-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 343,
										columnNumber: 26
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 339,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 332,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "h-44 w-44 shrink-0 overflow-hidden rounded-xl border border-[#3F2319]",
							children: /* @__PURE__ */ _jsxDEV("img", {
								src: "/assets/images/promo-genesis.webp",
								alt: "Promo Genesis",
								className: "h-full w-full object-cover"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 347,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 346,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 331,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col-reverse items-center justify-between gap-6 rounded-2xl border border-[#3F2319] bg-[#241612] p-8 sm:flex-row",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-1 flex-col gap-3 font-mono",
							children: [
								/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-xl font-bold text-[#F5F1EB]",
									children: "Arte digital selecionada e muito mais"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 358,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs leading-relaxed text-[#CFB28C]",
									children: "Explore novos artistas, coleções verificadas e obras digitais que definem a cultura."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 361,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("a", {
									href: "#catalogo",
									className: "mt-2 inline-flex w-fit items-center gap-2 rounded bg-[#D28A4C] px-5 py-2 text-xs font-bold text-[#140D0A] transition-colors hover:bg-[#E89B55]",
									children: ["Explorar ", /* @__PURE__ */ _jsxDEV(ArrowRight, { className: "h-3.5 w-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 368,
										columnNumber: 26
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 364,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 357,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "h-44 w-44 shrink-0 overflow-hidden rounded-xl border border-[#3F2319]",
							children: /* @__PURE__ */ _jsxDEV("img", {
								src: "/assets/images/promo-curated.webp",
								alt: "Promo Curated",
								className: "h-full w-full object-cover"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 372,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 371,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 356,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 329,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 328,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				id: "blog",
				className: "mx-auto max-w-[1240px] px-4 py-16 md:px-8 font-mono",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col gap-2",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-xs font-bold uppercase tracking-wider text-[#D28A4C]",
						children: "Diário da Cunhagem"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 385,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("h2", {
						className: "text-2xl font-bold text-[#F5F1EB]",
						children: "Histórias, guias e insights para colecionadores sobre o universo da propriedade digital."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 388,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 384,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4",
					children: [
						{
							title: "Como funciona a propriedade de NFTs",
							category: "12 de setembro | Leitura de 6 min",
							description: "Aprenda a colecionar, negociar e verificar ativos digitais.",
							image: "/assets/images/blog-1.webp"
						},
						{
							title: "10 artistas digitais para acompanhar",
							category: "13 de setembro | Leitura de 2 min",
							description: "Conheça criadores que moldam a cultura digital.",
							image: "/assets/images/blog-2.webp"
						},
						{
							title: "Raridade, atributos e procedência",
							category: "15 de setembro | Leitura de 3 min",
							description: "Entenda raridade, procedência, direitos autorais e utilidade.",
							image: "/assets/images/blog-3.webp"
						},
						{
							title: "Como proteger sua carteira",
							category: "15 de setembro | Leitura de 2 min",
							description: "Proteja sua carteira, seus ativos e sua identidade.",
							image: "/assets/images/blog-4.webp"
						}
					].map((post, idx) => /* @__PURE__ */ _jsxDEV("div", {
						className: "group overflow-hidden rounded-xl border border-[#3F2319] bg-[#241612] transition-colors hover:border-[#D28A4C]",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "aspect-video w-full overflow-hidden bg-[#140D0A]",
							children: /* @__PURE__ */ _jsxDEV("img", {
								src: post.image,
								alt: post.title,
								className: "h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 425,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 424,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "p-4 flex flex-col gap-1.5",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[11px] font-semibold text-[#D28A4C]",
									children: post.category
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 432,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-sm font-bold text-[#F5F1EB] group-hover:text-[#E89B55] transition-colors",
									children: post.title
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 435,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "blog-description",
									children: post.description
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 438,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV(UnavailableAction, {
									className: "blog-read",
									name: post.title,
									children: "Ler mais →"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 439,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 431,
							columnNumber: 15
						}, this)]
					}, idx, true, {
						fileName: _jsxFileName,
						lineNumber: 420,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 393,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 383,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 135,
		columnNumber: 5
	}, this);
}
_s(HomePage, "rgpmcgYKMdySBOMEek2Uk+tGwKY=", false, function() {
	return [
		useMediaQuery,
		useQueryClient,
		useSearch,
		useNavigate,
		useQuery,
		useFavorites,
		useMutation
	];
});
_c5 = HomePage;
var _c, _c2, _c3, _c4, _c5;
$RefreshReg$(_c, "SidebarFilters$lazy");
$RefreshReg$(_c2, "SidebarFilters");
$RefreshReg$(_c3, "FormSelect$lazy");
$RefreshReg$(_c4, "FormSelect");
$RefreshReg$(_c5, "HomePage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/HomePage.tsx?t=1792167170549";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/HomePage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/HomePage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/HomePage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxNQUFNLFVBQVUsVUFBVSxXQUFXLG1CQUFtQjtBQUNqRSxTQUFTLFdBQVcsbUJBQW1CO0FBQ3ZDLFNBQVMsVUFBVSxhQUFhLHNCQUFzQjtBQUN0RCxTQUFTLG9CQUFvQjtBQUM3QixTQUFTLHlCQUF5QjtBQUNsQyxTQUFTLFlBQVk7QUFDckIsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsV0FBVztBQUNwQixTQUFTLDZCQUE2QjtBQUV0QyxTQUFTLFlBQVksUUFBUSx5QkFBeUI7Ozs7QUFJdEQsTUFBTSxpQkFBaUIsZ0JBQVcsT0FBTyw4QkFBOEIsQ0FBQyxNQUFLLFlBQVcsRUFBRSxTQUFTLE9BQU8sZUFBZSxFQUFFLENBQUM7O0FBQzVILE1BQU0sYUFBYSxpQkFBVyxPQUFPLDBCQUEwQixDQUFDLE1BQUssWUFBVyxFQUFFLFNBQVMsT0FBTyxXQUFXLEVBQUUsQ0FBQzs7QUFFaEgsT0FBTyxTQUFTLFdBQVc7O0NBQ3pCLE1BQU0sU0FBUyxjQUFjLG9CQUFvQjtDQUNqRCxNQUFNLGNBQWMsZUFBZTtDQUNuQyxNQUFNLGVBQWUsVUFBVSxFQUFFLFFBQVEsTUFBTSxDQUFDO0NBQ2hELE1BQU0sV0FBVyxZQUFZLEVBQUUsTUFBTSxJQUFJLENBQUM7Q0FFMUMsTUFBTSxFQUNKLFNBQVMsSUFDVCxhQUFhLElBQ2IsVUFBVSxJQUNWLFdBQVcsSUFDWCxXQUFXLElBQ1gsTUFBTSxPQUNOLE9BQU8sVUFDUCxPQUFPLE1BQ0w7O0NBR0osTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsS0FBSztDQUNwRCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUztFQUFFLFFBQVE7RUFBUSxPQUFPO0NBQU8sQ0FBQztDQUNoRixNQUFNLGNBQWMsWUFBWSxXQUFXLFNBQVMsWUFBWSxRQUFRO0NBQ3hFLE1BQU0sa0JBQWtCLFVBQWtCLGVBQWU7RUFBRSxRQUFRO0VBQVE7Q0FBTSxDQUFDOztDQUdsRixNQUFNLGdCQUFnQixhQUNuQixXQUFzQyxZQUFZLFNBQVM7RUFDMUQsU0FBUyxFQUNQLFNBQVMsU0FBUztHQUNoQixNQUFNLE9BQU87SUFDWCxHQUFHO0lBQ0gsR0FBRztJQUNILE1BQU0sWUFBWSxJQUFJLFVBQVUsUUFBUSxLQUFLLFFBQVE7R0FDdkQ7O0dBRUEsTUFBTSxVQUFtQyxDQUFDO0dBQzFDLEtBQUssTUFBTSxDQUFDLEdBQUcsTUFBTSxPQUFPLFFBQVEsSUFBSSxHQUFHO0lBQ3pDLElBQUksTUFBTSxhQUFhLE1BQU0sTUFBTSxNQUFNLE1BQU07S0FDN0MsUUFBUSxLQUFLO0lBQ2Y7R0FDRjtHQUNBLE9BQU87RUFDVCxFQUNGLENBQUM7Q0FDSCxHQUNBLENBQUMsUUFBUSxDQUNYOztDQUdBLE1BQU0sRUFBRSxNQUFNLFdBQVcsWUFBWSxTQUFTLFlBQVksU0FBUyxhQUFhLFlBQVksQ0FBQzs7Q0FHN0YsZ0JBQWdCO0VBQ2QsTUFBTSxjQUFjLHVCQUF1QixVQUEyQjtHQUNwRSxRQUFRLElBQUksMkNBQTJDLEtBQUs7R0FDNUQsWUFBWSxlQUFnQyxFQUFFLFVBQVUsQ0FBQyxNQUFNLEVBQUUsSUFBSSxRQUFRO0lBQzNFLElBQUksQ0FBQyxLQUFLLE9BQU87SUFDakIsT0FBTztLQUNMLEdBQUc7S0FDSCxPQUFPLElBQUksTUFBTSxLQUFLLFNBQ3BCLEtBQUssT0FBTyxNQUFNLGFBQ2Q7TUFDRSxHQUFHO01BQ0gsVUFBVSxNQUFNO01BQ2hCLG1CQUFtQixNQUFNO01BQ3pCLFNBQVMsTUFBTTtLQUVqQixJQUNBLElBQ047SUFDRjtHQUNGLENBQUM7RUFDSCxDQUFDO0VBRUQsYUFBYTtHQUNYLFlBQVk7RUFDZDtDQUNGLEdBQUcsQ0FBQyxXQUFXLENBQUM7Q0FFaEIsTUFBTSxFQUFFLGFBQWEsZ0JBQWdCLGVBQWUsYUFBYTtDQUNqRSxNQUFNLHdCQUF3QixPQUFlO0VBQzNDLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBSyxTQUFRLEtBQUssT0FBTyxFQUFFO0VBQ25ELElBQUksS0FBSyxlQUFlLEdBQUc7Q0FDN0I7O0NBR0EsTUFBTSxvQkFBb0IsWUFBWTtFQUNwQyxZQUFZLE9BQU8sUUFBYTtHQUM5QixNQUFNLElBQUksS0FBSyxlQUFlO0lBQzVCLE9BQU8sSUFBSTtJQUNYLFVBQVU7SUFDVixTQUFTLElBQUksV0FBVztHQUMxQixDQUFDO0VBQ0g7RUFDQSxpQkFBaUI7R0FDZixZQUFZLGtCQUFrQixFQUFFLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztFQUN0RDtDQUNGLENBQUM7Q0FFRCxNQUFNLG1CQUFtQixRQUFhO0VBQ3BDLGtCQUFrQixPQUFPLEdBQUc7Q0FDOUI7Q0FFQSxNQUFNLDJCQUEyQjtFQUMvQixjQUFjO0dBQ1osWUFBWTtHQUNaLFNBQVM7R0FDVCxVQUFVO0dBQ1YsVUFBVTtHQUNWLFFBQVE7RUFDVixDQUFDO0VBQ0QsZUFBZSxFQUFFO0NBQ25CO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUErQix3QkFBQyxRQUFEO0tBQU0sV0FBVSxNQUFLO01BQUUsRUFBRSxlQUFlO01BQUcsY0FBYyxFQUFFLFFBQVEsWUFBWSxDQUFDO0tBQUU7ZUFBbEYsQ0FBcUYsd0JBQUMsUUFBRCxFQUFRLE1BQU0sR0FBSzs7OztlQUFDLHdCQUFDLFNBQUQ7TUFBTyxjQUFXO01BQWtCLGFBQVk7TUFBb0IsT0FBTztNQUFhLFdBQVUsTUFBSyxlQUFlLEVBQUUsT0FBTyxLQUFLO0tBQUk7Ozs7YUFBTzs7Ozs7Y0FBQyx3QkFBQyxVQUFEO0tBQVEsVUFBVTtLQUFXLGNBQVc7S0FBc0IsaUJBQWU7S0FBYSxlQUFlLGVBQWUsQ0FBQyxXQUFXO2VBQUcsd0JBQUMsbUJBQUQsRUFBbUIsTUFBTSxHQUFLOzs7OztJQUFTOzs7O1lBQU07Ozs7OztHQUU1Yyx3QkFBQyxNQUFELENBQU87Ozs7O0dBRU4sa0JBQWtCLFdBQVcsd0JBQUMsS0FBRDtJQUFHLFdBQVU7SUFBNEIsTUFBSztjQUFRO0dBQXlFOzs7OztHQUU3Six3QkFBQyxXQUFEO0lBQVMsSUFBRztJQUFXLGFBQVc7SUFBWSxXQUFVO2NBQ3RELHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsRUFFSSxDQUFDLFVBQVUsZ0JBQWdCLHdCQUFDLFVBQUQ7TUFBVSxVQUFVLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO09BQWtCLGNBQVc7T0FBcUIsYUFBVTtpQkFBTyx3QkFBQyxPQUFELEVBQUssV0FBVSwwQ0FBMkM7Ozs7O01BQVE7Ozs7O2dCQUFHLHdCQUFDLGdCQUFEO09BQ3hNLFlBQVk7T0FDWixvQkFBb0I7T0FDcEIsYUFBYSxNQUFNLGVBQWUsQ0FBQztPQUNuQyxVQUFVLE1BQU0sWUFBWSxDQUFDO09BQzdCLG9CQUFvQjtPQUNwQixpQkFBaUI7T0FDUDtPQUNBO09BQ1YscUJBQXFCLFFBQVEsY0FBYyxFQUFFLFlBQVksSUFBSSxDQUFDO09BQzlELGtCQUFrQixRQUFRLGNBQWMsRUFBRSxTQUFTLElBQUksQ0FBQztPQUN4RCxnQkFBZ0IsS0FBSyxRQUFRLGNBQWM7UUFBRSxVQUFVO1FBQUssVUFBVTtPQUFJLENBQUM7T0FDM0UsZ0JBQWdCO09BQ2hCLGNBQWM7T0FDZCxlQUFjLFVBQVMsY0FBYyxFQUFFLE1BQU0sTUFBTSxDQUFDO01BQ3JEOzs7OztLQUFXOzs7O2VBR1osd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FFRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxjQUFXO1VBQ1gsYUFBWTtVQUNaLE9BQU87VUFDUCxXQUFXLE1BQU0sZUFBZSxFQUFFLE9BQU8sS0FBSztVQUM5QyxZQUFZLE1BQU07V0FDaEIsSUFBSSxFQUFFLFFBQVEsU0FBUztZQUNyQixjQUFjLEVBQUUsUUFBUSxZQUFZLENBQUM7V0FDdkM7VUFDRjtVQUNBLGNBQWM7V0FDWixJQUFJLGdCQUFnQixRQUFRO1lBQzFCLGNBQWMsRUFBRSxRQUFRLFlBQVksQ0FBQztXQUN2QztVQUNGO1VBQ0EsV0FBVTtTQUNYOzs7O21CQUNELHdCQUFDLFFBQUQsRUFBUSxXQUFVLHFFQUFzRTs7OztpQkFDckY7Ozs7O2tCQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBRUUsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FDRSx3QkFBQyxVQUFEO1lBQ0UsTUFBSztZQUNMLGVBQWUsY0FBYyxFQUFFLEtBQUssTUFBTSxDQUFDO1lBQzNDLFdBQVcseUNBQ1QsUUFBUSxRQUNKLHlEQUNBO3NCQUVQO1dBRU87Ozs7O1dBQ1Isd0JBQUMsVUFBRDtZQUNFLE1BQUs7WUFDTCxlQUFlLGNBQWMsRUFBRSxLQUFLLE1BQU0sQ0FBQztZQUMzQyxXQUFXLHlDQUNULFFBQVEsUUFDSix5REFDQTtzQkFFUDtXQUVPOzs7OztXQUNSLHdCQUFDLFVBQUQ7WUFDRSxNQUFLO1lBQ0wsZUFBZSxjQUFjLEVBQUUsS0FBSyxXQUFXLENBQUM7WUFDaEQsV0FBVyx5Q0FDVCxRQUFRLGFBQ0oseURBQ0E7c0JBRVA7V0FFTzs7Ozs7VUFDTDs7Ozs7bUJBR0osQ0FBQyxVQUFVLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ1Ysd0JBQUMsUUFBRCxZQUFNLGVBQWtCOzs7O29CQUN4Qix3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDYix3QkFBQyxVQUFEO1lBQVUsVUFBVSx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBdUI7WUFBMkI7Ozs7O3NCQUFHLHdCQUFDLFlBQUQ7YUFBWSxjQUFXO2FBQzlHLE9BQU87YUFDUCxnQkFBZSxVQUFTLGNBQWMsRUFBRSxNQUFNLE1BQWtDLENBQUM7YUFDakYsV0FBVTthQUNWLFNBQVM7Y0FBQztlQUFFLE9BQU87ZUFBVSxPQUFPO2NBQXdCO2NBQUc7ZUFBRSxPQUFPO2VBQWEsT0FBTztjQUFjO2NBQUc7ZUFBRSxPQUFPO2VBQWMsT0FBTztjQUFjO2FBQUM7WUFDM0o7Ozs7O1dBQVc7Ozs7O1VBQ1Q7Ozs7a0JBQ0Y7Ozs7O2lCQUNGOzs7OztnQkFDRjs7Ozs7O09BR0osWUFDQyx3QkFBQyxPQUFEO1FBQUssV0FBVTtRQUFnRSxNQUFLO1FBQVMsY0FBVztrQkFDckcsTUFBTSxLQUFLLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxNQUNqQyx3QkFBQyxhQUFELENBQXNCLEdBQUo7Ozs7ZUFBSSxDQUN2QjtPQUNFOzs7O2tCQUNILFVBQ0Ysd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBcUM7U0FFL0M7Ozs7O1NBQ0gsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQThCO1NBRXhDOzs7OztTQUNILHdCQUFDLFVBQUQ7VUFDRSxNQUFLO1VBQ0wsZUFBZSxRQUFRO1VBQ3ZCLFdBQVU7b0JBQ1g7U0FFTzs7Ozs7UUFDTDs7Ozs7a0JBQ0gsTUFBTSxNQUFNLFdBQVcsSUFDekIsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBcUM7U0FFL0M7Ozs7O1NBQ0gsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQThCO1NBRXhDOzs7OztTQUNILHdCQUFDLFVBQUQ7VUFDRSxNQUFLO1VBQ0wsU0FBUztVQUNULFdBQVU7b0JBQ1g7U0FFTzs7Ozs7UUFDTDs7Ozs7a0JBRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1osTUFBTSxNQUFNLEtBQUssS0FBSyxVQUNyQix3QkFBQyxTQUFEO1NBRU87U0FDTCxPQUFPLFFBQVE7U0FDZixZQUFZLFlBQVksU0FBUyxJQUFJLEVBQUU7U0FDdkMsbUJBQW1CO1NBQ25CLGtCQUFrQjtTQUNsQixhQUFhO1NBQ2IsV0FBVyxPQUFPO1VBQ2hCLFNBQVM7V0FBRSxJQUFJO1dBQWEsUUFBUSxFQUFFLEdBQUc7VUFBRSxDQUFDO1NBQzlDO1FBRUQsR0FYTSxJQUFJOzs7O2VBV1YsQ0FDRjtPQUNFOzs7OztPQUlOLFFBQVEsS0FBSyxhQUFhLEtBQ3pCLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNaLE1BQU0sS0FBSyxFQUFFLFFBQVEsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxVQUFVO1NBQ3pELE1BQU0sVUFBVSxRQUFRO1NBQ3hCLE1BQU0sV0FBVyxTQUFTO1NBQzFCLE9BQ0Usd0JBQUMsVUFBRDtVQUVFLE1BQUs7VUFDTCxlQUFlLGNBQWMsRUFBRSxNQUFNLFFBQVEsR0FBRyxLQUFLO1VBQ3JELFdBQVcsd0hBQ1QsV0FDSSxpREFDQTtvQkFHTDtTQUNLLEdBVkQ7Ozs7Z0JBVUM7UUFFWixDQUFDO09BQ0U7Ozs7O01BRUo7Ozs7O2FBQ0Y7Ozs7OztHQUNFOzs7OztHQUdULHdCQUFDLFdBQUQ7SUFBUyxJQUFHO0lBQVMsV0FBVTtjQUM3Qix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBRUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFtQztRQUU3Qzs7Ozs7UUFDSix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBeUM7UUFFbkQ7Ozs7O1FBQ0gsd0JBQUMsS0FBRDtTQUNFLE1BQUs7U0FDTCxXQUFVO21CQUZaLENBR0MsYUFDVSx3QkFBQyxZQUFELEVBQVksV0FBVSxjQUFlOzs7O2lCQUM3Qzs7Ozs7O09BQ0E7Ozs7O2dCQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLE9BQUQ7UUFDRSxLQUFJO1FBQ0osS0FBSTtRQUNKLFdBQVU7T0FDWDs7Ozs7TUFDRTs7OztjQUNGOzs7OztlQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBbUM7UUFFN0M7Ozs7O1FBQ0osd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQXlDO1FBRW5EOzs7OztRQUNILHdCQUFDLEtBQUQ7U0FDRSxNQUFLO1NBQ0wsV0FBVTttQkFGWixDQUdDLGFBQ1Usd0JBQUMsWUFBRCxFQUFZLFdBQVUsY0FBZTs7OztpQkFDN0M7Ozs7OztPQUNBOzs7OztnQkFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxPQUFEO1FBQ0UsS0FBSTtRQUNKLEtBQUk7UUFDSixXQUFVO09BQ1g7Ozs7O01BQ0U7Ozs7Y0FDRjs7Ozs7YUFDRjs7Ozs7O0dBQ0U7Ozs7O0dBR1Qsd0JBQUMsV0FBRDtJQUFTLElBQUc7SUFBTyxXQUFVO2NBQTdCLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUE0RDtLQUV0RTs7OztlQUNOLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFvQztLQUU5Qzs7OzthQUNEOzs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1o7TUFDQztPQUNFLE9BQU87T0FDUCxVQUFVO09BQ1YsYUFBYTtPQUNiLE9BQU87TUFDVDtNQUNBO09BQ0UsT0FBTztPQUNQLFVBQVU7T0FDVixhQUFhO09BQ2IsT0FBTztNQUNUO01BQ0E7T0FDRSxPQUFPO09BQ1AsVUFBVTtPQUNWLGFBQWE7T0FDYixPQUFPO01BQ1Q7TUFDQTtPQUNFLE9BQU87T0FDUCxVQUFVO09BQ1YsYUFBYTtPQUNiLE9BQU87TUFDVDtLQUNGLENBQUMsQ0FBQyxLQUFLLE1BQU0sUUFDWCx3QkFBQyxPQUFEO01BRUUsV0FBVTtnQkFGWixDQUlFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLE9BQUQ7UUFDRSxLQUFLLEtBQUs7UUFDVixLQUFLLEtBQUs7UUFDVixXQUFVO09BQ1g7Ozs7O01BQ0U7Ozs7Z0JBQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFDYixLQUFLO1FBQ0Y7Ozs7O1FBQ04sd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQ1gsS0FBSztRQUNKOzs7OztRQUNKLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFvQixLQUFLO1FBQWU7Ozs7O1FBQ3JELHdCQUFDLG1CQUFEO1NBQW1CLFdBQVU7U0FBWSxNQUFNLEtBQUs7bUJBQU87UUFBNkI7Ozs7O09BQ3JGOzs7OztjQUNGO1FBcEJFOzs7O1lBb0JGLENBQ047SUFDRTs7OztZQUNFOzs7Ozs7RUFDTjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSG9tZVBhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNhdGFsb2dRdWVyeSB9IGZyb20gJ0AvbGliL2NhdGFsb2ctcXVlcnknXHJcbmltcG9ydCB7IGxhenksIFN1c3BlbnNlLCB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VDYWxsYmFjayB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyB1c2VTZWFyY2gsIHVzZU5hdmlnYXRlIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcidcclxuaW1wb3J0IHsgdXNlUXVlcnksIHVzZU11dGF0aW9uLCB1c2VRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcclxuaW1wb3J0IHsgdXNlRmF2b3JpdGVzIH0gZnJvbSAnQC9saWIvZmF2b3JpdGVzJ1xyXG5pbXBvcnQgeyBVbmF2YWlsYWJsZUFjdGlvbiB9IGZyb20gJ0AvY29tcG9uZW50cy9BY3Rpb25Ob3RpY2UnXHJcbmltcG9ydCB7IEhlcm8gfSBmcm9tICdAL2NvbXBvbmVudHMvSGVybydcclxuaW1wb3J0IHsgTkZUQ2FyZCB9IGZyb20gJ0AvY29tcG9uZW50cy9ORlRDYXJkJ1xyXG5pbXBvcnQgeyBORlRTa2VsZXRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy9ORlRTa2VsZXRvbidcclxuaW1wb3J0IHsgdXNlTWVkaWFRdWVyeSB9IGZyb20gJ0AvbGliL3VzZS1tZWRpYS1xdWVyeSdcclxuaW1wb3J0IHsgYXBpIH0gZnJvbSAnQC9saWIvYXhpb3MnXHJcbmltcG9ydCB7IHN1YnNjcmliZVRvTmZ0VXBkYXRlcyB9IGZyb20gJ0AvbGliL3NvY2tldCdcclxuaW1wb3J0IHR5cGUgeyBORlQsIE5GVExpc3RSZXNwb25zZSwgTkZUVXBkYXRlZEV2ZW50IH0gZnJvbSAnQC90eXBlcy9hcGknXHJcbmltcG9ydCB7IEFycm93UmlnaHQsIFNlYXJjaCwgU2xpZGVyc0hvcml6b250YWwgfSBmcm9tICdsdWNpZGUtcmVhY3QnXHJcblxyXG5pbXBvcnQgdHlwZSB7IEhvbWVTZWFyY2hQYXJhbXMgfSBmcm9tICdAL3JvdXRlcy9pbmRleCdcclxuXHJcbmNvbnN0IFNpZGViYXJGaWx0ZXJzID0gbGF6eSgoKSA9PiBpbXBvcnQoJ0AvY29tcG9uZW50cy9TaWRlYmFyRmlsdGVycycpLnRoZW4obW9kdWxlID0+ICh7IGRlZmF1bHQ6IG1vZHVsZS5TaWRlYmFyRmlsdGVycyB9KSkpXHJcbmNvbnN0IEZvcm1TZWxlY3QgPSBsYXp5KCgpID0+IGltcG9ydCgnQC9jb21wb25lbnRzL0Zvcm1TZWxlY3QnKS50aGVuKG1vZHVsZSA9PiAoeyBkZWZhdWx0OiBtb2R1bGUuRm9ybVNlbGVjdCB9KSkpXHJcblxyXG5leHBvcnQgZnVuY3Rpb24gSG9tZVBhZ2UoKSB7XHJcbiAgY29uc3QgbW9iaWxlID0gdXNlTWVkaWFRdWVyeSgnKG1heC13aWR0aDogNzY3cHgpJylcclxuICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KClcclxuICBjb25zdCBzZWFyY2hQYXJhbXMgPSB1c2VTZWFyY2goeyBzdHJpY3Q6IGZhbHNlIH0pIGFzIEhvbWVTZWFyY2hQYXJhbXNcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKHsgZnJvbTogJy8nIH0pXHJcblxyXG4gIGNvbnN0IHtcclxuICAgIHNlYXJjaCA9ICcnLFxyXG4gICAgY29sbGVjdGlvbiA9ICcnLFxyXG4gICAgbmV0d29yayA9ICcnLFxyXG4gICAgbWluUHJpY2UgPSAnJyxcclxuICAgIG1heFByaWNlID0gJycsXHJcbiAgICB0YWIgPSAnYWxsJyxcclxuICAgIHNvcnQgPSAncmVjZW50JyxcclxuICAgIHBhZ2UgPSAxLFxyXG4gIH0gPSBzZWFyY2hQYXJhbXNcclxuXHJcbiAgLy8gTG9jYWwgc3RhdGUgZm9yIGluc3RhbnQgaW5wdXQgcmVzcG9uc2l2ZW5lc3MgYmVmb3JlIGNvbW1pdHRpbmcgdG8gVVJMXHJcbiAgY29uc3QgW2ZpbHRlcnNPcGVuLCBzZXRGaWx0ZXJzT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSlcclxuICBjb25zdCBbc2VhcmNoRHJhZnQsIHNldFNlYXJjaERyYWZ0XSA9IHVzZVN0YXRlKHsgc291cmNlOiBzZWFyY2gsIHZhbHVlOiBzZWFyY2ggfSlcclxuICBjb25zdCBzZWFyY2hJbnB1dCA9IHNlYXJjaERyYWZ0LnNvdXJjZSA9PT0gc2VhcmNoID8gc2VhcmNoRHJhZnQudmFsdWUgOiBzZWFyY2hcclxuICBjb25zdCBzZXRTZWFyY2hJbnB1dCA9ICh2YWx1ZTogc3RyaW5nKSA9PiBzZXRTZWFyY2hEcmFmdCh7IHNvdXJjZTogc2VhcmNoLCB2YWx1ZSB9KVxyXG5cclxuICAvLyBIZWxwZXIgdG8gdXBkYXRlIFVSTCBzZWFyY2ggcGFyYW1zIHdpdGggcGFnZSByZXNldFxyXG4gIGNvbnN0IHVwZGF0ZUZpbHRlcnMgPSB1c2VDYWxsYmFjayhcclxuICAgIChuZXdQYXJhbXM6IFBhcnRpYWw8SG9tZVNlYXJjaFBhcmFtcz4sIHJlc2V0UGFnZSA9IHRydWUpID0+IHtcclxuICAgICAgbmF2aWdhdGUoe1xyXG4gICAgICAgIHNlYXJjaDogKHByZXYpID0+IHtcclxuICAgICAgICAgIGNvbnN0IG5leHQgPSB7XHJcbiAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgIC4uLm5ld1BhcmFtcyxcclxuICAgICAgICAgICAgcGFnZTogcmVzZXRQYWdlID8gMSA6IG5ld1BhcmFtcy5wYWdlID8/IHByZXYucGFnZSA/PyAxLFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgLy8gQ2xlYW4gZW1wdHkgb3IgdW5kZWZpbmVkIHZhbHVlcyBmcm9tIHF1ZXJ5IHN0cmluZ1xyXG4gICAgICAgICAgY29uc3QgY2xlYW5lZDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fVxyXG4gICAgICAgICAgZm9yIChjb25zdCBbaywgdl0gb2YgT2JqZWN0LmVudHJpZXMobmV4dCkpIHtcclxuICAgICAgICAgICAgaWYgKHYgIT09IHVuZGVmaW5lZCAmJiB2ICE9PSAnJyAmJiB2ICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgY2xlYW5lZFtrXSA9IHZcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgcmV0dXJuIGNsZWFuZWQgYXMgSG9tZVNlYXJjaFBhcmFtc1xyXG4gICAgICAgIH0sXHJcbiAgICAgIH0pXHJcbiAgICB9LFxyXG4gICAgW25hdmlnYXRlXVxyXG4gIClcclxuXHJcbiAgLy8gUXVlcnkgTkZUcyBmcm9tIEFQSSBiYXNlZCBvbiBVUkwgc2VhcmNoIHBhcmFtc1xyXG4gIGNvbnN0IHsgZGF0YSwgaXNMb2FkaW5nLCBpc0ZldGNoaW5nLCBpc0Vycm9yLCByZWZldGNoIH0gPSB1c2VRdWVyeShjYXRhbG9nUXVlcnkoc2VhcmNoUGFyYW1zKSlcclxuXHJcbiAgLy8gUmVhbC10aW1lIFNvY2tldC5JTyBzdWJzY3JpcHRpb25cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdW5zdWJzY3JpYmUgPSBzdWJzY3JpYmVUb05mdFVwZGF0ZXMoKGV2ZW50OiBORlRVcGRhdGVkRXZlbnQpID0+IHtcclxuICAgICAgY29uc29sZS5sb2coJ1tIb21lIFJlYWx0aW1lXSBORlQgdXBkYXRlZCB2aWEgc29ja2V0OicsIGV2ZW50KVxyXG4gICAgICBxdWVyeUNsaWVudC5zZXRRdWVyaWVzRGF0YTxORlRMaXN0UmVzcG9uc2U+KHsgcXVlcnlLZXk6IFsnbmZ0cyddIH0sIChvbGQpID0+IHtcclxuICAgICAgICBpZiAoIW9sZCkgcmV0dXJuIG9sZFxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAuLi5vbGQsXHJcbiAgICAgICAgICBpdGVtczogb2xkLml0ZW1zLm1hcCgoaXRlbSkgPT5cclxuICAgICAgICAgICAgaXRlbS5pZCA9PT0gZXZlbnQucmVzb3VyY2VJZFxyXG4gICAgICAgICAgICAgID8ge1xyXG4gICAgICAgICAgICAgICAgICAuLi5pdGVtLFxyXG4gICAgICAgICAgICAgICAgICBwcmljZUV0aDogZXZlbnQucHJpY2VFdGgsXHJcbiAgICAgICAgICAgICAgICAgIGF2YWlsYWJsZVF1YW50aXR5OiBldmVudC5hdmFpbGFibGVRdWFudGl0eSxcclxuICAgICAgICAgICAgICAgICAgdmVyc2lvbjogZXZlbnQudmVyc2lvbixcclxuXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgOiBpdGVtXHJcbiAgICAgICAgICApLFxyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuICAgIH0pXHJcblxyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgdW5zdWJzY3JpYmUoKVxyXG4gICAgfVxyXG4gIH0sIFtxdWVyeUNsaWVudF0pXHJcblxyXG4gIGNvbnN0IHsgZmF2b3JpdGVJZHMsIHRvZ2dsZUZhdm9yaXRlLCBpc1VwZGF0aW5nIH0gPSB1c2VGYXZvcml0ZXMoKVxyXG4gIGNvbnN0IGhhbmRsZVRvZ2dsZUZhdm9yaXRlID0gKGlkOiBzdHJpbmcpID0+IHtcclxuICAgIGNvbnN0IG5mdCA9IGRhdGE/Lml0ZW1zLmZpbmQoaXRlbSA9PiBpdGVtLmlkID09PSBpZClcclxuICAgIGlmIChuZnQpIHRvZ2dsZUZhdm9yaXRlKG5mdClcclxuICB9XHJcblxyXG4gIC8vIFJlYWwgQWRkIHRvIENhcnQgTXV0YXRpb25cclxuICBjb25zdCBhZGRUb0NhcnRNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcclxuICAgIG11dGF0aW9uRm46IGFzeW5jIChuZnQ6IE5GVCkgPT4ge1xyXG4gICAgICBhd2FpdCBhcGkucG9zdCgnL2NhcnQvaXRlbXMnLCB7XHJcbiAgICAgICAgbmZ0SWQ6IG5mdC5pZCxcclxuICAgICAgICBxdWFudGl0eTogMSxcclxuICAgICAgICBlZGl0aW9uOiBuZnQuZWRpdGlvbiB8fCAnMS81MCcsXHJcbiAgICAgIH0pXHJcbiAgICB9LFxyXG4gICAgb25TdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFsnY2FydCddIH0pXHJcbiAgICB9LFxyXG4gIH0pXHJcblxyXG4gIGNvbnN0IGhhbmRsZUFkZFRvQ2FydCA9IChuZnQ6IE5GVCkgPT4ge1xyXG4gICAgYWRkVG9DYXJ0TXV0YXRpb24ubXV0YXRlKG5mdClcclxuICB9XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNsZWFyRmlsdGVycyA9ICgpID0+IHtcclxuICAgIHVwZGF0ZUZpbHRlcnMoe1xyXG4gICAgICBjb2xsZWN0aW9uOiB1bmRlZmluZWQsXHJcbiAgICAgIG5ldHdvcms6IHVuZGVmaW5lZCxcclxuICAgICAgbWluUHJpY2U6IHVuZGVmaW5lZCxcclxuICAgICAgbWF4UHJpY2U6IHVuZGVmaW5lZCxcclxuICAgICAgc2VhcmNoOiB1bmRlZmluZWQsXHJcbiAgICB9KVxyXG4gICAgc2V0U2VhcmNoSW5wdXQoJycpXHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJob21lLXBhZ2UgYmctWyMxNDBEMEFdIHRleHQtWyNGNUYxRUJdXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9iaWxlLXNlYXJjaFwiPjxmb3JtIG9uU3VibWl0PXtlID0+IHsgZS5wcmV2ZW50RGVmYXVsdCgpOyB1cGRhdGVGaWx0ZXJzKHsgc2VhcmNoOiBzZWFyY2hJbnB1dCB9KSB9fT48U2VhcmNoIHNpemU9ezIxfSAvPjxpbnB1dCBhcmlhLWxhYmVsPVwiQnVzY2FyIGNvbGXDp8O1ZXNcIiBwbGFjZWhvbGRlcj1cIkV4cGxvcmFyIGNvbGXDp8O1ZXNcIiB2YWx1ZT17c2VhcmNoSW5wdXR9IG9uQ2hhbmdlPXtlID0+IHNldFNlYXJjaElucHV0KGUudGFyZ2V0LnZhbHVlKX0gLz48L2Zvcm0+PGJ1dHRvbiBkaXNhYmxlZD17aXNMb2FkaW5nfSBhcmlhLWxhYmVsPVwiRmlsdHJvcyBkbyBjYXTDoWxvZ29cIiBhcmlhLWV4cGFuZGVkPXtmaWx0ZXJzT3Blbn0gb25DbGljaz17KCkgPT4gc2V0RmlsdGVyc09wZW4oIWZpbHRlcnNPcGVuKX0+PFNsaWRlcnNIb3Jpem9udGFsIHNpemU9ezIyfSAvPjwvYnV0dG9uPjwvZGl2PlxyXG4gICAgICB7LyogSGVybyBTZWN0aW9uICovfVxyXG4gICAgICA8SGVybyAvPlxyXG5cclxuICAgICAge2FkZFRvQ2FydE11dGF0aW9uLmlzRXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwicGFnZS13aWR0aCB0ZXh0LVsjRjA4MDVGXVwiIHJvbGU9XCJhbGVydFwiPk7Do28gZm9pIHBvc3PDrXZlbCBhZGljaW9uYXIgbyBORlQuIENvbmZpcmEgbyBlc3RvcXVlIGUgdGVudGUgbm92YW1lbnRlLjwvcD59XHJcbiAgICAgIHsvKiBDYXRhbG9nICYgRmlsdGVyIFNlY3Rpb24gKi99XHJcbiAgICAgIDxzZWN0aW9uIGlkPVwiY2F0YWxvZ29cIiBhcmlhLWJ1c3k9e2lzRmV0Y2hpbmd9IGNsYXNzTmFtZT1cImNhdGFsb2ctc2VjdGlvbiBteC1hdXRvIG1heC13LVsxMjQwcHhdIHB4LTQgcHktMTYgbWQ6cHgtOFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMTAgbWQ6ZmxleC1yb3dcIj5cclxuICAgICAgICAgIHsvKiBMZWZ0IENvbHVtbjogRmlsdGVycyAqL31cclxuICAgICAgICAgIHsoIW1vYmlsZSB8fCBmaWx0ZXJzT3BlbikgJiYgPFN1c3BlbnNlIGZhbGxiYWNrPXs8YXNpZGUgY2xhc3NOYW1lPVwiY2F0YWxvZy1maWx0ZXJzXCIgYXJpYS1sYWJlbD1cIkNhcnJlZ2FuZG8gZmlsdHJvc1wiIGFyaWEtYnVzeT1cInRydWVcIj48ZGl2IGNsYXNzTmFtZT1cImZpbHRlci1wYW5lbCBza2VsZXRvbi1zaGltbWVyIGgtWzcyMHB4XVwiIC8+PC9hc2lkZT59PjxTaWRlYmFyRmlsdGVyc1xyXG4gICAgICAgICAgICBtb2JpbGVPcGVuPXtmaWx0ZXJzT3Blbn1cclxuICAgICAgICAgICAgb25Nb2JpbGVPcGVuQ2hhbmdlPXtzZXRGaWx0ZXJzT3Blbn1cclxuICAgICAgICAgICAgY29sbGVjdGlvbnM9e2RhdGE/LmNvbGxlY3Rpb25zIHx8IFtdfVxyXG4gICAgICAgICAgICBuZXR3b3Jrcz17ZGF0YT8ubmV0d29ya3MgfHwgW119XHJcbiAgICAgICAgICAgIHNlbGVjdGVkQ29sbGVjdGlvbj17Y29sbGVjdGlvbn1cclxuICAgICAgICAgICAgc2VsZWN0ZWROZXR3b3JrPXtuZXR3b3JrfVxyXG4gICAgICAgICAgICBtaW5QcmljZT17bWluUHJpY2V9XHJcbiAgICAgICAgICAgIG1heFByaWNlPXttYXhQcmljZX1cclxuICAgICAgICAgICAgb25TZWxlY3RDb2xsZWN0aW9uPXsoY29sKSA9PiB1cGRhdGVGaWx0ZXJzKHsgY29sbGVjdGlvbjogY29sIH0pfVxyXG4gICAgICAgICAgICBvblNlbGVjdE5ldHdvcms9eyhuZXQpID0+IHVwZGF0ZUZpbHRlcnMoeyBuZXR3b3JrOiBuZXQgfSl9XHJcbiAgICAgICAgICAgIG9uUHJpY2VDaGFuZ2U9eyhtaW4sIG1heCkgPT4gdXBkYXRlRmlsdGVycyh7IG1pblByaWNlOiBtaW4sIG1heFByaWNlOiBtYXggfSl9XHJcbiAgICAgICAgICAgIG9uQ2xlYXJGaWx0ZXJzPXtoYW5kbGVDbGVhckZpbHRlcnN9XHJcbiAgICAgICAgICAgIHNlbGVjdGVkU29ydD17c29ydH1cclxuICAgICAgICAgICAgb25Tb3J0Q2hhbmdlPXt2YWx1ZSA9PiB1cGRhdGVGaWx0ZXJzKHsgc29ydDogdmFsdWUgfSl9XHJcbiAgICAgICAgICAvPjwvU3VzcGVuc2U+fVxyXG5cclxuICAgICAgICAgIHsvKiBSaWdodCBDb2x1bW46IENhdGFsb2cgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhdGFsb2ctY29udGVudCBmbGV4IGZsZXgtMSBmbGV4LWNvbCBnYXAtOFwiPlxyXG4gICAgICAgICAgICB7LyogVG9vbGJhcjogU2VhcmNoLCBUYWJzICYgU29ydCAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXRhbG9nLXRvb2xiYXIgZmxleCBmbGV4LWNvbCBnYXAtNCBib3JkZXItYiBib3JkZXItWyMzRjIzMTldIHBiLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhdGFsb2ctc2VhcmNoIHJlbGF0aXZlIHctZnVsbCBzbTptYXgtdy1tZFwiPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkJ1c2NhciBORlRzXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJCdXNjYXIgcG9yIG5vbWUsIGVkacOnw6NvLCBjb2xlw6fDo28uLi5cIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2VhcmNoSW5wdXR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoSW5wdXQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICBvbktleURvd249eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGUua2V5ID09PSAnRW50ZXInKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGaWx0ZXJzKHsgc2VhcmNoOiBzZWFyY2hJbnB1dCB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgb25CbHVyPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHNlYXJjaElucHV0ICE9PSBzZWFyY2gpIHtcclxuICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZpbHRlcnMoeyBzZWFyY2g6IHNlYXJjaElucHV0IH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLVsjM0YyMzE5XSBiZy1bIzI0MTYxMl0gcHktMiBwbC05IHByLTMgZm9udC1tb25vIHRleHQteHMgdGV4dC1bI0Y1RjFFQl0gcGxhY2Vob2xkZXI6dGV4dC1bI0NGQjI4Q10vNjAgZm9jdXM6Ym9yZGVyLVsjRDI4QTRDXSBmb2N1czpvdXRsaW5lLW5vbmVcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxTZWFyY2ggY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtbm9uZSBhYnNvbHV0ZSBsZWZ0LTMgdG9wLTIuNSBoLTQgdy00IHRleHQtWyNDRkIyOENdXCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICB7LyogQ2F0ZWdvcnkgVGFicyAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2F0YWxvZy10YWJzIGZsZXggaXRlbXMtY2VudGVyIGdhcC02IGZvbnQtbW9ubyB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB1cGRhdGVGaWx0ZXJzKHsgdGFiOiAnYWxsJyB9KX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwYi0yIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyICR7XHJcbiAgICAgICAgICAgICAgICAgICAgICB0YWIgPT09ICdhbGwnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci1iLTIgYm9yZGVyLVsjRDI4QTRDXSBmb250LWJvbGQgdGV4dC1bI0U4OUI1NV0nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtWyNGNUYxRUJdIGhvdmVyOnRleHQtWyNFODlCNTVdJ1xyXG4gICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgVG9kb3Mgb3MgTkZUc1xyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHVwZGF0ZUZpbHRlcnMoeyB0YWI6ICduZXcnIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHBiLTIgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgJHtcclxuICAgICAgICAgICAgICAgICAgICAgIHRhYiA9PT0gJ25ldydcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyLWItMiBib3JkZXItWyNEMjhBNENdIGZvbnQtYm9sZCB0ZXh0LVsjRTg5QjU1XSdcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1bI0Y1RjFFQl0gaG92ZXI6dGV4dC1bI0U4OUI1NV0nXHJcbiAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBOb3ZvcyBsYW7Dp2FtZW50b3NcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB1cGRhdGVGaWx0ZXJzKHsgdGFiOiAndHJlbmRpbmcnIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHBiLTIgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgJHtcclxuICAgICAgICAgICAgICAgICAgICAgIHRhYiA9PT0gJ3RyZW5kaW5nJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdib3JkZXItYi0yIGJvcmRlci1bI0QyOEE0Q10gZm9udC1ib2xkIHRleHQtWyNFODlCNTVdJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LVsjRjVGMUVCXSBob3Zlcjp0ZXh0LVsjRTg5QjU1XSdcclxuICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEVtIGFsdGFcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogU29ydCBTZWxlY3RvciAqL31cclxuICAgICAgICAgICAgICAgIHshbW9iaWxlICYmIDxkaXYgY2xhc3NOYW1lPVwiY2F0YWxvZy1zb3J0IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGZvbnQtbW9ubyB0ZXh0LXhzIHRleHQtWyNDRkIyOENdXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuPk9yZGVuYXIgcG9yOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTdXNwZW5zZSBmYWxsYmFjaz17PHNwYW4gY2xhc3NOYW1lPVwiY2F0YWxvZy1zb3J0LXRyaWdnZXJcIj5MaXN0YWRvcyByZWNlbnRlbWVudGU8L3NwYW4+fT48Rm9ybVNlbGVjdCBhcmlhLWxhYmVsPVwiT3JkZW5hciBORlRzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzb3J0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25WYWx1ZUNoYW5nZT17dmFsdWUgPT4gdXBkYXRlRmlsdGVycyh7IHNvcnQ6IHZhbHVlIGFzIEhvbWVTZWFyY2hQYXJhbXNbJ3NvcnQnXSB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNhdGFsb2ctc29ydC10cmlnZ2VyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e1t7IHZhbHVlOiAncmVjZW50JywgbGFiZWw6ICdMaXN0YWRvcyByZWNlbnRlbWVudGUnIH0sIHsgdmFsdWU6ICdwcmljZV9hc2MnLCBsYWJlbDogJ01lbm9yIHByZcOnbycgfSwgeyB2YWx1ZTogJ3ByaWNlX2Rlc2MnLCBsYWJlbDogJ01haW9yIHByZcOnbycgfV19XHJcbiAgICAgICAgICAgICAgICAgICAgLz48L1N1c3BlbnNlPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2Pn1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogQ29udGVudCBBcmVhICovfVxyXG4gICAgICAgICAgICB7aXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibmZ0LWdyaWQgZ3JpZCBncmlkLWNvbHMtMSBnYXAtNiBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtM1wiIHJvbGU9XCJzdGF0dXNcIiBhcmlhLWxhYmVsPVwiQ2FycmVnYW5kbyBjYXTDoWxvZ29cIj5cclxuICAgICAgICAgICAgICAgIHtBcnJheS5mcm9tKHsgbGVuZ3RoOiA5IH0pLm1hcCgoXywgaSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8TkZUU2tlbGV0b24ga2V5PXtpfSAvPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICkgOiBpc0Vycm9yID8gKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLVsjM0YyMzE5XSBiZy1bIzI0MTYxMl0gcC0xMiB0ZXh0LWNlbnRlciBmb250LW1vbm9cIj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1bI0U4OUI1NV1cIj5cclxuICAgICAgICAgICAgICAgICAgRmFsaGEgYW8gY2FycmVnYXIgbyBjYXTDoWxvZ28gZGUgTkZUcy5cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LVsjQ0ZCMjhDXVwiPlxyXG4gICAgICAgICAgICAgICAgICBPY29ycmV1IHVtIGVycm8gbmEgcmVxdWlzacOnw6NvIGNvbSBvIG1vY2sgZGEgQVBJLlxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcmVmZXRjaCgpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC00IHJvdW5kZWQgYmctWyNEMjhBNENdIHB4LTUgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LVsjMTQwRDBBXSBob3ZlcjpiZy1bI0U4OUI1NV0gY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBUZW50YXIgbm92YW1lbnRlXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSA6IGRhdGE/Lml0ZW1zLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1bIzNGMjMxOV0gYmctWyMyNDE2MTJdIHAtMTIgdGV4dC1jZW50ZXIgZm9udC1tb25vXCI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtWyNFODlCNTVdXCI+XHJcbiAgICAgICAgICAgICAgICAgIE5lbmh1bSBORlQgZW5jb250cmFkbyBjb20gb3MgZmlsdHJvcyBzZWxlY2lvbmFkb3MuXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgdGV4dC1bI0NGQjI4Q11cIj5cclxuICAgICAgICAgICAgICAgICAgVGVudGUgYWx0ZXJhciBvcyB0ZXJtb3MgZGEgYnVzY2Egb3UgbGltcGFyIG9zIGZpbHRyb3MuXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDbGVhckZpbHRlcnN9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTQgcm91bmRlZCBiZy1bI0QyOEE0Q10gcHgtNSBweS0yIHRleHQteHMgZm9udC1ib2xkIHRleHQtWyMxNDBEMEFdIGhvdmVyOmJnLVsjRTg5QjU1XSBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIExpbXBhciBmaWx0cm9zXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5mdC1ncmlkIGdyaWQgZ3JpZC1jb2xzLTEgZ2FwLTYgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMganVzdGlmeS1pdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIHtkYXRhPy5pdGVtcy5tYXAoKG5mdCwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgPE5GVENhcmRcclxuICAgICAgICAgICAgICAgICAgICBrZXk9e25mdC5pZH1cclxuICAgICAgICAgICAgICAgICAgICBuZnQ9e25mdH1cclxuICAgICAgICAgICAgICAgICAgICBlYWdlcj17aW5kZXggPCAyfVxyXG4gICAgICAgICAgICAgICAgICAgIGlzRmF2b3JpdGU9e2Zhdm9yaXRlSWRzLmluY2x1ZGVzKG5mdC5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgaXNGYXZvcml0ZVBlbmRpbmc9e2lzVXBkYXRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgb25Ub2dnbGVGYXZvcml0ZT17aGFuZGxlVG9nZ2xlRmF2b3JpdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25BZGRUb0NhcnQ9e2hhbmRsZUFkZFRvQ2FydH1cclxuICAgICAgICAgICAgICAgICAgICBvblNlbGVjdD17KGlkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBuYXZpZ2F0ZSh7IHRvOiAnL25mdHMvJGlkJywgcGFyYW1zOiB7IGlkIH0gfSlcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG5cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgey8qIFBhZ2luYXRpb24gQ29udHJvbHMgKi99XHJcbiAgICAgICAgICAgIHtkYXRhICYmIGRhdGEudG90YWxQYWdlcyA+IDEgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2F0YWxvZy1wYWdpbmF0aW9uIG10LTggZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIHtBcnJheS5mcm9tKHsgbGVuZ3RoOiBkYXRhLnRvdGFsUGFnZXMgfSkubWFwKChfLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCBwYWdlTnVtID0gaW5kZXggKyAxXHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGlzQWN0aXZlID0gcGFnZSA9PT0gcGFnZU51bVxyXG4gICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIGtleT17cGFnZU51bX1cclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdXBkYXRlRmlsdGVycyh7IHBhZ2U6IHBhZ2VOdW0gfSwgZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBoLTkgdy05IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkIGJvcmRlciBmb250LW1vbm8gdGV4dC1zbSBmb250LWJvbGQgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaXNBY3RpdmVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdib3JkZXItWyNEMjhBNENdIGJnLVsjRDI4QTRDXSB0ZXh0LVsjMTQwRDBBXSdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXItWyMzRjIzMTldIGJnLVsjMjQxNjEyXSB0ZXh0LVsjRjVGMUVCXSBob3Zlcjpib3JkZXItWyNEMjhBNENdJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3BhZ2VOdW19XHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuXHJcbiAgICAgIHsvKiBQcm9tb3MgU2VjdGlvbiAoTWF0Y2hpbmcgRmlnbWEgZnJhbWUgNzAzNTM6MjQxKSAqL31cclxuICAgICAgPHNlY3Rpb24gaWQ9XCJwcm9tb3NcIiBjbGFzc05hbWU9XCJteC1hdXRvIG1heC13LVsxMjQwcHhdIHB4LTQgcHktOCBtZDpweC04XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGdhcC04IG1kOmdyaWQtY29scy0yXCI+XHJcbiAgICAgICAgICB7LyogUHJvbW8gMSAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbC1yZXZlcnNlIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTYgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1bIzNGMjMxOV0gYmctWyMyNDE2MTJdIHAtOCBzbTpmbGV4LXJvd1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC0xIGZsZXgtY29sIGdhcC0zIGZvbnQtbW9ub1wiPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LVsjRjVGMUVCXVwiPlxyXG4gICAgICAgICAgICAgICAgTGFuw6dhbWVudG9zIGfDqm5lc2lzIGRlIGVkacOnw6NvIGxpbWl0YWRhXHJcbiAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGxlYWRpbmctcmVsYXhlZCB0ZXh0LVsjQ0ZCMjhDXVwiPlxyXG4gICAgICAgICAgICAgICAgQ29sZWNpb25lIGVkacOnw7VlcyBlc2Nhc3NhcyBkaXJldGFtZW50ZSBkb3MgY3JpYWRvcmVzIGFudGVzIGRhIHJldmVsYcOnw6NvIHDDumJsaWNhLlxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8YVxyXG4gICAgICAgICAgICAgICAgaHJlZj1cIiNjYXRhbG9nb1wiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0yIGlubGluZS1mbGV4IHctZml0IGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkIGJnLVsjRDI4QTRDXSBweC01IHB5LTIgdGV4dC14cyBmb250LWJvbGQgdGV4dC1bIzE0MEQwQV0gdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6YmctWyNFODlCNTVdXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBFeHBsb3JhciA8QXJyb3dSaWdodCBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XHJcbiAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTQ0IHctNDQgc2hyaW5rLTAgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1bIzNGMjMxOV1cIj5cclxuICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICBzcmM9XCIvYXNzZXRzL2ltYWdlcy9wcm9tby1nZW5lc2lzLndlYnBcIlxyXG4gICAgICAgICAgICAgICAgYWx0PVwiUHJvbW8gR2VuZXNpc1wiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLWZ1bGwgdy1mdWxsIG9iamVjdC1jb3ZlclwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogUHJvbW8gMiAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbC1yZXZlcnNlIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTYgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1bIzNGMjMxOV0gYmctWyMyNDE2MTJdIHAtOCBzbTpmbGV4LXJvd1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC0xIGZsZXgtY29sIGdhcC0zIGZvbnQtbW9ub1wiPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LVsjRjVGMUVCXVwiPlxyXG4gICAgICAgICAgICAgICAgQXJ0ZSBkaWdpdGFsIHNlbGVjaW9uYWRhIGUgbXVpdG8gbWFpc1xyXG4gICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1bI0NGQjI4Q11cIj5cclxuICAgICAgICAgICAgICAgIEV4cGxvcmUgbm92b3MgYXJ0aXN0YXMsIGNvbGXDp8O1ZXMgdmVyaWZpY2FkYXMgZSBvYnJhcyBkaWdpdGFpcyBxdWUgZGVmaW5lbSBhIGN1bHR1cmEuXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICBocmVmPVwiI2NhdGFsb2dvXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTIgaW5saW5lLWZsZXggdy1maXQgaXRlbXMtY2VudGVyIGdhcC0yIHJvdW5kZWQgYmctWyNEMjhBNENdIHB4LTUgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LVsjMTQwRDBBXSB0cmFuc2l0aW9uLWNvbG9ycyBob3ZlcjpiZy1bI0U4OUI1NV1cIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIEV4cGxvcmFyIDxBcnJvd1JpZ2h0IGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz5cclxuICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtNDQgdy00NCBzaHJpbmstMCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLVsjM0YyMzE5XVwiPlxyXG4gICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgIHNyYz1cIi9hc3NldHMvaW1hZ2VzL3Byb21vLWN1cmF0ZWQud2VicFwiXHJcbiAgICAgICAgICAgICAgICBhbHQ9XCJQcm9tbyBDdXJhdGVkXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtZnVsbCB3LWZ1bGwgb2JqZWN0LWNvdmVyXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgICB7LyogRWR1Y2F0aW9uYWwgLyBCbG9nIFNlY3Rpb24gKE1hdGNoaW5nIEZpZ21hIGZyYW1lIDcwMzUzOjI4OCkgKi99XHJcbiAgICAgIDxzZWN0aW9uIGlkPVwiYmxvZ1wiIGNsYXNzTmFtZT1cIm14LWF1dG8gbWF4LXctWzEyNDBweF0gcHgtNCBweS0xNiBtZDpweC04IGZvbnQtbW9ub1wiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMlwiPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtWyNEMjhBNENdXCI+XHJcbiAgICAgICAgICAgIERpw6FyaW8gZGEgQ3VuaGFnZW1cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1bI0Y1RjFFQl1cIj5cclxuICAgICAgICAgICAgSGlzdMOzcmlhcywgZ3VpYXMgZSBpbnNpZ2h0cyBwYXJhIGNvbGVjaW9uYWRvcmVzIHNvYnJlIG8gdW5pdmVyc28gZGEgcHJvcHJpZWRhZGUgZGlnaXRhbC5cclxuICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtOCBncmlkIGdyaWQtY29scy0xIGdhcC02IHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00XCI+XHJcbiAgICAgICAgICB7W1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgdGl0bGU6ICdDb21vIGZ1bmNpb25hIGEgcHJvcHJpZWRhZGUgZGUgTkZUcycsXHJcbiAgICAgICAgICAgICAgY2F0ZWdvcnk6ICcxMiBkZSBzZXRlbWJybyB8IExlaXR1cmEgZGUgNiBtaW4nLFxyXG4gICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiAnQXByZW5kYSBhIGNvbGVjaW9uYXIsIG5lZ29jaWFyIGUgdmVyaWZpY2FyIGF0aXZvcyBkaWdpdGFpcy4nLFxyXG4gICAgICAgICAgICAgIGltYWdlOiAnL2Fzc2V0cy9pbWFnZXMvYmxvZy0xLndlYnAnLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgdGl0bGU6ICcxMCBhcnRpc3RhcyBkaWdpdGFpcyBwYXJhIGFjb21wYW5oYXInLFxyXG4gICAgICAgICAgICAgIGNhdGVnb3J5OiAnMTMgZGUgc2V0ZW1icm8gfCBMZWl0dXJhIGRlIDIgbWluJyxcclxuICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogJ0Nvbmhlw6dhIGNyaWFkb3JlcyBxdWUgbW9sZGFtIGEgY3VsdHVyYSBkaWdpdGFsLicsXHJcbiAgICAgICAgICAgICAgaW1hZ2U6ICcvYXNzZXRzL2ltYWdlcy9ibG9nLTIud2VicCcsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICB0aXRsZTogJ1JhcmlkYWRlLCBhdHJpYnV0b3MgZSBwcm9jZWTDqm5jaWEnLFxyXG4gICAgICAgICAgICAgIGNhdGVnb3J5OiAnMTUgZGUgc2V0ZW1icm8gfCBMZWl0dXJhIGRlIDMgbWluJyxcclxuICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogJ0VudGVuZGEgcmFyaWRhZGUsIHByb2NlZMOqbmNpYSwgZGlyZWl0b3MgYXV0b3JhaXMgZSB1dGlsaWRhZGUuJyxcclxuICAgICAgICAgICAgICBpbWFnZTogJy9hc3NldHMvaW1hZ2VzL2Jsb2ctMy53ZWJwJyxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIHRpdGxlOiAnQ29tbyBwcm90ZWdlciBzdWEgY2FydGVpcmEnLFxyXG4gICAgICAgICAgICAgIGNhdGVnb3J5OiAnMTUgZGUgc2V0ZW1icm8gfCBMZWl0dXJhIGRlIDIgbWluJyxcclxuICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogJ1Byb3RlamEgc3VhIGNhcnRlaXJhLCBzZXVzIGF0aXZvcyBlIHN1YSBpZGVudGlkYWRlLicsXHJcbiAgICAgICAgICAgICAgaW1hZ2U6ICcvYXNzZXRzL2ltYWdlcy9ibG9nLTQud2VicCcsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICBdLm1hcCgocG9zdCwgaWR4KSA9PiAoXHJcbiAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICBrZXk9e2lkeH1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLVsjM0YyMzE5XSBiZy1bIzI0MTYxMl0gdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6Ym9yZGVyLVsjRDI4QTRDXVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFzcGVjdC12aWRlbyB3LWZ1bGwgb3ZlcmZsb3ctaGlkZGVuIGJnLVsjMTQwRDBBXVwiPlxyXG4gICAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgICBzcmM9e3Bvc3QuaW1hZ2V9XHJcbiAgICAgICAgICAgICAgICAgIGFsdD17cG9zdC50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC1mdWxsIHctZnVsbCBvYmplY3QtY292ZXIgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwIGdyb3VwLWhvdmVyOnNjYWxlLTEwNVwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGZsZXggZmxleC1jb2wgZ2FwLTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LVsjRDI4QTRDXVwiPlxyXG4gICAgICAgICAgICAgICAgICB7cG9zdC5jYXRlZ29yeX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LVsjRjVGMUVCXSBncm91cC1ob3Zlcjp0ZXh0LVsjRTg5QjU1XSB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICB7cG9zdC50aXRsZX1cclxuICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJibG9nLWRlc2NyaXB0aW9uXCI+e3Bvc3QuZGVzY3JpcHRpb259PC9wPlxyXG4gICAgICAgICAgICAgICAgPFVuYXZhaWxhYmxlQWN0aW9uIGNsYXNzTmFtZT1cImJsb2ctcmVhZFwiIG5hbWU9e3Bvc3QudGl0bGV9PkxlciBtYWlzIOKGkjwvVW5hdmFpbGFibGVBY3Rpb24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG4iXX0=
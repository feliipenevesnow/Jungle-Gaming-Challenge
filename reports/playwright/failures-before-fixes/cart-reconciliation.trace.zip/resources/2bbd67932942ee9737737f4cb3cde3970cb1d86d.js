import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/dialog.tsx");const React = ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(__vite__cjsImport0_react, 1);const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=7abeec5e";
import * as DialogPrimitive from "/node_modules/.vite/deps/@radix-ui_react-dialog.js?v=c3b2d17a";
import { X } from "/node_modules/.vite/deps/lucide-react.js?v=c7b96d59";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/ui/dialog.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7abeec5e";
const Dialog = DialogPrimitive.Root;
const DialogTrigger = DialogPrimitive.Trigger;
const DialogPortal = DialogPrimitive.Portal;
const DialogClose = DialogPrimitive.Close;
const DialogOverlay = React.forwardRef(_c = ({ className, ...props }, ref) => /* @__PURE__ */ _jsxDEV(DialogPrimitive.Overlay, {
	ref,
	className: cn("fixed inset-0 z-50 bg-[#140D0A]/85 backdrop-blur-sm data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 15,
	columnNumber: 3
}, this));
_c2 = DialogOverlay;
DialogOverlay.displayName = DialogPrimitive.Overlay.displayName;
const DialogContent = React.forwardRef(_c3 = ({ className, children, overlayClassName, ...props }, ref) => /* @__PURE__ */ _jsxDEV(DialogPortal, { children: [/* @__PURE__ */ _jsxDEV(DialogOverlay, { className: cn(className?.includes("auth-dialog") ? "auth-overlay" : undefined, overlayClassName) }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 31,
	columnNumber: 5
}, this), /* @__PURE__ */ _jsxDEV(DialogPrimitive.Content, {
	ref,
	className: cn("fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50 grid w-[calc(100%-32px)] max-w-lg gap-4 border border-[#3F2319] bg-[#241612] p-6 shadow-2xl rounded-xl font-mono text-[#F5F1EB] box-border duration-200", className),
	...props,
	children: [children, /* @__PURE__ */ _jsxDEV(DialogPrimitive.Close, {
		className: "absolute right-4 top-4 rounded-sm p-1 text-[#CFB28C] opacity-70 transition-opacity hover:opacity-100 hover:text-[#D28A4C] focus:outline-none focus:ring-2 focus:ring-[#D28A4C]",
		children: [/* @__PURE__ */ _jsxDEV(X, { className: "h-5 w-5" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 42,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("span", {
			className: "sr-only",
			children: "Fechar"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 43,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 41,
		columnNumber: 7
	}, this)]
}, void 0, true, {
	fileName: _jsxFileName,
	lineNumber: 32,
	columnNumber: 5
}, this)] }, void 0, true, {
	fileName: _jsxFileName,
	lineNumber: 30,
	columnNumber: 3
}, this));
_c4 = DialogContent;
DialogContent.displayName = DialogPrimitive.Content.displayName;
const DialogHeader = ({ className, ...props }) => /* @__PURE__ */ _jsxDEV("div", {
	className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className),
	...props
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 54,
	columnNumber: 3
}, this);
_c5 = DialogHeader;
DialogHeader.displayName = "DialogHeader";
const DialogFooter = ({ className, ...props }) => /* @__PURE__ */ _jsxDEV("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 68,
	columnNumber: 3
}, this);
_c6 = DialogFooter;
DialogFooter.displayName = "DialogFooter";
const DialogTitle = React.forwardRef(_c7 = ({ className, ...props }, ref) => /* @__PURE__ */ _jsxDEV(DialogPrimitive.Title, {
	ref,
	className: cn("text-lg font-bold leading-none tracking-tight text-[#F5F1EB]", className),
	...props
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 82,
	columnNumber: 3
}, this));
_c8 = DialogTitle;
DialogTitle.displayName = DialogPrimitive.Title.displayName;
const DialogDescription = React.forwardRef(_c9 = ({ className, ...props }, ref) => /* @__PURE__ */ _jsxDEV(DialogPrimitive.Description, {
	ref,
	className: cn("text-sm text-[#CFB28C]", className),
	...props
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 97,
	columnNumber: 3
}, this));
_c10 = DialogDescription;
DialogDescription.displayName = DialogPrimitive.Description.displayName;
export { Dialog, DialogPortal, DialogOverlay, DialogClose, DialogTrigger, DialogContent, DialogHeader, DialogFooter, DialogTitle, DialogDescription };
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10;
$RefreshReg$(_c, "DialogOverlay$React.forwardRef");
$RefreshReg$(_c2, "DialogOverlay");
$RefreshReg$(_c3, "DialogContent$React.forwardRef");
$RefreshReg$(_c4, "DialogContent");
$RefreshReg$(_c5, "DialogHeader");
$RefreshReg$(_c6, "DialogFooter");
$RefreshReg$(_c7, "DialogTitle$React.forwardRef");
$RefreshReg$(_c8, "DialogTitle");
$RefreshReg$(_c9, "DialogDescription$React.forwardRef");
$RefreshReg$(_c10, "DialogDescription");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/dialog.tsx?t=1792166201444";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/ui/dialog.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/ui/dialog.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/ui/dialog.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsWUFBWSxXQUFXO0FBQ3ZCLFlBQVkscUJBQXFCO0FBQ2pDLFNBQVMsU0FBUztBQUNsQixTQUFTLFVBQVU7OztBQUVuQixNQUFNLFNBQVMsZ0JBQWdCO0FBQy9CLE1BQU0sZ0JBQWdCLGdCQUFnQjtBQUN0QyxNQUFNLGVBQWUsZ0JBQWdCO0FBQ3JDLE1BQU0sY0FBYyxnQkFBZ0I7QUFFcEMsTUFBTSxnQkFBZ0IsTUFBTSxpQkFHekIsRUFBRSxXQUFXLEdBQUcsU0FBUyxRQUMxQix3QkFBQyxnQkFBZ0IsU0FBakI7Q0FDTztDQUNMLFdBQVcsR0FDVCwrS0FDQSxTQUNGO0NBQ0EsR0FBSTtBQUNMOzs7O1FBQ0Y7O0FBQ0QsY0FBYyxjQUFjLGdCQUFnQixRQUFRO0FBRXBELE1BQU0sZ0JBQWdCLE1BQU0sa0JBR3pCLEVBQUUsV0FBVyxVQUFVLGtCQUFrQixHQUFHLFNBQVMsUUFDdEQsd0JBQUMsY0FBRCxhQUNFLHdCQUFDLGVBQUQsRUFBZSxXQUFXLEdBQUcsV0FBVyxTQUFTLGFBQWEsSUFBSSxpQkFBaUIsV0FBVyxnQkFBZ0IsRUFBSTs7OztVQUNsSCx3QkFBQyxnQkFBZ0IsU0FBakI7Q0FDTztDQUNMLFdBQVcsR0FDVCx5TkFDQSxTQUNGO0NBQ0EsR0FBSTtXQU5OLENBUUcsVUFDRCx3QkFBQyxnQkFBZ0IsT0FBakI7RUFBdUIsV0FBVTtZQUFqQyxDQUNFLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7WUFDeEIsd0JBQUMsUUFBRDtHQUFNLFdBQVU7YUFBVTtFQUFZOzs7O1VBQ2pCOzs7OztTQUNBOzs7OztRQUNiOzs7O1FBQ2Y7O0FBQ0QsY0FBYyxjQUFjLGdCQUFnQixRQUFRO0FBRXBELE1BQU0sZ0JBQWdCLEVBQ3BCLFdBQ0EsR0FBRyxZQUVILHdCQUFDLE9BQUQ7Q0FDRSxXQUFXLEdBQ1Qsc0RBQ0EsU0FDRjtDQUNBLEdBQUk7QUFDTDs7Ozs7O0FBRUgsYUFBYSxjQUFjO0FBRTNCLE1BQU0sZ0JBQWdCLEVBQ3BCLFdBQ0EsR0FBRyxZQUVILHdCQUFDLE9BQUQ7Q0FDRSxXQUFXLEdBQ1QsaUVBQ0EsU0FDRjtDQUNBLEdBQUk7QUFDTDs7Ozs7O0FBRUgsYUFBYSxjQUFjO0FBRTNCLE1BQU0sY0FBYyxNQUFNLGtCQUd2QixFQUFFLFdBQVcsR0FBRyxTQUFTLFFBQzFCLHdCQUFDLGdCQUFnQixPQUFqQjtDQUNPO0NBQ0wsV0FBVyxHQUNULGdFQUNBLFNBQ0Y7Q0FDQSxHQUFJO0FBQ0w7Ozs7UUFDRjs7QUFDRCxZQUFZLGNBQWMsZ0JBQWdCLE1BQU07QUFFaEQsTUFBTSxvQkFBb0IsTUFBTSxrQkFHN0IsRUFBRSxXQUFXLEdBQUcsU0FBUyxRQUMxQix3QkFBQyxnQkFBZ0IsYUFBakI7Q0FDTztDQUNMLFdBQVcsR0FBRywwQkFBMEIsU0FBUztDQUNqRCxHQUFJO0FBQ0w7Ozs7UUFDRjs7QUFDRCxrQkFBa0IsY0FBYyxnQkFBZ0IsWUFBWTtBQUU1RCxTQUNFLFFBQ0EsY0FDQSxlQUNBLGFBQ0EsZUFDQSxlQUNBLGNBQ0EsY0FDQSxhQUNBIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImRpYWxvZy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnXHJcbmltcG9ydCAqIGFzIERpYWxvZ1ByaW1pdGl2ZSBmcm9tICdAcmFkaXgtdWkvcmVhY3QtZGlhbG9nJ1xyXG5pbXBvcnQgeyBYIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xyXG5pbXBvcnQgeyBjbiB9IGZyb20gJ0AvbGliL3V0aWxzJ1xyXG5cclxuY29uc3QgRGlhbG9nID0gRGlhbG9nUHJpbWl0aXZlLlJvb3RcclxuY29uc3QgRGlhbG9nVHJpZ2dlciA9IERpYWxvZ1ByaW1pdGl2ZS5UcmlnZ2VyXHJcbmNvbnN0IERpYWxvZ1BvcnRhbCA9IERpYWxvZ1ByaW1pdGl2ZS5Qb3J0YWxcclxuY29uc3QgRGlhbG9nQ2xvc2UgPSBEaWFsb2dQcmltaXRpdmUuQ2xvc2VcclxuXHJcbmNvbnN0IERpYWxvZ092ZXJsYXkgPSBSZWFjdC5mb3J3YXJkUmVmPFxyXG4gIFJlYWN0LkVsZW1lbnRSZWY8dHlwZW9mIERpYWxvZ1ByaW1pdGl2ZS5PdmVybGF5PixcclxuICBSZWFjdC5Db21wb25lbnRQcm9wc1dpdGhvdXRSZWY8dHlwZW9mIERpYWxvZ1ByaW1pdGl2ZS5PdmVybGF5PlxyXG4+KCh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfSwgcmVmKSA9PiAoXHJcbiAgPERpYWxvZ1ByaW1pdGl2ZS5PdmVybGF5XHJcbiAgICByZWY9e3JlZn1cclxuICAgIGNsYXNzTmFtZT17Y24oXHJcbiAgICAgICdmaXhlZCBpbnNldC0wIHotNTAgYmctWyMxNDBEMEFdLzg1IGJhY2tkcm9wLWJsdXItc20gZGF0YS1bc3RhdGU9b3Blbl06YW5pbWF0ZS1pbiBkYXRhLVtzdGF0ZT1jbG9zZWRdOmFuaW1hdGUtb3V0IGRhdGEtW3N0YXRlPWNsb3NlZF06ZmFkZS1vdXQtMCBkYXRhLVtzdGF0ZT1vcGVuXTpmYWRlLWluLTAnLFxyXG4gICAgICBjbGFzc05hbWVcclxuICAgICl9XHJcbiAgICB7Li4ucHJvcHN9XHJcbiAgLz5cclxuKSlcclxuRGlhbG9nT3ZlcmxheS5kaXNwbGF5TmFtZSA9IERpYWxvZ1ByaW1pdGl2ZS5PdmVybGF5LmRpc3BsYXlOYW1lXHJcblxyXG5jb25zdCBEaWFsb2dDb250ZW50ID0gUmVhY3QuZm9yd2FyZFJlZjxcclxuICBSZWFjdC5FbGVtZW50UmVmPHR5cGVvZiBEaWFsb2dQcmltaXRpdmUuQ29udGVudD4sXHJcbiAgUmVhY3QuQ29tcG9uZW50UHJvcHNXaXRob3V0UmVmPHR5cGVvZiBEaWFsb2dQcmltaXRpdmUuQ29udGVudD4gJiB7IG92ZXJsYXlDbGFzc05hbWU/OiBzdHJpbmcgfVxyXG4+KCh7IGNsYXNzTmFtZSwgY2hpbGRyZW4sIG92ZXJsYXlDbGFzc05hbWUsIC4uLnByb3BzIH0sIHJlZikgPT4gKFxyXG4gIDxEaWFsb2dQb3J0YWw+XHJcbiAgICA8RGlhbG9nT3ZlcmxheSBjbGFzc05hbWU9e2NuKGNsYXNzTmFtZT8uaW5jbHVkZXMoJ2F1dGgtZGlhbG9nJykgPyAnYXV0aC1vdmVybGF5JyA6IHVuZGVmaW5lZCwgb3ZlcmxheUNsYXNzTmFtZSl9IC8+XHJcbiAgICA8RGlhbG9nUHJpbWl0aXZlLkNvbnRlbnRcclxuICAgICAgcmVmPXtyZWZ9XHJcbiAgICAgIGNsYXNzTmFtZT17Y24oXHJcbiAgICAgICAgJ2ZpeGVkIGxlZnQtMS8yIHRvcC0xLzIgLXRyYW5zbGF0ZS14LTEvMiAtdHJhbnNsYXRlLXktMS8yIHotNTAgZ3JpZCB3LVtjYWxjKDEwMCUtMzJweCldIG1heC13LWxnIGdhcC00IGJvcmRlciBib3JkZXItWyMzRjIzMTldIGJnLVsjMjQxNjEyXSBwLTYgc2hhZG93LTJ4bCByb3VuZGVkLXhsIGZvbnQtbW9ubyB0ZXh0LVsjRjVGMUVCXSBib3gtYm9yZGVyIGR1cmF0aW9uLTIwMCcsXHJcbiAgICAgICAgY2xhc3NOYW1lXHJcbiAgICAgICl9XHJcbiAgICAgIHsuLi5wcm9wc31cclxuICAgID5cclxuICAgICAge2NoaWxkcmVufVxyXG4gICAgICA8RGlhbG9nUHJpbWl0aXZlLkNsb3NlIGNsYXNzTmFtZT1cImFic29sdXRlIHJpZ2h0LTQgdG9wLTQgcm91bmRlZC1zbSBwLTEgdGV4dC1bI0NGQjI4Q10gb3BhY2l0eS03MCB0cmFuc2l0aW9uLW9wYWNpdHkgaG92ZXI6b3BhY2l0eS0xMDAgaG92ZXI6dGV4dC1bI0QyOEE0Q10gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjRDI4QTRDXVwiPlxyXG4gICAgICAgIDxYIGNsYXNzTmFtZT1cImgtNSB3LTVcIiAvPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5GZWNoYXI8L3NwYW4+XHJcbiAgICAgIDwvRGlhbG9nUHJpbWl0aXZlLkNsb3NlPlxyXG4gICAgPC9EaWFsb2dQcmltaXRpdmUuQ29udGVudD5cclxuICA8L0RpYWxvZ1BvcnRhbD5cclxuKSlcclxuRGlhbG9nQ29udGVudC5kaXNwbGF5TmFtZSA9IERpYWxvZ1ByaW1pdGl2ZS5Db250ZW50LmRpc3BsYXlOYW1lXHJcblxyXG5jb25zdCBEaWFsb2dIZWFkZXIgPSAoe1xyXG4gIGNsYXNzTmFtZSxcclxuICAuLi5wcm9wc1xyXG59OiBSZWFjdC5IVE1MQXR0cmlidXRlczxIVE1MRGl2RWxlbWVudD4pID0+IChcclxuICA8ZGl2XHJcbiAgICBjbGFzc05hbWU9e2NuKFxyXG4gICAgICAnZmxleCBmbGV4LWNvbCBzcGFjZS15LTEuNSB0ZXh0LWNlbnRlciBzbTp0ZXh0LWxlZnQnLFxyXG4gICAgICBjbGFzc05hbWVcclxuICAgICl9XHJcbiAgICB7Li4ucHJvcHN9XHJcbiAgLz5cclxuKVxyXG5EaWFsb2dIZWFkZXIuZGlzcGxheU5hbWUgPSAnRGlhbG9nSGVhZGVyJ1xyXG5cclxuY29uc3QgRGlhbG9nRm9vdGVyID0gKHtcclxuICBjbGFzc05hbWUsXHJcbiAgLi4ucHJvcHNcclxufTogUmVhY3QuSFRNTEF0dHJpYnV0ZXM8SFRNTERpdkVsZW1lbnQ+KSA9PiAoXHJcbiAgPGRpdlxyXG4gICAgY2xhc3NOYW1lPXtjbihcclxuICAgICAgJ2ZsZXggZmxleC1jb2wtcmV2ZXJzZSBzbTpmbGV4LXJvdyBzbTpqdXN0aWZ5LWVuZCBzbTpzcGFjZS14LTInLFxyXG4gICAgICBjbGFzc05hbWVcclxuICAgICl9XHJcbiAgICB7Li4ucHJvcHN9XHJcbiAgLz5cclxuKVxyXG5EaWFsb2dGb290ZXIuZGlzcGxheU5hbWUgPSAnRGlhbG9nRm9vdGVyJ1xyXG5cclxuY29uc3QgRGlhbG9nVGl0bGUgPSBSZWFjdC5mb3J3YXJkUmVmPFxyXG4gIFJlYWN0LkVsZW1lbnRSZWY8dHlwZW9mIERpYWxvZ1ByaW1pdGl2ZS5UaXRsZT4sXHJcbiAgUmVhY3QuQ29tcG9uZW50UHJvcHNXaXRob3V0UmVmPHR5cGVvZiBEaWFsb2dQcmltaXRpdmUuVGl0bGU+XHJcbj4oKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9LCByZWYpID0+IChcclxuICA8RGlhbG9nUHJpbWl0aXZlLlRpdGxlXHJcbiAgICByZWY9e3JlZn1cclxuICAgIGNsYXNzTmFtZT17Y24oXHJcbiAgICAgICd0ZXh0LWxnIGZvbnQtYm9sZCBsZWFkaW5nLW5vbmUgdHJhY2tpbmctdGlnaHQgdGV4dC1bI0Y1RjFFQl0nLFxyXG4gICAgICBjbGFzc05hbWVcclxuICAgICl9XHJcbiAgICB7Li4ucHJvcHN9XHJcbiAgLz5cclxuKSlcclxuRGlhbG9nVGl0bGUuZGlzcGxheU5hbWUgPSBEaWFsb2dQcmltaXRpdmUuVGl0bGUuZGlzcGxheU5hbWVcclxuXHJcbmNvbnN0IERpYWxvZ0Rlc2NyaXB0aW9uID0gUmVhY3QuZm9yd2FyZFJlZjxcclxuICBSZWFjdC5FbGVtZW50UmVmPHR5cGVvZiBEaWFsb2dQcmltaXRpdmUuRGVzY3JpcHRpb24+LFxyXG4gIFJlYWN0LkNvbXBvbmVudFByb3BzV2l0aG91dFJlZjx0eXBlb2YgRGlhbG9nUHJpbWl0aXZlLkRlc2NyaXB0aW9uPlxyXG4+KCh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfSwgcmVmKSA9PiAoXHJcbiAgPERpYWxvZ1ByaW1pdGl2ZS5EZXNjcmlwdGlvblxyXG4gICAgcmVmPXtyZWZ9XHJcbiAgICBjbGFzc05hbWU9e2NuKCd0ZXh0LXNtIHRleHQtWyNDRkIyOENdJywgY2xhc3NOYW1lKX1cclxuICAgIHsuLi5wcm9wc31cclxuICAvPlxyXG4pKVxyXG5EaWFsb2dEZXNjcmlwdGlvbi5kaXNwbGF5TmFtZSA9IERpYWxvZ1ByaW1pdGl2ZS5EZXNjcmlwdGlvbi5kaXNwbGF5TmFtZVxyXG5cclxuZXhwb3J0IHtcclxuICBEaWFsb2csXHJcbiAgRGlhbG9nUG9ydGFsLFxyXG4gIERpYWxvZ092ZXJsYXksXHJcbiAgRGlhbG9nQ2xvc2UsXHJcbiAgRGlhbG9nVHJpZ2dlcixcclxuICBEaWFsb2dDb250ZW50LFxyXG4gIERpYWxvZ0hlYWRlcixcclxuICBEaWFsb2dGb290ZXIsXHJcbiAgRGlhbG9nVGl0bGUsXHJcbiAgRGlhbG9nRGVzY3JpcHRpb24sXHJcbn1cclxuIl19
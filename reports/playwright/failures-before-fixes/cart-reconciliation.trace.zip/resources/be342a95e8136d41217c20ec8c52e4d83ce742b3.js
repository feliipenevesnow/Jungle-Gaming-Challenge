import { keys } from "/src/lib/query-keys.ts";
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=281272ec";
import { useActionNotice } from "/src/components/ActionNotice.tsx?t=1792166201444";
import { api } from "/src/lib/axios.ts?t=1792164562494";
import { useAuth } from "/src/lib/auth.tsx?t=1792165206673";
export function useFavorites() {
	const { user, isAuthenticated, openAuthModal } = useAuth();
	const client = useQueryClient();
	const showNotice = useActionNotice();
	const key = keys.favorites(user?.id);
	const query = useQuery({
		queryKey: key,
		queryFn: async ({ signal }) => (await api.get("/favorites", { signal })).data,
		enabled: isAuthenticated
	});
	const items = isAuthenticated ? query.data ?? [] : [];
	const mutation = useMutation({
		mutationFn: async ({ nft, remove }) => {
			if (remove) await api.delete(`/favorites/${nft.id}`);
			else await api.post(`/favorites/${nft.id}`);
		},
		onMutate: async ({ nft, remove }) => {
			await client.cancelQueries({ queryKey: key });
			const previous = client.getQueryData(key) ?? [];
			client.setQueryData(key, remove ? previous.filter((item) => item.id !== nft.id) : [...previous, nft]);
			return { previous };
		},
		onError: (_error, _variables, context) => {
			if (context) client.setQueryData(key, context.previous);
			showNotice({
				title: "Não foi possível atualizar os favoritos",
				description: "A alteração foi desfeita. Tente novamente."
			});
		},
		onSettled: () => client.invalidateQueries({ queryKey: key })
	});
	function toggleFavorite(nft) {
		if (!isAuthenticated) {
			openAuthModal("login");
			return;
		}
		if (!mutation.isPending) mutation.mutate({
			nft,
			remove: items.some((item) => item.id === nft.id)
		});
	}
	return {
		...query,
		items,
		favoriteIds: items.map((item) => item.id),
		toggleFavorite,
		isUpdating: mutation.isPending
	};
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsYUFBYSxVQUFVLHNCQUFzQjtBQUN0RCxTQUFTLHVCQUF1QjtBQUNoQyxTQUFTLFdBQVc7QUFDcEIsU0FBUyxlQUFlO0FBR3hCLE9BQU8sU0FBUyxlQUFlO0NBQzdCLE1BQU0sRUFBRSxNQUFNLGlCQUFpQixrQkFBa0IsUUFBUTtDQUN6RCxNQUFNLFNBQVMsZUFBZTtDQUM5QixNQUFNLGFBQWEsZ0JBQWdCO0NBQ25DLE1BQU0sTUFBTSxLQUFLLFVBQVUsTUFBTSxFQUFFO0NBQ25DLE1BQU0sUUFBUSxTQUFTO0VBQ3JCLFVBQVU7RUFDVixTQUFTLE9BQU8sRUFBRSxjQUFjLE1BQU0sSUFBSSxJQUFXLGNBQWMsRUFBRSxPQUFPLENBQUMsRUFBQyxDQUFFO0VBQ2hGLFNBQVM7Q0FDWCxDQUFDO0NBQ0QsTUFBTSxRQUFRLGtCQUFrQixNQUFNLFFBQVEsQ0FBQyxJQUFJLENBQUM7Q0FDcEQsTUFBTSxXQUFXLFlBQVk7RUFDM0IsWUFBWSxPQUFPLEVBQUUsS0FBSyxhQUE0QztHQUNwRSxJQUFJLFFBQVEsTUFBTSxJQUFJLE9BQU8sY0FBYyxJQUFJLElBQUk7UUFDOUMsTUFBTSxJQUFJLEtBQUssY0FBYyxJQUFJLElBQUk7RUFDNUM7RUFDQSxVQUFVLE9BQU8sRUFBRSxLQUFLLGFBQWE7R0FDbkMsTUFBTSxPQUFPLGNBQWMsRUFBRSxVQUFVLElBQUksQ0FBQztHQUM1QyxNQUFNLFdBQVcsT0FBTyxhQUFvQixHQUFHLEtBQUssQ0FBQztHQUNyRCxPQUFPLGFBQW9CLEtBQUssU0FBUyxTQUFTLFFBQU8sU0FBUSxLQUFLLE9BQU8sSUFBSSxFQUFFLElBQUksQ0FBQyxHQUFHLFVBQVUsR0FBRyxDQUFDO0dBQ3pHLE9BQU8sRUFBRSxTQUFTO0VBQ3BCO0VBQ0EsVUFBVSxRQUFRLFlBQVksWUFBWTtHQUN4QyxJQUFJLFNBQVMsT0FBTyxhQUFhLEtBQUssUUFBUSxRQUFRO0dBQ3RELFdBQVc7SUFBRSxPQUFPO0lBQTJDLGFBQWE7R0FBNkMsQ0FBQztFQUM1SDtFQUNBLGlCQUFpQixPQUFPLGtCQUFrQixFQUFFLFVBQVUsSUFBSSxDQUFDO0NBQzdELENBQUM7Q0FDRCxTQUFTLGVBQWUsS0FBVTtFQUNoQyxJQUFJLENBQUMsaUJBQWlCO0dBQUUsY0FBYyxPQUFPO0dBQUc7RUFBTztFQUN2RCxJQUFJLENBQUMsU0FBUyxXQUFXLFNBQVMsT0FBTztHQUFFO0dBQUssUUFBUSxNQUFNLE1BQUssU0FBUSxLQUFLLE9BQU8sSUFBSSxFQUFFO0VBQUUsQ0FBQztDQUNsRztDQUNBLE9BQU87RUFBRSxHQUFHO0VBQU87RUFBTyxhQUFhLE1BQU0sS0FBSSxTQUFRLEtBQUssRUFBRTtFQUFHO0VBQWdCLFlBQVksU0FBUztDQUFVO0FBQ3BIIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImZhdm9yaXRlcy50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBrZXlzIH0gZnJvbSAnQC9saWIvcXVlcnkta2V5cydcclxuaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5LCB1c2VRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcclxuaW1wb3J0IHsgdXNlQWN0aW9uTm90aWNlIH0gZnJvbSAnQC9jb21wb25lbnRzL0FjdGlvbk5vdGljZSdcclxuaW1wb3J0IHsgYXBpIH0gZnJvbSAnQC9saWIvYXhpb3MnXHJcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICdAL2xpYi9hdXRoJ1xyXG5pbXBvcnQgdHlwZSB7IE5GVCB9IGZyb20gJ0AvdHlwZXMvYXBpJ1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHVzZUZhdm9yaXRlcygpIHtcclxuICBjb25zdCB7IHVzZXIsIGlzQXV0aGVudGljYXRlZCwgb3BlbkF1dGhNb2RhbCB9ID0gdXNlQXV0aCgpXHJcbiAgY29uc3QgY2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKVxyXG4gIGNvbnN0IHNob3dOb3RpY2UgPSB1c2VBY3Rpb25Ob3RpY2UoKVxyXG4gIGNvbnN0IGtleSA9IGtleXMuZmF2b3JpdGVzKHVzZXI/LmlkKVxyXG4gIGNvbnN0IHF1ZXJ5ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IGtleSxcclxuICAgIHF1ZXJ5Rm46IGFzeW5jICh7IHNpZ25hbCB9KSA9PiAoYXdhaXQgYXBpLmdldDxORlRbXT4oJy9mYXZvcml0ZXMnLCB7IHNpZ25hbCB9KSkuZGF0YSxcclxuICAgIGVuYWJsZWQ6IGlzQXV0aGVudGljYXRlZCxcclxuICB9KVxyXG4gIGNvbnN0IGl0ZW1zID0gaXNBdXRoZW50aWNhdGVkID8gcXVlcnkuZGF0YSA/PyBbXSA6IFtdXHJcbiAgY29uc3QgbXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiBhc3luYyAoeyBuZnQsIHJlbW92ZSB9OiB7IG5mdDogTkZUOyByZW1vdmU6IGJvb2xlYW4gfSkgPT4ge1xyXG4gICAgICBpZiAocmVtb3ZlKSBhd2FpdCBhcGkuZGVsZXRlKGAvZmF2b3JpdGVzLyR7bmZ0LmlkfWApXHJcbiAgICAgIGVsc2UgYXdhaXQgYXBpLnBvc3QoYC9mYXZvcml0ZXMvJHtuZnQuaWR9YClcclxuICAgIH0sXHJcbiAgICBvbk11dGF0ZTogYXN5bmMgKHsgbmZ0LCByZW1vdmUgfSkgPT4ge1xyXG4gICAgICBhd2FpdCBjbGllbnQuY2FuY2VsUXVlcmllcyh7IHF1ZXJ5S2V5OiBrZXkgfSlcclxuICAgICAgY29uc3QgcHJldmlvdXMgPSBjbGllbnQuZ2V0UXVlcnlEYXRhPE5GVFtdPihrZXkpID8/IFtdXHJcbiAgICAgIGNsaWVudC5zZXRRdWVyeURhdGE8TkZUW10+KGtleSwgcmVtb3ZlID8gcHJldmlvdXMuZmlsdGVyKGl0ZW0gPT4gaXRlbS5pZCAhPT0gbmZ0LmlkKSA6IFsuLi5wcmV2aW91cywgbmZ0XSlcclxuICAgICAgcmV0dXJuIHsgcHJldmlvdXMgfVxyXG4gICAgfSxcclxuICAgIG9uRXJyb3I6IChfZXJyb3IsIF92YXJpYWJsZXMsIGNvbnRleHQpID0+IHtcclxuICAgICAgaWYgKGNvbnRleHQpIGNsaWVudC5zZXRRdWVyeURhdGEoa2V5LCBjb250ZXh0LnByZXZpb3VzKVxyXG4gICAgICBzaG93Tm90aWNlKHsgdGl0bGU6ICdOw6NvIGZvaSBwb3Nzw612ZWwgYXR1YWxpemFyIG9zIGZhdm9yaXRvcycsIGRlc2NyaXB0aW9uOiAnQSBhbHRlcmHDp8OjbyBmb2kgZGVzZmVpdGEuIFRlbnRlIG5vdmFtZW50ZS4nIH0pXHJcbiAgICB9LFxyXG4gICAgb25TZXR0bGVkOiAoKSA9PiBjbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleToga2V5IH0pLFxyXG4gIH0pXHJcbiAgZnVuY3Rpb24gdG9nZ2xlRmF2b3JpdGUobmZ0OiBORlQpIHtcclxuICAgIGlmICghaXNBdXRoZW50aWNhdGVkKSB7IG9wZW5BdXRoTW9kYWwoJ2xvZ2luJyk7IHJldHVybiB9XHJcbiAgICBpZiAoIW11dGF0aW9uLmlzUGVuZGluZykgbXV0YXRpb24ubXV0YXRlKHsgbmZ0LCByZW1vdmU6IGl0ZW1zLnNvbWUoaXRlbSA9PiBpdGVtLmlkID09PSBuZnQuaWQpIH0pXHJcbiAgfVxyXG4gIHJldHVybiB7IC4uLnF1ZXJ5LCBpdGVtcywgZmF2b3JpdGVJZHM6IGl0ZW1zLm1hcChpdGVtID0+IGl0ZW0uaWQpLCB0b2dnbGVGYXZvcml0ZSwgaXNVcGRhdGluZzogbXV0YXRpb24uaXNQZW5kaW5nIH1cclxufVxyXG4iXX0=
import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/cart.tsx?tsr-split=component");const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"]; const useMemo = __vite__cjsImport1_react["useMemo"];const _jsxDEV = __vite__cjsImport13_react_jsxDevRuntime["jsxDEV"];import { keys } from "/src/lib/query-keys.ts";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=7abeec5e";
import { Link, useNavigate } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=23b60560";
import { useQuery, useMutation, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=281272ec";
import { ChevronLeft, Plus, Minus, ShoppingBag, AlertTriangle } from "/node_modules/.vite/deps/lucide-react.js?v=c7b96d59";
import { api } from "/src/lib/axios.ts?t=1792164562494";
import { apiErrorMessage } from "/src/lib/api-error.ts";
import { useAuth } from "/src/lib/auth.tsx?t=1792165206673";
import { subscribeToNftUpdates } from "/src/lib/socket.ts?t=1792164137833";
import { Button } from "/src/components/ui/button.tsx";
import { CouponForm } from "/src/components/CouponForm.tsx?t=1792164562494";
import { SummarySkeleton } from "/src/components/SummarySkeleton.tsx";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "/src/components/ui/dialog.tsx?t=1792166201444";
var _jsxFileName = "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/routes/cart.tsx?tsr-split=component";
import __vite__cjsImport13_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7abeec5e";
var _s = $RefreshSig$();
function CartPage() {
	_s();
	const queryClient = useQueryClient();
	const navigate = useNavigate();
	const { user, isAuthenticated, openAuthModal } = useAuth();
	const [realtimeAlert, setRealtimeAlert] = useState(null);
	const [itemToRemove, setItemToRemove] = useState(null);
	// Query Cart Items
	const { data: cart, isLoading, error: cartError, refetch: refetchCart } = useQuery({
		queryKey: keys.cart(user?.id),
		queryFn: async ({ signal }) => {
			const res = await api.get("/cart", { signal });
			return res.data;
		}
	});
	const cartItems = useMemo(() => cart?.items || [], [cart]);
	const appliedCoupon = cart?.couponCode;
	// Socket.IO live update listener
	useEffect(() => {
		if (cartItems.length === 0) return;
		const unsubscribe = subscribeToNftUpdates((event) => {
			const item = cartItems.find((ci) => ci.nftId === event.resourceId);
			if (item) {
				setRealtimeAlert(`O item "${item.nft.name}" teve seu preço ou disponibilidade alterado em tempo real.`);
			}
		});
		return () => {
			unsubscribe();
		};
	}, [cartItems]);
	// Quote Query
	const { data: quote, refetch: refetchQuote, error: quoteError, isPending: isQuotePending } = useQuery({
		queryKey: keys.cartQuote(user?.id, cartItems, appliedCoupon),
		queryFn: async ({ signal }) => {
			const res = await api.post("/cart/quote", {
				items: cartItems.map((item) => ({
					nftId: item.nftId,
					quantity: item.quantity,
					edition: item.edition
				})),
				couponCode: appliedCoupon || undefined,
				network: "Ethereum"
			}, { signal });
			return res.data;
		},
		enabled: cartItems.length > 0
	});
	const adjustStockMutation = useMutation({
		mutationFn: () => api.post("/cart/adjust-stock"),
		onSuccess: () => queryClient.invalidateQueries({ queryKey: keys.cart(user?.id) })
	});
	// Mutations
	const updateQuantityMutation = useMutation({
		mutationFn: async ({ itemId, quantity }) => {
			await api.patch(`/cart/items/${itemId}`, { quantity });
		},
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: keys.cart(user?.id) });
		}
	});
	const removeItemMutation = useMutation({
		mutationFn: async (itemId) => {
			await api.delete(`/cart/items/${itemId}`);
		},
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: keys.cart(user?.id) });
		}
	});
	// Suggested NFTs (5 items matching Figma Frame 11:1278)
	const { data: suggestedData } = useQuery({
		queryKey: ["suggested-nfts"],
		queryFn: async ({ signal }) => {
			const res = await api.get("/nfts", {
				signal,
				params: { limit: 10 }
			});
			return res.data;
		}
	});
	const suggestedCards = suggestedData?.items?.filter((n) => [
		"nft-4",
		"nft-5",
		"nft-6",
		"nft-7",
		"nft-8"
	].includes(n.id)) || suggestedData?.items?.slice(0, 5) || [];
	const handleProceedToCheckout = () => {
		navigate({ to: "/checkout" });
		if (!isAuthenticated) openAuthModal("login");
	};
	if (cartError) return /* @__PURE__ */ _jsxDEV("div", {
		className: "page-width py-16",
		role: "alert",
		children: [/* @__PURE__ */ _jsxDEV("p", { children: apiErrorMessage(cartError, "Não foi possível carregar o carrinho.") }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 146,
			columnNumber: 72
		}, this), /* @__PURE__ */ _jsxDEV(Button, {
			onClick: () => refetchCart(),
			children: "Tentar novamente"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 146,
			columnNumber: 148
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 146,
		columnNumber: 25
	}, this);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "cart-page page-width font-mono pb-[380px] md:pb-12",
		children: [
			/* @__PURE__ */ _jsxDEV("h1", {
				className: "mobile-page-heading",
				children: [/* @__PURE__ */ _jsxDEV(Link, {
					to: "/",
					"aria-label": "Voltar",
					children: /* @__PURE__ */ _jsxDEV(ChevronLeft, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 149,
						columnNumber: 76
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 149,
					columnNumber: 43
				}, this), "Carrinho de NFTs"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 149,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("nav", {
				className: "mb-6 flex items-center gap-2 text-xs text-[#CFB28C]",
				children: [
					/* @__PURE__ */ _jsxDEV(Link, {
						to: "/",
						className: "hover:text-[#E89B55]",
						children: "Início"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 151,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("span", { children: "/" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 154,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("a", {
						href: "/#catalogo",
						className: "hover:text-[#E89B55]",
						children: "Mercado"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 155,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("span", { children: "/" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 158,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "text-[#F5F1EB] font-bold",
						children: "Carrinho"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 159,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 150,
				columnNumber: 7
			}, this),
			[
				updateQuantityMutation.error,
				removeItemMutation.error,
				adjustStockMutation.error,
				quoteError
			].filter(Boolean).map((error, index) => /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				className: "mb-4 text-sm text-[#F0805F]",
				children: [
					apiErrorMessage(error, "Não foi possível atualizar o carrinho."),
					" ",
					/* @__PURE__ */ _jsxDEV("button", {
						className: "underline",
						onClick: () => {
							void refetchCart();
							void refetchQuote();
						},
						children: "Tentar novamente"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 162,
						columnNumber: 277
					}, this)
				]
			}, index, true, {
				fileName: _jsxFileName,
				lineNumber: 162,
				columnNumber: 142
			}, this)),
			realtimeAlert && /* @__PURE__ */ _jsxDEV("div", {
				role: "status",
				"aria-live": "polite",
				className: "mb-6 flex items-center justify-between gap-3 rounded-lg border border-[#D28A4C] bg-[#D28A4C]/15 p-4 text-xs text-[#E89B55]",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-4 h-4 shrink-0 text-[#E89B55]" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 169,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: realtimeAlert }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 170,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 168,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(Button, {
					size: "sm",
					onClick: () => {
						refetchQuote();
						setRealtimeAlert(null);
					},
					className: "h-8 bg-[#D28A4C] hover:bg-[#E89B55] text-[#140D0A] font-bold text-xs",
					children: "Atualizar cotação"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 172,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 167,
				columnNumber: 25
			}, this),
			quote?.warnings && /* @__PURE__ */ _jsxDEV("div", {
				role: "alert",
				className: "mb-6 rounded border border-[#D28A4C] p-4 text-sm text-[#CFB28C]",
				children: [quote.warnings.map((warning) => /* @__PURE__ */ _jsxDEV("p", { children: warning }, warning, false, {
					fileName: _jsxFileName,
					lineNumber: 181,
					columnNumber: 40
				}, this)), /* @__PURE__ */ _jsxDEV(Button, {
					disabled: adjustStockMutation.isPending,
					onClick: () => adjustStockMutation.mutate(),
					className: "mt-3 bg-[#D28A4C] text-[#140D0A]",
					children: "Ajustar quantidades ao estoque"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 182,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 180,
				columnNumber: 27
			}, this),
			cartItems.length === 0 && !isLoading ? /* @__PURE__ */ _jsxDEV("div", {
				className: "rounded-2xl border border-[#3F2319] bg-[#241612] p-16 text-center",
				children: [
					/* @__PURE__ */ _jsxDEV(ShoppingBag, { className: "w-16 h-16 mx-auto text-[#3F2319] mb-4" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 185,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-xl font-bold text-[#F5F1EB]",
						children: "Seu carrinho está vazio"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 186,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mt-2 text-xs text-[#CFB28C] max-w-md mx-auto leading-relaxed",
						children: "Nenhum NFT foi adicionado ainda. Explore nossa coleção de arte digital e encontre sua próxima obra rara."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 187,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Link, {
						to: "/",
						className: "mt-6 inline-flex items-center gap-2 rounded bg-[#D28A4C] px-6 py-2.5 text-xs font-bold uppercase text-[#140D0A] hover:bg-[#E89B55]",
						children: "Explorar catálogo →"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 191,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 184,
				columnNumber: 47
			}, this) : /* @__PURE__ */ _jsxDEV("div", {
				className: "cart-layout",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "cart-table overflow-x-auto rounded-xl border border-[#3F2319] bg-[#241612]",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "cart-table-head grid grid-cols-12 gap-4 px-6 py-4 border-b border-[#3F2319] text-xs font-bold text-[#F5F1EB]",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "col-span-5",
									children: "NFTs"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 200,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "cart-unit col-span-2 text-center",
									children: "Preço"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 201,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "col-span-3 text-center",
									children: "Edições"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 202,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "col-span-2 text-right",
									children: "Total"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 203,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 199,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "cart-rows",
							children: cartItems.map((item) => /* @__PURE__ */ _jsxDEV("div", {
								className: "cart-row grid grid-cols-12 gap-4 items-center px-6 py-4 text-xs transition-colors hover:bg-[#140D0A]/30",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "cart-identity col-span-5 flex items-center gap-3",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "cart-art h-16 w-16 shrink-0 overflow-hidden rounded-md border border-[#3F2319] bg-[#140D0A]",
											children: /* @__PURE__ */ _jsxDEV("img", {
												src: item.nft.imageUrl,
												alt: item.nft.name,
												className: "h-full w-full object-cover"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 212,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 211,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "flex flex-col gap-0.5 min-w-0",
											children: [/* @__PURE__ */ _jsxDEV(Link, {
												to: "/nfts/$id",
												params: { id: item.nftId },
												className: "font-bold text-[#F5F1EB] truncate hover:text-[#E89B55]",
												children: item.nft.name
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 215,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-[11px] text-[#CFB28C]",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "cart-token",
													children: ["ID do token: ", item.nft.tokenId]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 221,
													columnNumber: 27
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "cart-mobile-edition",
													children: ["Edição: ", item.edition]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 221,
													columnNumber: 94
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 220,
												columnNumber: 25
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 214,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 210,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "cart-unit col-span-2 text-center text-[#F5F1EB] font-medium",
										children: [item.priceEth, " ETH"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 227,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "cart-stepper col-span-3 flex items-center justify-center gap-2",
										children: [
											/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => {
													if (item.quantity > 1) {
														updateQuantityMutation.mutate({
															itemId: item.id,
															quantity: item.quantity - 1
														});
													} else {
														setItemToRemove(item);
													}
												},
												"aria-label": "Diminuir quantidade",
												className: "h-6 w-6 rounded-full bg-[#D28A4C] hover:bg-[#E89B55] text-[#140D0A] flex items-center justify-center font-bold transition-transform active:scale-90 cursor-pointer",
												children: /* @__PURE__ */ _jsxDEV(Minus, { className: "w-3.5 h-3.5 stroke-[3]" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 243,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 233,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: "w-6 text-center font-bold text-sm text-[#F5F1EB]",
												children: item.quantity
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 245,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => updateQuantityMutation.mutate({
													itemId: item.id,
													quantity: item.quantity + 1
												}),
												disabled: updateQuantityMutation.isPending || item.quantity >= Math.min(item.nft.availableQuantity, item.nft.editionStock?.[item.edition] ?? 0),
												"aria-label": "Aumentar quantidade",
												className: "h-6 w-6 rounded-full bg-[#D28A4C] hover:bg-[#E89B55] text-[#140D0A] flex items-center justify-center font-bold transition-transform active:scale-90 cursor-pointer",
												children: /* @__PURE__ */ _jsxDEV(Plus, { className: "w-3.5 h-3.5 stroke-[3]" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 252,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 248,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 232,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "cart-line-total col-span-2 flex items-center justify-end",
										children: /* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-[#E89B55]",
											children: [item.subtotalEth, " ETH"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 258,
											columnNumber: 23
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 257,
										columnNumber: 21
									}, this)
								]
							}, item.id, true, {
								fileName: _jsxFileName,
								lineNumber: 208,
								columnNumber: 40
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 207,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 197,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 196,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "cart-summary flex flex-col gap-6 rounded-xl border border-[#3F2319] bg-[#241612] p-6 shadow-xl h-fit",
					children: [
						/* @__PURE__ */ _jsxDEV("h2", {
							className: "hidden md:block text-base font-bold text-[#F5F1EB] pb-3 border-b border-[#3F2319]",
							children: "Resumo da carteira"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 267,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "hidden md:block text-xs font-bold text-[#F5F1EB]",
								children: "Código promocional"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 273,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV(CouponForm, {
								code: appliedCoupon,
								invalidReason: cart?.couponError
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 274,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 272,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							"aria-busy": isLoading || isQuotePending,
							className: "cart-totals financial-summary space-y-3 pt-3 border-t border-[#3F2319] text-xs text-[#CFB28C]",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-center",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "Subtotal" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 280,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[#F5F1EB] font-medium text-sm",
										children: [quote?.subtotalEth || "0.00", " ETH"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 281,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 279,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-center",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "Desconto do lançamento" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 287,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[#CFB28C] font-medium text-sm",
										children: ["(-) ", quote?.discountEth && quote.discountEth !== "0.00" ? quote.discountEth : "00.00"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 288,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 286,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-center",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-[#F5F1EB]",
										children: "Taxa de rede"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 295,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-[10px] text-[#CFB28C]",
										children: "Taxa estimada"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 296,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 294,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[#F5F1EB] font-medium text-sm",
										children: [quote?.networkFeeEth || "0.016", " ETH"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 298,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 293,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-center pt-3 border-t border-[#3F2319] text-base font-bold text-[#F5F1EB]",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "Total" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 304,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-xl text-[#E89B55]",
										children: [quote?.totalEth || "0.00", " ETH"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 305,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 303,
									columnNumber: 15
								}, this),
								(isLoading || isQuotePending) && /* @__PURE__ */ _jsxDEV(SummarySkeleton, {}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 307,
									columnNumber: 49
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 278,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col gap-3 pt-2",
							children: [/* @__PURE__ */ _jsxDEV(Button, {
								type: "button",
								onClick: handleProceedToCheckout,
								disabled: !quote?.valid || !!quoteError || isLoading || isQuotePending,
								className: "w-full h-12 md:h-11 bg-[#D28A4C] hover:bg-[#E89B55] text-[#140D0A] font-bold text-xs uppercase tracking-wider rounded-full md:rounded-[4px] shadow-lg cursor-pointer",
								children: "Conectar e finalizar"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 312,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV(Link, {
								to: "/",
								className: "hidden md:block text-center text-xs text-[#E89B55] hover:underline transition-colors",
								children: "Continuar explorando"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 315,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 311,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 266,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 194,
				columnNumber: 18
			}, this),
			suggestedCards.length > 0 && /* @__PURE__ */ _jsxDEV("section", {
				className: "cart-related mt-20 border-t border-[#3F2319] pt-12",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mb-6",
						children: /* @__PURE__ */ _jsxDEV("h2", {
							className: "text-base font-bold text-[#E89B55]",
							children: "Colecionadores também viram"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 325,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 324,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4",
						children: suggestedCards.map((item) => /* @__PURE__ */ _jsxDEV("div", {
							onClick: () => navigate({
								to: "/nfts/$id",
								params: { id: item.id }
							}),
							className: "group flex flex-col cursor-pointer transition-transform duration-200 hover:-translate-y-1",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "aspect-square w-full overflow-hidden rounded-xl border border-[#3F2319] bg-[#241612]",
								children: /* @__PURE__ */ _jsxDEV("img", {
									src: item.imageUrl,
									alt: item.name,
									className: "h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 335,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 334,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "mt-2 flex flex-col gap-0.5",
								children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "font-bold text-xs text-[#F5F1EB] truncate group-hover:text-[#E89B55]",
									children: item.name
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 338,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs font-bold text-[#E89B55]",
									children: [item.priceEth, " ETH"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 341,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 337,
								columnNumber: 17
							}, this)]
						}, item.id, true, {
							fileName: _jsxFileName,
							lineNumber: 328,
							columnNumber: 41
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 327,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mt-8 flex items-center justify-center gap-2",
						children: [
							/* @__PURE__ */ _jsxDEV("span", { className: "h-2 w-2 rounded-full border border-[#D28A4C]" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 350,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { className: "h-2 w-2 rounded-full bg-[#D28A4C]" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 351,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { className: "h-2 w-2 rounded-full border border-[#D28A4C]" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 352,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 349,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 323,
				columnNumber: 37
			}, this),
			/* @__PURE__ */ _jsxDEV(Dialog, {
				open: !!itemToRemove,
				onOpenChange: (open) => {
					if (!open) setItemToRemove(null);
				},
				children: /* @__PURE__ */ _jsxDEV(DialogContent, {
					className: "max-w-md border border-[#3F2319] bg-[#241612] text-[#F5F1EB] font-mono",
					children: [
						/* @__PURE__ */ _jsxDEV(DialogHeader, { children: [/* @__PURE__ */ _jsxDEV(DialogTitle, {
							className: "text-lg font-bold text-[#F5F1EB]",
							children: "Remover item do carrinho?"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 362,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV(DialogDescription, {
							className: "text-xs text-[#CFB28C] leading-relaxed pt-1",
							children: "Deseja realmente remover este NFT do seu carrinho de compras?"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 365,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 361,
							columnNumber: 11
						}, this),
						itemToRemove && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3.5 p-3.5 rounded-xl border border-[#3F2319] bg-[#140D0A]/70 my-2",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "h-14 w-14 shrink-0 overflow-hidden rounded-lg border border-[#3F2319]",
								children: /* @__PURE__ */ _jsxDEV("img", {
									src: itemToRemove.nft.imageUrl,
									alt: itemToRemove.nft.name,
									className: "h-full w-full object-cover"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 372,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 371,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col min-w-0",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-sm text-[#F5F1EB] truncate",
										children: itemToRemove.nft.name
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 375,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs text-[#CFB28C]",
										children: ["Edição: ", itemToRemove.edition]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 378,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold text-[#D28A4C] mt-0.5",
										children: [itemToRemove.priceEth, " ETH"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 381,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 374,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 370,
							columnNumber: 28
						}, this),
						/* @__PURE__ */ _jsxDEV(DialogFooter, {
							className: "mt-4 flex flex-row justify-end gap-3",
							children: [/* @__PURE__ */ _jsxDEV(Button, {
								type: "button",
								variant: "outline",
								onClick: () => setItemToRemove(null),
								className: "border-[#3F2319] bg-[#140D0A] text-[#CFB28C] hover:bg-[#241612] hover:text-[#F5F1EB] text-xs h-9 px-4 cursor-pointer",
								children: "Cancelar"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 388,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(Button, {
								type: "button",
								onClick: () => {
									if (itemToRemove) {
										removeItemMutation.mutate(itemToRemove.id);
										setItemToRemove(null);
									}
								},
								className: "bg-[#D28A4C] hover:bg-[#E89B55] text-[#140D0A] font-bold text-xs h-9 px-4 cursor-pointer",
								children: "Remover item"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 391,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 387,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 360,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 357,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 147,
		columnNumber: 10
	}, this);
}
_s(CartPage, "8XQih3y/IvNFBxPQ8JbSqlgQ7so=", false, function() {
	return [
		useQueryClient,
		useNavigate,
		useAuth,
		useQuery,
		useQuery,
		useMutation,
		useMutation,
		useMutation,
		useQuery
	];
});
_c = CartPage;
export { CartPage as component };
var _c;
$RefreshReg$(_c, "CartPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/cart.tsx?t=1792166201444&tsr-split=component";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/routes/cart.tsx?tsr-split=component", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/routes/cart.tsx?tsr-split=component", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/routes/cart.tsx?tsr-split=component" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsU0FBU0EsWUFBWTtBQUNyQixTQUFTQyxVQUFVQyxXQUFXQyxlQUFlO0FBQzdDLFNBQTBCQyxNQUFNQyxtQkFBbUI7QUFDbkQsU0FBU0MsVUFBVUMsYUFBYUMsc0JBQXNCO0FBQ3RELFNBQVNDLGFBQWFDLE1BQU1DLE9BQU9DLGFBQWFDLHFCQUFxQjtBQUNyRSxTQUFTQyxXQUFXO0FBQ3BCLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLDZCQUE2QjtBQUN0QyxTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyx1QkFBdUI7QUFDaEMsU0FDRUMsUUFDQUMsZUFDQUMsbUJBQ0FDLGNBQ0FDLGNBQ0FDLG1CQUNLOzs7O0FBT1AsU0FBU0MsV0FBVzs7Q0FDbEIsTUFBTUMsY0FBY3BCLGVBQWU7Q0FDbkMsTUFBTXFCLFdBQVd4QixZQUFZO0NBQzdCLE1BQU0sRUFBRXlCLE1BQU1DLGlCQUFpQkMsa0JBQWtCaEIsUUFBUTtDQUV6RCxNQUFNLENBQUNpQixlQUFlQyxvQkFBb0JqQyxTQUF3QixJQUFJO0NBQ3RFLE1BQU0sQ0FBQ2tDLGNBQWNDLG1CQUFtQm5DLFNBQTBCLElBQUk7O0NBR3RFLE1BQU0sRUFBRW9DLE1BQU1DLE1BQU1DLFdBQVdDLE9BQU9DLFdBQVdDLFNBQVNDLGdCQUFnQnJDLFNBQW9CO0VBQzVGc0MsVUFBVTVDLEtBQUtzQyxLQUFLUixNQUFNZSxFQUFFO0VBQzVCQyxTQUFTLE9BQU8sRUFBRUMsYUFBYTtHQUM3QixNQUFNQyxNQUFNLE1BQU1sQyxJQUFJbUMsSUFBSSxTQUFTLEVBQUVGLE9BQU8sQ0FBQztHQUM3QyxPQUFPQyxJQUFJWDtFQUNiO0NBQ0YsQ0FBQztDQUVELE1BQU1hLFlBQVkvQyxjQUFjbUMsTUFBTWEsU0FBUyxJQUFJLENBQUNiLElBQUksQ0FBQztDQUN6RCxNQUFNYyxnQkFBZ0JkLE1BQU1lOztDQUc1Qm5ELGdCQUFnQjtFQUNkLElBQUlnRCxVQUFVSSxXQUFXLEdBQUc7RUFFNUIsTUFBTUMsY0FBY3RDLHVCQUF1QnVDLFVBQTJCO0dBQ3BFLE1BQU1DLE9BQU9QLFVBQVVRLE1BQU1DLE9BQU9BLEdBQUdDLFVBQVVKLE1BQU1LLFVBQVU7R0FDakUsSUFBSUosTUFBTTtJQUNSdkIsaUJBQ0UsV0FBV3VCLEtBQUtLLElBQUlDLEtBQUksNERBQzFCO0dBQ0Y7RUFDRixDQUFDO0VBRUQsYUFBYTtHQUNYUixZQUFZO0VBQ2Q7Q0FDRixHQUFHLENBQUNMLFNBQVMsQ0FBQzs7Q0FHZCxNQUFNLEVBQUViLE1BQU0yQixPQUFPdEIsU0FBU3VCLGNBQWN6QixPQUFPMEIsWUFBWUMsV0FBV0MsbUJBQW1COUQsU0FBd0I7RUFDbkhzQyxVQUFVNUMsS0FBS3FFLFVBQVV2QyxNQUFNZSxJQUFJSyxXQUFXRSxhQUFhO0VBQzNETixTQUFTLE9BQU8sRUFBRUMsYUFBYTtHQUM3QixNQUFNQyxNQUFNLE1BQU1sQyxJQUFJd0QsS0FBSyxlQUFlO0lBQ3hDbkIsT0FBT0QsVUFBVXFCLEtBQUtkLFVBQVU7S0FDOUJHLE9BQU9ILEtBQUtHO0tBQ1pZLFVBQVVmLEtBQUtlO0tBQ2ZDLFNBQVNoQixLQUFLZ0I7SUFDaEIsRUFBRTtJQUNGcEIsWUFBWUQsaUJBQWlCc0I7SUFDN0JDLFNBQVM7R0FDWCxHQUFHLEVBQUU1QixPQUFPLENBQUM7R0FDYixPQUFPQyxJQUFJWDtFQUNiO0VBQ0F1QyxTQUFTMUIsVUFBVUksU0FBUztDQUM5QixDQUFDO0NBRUQsTUFBTXVCLHNCQUFzQnRFLFlBQVk7RUFDdEN1RSxrQkFBa0JoRSxJQUFJd0QsS0FBSyxvQkFBb0I7RUFDL0NTLGlCQUFpQm5ELFlBQVlvRCxrQkFBa0IsRUFBRXBDLFVBQVU1QyxLQUFLc0MsS0FBS1IsTUFBTWUsRUFBRSxFQUFFLENBQUM7Q0FDbEYsQ0FBQzs7Q0FHRCxNQUFNb0MseUJBQXlCMUUsWUFBWTtFQUN6Q3VFLFlBQVksT0FBTyxFQUFFSSxRQUFRVixlQUFxRDtHQUNoRixNQUFNMUQsSUFBSXFFLE1BQU0sZUFBZUQsVUFBVSxFQUFFVixTQUFTLENBQUM7RUFDdkQ7RUFDQU8saUJBQWlCO0dBQ2ZuRCxZQUFZb0Qsa0JBQWtCLEVBQUVwQyxVQUFVNUMsS0FBS3NDLEtBQUtSLE1BQU1lLEVBQUUsRUFBRSxDQUFDO0VBQ2pFO0NBQ0YsQ0FBQztDQUVELE1BQU11QyxxQkFBcUI3RSxZQUFZO0VBQ3JDdUUsWUFBWSxPQUFPSSxXQUFtQjtHQUNwQyxNQUFNcEUsSUFBSXVFLE9BQU8sZUFBZUgsUUFBUTtFQUMxQztFQUNBSCxpQkFBaUI7R0FDZm5ELFlBQVlvRCxrQkFBa0IsRUFBRXBDLFVBQVU1QyxLQUFLc0MsS0FBS1IsTUFBTWUsRUFBRSxFQUFFLENBQUM7RUFDakU7Q0FDRixDQUFDOztDQUdELE1BQU0sRUFBRVIsTUFBTWlELGtCQUFrQmhGLFNBQTBCO0VBQ3hEc0MsVUFBVSxDQUFDLGdCQUFnQjtFQUMzQkUsU0FBUyxPQUFPLEVBQUVDLGFBQWE7R0FDN0IsTUFBTUMsTUFBTSxNQUFNbEMsSUFBSW1DLElBQUksU0FBUztJQUFFRjtJQUFRd0MsUUFBUSxFQUFFQyxPQUFPLEdBQUc7R0FBRSxDQUFDO0dBQ3BFLE9BQU94QyxJQUFJWDtFQUNiO0NBQ0YsQ0FBQztDQUVELE1BQU1vRCxpQkFBaUJILGVBQWVuQyxPQUFPdUMsUUFDMUNDLE1BQU07RUFBQztFQUFTO0VBQVM7RUFBUztFQUFTO0NBQU8sQ0FBQyxDQUFDQyxTQUFTRCxFQUFFOUMsRUFBRSxDQUNwRSxLQUFLeUMsZUFBZW5DLE9BQU8wQyxNQUFNLEdBQUcsQ0FBQyxLQUFLO0NBRTFDLE1BQU1DLGdDQUFnQztFQUNwQ2pFLFNBQVMsRUFBRWtFLElBQUksWUFBWSxDQUFDO0VBQzVCLElBQUksQ0FBQ2hFLGlCQUFpQkMsY0FBYyxPQUFPO0NBQzdDO0NBRUEsSUFBSVMsV0FBVyxPQUFPLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO0VBQW1CLE1BQUs7WUFBdkMsQ0FBK0Msd0JBQUMsS0FBRCxZQUFJMUIsZ0JBQWdCMEIsV0FBVyx1Q0FBdUMsRUFBSzs7OztZQUFDLHdCQUFDLFFBQUQ7R0FBUSxlQUFlRSxZQUFZO2FBQUc7RUFBd0I7Ozs7VUFBTTs7Ozs7O0NBRXJOLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQWQsQ0FBb0Msd0JBQUMsTUFBRDtLQUFNLElBQUc7S0FBSSxjQUFXO2VBQVMsd0JBQUMsYUFBRCxDQUFZOzs7OztJQUFTOzs7O2NBQUMsa0JBQW9COzs7Ozs7R0FDL0csd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE1BQUQ7TUFBTSxJQUFHO01BQUksV0FBVTtnQkFBdUI7S0FFeEM7Ozs7O0tBQ04sd0JBQUMsUUFBRCxZQUFNLElBQU87Ozs7O0tBQ2Isd0JBQUMsS0FBRDtNQUFHLE1BQUs7TUFBYSxXQUFVO2dCQUF1QjtLQUVuRDs7Ozs7S0FDSCx3QkFBQyxRQUFELFlBQU0sSUFBTzs7Ozs7S0FDYix3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBMkI7S0FBYzs7Ozs7SUFDdEQ7Ozs7OztHQUVKO0lBQUNzQyx1QkFBdUJ6QztJQUFPNEMsbUJBQW1CNUM7SUFBT3FDLG9CQUFvQnJDO0lBQU8wQjtHQUFVLENBQUMsQ0FBQ3dCLE9BQU9NLE9BQU8sQ0FBQyxDQUFDekIsS0FBSy9CLE9BQU95RCxVQUFVLHdCQUFDLEtBQUQ7SUFBZSxNQUFLO0lBQVEsV0FBVTtjQUF0QztLQUFxRWxGLGdCQUFnQnlCLE9BQU8sd0NBQXdDO0tBQUU7S0FBQyx3QkFBQyxVQUFEO01BQVEsV0FBVTtNQUFZLGVBQWU7T0FBRSxLQUFLRyxZQUFZO09BQUcsS0FBS3NCLGFBQWE7TUFBRTtnQkFBRztLQUF3Qjs7Ozs7SUFBSTtNQUFyUGdDOzs7O1VBQXFQLENBQUM7R0FFcFloRSxpQkFDQyx3QkFBQyxPQUFEO0lBQUssTUFBSztJQUFTLGFBQVU7SUFBUyxXQUFVO2NBQWhELENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLGVBQUQsRUFBZSxXQUFVLGtDQUFpQzs7OztlQUMxRCx3QkFBQyxRQUFELFlBQU9BLGNBQW9COzs7O2FBQ3hCOzs7OztjQUNMLHdCQUFDLFFBQUQ7S0FDRSxNQUFLO0tBQ0wsZUFBZTtNQUNiZ0MsYUFBYTtNQUNiL0IsaUJBQWlCLElBQUk7S0FDdkI7S0FDQSxXQUFVO2VBQ1g7SUFFTzs7OztZQUNMOzs7Ozs7R0FHTjhCLE9BQU9rQyxZQUFZLHdCQUFDLE9BQUQ7SUFBSyxNQUFLO0lBQVEsV0FBVTtjQUE1QixDQUNqQmxDLE1BQU1rQyxTQUFTM0IsS0FBSTRCLFlBQVcsd0JBQUMsS0FBRCxZQUFrQkEsUUFBVyxHQUFyQkE7Ozs7V0FBcUIsQ0FBQyxHQUM3RCx3QkFBQyxRQUFEO0tBQVEsVUFBVXRCLG9CQUFvQlY7S0FBVyxlQUFlVSxvQkFBb0J1QixPQUFPO0tBQUcsV0FBVTtlQUFtQztJQUFzQzs7OztZQUM5Szs7Ozs7O0dBQ0psRCxVQUFVSSxXQUFXLEtBQUssQ0FBQ2YsWUFDMUIsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLGFBQUQsRUFBYSxXQUFVLHdDQUF1Qzs7Ozs7S0FDOUQsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQW1DO0tBQTJCOzs7OztLQUM1RSx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBK0Q7S0FHekU7Ozs7O0tBQ0gsd0JBQUMsTUFBRDtNQUNFLElBQUc7TUFDSCxXQUFVO2dCQUNYO0tBRUs7Ozs7O0lBQ0g7Ozs7O2NBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUVFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FFRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFhO1FBQVU7Ozs7O1FBQ3ZDLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFtQztRQUFXOzs7OztRQUM5RCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBeUI7UUFBYTs7Ozs7UUFDdEQsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQXdCO1FBQVc7Ozs7O09BQ2hEOzs7OztnQkFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDWlcsVUFBVXFCLEtBQUtkLFNBQ2Qsd0JBQUMsT0FBRDtRQUVFLFdBQVU7a0JBRlo7U0FLRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUNiLHdCQUFDLE9BQUQ7WUFDRSxLQUFLQSxLQUFLSyxJQUFJdUM7WUFDZCxLQUFLNUMsS0FBS0ssSUFBSUM7WUFDZCxXQUFVO1dBQTRCOzs7OztVQUVyQzs7OztvQkFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLE1BQUQ7WUFDRSxJQUFHO1lBQ0gsUUFBUSxFQUFFbEIsSUFBSVksS0FBS0csTUFBTTtZQUN6QixXQUFVO3NCQUVUSCxLQUFLSyxJQUFJQztXQUNOOzs7O3FCQUNOLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFoQixDQUNFLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFoQixDQUE2QixpQkFBY04sS0FBS0ssSUFBSXdDLE9BQWM7Ozs7O3NCQUFDLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFoQixDQUFzQyxZQUFTN0MsS0FBS2dCLE9BQWM7Ozs7O29CQUNqSTs7Ozs7bUJBQ0g7Ozs7O2tCQUNGOzs7Ozs7U0FHTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNHaEIsS0FBSzhDLFVBQVMsTUFDWjs7Ozs7O1NBR0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FDRSx3QkFBQyxVQUFEO1lBQ0UsTUFBSztZQUNMLGVBQWU7YUFDYixJQUFJOUMsS0FBS2UsV0FBVyxHQUFHO2NBQ3JCUyx1QkFBdUJtQixPQUFPO2VBQzVCbEIsUUFBUXpCLEtBQUtaO2VBQ2IyQixVQUFVZixLQUFLZSxXQUFXO2NBQzVCLENBQUM7YUFDSCxPQUFPO2NBQ0xwQyxnQkFBZ0JxQixJQUFJO2FBQ3RCO1lBQ0Y7WUFDQSxjQUFXO1lBQ1gsV0FBVTtzQkFFVix3QkFBQyxPQUFELEVBQU8sV0FBVSx5QkFBd0I7Ozs7O1dBQ25DOzs7OztXQUNSLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUNiQSxLQUFLZTtXQUNGOzs7OztXQUNOLHdCQUFDLFVBQUQ7WUFDRSxNQUFLO1lBQ0wsZUFDRVMsdUJBQXVCbUIsT0FBTzthQUM1QmxCLFFBQVF6QixLQUFLWjthQUNiMkIsVUFBVWYsS0FBS2UsV0FBVztZQUM1QixDQUFDO1lBRUgsVUFBVVMsdUJBQXVCZCxhQUFhVixLQUFLZSxZQUFZZ0MsS0FBS0MsSUFBSWhELEtBQUtLLElBQUk0QyxtQkFBbUJqRCxLQUFLSyxJQUFJNkMsZUFBZWxELEtBQUtnQixZQUFZLENBQUM7WUFDOUksY0FBVztZQUNYLFdBQVU7c0JBRVYsd0JBQUMsTUFBRCxFQUFNLFdBQVUseUJBQXdCOzs7OztXQUNsQzs7Ozs7VUFDTDs7Ozs7O1NBR0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ2Isd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCLENBQTRDaEIsS0FBS21ELGFBQVksTUFBVTs7Ozs7O1NBQ3BFOzs7OztRQUNGO1VBekVFbkQsS0FBS1o7Ozs7Y0F5RVAsQ0FDTjtNQUNFOzs7O2NBQ0Y7Ozs7OztJQUNGOzs7O2NBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFvRjtNQUU5Rjs7Ozs7TUFHSix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFtRDtPQUF3Qjs7OztpQkFDM0Ysd0JBQUMsWUFBRDtRQUFZLE1BQU1PO1FBQWUsZUFBZWQsTUFBTXVFO09BQVk7Ozs7ZUFDL0Q7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxhQUFXdEUsYUFBYTZCO09BQWdCLFdBQVU7aUJBQXZEO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sV0FBYzs7OzttQkFDcEIsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQ0dKLE9BQU80QyxlQUFlLFFBQU8sTUFDMUI7Ozs7O2lCQUNIOzs7Ozs7UUFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSx5QkFBNEI7Ozs7bUJBQ2xDLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUFxRCxRQUM5QzVDLE9BQU84QyxlQUFlOUMsTUFBTThDLGdCQUFnQixTQUFTOUMsTUFBTThDLGNBQWMsT0FDMUU7Ozs7O2lCQUNIOzs7Ozs7UUFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBaUI7U0FBZTs7OzttQkFDN0Msd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQTZCO1NBQWdCOzs7O2lCQUN2RDs7OzttQkFDTCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEIsQ0FDRzlDLE9BQU8rQyxpQkFBaUIsU0FBUSxNQUM3Qjs7Ozs7aUJBQ0g7Ozs7OztRQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLFFBQVc7Ozs7bUJBQ2pCLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUEwQy9DLE9BQU9nRCxZQUFZLFFBQU8sTUFBVTs7Ozs7aUJBQzNFOzs7Ozs7U0FDSHpFLGFBQWE2QixtQkFBbUIsd0JBQUMsaUJBQUQsQ0FBZ0I7Ozs7O09BQy9DOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFDRSxNQUFLO1FBQ0wsU0FBUzBCO1FBQ1QsVUFBVSxDQUFDOUIsT0FBT2lELFNBQVMsQ0FBQyxDQUFDL0MsY0FBYzNCLGFBQWE2QjtRQUN4RCxXQUFVO2tCQUNYO09BRU87Ozs7aUJBQ1Isd0JBQUMsTUFBRDtRQUNFLElBQUc7UUFDSCxXQUFVO2tCQUNYO09BRUs7Ozs7ZUFDSDs7Ozs7O0tBQ0Y7Ozs7O1lBQ0Y7Ozs7OztHQUlOcUIsZUFBZW5DLFNBQVMsS0FDdkIsd0JBQUMsV0FBRDtJQUFTLFdBQVU7Y0FBbkI7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBcUM7TUFBK0I7Ozs7O0tBQy9FOzs7OztLQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNabUMsZUFBZWxCLEtBQUtkLFNBQ25CLHdCQUFDLE9BQUQ7T0FFRSxlQUFlNUIsU0FBUztRQUFFa0UsSUFBSTtRQUFhUixRQUFRLEVBQUUxQyxJQUFJWSxLQUFLWixHQUFHO09BQUUsQ0FBQztPQUNwRSxXQUFVO2lCQUhaLENBS0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsT0FBRDtTQUNFLEtBQUtZLEtBQUs0QztTQUNWLEtBQUs1QyxLQUFLTTtTQUNWLFdBQVU7UUFBb0Y7Ozs7O09BRTdGOzs7O2lCQUNMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQ1ZOLEtBQUtNO1FBQ0w7Ozs7a0JBQ0gsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQWIsQ0FDR04sS0FBSzhDLFVBQVMsTUFDZDs7Ozs7Z0JBQ0E7Ozs7O2VBQ0Y7U0FuQkU5QyxLQUFLWjs7OzthQW1CUCxDQUNOO0tBQ0U7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSwrQ0FBOEM7Ozs7O09BQzlELHdCQUFDLFFBQUQsRUFBTSxXQUFVLG9DQUFtQzs7Ozs7T0FDbkQsd0JBQUMsUUFBRCxFQUFNLFdBQVUsK0NBQThDOzs7OztNQUMzRDs7Ozs7O0lBQ0U7Ozs7OztHQUlYLHdCQUFDLFFBQUQ7SUFBUSxNQUFNLENBQUMsQ0FBQ1Y7SUFBYyxlQUFlK0UsU0FBUztLQUFFLElBQUksQ0FBQ0EsTUFBTTlFLGdCQUFnQixJQUFJO0lBQUU7Y0FDdkYsd0JBQUMsZUFBRDtLQUFlLFdBQVU7ZUFBekI7TUFDRSx3QkFBQyxjQUFELGFBQ0Usd0JBQUMsYUFBRDtPQUFhLFdBQVU7aUJBQW1DO01BRTdDOzs7O2dCQUNiLHdCQUFDLG1CQUFEO09BQW1CLFdBQVU7aUJBQThDO01BRXhEOzs7O2NBQ1A7Ozs7O01BRWJELGdCQUNDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsT0FBRDtTQUNFLEtBQUtBLGFBQWEyQixJQUFJdUM7U0FDdEIsS0FBS2xFLGFBQWEyQixJQUFJQztTQUN0QixXQUFVO1FBQTRCOzs7OztPQUVyQzs7OztpQkFDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUNiNUIsYUFBYTJCLElBQUlDO1NBQ2Q7Ozs7O1NBQ04sd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQXlDLFlBQzlCNUIsYUFBYXNDLE9BQ2xCOzs7Ozs7U0FDTix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEIsQ0FDR3RDLGFBQWFvRSxVQUFTLE1BQ25COzs7Ozs7UUFDSDs7Ozs7ZUFDRjs7Ozs7O01BR1Asd0JBQUMsY0FBRDtPQUFjLFdBQVU7aUJBQXhCLENBQ0Usd0JBQUMsUUFBRDtRQUNFLE1BQUs7UUFDTCxTQUFRO1FBQ1IsZUFBZW5FLGdCQUFnQixJQUFJO1FBQ25DLFdBQVU7a0JBQ1g7T0FFTzs7OztpQkFDUix3QkFBQyxRQUFEO1FBQ0UsTUFBSztRQUNMLGVBQWU7U0FDYixJQUFJRCxjQUFjO1VBQ2hCaUQsbUJBQW1CZ0IsT0FBT2pFLGFBQWFVLEVBQUU7VUFDekNULGdCQUFnQixJQUFJO1NBQ3RCO1FBQ0Y7UUFDQSxXQUFVO2tCQUNYO09BRU87Ozs7ZUFDSTs7Ozs7O0tBQ0Q7Ozs7OztHQUNUOzs7OztFQUNMOzs7Ozs7QUFFVDs7Ozs7Ozs7Ozs7Ozs7O0FBQUMsU0FBQVQsWUFBQXdGIiwibmFtZXMiOlsia2V5cyIsInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlTWVtbyIsIkxpbmsiLCJ1c2VOYXZpZ2F0ZSIsInVzZVF1ZXJ5IiwidXNlTXV0YXRpb24iLCJ1c2VRdWVyeUNsaWVudCIsIkNoZXZyb25MZWZ0IiwiUGx1cyIsIk1pbnVzIiwiU2hvcHBpbmdCYWciLCJBbGVydFRyaWFuZ2xlIiwiYXBpIiwiYXBpRXJyb3JNZXNzYWdlIiwidXNlQXV0aCIsInN1YnNjcmliZVRvTmZ0VXBkYXRlcyIsIkJ1dHRvbiIsIkNvdXBvbkZvcm0iLCJTdW1tYXJ5U2tlbGV0b24iLCJEaWFsb2ciLCJEaWFsb2dDb250ZW50IiwiRGlhbG9nRGVzY3JpcHRpb24iLCJEaWFsb2dGb290ZXIiLCJEaWFsb2dIZWFkZXIiLCJEaWFsb2dUaXRsZSIsIkNhcnRQYWdlIiwicXVlcnlDbGllbnQiLCJuYXZpZ2F0ZSIsInVzZXIiLCJpc0F1dGhlbnRpY2F0ZWQiLCJvcGVuQXV0aE1vZGFsIiwicmVhbHRpbWVBbGVydCIsInNldFJlYWx0aW1lQWxlcnQiLCJpdGVtVG9SZW1vdmUiLCJzZXRJdGVtVG9SZW1vdmUiLCJkYXRhIiwiY2FydCIsImlzTG9hZGluZyIsImVycm9yIiwiY2FydEVycm9yIiwicmVmZXRjaCIsInJlZmV0Y2hDYXJ0IiwicXVlcnlLZXkiLCJpZCIsInF1ZXJ5Rm4iLCJzaWduYWwiLCJyZXMiLCJnZXQiLCJjYXJ0SXRlbXMiLCJpdGVtcyIsImFwcGxpZWRDb3Vwb24iLCJjb3Vwb25Db2RlIiwibGVuZ3RoIiwidW5zdWJzY3JpYmUiLCJldmVudCIsIml0ZW0iLCJmaW5kIiwiY2kiLCJuZnRJZCIsInJlc291cmNlSWQiLCJuZnQiLCJuYW1lIiwicXVvdGUiLCJyZWZldGNoUXVvdGUiLCJxdW90ZUVycm9yIiwiaXNQZW5kaW5nIiwiaXNRdW90ZVBlbmRpbmciLCJjYXJ0UXVvdGUiLCJwb3N0IiwibWFwIiwicXVhbnRpdHkiLCJlZGl0aW9uIiwidW5kZWZpbmVkIiwibmV0d29yayIsImVuYWJsZWQiLCJhZGp1c3RTdG9ja011dGF0aW9uIiwibXV0YXRpb25GbiIsIm9uU3VjY2VzcyIsImludmFsaWRhdGVRdWVyaWVzIiwidXBkYXRlUXVhbnRpdHlNdXRhdGlvbiIsIml0ZW1JZCIsInBhdGNoIiwicmVtb3ZlSXRlbU11dGF0aW9uIiwiZGVsZXRlIiwic3VnZ2VzdGVkRGF0YSIsInBhcmFtcyIsImxpbWl0Iiwic3VnZ2VzdGVkQ2FyZHMiLCJmaWx0ZXIiLCJuIiwiaW5jbHVkZXMiLCJzbGljZSIsImhhbmRsZVByb2NlZWRUb0NoZWNrb3V0IiwidG8iLCJCb29sZWFuIiwiaW5kZXgiLCJ3YXJuaW5ncyIsIndhcm5pbmciLCJtdXRhdGUiLCJpbWFnZVVybCIsInRva2VuSWQiLCJwcmljZUV0aCIsIk1hdGgiLCJtaW4iLCJhdmFpbGFibGVRdWFudGl0eSIsImVkaXRpb25TdG9jayIsInN1YnRvdGFsRXRoIiwiY291cG9uRXJyb3IiLCJkaXNjb3VudEV0aCIsIm5ldHdvcmtGZWVFdGgiLCJ0b3RhbEV0aCIsInZhbGlkIiwib3BlbiIsImNvbXBvbmVudCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJjYXJ0LnRzeD90c3Itc3BsaXQ9Y29tcG9uZW50Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGtleXMgfSBmcm9tICdAL2xpYi9xdWVyeS1rZXlzJ1xyXG5pbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VNZW1vIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IGNyZWF0ZUZpbGVSb3V0ZSwgTGluaywgdXNlTmF2aWdhdGUgfSBmcm9tICdAdGFuc3RhY2svcmVhY3Qtcm91dGVyJ1xyXG5pbXBvcnQgeyB1c2VRdWVyeSwgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xyXG5pbXBvcnQgeyBDaGV2cm9uTGVmdCwgUGx1cywgTWludXMsIFNob3BwaW5nQmFnLCBBbGVydFRyaWFuZ2xlIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xyXG5pbXBvcnQgeyBhcGkgfSBmcm9tICdAL2xpYi9heGlvcydcclxuaW1wb3J0IHsgYXBpRXJyb3JNZXNzYWdlIH0gZnJvbSAnQC9saWIvYXBpLWVycm9yJ1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnQC9saWIvYXV0aCdcclxuaW1wb3J0IHsgc3Vic2NyaWJlVG9OZnRVcGRhdGVzIH0gZnJvbSAnQC9saWIvc29ja2V0J1xyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJ1xyXG5pbXBvcnQgeyBDb3Vwb25Gb3JtIH0gZnJvbSAnQC9jb21wb25lbnRzL0NvdXBvbkZvcm0nXHJcbmltcG9ydCB7IFN1bW1hcnlTa2VsZXRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy9TdW1tYXJ5U2tlbGV0b24nXHJcbmltcG9ydCB7XHJcbiAgRGlhbG9nLFxyXG4gIERpYWxvZ0NvbnRlbnQsXHJcbiAgRGlhbG9nRGVzY3JpcHRpb24sXHJcbiAgRGlhbG9nRm9vdGVyLFxyXG4gIERpYWxvZ0hlYWRlcixcclxuICBEaWFsb2dUaXRsZSxcclxufSBmcm9tICdAL2NvbXBvbmVudHMvdWkvZGlhbG9nJ1xyXG5pbXBvcnQgdHlwZSB7IENhcnRTdGF0ZSwgQ2FydEl0ZW0sIFF1b3RlUmVzcG9uc2UsIE5GVExpc3RSZXNwb25zZSwgTkZUVXBkYXRlZEV2ZW50IH0gZnJvbSAnQC90eXBlcy9hcGknXHJcblxyXG5leHBvcnQgY29uc3QgUm91dGUgPSBjcmVhdGVGaWxlUm91dGUoJy9jYXJ0Jykoe1xyXG4gIGNvbXBvbmVudDogQ2FydFBhZ2UsXHJcbn0pXHJcblxyXG5mdW5jdGlvbiBDYXJ0UGFnZSgpIHtcclxuICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KClcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKClcclxuICBjb25zdCB7IHVzZXIsIGlzQXV0aGVudGljYXRlZCwgb3BlbkF1dGhNb2RhbCB9ID0gdXNlQXV0aCgpXHJcblxyXG4gIGNvbnN0IFtyZWFsdGltZUFsZXJ0LCBzZXRSZWFsdGltZUFsZXJ0XSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpXHJcbiAgY29uc3QgW2l0ZW1Ub1JlbW92ZSwgc2V0SXRlbVRvUmVtb3ZlXSA9IHVzZVN0YXRlPENhcnRJdGVtIHwgbnVsbD4obnVsbClcclxuXHJcbiAgLy8gUXVlcnkgQ2FydCBJdGVtc1xyXG4gIGNvbnN0IHsgZGF0YTogY2FydCwgaXNMb2FkaW5nLCBlcnJvcjogY2FydEVycm9yLCByZWZldGNoOiByZWZldGNoQ2FydCB9ID0gdXNlUXVlcnk8Q2FydFN0YXRlPih7XHJcbiAgICBxdWVyeUtleToga2V5cy5jYXJ0KHVzZXI/LmlkKSxcclxuICAgIHF1ZXJ5Rm46IGFzeW5jICh7IHNpZ25hbCB9KSA9PiB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoJy9jYXJ0JywgeyBzaWduYWwgfSlcclxuICAgICAgcmV0dXJuIHJlcy5kYXRhXHJcbiAgICB9LFxyXG4gIH0pXHJcblxyXG4gIGNvbnN0IGNhcnRJdGVtcyA9IHVzZU1lbW8oKCkgPT4gY2FydD8uaXRlbXMgfHwgW10sIFtjYXJ0XSlcclxuICBjb25zdCBhcHBsaWVkQ291cG9uID0gY2FydD8uY291cG9uQ29kZVxyXG5cclxuICAvLyBTb2NrZXQuSU8gbGl2ZSB1cGRhdGUgbGlzdGVuZXJcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGNhcnRJdGVtcy5sZW5ndGggPT09IDApIHJldHVyblxyXG5cclxuICAgIGNvbnN0IHVuc3Vic2NyaWJlID0gc3Vic2NyaWJlVG9OZnRVcGRhdGVzKChldmVudDogTkZUVXBkYXRlZEV2ZW50KSA9PiB7XHJcbiAgICAgIGNvbnN0IGl0ZW0gPSBjYXJ0SXRlbXMuZmluZCgoY2kpID0+IGNpLm5mdElkID09PSBldmVudC5yZXNvdXJjZUlkKVxyXG4gICAgICBpZiAoaXRlbSkge1xyXG4gICAgICAgIHNldFJlYWx0aW1lQWxlcnQoXHJcbiAgICAgICAgICBgTyBpdGVtIFwiJHtpdGVtLm5mdC5uYW1lfVwiIHRldmUgc2V1IHByZcOnbyBvdSBkaXNwb25pYmlsaWRhZGUgYWx0ZXJhZG8gZW0gdGVtcG8gcmVhbC5gXHJcbiAgICAgICAgKVxyXG4gICAgICB9XHJcbiAgICB9KVxyXG5cclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIHVuc3Vic2NyaWJlKClcclxuICAgIH1cclxuICB9LCBbY2FydEl0ZW1zXSlcclxuXHJcbiAgLy8gUXVvdGUgUXVlcnlcclxuICBjb25zdCB7IGRhdGE6IHF1b3RlLCByZWZldGNoOiByZWZldGNoUXVvdGUsIGVycm9yOiBxdW90ZUVycm9yLCBpc1BlbmRpbmc6IGlzUXVvdGVQZW5kaW5nIH0gPSB1c2VRdWVyeTxRdW90ZVJlc3BvbnNlPih7XHJcbiAgICBxdWVyeUtleToga2V5cy5jYXJ0UXVvdGUodXNlcj8uaWQsIGNhcnRJdGVtcywgYXBwbGllZENvdXBvbiksXHJcbiAgICBxdWVyeUZuOiBhc3luYyAoeyBzaWduYWwgfSkgPT4ge1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkucG9zdCgnL2NhcnQvcXVvdGUnLCB7XHJcbiAgICAgICAgaXRlbXM6IGNhcnRJdGVtcy5tYXAoKGl0ZW0pID0+ICh7XHJcbiAgICAgICAgICBuZnRJZDogaXRlbS5uZnRJZCxcclxuICAgICAgICAgIHF1YW50aXR5OiBpdGVtLnF1YW50aXR5LFxyXG4gICAgICAgICAgZWRpdGlvbjogaXRlbS5lZGl0aW9uLFxyXG4gICAgICAgIH0pKSxcclxuICAgICAgICBjb3Vwb25Db2RlOiBhcHBsaWVkQ291cG9uIHx8IHVuZGVmaW5lZCxcclxuICAgICAgICBuZXR3b3JrOiAnRXRoZXJldW0nLFxyXG4gICAgICB9LCB7IHNpZ25hbCB9KVxyXG4gICAgICByZXR1cm4gcmVzLmRhdGFcclxuICAgIH0sXHJcbiAgICBlbmFibGVkOiBjYXJ0SXRlbXMubGVuZ3RoID4gMCxcclxuICB9KVxyXG5cclxuICBjb25zdCBhZGp1c3RTdG9ja011dGF0aW9uID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogKCkgPT4gYXBpLnBvc3QoJy9jYXJ0L2FkanVzdC1zdG9jaycpLFxyXG4gICAgb25TdWNjZXNzOiAoKSA9PiBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBrZXlzLmNhcnQodXNlcj8uaWQpIH0pLFxyXG4gIH0pXHJcblxyXG4gIC8vIE11dGF0aW9uc1xyXG4gIGNvbnN0IHVwZGF0ZVF1YW50aXR5TXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiBhc3luYyAoeyBpdGVtSWQsIHF1YW50aXR5IH06IHsgaXRlbUlkOiBzdHJpbmc7IHF1YW50aXR5OiBudW1iZXIgfSkgPT4ge1xyXG4gICAgICBhd2FpdCBhcGkucGF0Y2goYC9jYXJ0L2l0ZW1zLyR7aXRlbUlkfWAsIHsgcXVhbnRpdHkgfSlcclxuICAgIH0sXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleToga2V5cy5jYXJ0KHVzZXI/LmlkKSB9KVxyXG4gICAgfSxcclxuICB9KVxyXG5cclxuICBjb25zdCByZW1vdmVJdGVtTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiBhc3luYyAoaXRlbUlkOiBzdHJpbmcpID0+IHtcclxuICAgICAgYXdhaXQgYXBpLmRlbGV0ZShgL2NhcnQvaXRlbXMvJHtpdGVtSWR9YClcclxuICAgIH0sXHJcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcclxuICAgICAgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleToga2V5cy5jYXJ0KHVzZXI/LmlkKSB9KVxyXG4gICAgfSxcclxuICB9KVxyXG5cclxuICAvLyBTdWdnZXN0ZWQgTkZUcyAoNSBpdGVtcyBtYXRjaGluZyBGaWdtYSBGcmFtZSAxMToxMjc4KVxyXG4gIGNvbnN0IHsgZGF0YTogc3VnZ2VzdGVkRGF0YSB9ID0gdXNlUXVlcnk8TkZUTGlzdFJlc3BvbnNlPih7XHJcbiAgICBxdWVyeUtleTogWydzdWdnZXN0ZWQtbmZ0cyddLFxyXG4gICAgcXVlcnlGbjogYXN5bmMgKHsgc2lnbmFsIH0pID0+IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldCgnL25mdHMnLCB7IHNpZ25hbCwgcGFyYW1zOiB7IGxpbWl0OiAxMCB9IH0pXHJcbiAgICAgIHJldHVybiByZXMuZGF0YVxyXG4gICAgfSxcclxuICB9KVxyXG5cclxuICBjb25zdCBzdWdnZXN0ZWRDYXJkcyA9IHN1Z2dlc3RlZERhdGE/Lml0ZW1zPy5maWx0ZXIoXHJcbiAgICAobikgPT4gWyduZnQtNCcsICduZnQtNScsICduZnQtNicsICduZnQtNycsICduZnQtOCddLmluY2x1ZGVzKG4uaWQpXHJcbiAgKSB8fCBzdWdnZXN0ZWREYXRhPy5pdGVtcz8uc2xpY2UoMCwgNSkgfHwgW11cclxuXHJcbiAgY29uc3QgaGFuZGxlUHJvY2VlZFRvQ2hlY2tvdXQgPSAoKSA9PiB7XHJcbiAgICBuYXZpZ2F0ZSh7IHRvOiAnL2NoZWNrb3V0JyB9KVxyXG4gICAgaWYgKCFpc0F1dGhlbnRpY2F0ZWQpIG9wZW5BdXRoTW9kYWwoJ2xvZ2luJylcclxuICB9XHJcblxyXG4gIGlmIChjYXJ0RXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInBhZ2Utd2lkdGggcHktMTZcIiByb2xlPVwiYWxlcnRcIj48cD57YXBpRXJyb3JNZXNzYWdlKGNhcnRFcnJvciwgJ07Do28gZm9pIHBvc3PDrXZlbCBjYXJyZWdhciBvIGNhcnJpbmhvLicpfTwvcD48QnV0dG9uIG9uQ2xpY2s9eygpID0+IHJlZmV0Y2hDYXJ0KCl9PlRlbnRhciBub3ZhbWVudGU8L0J1dHRvbj48L2Rpdj5cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FydC1wYWdlIHBhZ2Utd2lkdGggZm9udC1tb25vIHBiLVszODBweF0gbWQ6cGItMTJcIj5cclxuICAgICAgey8qIEJyZWFkY3J1bWIgbWF0Y2hpbmcgRmlnbWEgRnJhbWUgMTE6MTI3OCAqL31cclxuICAgICAgPGgxIGNsYXNzTmFtZT1cIm1vYmlsZS1wYWdlLWhlYWRpbmdcIj48TGluayB0bz1cIi9cIiBhcmlhLWxhYmVsPVwiVm9sdGFyXCI+PENoZXZyb25MZWZ0IC8+PC9MaW5rPkNhcnJpbmhvIGRlIE5GVHM8L2gxPlxyXG4gICAgICA8bmF2IGNsYXNzTmFtZT1cIm1iLTYgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyB0ZXh0LVsjQ0ZCMjhDXVwiPlxyXG4gICAgICAgIDxMaW5rIHRvPVwiL1wiIGNsYXNzTmFtZT1cImhvdmVyOnRleHQtWyNFODlCNTVdXCI+XHJcbiAgICAgICAgICBJbsOtY2lvXHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDxzcGFuPi88L3NwYW4+XHJcbiAgICAgICAgPGEgaHJlZj1cIi8jY2F0YWxvZ29cIiBjbGFzc05hbWU9XCJob3Zlcjp0ZXh0LVsjRTg5QjU1XVwiPlxyXG4gICAgICAgICAgTWVyY2Fkb1xyXG4gICAgICAgIDwvYT5cclxuICAgICAgICA8c3Bhbj4vPC9zcGFuPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWyNGNUYxRUJdIGZvbnQtYm9sZFwiPkNhcnJpbmhvPC9zcGFuPlxyXG4gICAgICA8L25hdj5cclxuXHJcbiAgICAgIHtbdXBkYXRlUXVhbnRpdHlNdXRhdGlvbi5lcnJvciwgcmVtb3ZlSXRlbU11dGF0aW9uLmVycm9yLCBhZGp1c3RTdG9ja011dGF0aW9uLmVycm9yLCBxdW90ZUVycm9yXS5maWx0ZXIoQm9vbGVhbikubWFwKChlcnJvciwgaW5kZXgpID0+IDxwIGtleT17aW5kZXh9IHJvbGU9XCJhbGVydFwiIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC1zbSB0ZXh0LVsjRjA4MDVGXVwiPnthcGlFcnJvck1lc3NhZ2UoZXJyb3IsICdOw6NvIGZvaSBwb3Nzw612ZWwgYXR1YWxpemFyIG8gY2FycmluaG8uJyl9IDxidXR0b24gY2xhc3NOYW1lPVwidW5kZXJsaW5lXCIgb25DbGljaz17KCkgPT4geyB2b2lkIHJlZmV0Y2hDYXJ0KCk7IHZvaWQgcmVmZXRjaFF1b3RlKCkgfX0+VGVudGFyIG5vdmFtZW50ZTwvYnV0dG9uPjwvcD4pfVxyXG4gICAgICB7LyogUmVhbHRpbWUgQWxlcnQgQmFubmVyICovfVxyXG4gICAgICB7cmVhbHRpbWVBbGVydCAmJiAoXHJcbiAgICAgICAgPGRpdiByb2xlPVwic3RhdHVzXCIgYXJpYS1saXZlPVwicG9saXRlXCIgY2xhc3NOYW1lPVwibWItNiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLVsjRDI4QTRDXSBiZy1bI0QyOEE0Q10vMTUgcC00IHRleHQteHMgdGV4dC1bI0U4OUI1NV1cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgPEFsZXJ0VHJpYW5nbGUgY2xhc3NOYW1lPVwidy00IGgtNCBzaHJpbmstMCB0ZXh0LVsjRTg5QjU1XVwiIC8+XHJcbiAgICAgICAgICAgIDxzcGFuPntyZWFsdGltZUFsZXJ0fTwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICBzaXplPVwic21cIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgcmVmZXRjaFF1b3RlKClcclxuICAgICAgICAgICAgICBzZXRSZWFsdGltZUFsZXJ0KG51bGwpXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtOCBiZy1bI0QyOEE0Q10gaG92ZXI6YmctWyNFODlCNTVdIHRleHQtWyMxNDBEMEFdIGZvbnQtYm9sZCB0ZXh0LXhzXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgQXR1YWxpemFyIGNvdGHDp8Ojb1xyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7cXVvdGU/Lndhcm5pbmdzICYmIDxkaXYgcm9sZT1cImFsZXJ0XCIgY2xhc3NOYW1lPVwibWItNiByb3VuZGVkIGJvcmRlciBib3JkZXItWyNEMjhBNENdIHAtNCB0ZXh0LXNtIHRleHQtWyNDRkIyOENdXCI+XHJcbiAgICAgICAge3F1b3RlLndhcm5pbmdzLm1hcCh3YXJuaW5nID0+IDxwIGtleT17d2FybmluZ30+e3dhcm5pbmd9PC9wPil9XHJcbiAgICAgICAgPEJ1dHRvbiBkaXNhYmxlZD17YWRqdXN0U3RvY2tNdXRhdGlvbi5pc1BlbmRpbmd9IG9uQ2xpY2s9eygpID0+IGFkanVzdFN0b2NrTXV0YXRpb24ubXV0YXRlKCl9IGNsYXNzTmFtZT1cIm10LTMgYmctWyNEMjhBNENdIHRleHQtWyMxNDBEMEFdXCI+QWp1c3RhciBxdWFudGlkYWRlcyBhbyBlc3RvcXVlPC9CdXR0b24+XHJcbiAgICAgIDwvZGl2Pn1cclxuICAgICAge2NhcnRJdGVtcy5sZW5ndGggPT09IDAgJiYgIWlzTG9hZGluZyA/IChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItWyMzRjIzMTldIGJnLVsjMjQxNjEyXSBwLTE2IHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICA8U2hvcHBpbmdCYWcgY2xhc3NOYW1lPVwidy0xNiBoLTE2IG14LWF1dG8gdGV4dC1bIzNGMjMxOV0gbWItNFwiIC8+XHJcbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1bI0Y1RjFFQl1cIj5TZXUgY2FycmluaG8gZXN0w6EgdmF6aW88L2gyPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXhzIHRleHQtWyNDRkIyOENdIG1heC13LW1kIG14LWF1dG8gbGVhZGluZy1yZWxheGVkXCI+XHJcbiAgICAgICAgICAgIE5lbmh1bSBORlQgZm9pIGFkaWNpb25hZG8gYWluZGEuIEV4cGxvcmUgbm9zc2EgY29sZcOnw6NvIGRlIGFydGUgZGlnaXRhbCBlIGVuY29udHJlIHN1YVxyXG4gICAgICAgICAgICBwcsOzeGltYSBvYnJhIHJhcmEuXHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICB0bz1cIi9cIlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJtdC02IGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkIGJnLVsjRDI4QTRDXSBweC02IHB5LTIuNSB0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdGV4dC1bIzE0MEQwQV0gaG92ZXI6YmctWyNFODlCNTVdXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgRXhwbG9yYXIgY2F0w6Fsb2dvICZyYXJyO1xyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApIDogKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FydC1sYXlvdXRcIj5cclxuICAgICAgICAgIHsvKiBDYXJ0IFRhYmxlICg4IGNvbHMpIG1hdGNoaW5nIEZpZ21hIEZyYW1lIDExOjEyNzggKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJ0LXRhYmxlIG92ZXJmbG93LXgtYXV0byByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItWyMzRjIzMTldIGJnLVsjMjQxNjEyXVwiPlxyXG4gICAgICAgICAgICAgIHsvKiBUYWJsZSBIZWFkZXIgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJ0LXRhYmxlLWhlYWQgZ3JpZCBncmlkLWNvbHMtMTIgZ2FwLTQgcHgtNiBweS00IGJvcmRlci1iIGJvcmRlci1bIzNGMjMxOV0gdGV4dC14cyBmb250LWJvbGQgdGV4dC1bI0Y1RjFFQl1cIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNvbC1zcGFuLTVcIj5ORlRzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2FydC11bml0IGNvbC1zcGFuLTIgdGV4dC1jZW50ZXJcIj5QcmXDp288L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjb2wtc3Bhbi0zIHRleHQtY2VudGVyXCI+RWRpw6fDtWVzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY29sLXNwYW4tMiB0ZXh0LXJpZ2h0XCI+VG90YWw8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBJdGVtcyAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcnQtcm93c1wiPlxyXG4gICAgICAgICAgICAgICAge2NhcnRJdGVtcy5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5pZH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjYXJ0LXJvdyBncmlkIGdyaWQtY29scy0xMiBnYXAtNCBpdGVtcy1jZW50ZXIgcHgtNiBweS00IHRleHQteHMgdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6YmctWyMxNDBEMEFdLzMwXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBBcnR3b3JrICsgVGl0bGUgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJ0LWlkZW50aXR5IGNvbC1zcGFuLTUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FydC1hcnQgaC0xNiB3LTE2IHNocmluay0wIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItWyMzRjIzMTldIGJnLVsjMTQwRDBBXVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXtpdGVtLm5mdC5pbWFnZVVybH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9e2l0ZW0ubmZ0Lm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC1mdWxsIHctZnVsbCBvYmplY3QtY292ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTAuNSBtaW4tdy0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdG89XCIvbmZ0cy8kaWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtcz17eyBpZDogaXRlbS5uZnRJZCB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LVsjRjVGMUVCXSB0cnVuY2F0ZSBob3Zlcjp0ZXh0LVsjRTg5QjU1XVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5uZnQubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LVsjQ0ZCMjhDXVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNhcnQtdG9rZW5cIj5JRCBkbyB0b2tlbjoge2l0ZW0ubmZ0LnRva2VuSWR9PC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cImNhcnQtbW9iaWxlLWVkaXRpb25cIj5FZGnDp8Ojbzoge2l0ZW0uZWRpdGlvbn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogVW5pdCBQcmljZSAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcnQtdW5pdCBjb2wtc3Bhbi0yIHRleHQtY2VudGVyIHRleHQtWyNGNUYxRUJdIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5wcmljZUV0aH0gRVRIXHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBRdWFudGl0eSBTdGVwcGVyOiBjaXJjdWxhciBvcmFuZ2UgYnV0dG9ucyBtYXRjaGluZyBGaWdtYSAxMToxMjc4ICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FydC1zdGVwcGVyIGNvbC1zcGFuLTMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXRlbS5xdWFudGl0eSA+IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZVF1YW50aXR5TXV0YXRpb24ubXV0YXRlKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbUlkOiBpdGVtLmlkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWFudGl0eTogaXRlbS5xdWFudGl0eSAtIDEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRJdGVtVG9SZW1vdmUoaXRlbSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJEaW1pbnVpciBxdWFudGlkYWRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC02IHctNiByb3VuZGVkLWZ1bGwgYmctWyNEMjhBNENdIGhvdmVyOmJnLVsjRTg5QjU1XSB0ZXh0LVsjMTQwRDBBXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmb250LWJvbGQgdHJhbnNpdGlvbi10cmFuc2Zvcm0gYWN0aXZlOnNjYWxlLTkwIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPE1pbnVzIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHN0cm9rZS1bM11cIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTYgdGV4dC1jZW50ZXIgZm9udC1ib2xkIHRleHQtc20gdGV4dC1bI0Y1RjFFQl1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ucXVhbnRpdHl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZVF1YW50aXR5TXV0YXRpb24ubXV0YXRlKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW1JZDogaXRlbS5pZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1YW50aXR5OiBpdGVtLnF1YW50aXR5ICsgMSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXt1cGRhdGVRdWFudGl0eU11dGF0aW9uLmlzUGVuZGluZyB8fCBpdGVtLnF1YW50aXR5ID49IE1hdGgubWluKGl0ZW0ubmZ0LmF2YWlsYWJsZVF1YW50aXR5LCBpdGVtLm5mdC5lZGl0aW9uU3RvY2s/LltpdGVtLmVkaXRpb25dID8/IDApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiQXVtZW50YXIgcXVhbnRpZGFkZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtNiB3LTYgcm91bmRlZC1mdWxsIGJnLVsjRDI4QTRDXSBob3ZlcjpiZy1bI0U4OUI1NV0gdGV4dC1bIzE0MEQwQV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZm9udC1ib2xkIHRyYW5zaXRpb24tdHJhbnNmb3JtIGFjdGl2ZTpzY2FsZS05MCBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxQbHVzIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHN0cm9rZS1bM11cIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBTdWJ0b3RhbCAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcnQtbGluZS10b3RhbCBjb2wtc3Bhbi0yIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1bI0U4OUI1NV1cIj57aXRlbS5zdWJ0b3RhbEV0aH0gRVRIPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBXYWxsZXQgU3VtbWFyeSAoNCBjb2xzIGluIGRlc2t0b3AsIGZpeGVkIGJvdHRvbSBkcmF3ZXIgb24gbW9iaWxlKSAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FydC1zdW1tYXJ5IGZsZXggZmxleC1jb2wgZ2FwLTYgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLVsjM0YyMzE5XSBiZy1bIzI0MTYxMl0gcC02IHNoYWRvdy14bCBoLWZpdFwiPlxyXG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwiaGlkZGVuIG1kOmJsb2NrIHRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1bI0Y1RjFFQl0gcGItMyBib3JkZXItYiBib3JkZXItWyMzRjIzMTldXCI+XHJcbiAgICAgICAgICAgICAgUmVzdW1vIGRhIGNhcnRlaXJhXHJcbiAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICB7LyogUHJvbW8gQ29kZSBJbnB1dCAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gbWQ6YmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1bI0Y1RjFFQl1cIj5Dw7NkaWdvIHByb21vY2lvbmFsPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxDb3Vwb25Gb3JtIGNvZGU9e2FwcGxpZWRDb3Vwb259IGludmFsaWRSZWFzb249e2NhcnQ/LmNvdXBvbkVycm9yfSAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBGaW5hbmNpYWwgVG90YWxzICovfVxyXG4gICAgICAgICAgICA8ZGl2IGFyaWEtYnVzeT17aXNMb2FkaW5nIHx8IGlzUXVvdGVQZW5kaW5nfSBjbGFzc05hbWU9XCJjYXJ0LXRvdGFscyBmaW5hbmNpYWwtc3VtbWFyeSBzcGFjZS15LTMgcHQtMyBib3JkZXItdCBib3JkZXItWyMzRjIzMTldIHRleHQteHMgdGV4dC1bI0NGQjI4Q11cIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4+U3VidG90YWw8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsjRjVGMUVCXSBmb250LW1lZGl1bSB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtxdW90ZT8uc3VidG90YWxFdGggfHwgJzAuMDAnfSBFVEhcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuPkRlc2NvbnRvIGRvIGxhbsOnYW1lbnRvPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bI0NGQjI4Q10gZm9udC1tZWRpdW0gdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAoLSkge3F1b3RlPy5kaXNjb3VudEV0aCAmJiBxdW90ZS5kaXNjb3VudEV0aCAhPT0gJzAuMDAnID8gcXVvdGUuZGlzY291bnRFdGggOiAnMDAuMDAnfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bI0Y1RjFFQl1cIj5UYXhhIGRlIHJlZGU8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtWyNDRkIyOENdXCI+VGF4YSBlc3RpbWFkYTwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bI0Y1RjFFQl0gZm9udC1tZWRpdW0gdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICB7cXVvdGU/Lm5ldHdvcmtGZWVFdGggfHwgJzAuMDE2J30gRVRIXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHB0LTMgYm9yZGVyLXQgYm9yZGVyLVsjM0YyMzE5XSB0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtWyNGNUYxRUJdXCI+XHJcbiAgICAgICAgICAgICAgICA8c3Bhbj5Ub3RhbDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteGwgdGV4dC1bI0U4OUI1NV1cIj57cXVvdGU/LnRvdGFsRXRoIHx8ICcwLjAwJ30gRVRIPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIHsoaXNMb2FkaW5nIHx8IGlzUXVvdGVQZW5kaW5nKSAmJiA8U3VtbWFyeVNrZWxldG9uIC8+fVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBDaGVja291dCBBY3Rpb24gQ1RBICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTMgcHQtMlwiPlxyXG4gICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlUHJvY2VlZFRvQ2hlY2tvdXR9XHJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17IXF1b3RlPy52YWxpZCB8fCAhIXF1b3RlRXJyb3IgfHwgaXNMb2FkaW5nIHx8IGlzUXVvdGVQZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTIgbWQ6aC0xMSBiZy1bI0QyOEE0Q10gaG92ZXI6YmctWyNFODlCNTVdIHRleHQtWyMxNDBEMEFdIGZvbnQtYm9sZCB0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciByb3VuZGVkLWZ1bGwgbWQ6cm91bmRlZC1bNHB4XSBzaGFkb3ctbGcgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIENvbmVjdGFyIGUgZmluYWxpemFyXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgIHRvPVwiL1wiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoaWRkZW4gbWQ6YmxvY2sgdGV4dC1jZW50ZXIgdGV4dC14cyB0ZXh0LVsjRTg5QjU1XSBob3Zlcjp1bmRlcmxpbmUgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIENvbnRpbnVhciBleHBsb3JhbmRvXHJcbiAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuICAgICAgey8qIENvbGVjaW9uYWRvcmVzIHRhbWLDqW0gdmlyYW0gKDUgY2FyZHMgKyAzIGRvdHMgcGFnaW5hdGlvbiBwZXIgRmlnbWEgMTE6MTI3OCkgKi99XHJcbiAgICAgIHtzdWdnZXN0ZWRDYXJkcy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJjYXJ0LXJlbGF0ZWQgbXQtMjAgYm9yZGVyLXQgYm9yZGVyLVsjM0YyMzE5XSBwdC0xMlwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtWyNFODlCNTVdXCI+Q29sZWNpb25hZG9yZXMgdGFtYsOpbSB2aXJhbTwvaDI+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBzbTpncmlkLWNvbHMtMyBtZDpncmlkLWNvbHMtNSBnYXAtNFwiPlxyXG4gICAgICAgICAgICB7c3VnZ2VzdGVkQ2FyZHMubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAga2V5PXtpdGVtLmlkfVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoeyB0bzogJy9uZnRzLyRpZCcsIHBhcmFtczogeyBpZDogaXRlbS5pZCB9IH0pfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdXAgZmxleCBmbGV4LWNvbCBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0yMDAgaG92ZXI6LXRyYW5zbGF0ZS15LTFcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXNwZWN0LXNxdWFyZSB3LWZ1bGwgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1bIzNGMjMxOV0gYmctWyMyNDE2MTJdXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgICBzcmM9e2l0ZW0uaW1hZ2VVcmx9XHJcbiAgICAgICAgICAgICAgICAgICAgYWx0PXtpdGVtLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC1mdWxsIHctZnVsbCBvYmplY3QtY292ZXIgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwIGdyb3VwLWhvdmVyOnNjYWxlLTEwNVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiBmbGV4IGZsZXgtY29sIGdhcC0wLjVcIj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQteHMgdGV4dC1bI0Y1RjFFQl0gdHJ1bmNhdGUgZ3JvdXAtaG92ZXI6dGV4dC1bI0U4OUI1NV1cIj5cclxuICAgICAgICAgICAgICAgICAgICB7aXRlbS5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtWyNFODlCNTVdXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2l0ZW0ucHJpY2VFdGh9IEVUSFxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogMyBQYWdpbmF0aW9uIGRvdHMgbWF0Y2hpbmcgRmlnbWEgRnJhbWUgMTE6MTI3OCAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtOCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoLTIgdy0yIHJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLVsjRDI4QTRDXVwiIC8+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImgtMiB3LTIgcm91bmRlZC1mdWxsIGJnLVsjRDI4QTRDXVwiIC8+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImgtMiB3LTIgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItWyNEMjhBNENdXCIgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHsvKiBDb25maXJtYXRpb24gTW9kYWwgZm9yIFJlbW92aW5nIEl0ZW0gKi99XHJcbiAgICAgIDxEaWFsb2cgb3Blbj17ISFpdGVtVG9SZW1vdmV9IG9uT3BlbkNoYW5nZT17KG9wZW4pID0+IHsgaWYgKCFvcGVuKSBzZXRJdGVtVG9SZW1vdmUobnVsbCkgfX0+XHJcbiAgICAgICAgPERpYWxvZ0NvbnRlbnQgY2xhc3NOYW1lPVwibWF4LXctbWQgYm9yZGVyIGJvcmRlci1bIzNGMjMxOV0gYmctWyMyNDE2MTJdIHRleHQtWyNGNUYxRUJdIGZvbnQtbW9ub1wiPlxyXG4gICAgICAgICAgPERpYWxvZ0hlYWRlcj5cclxuICAgICAgICAgICAgPERpYWxvZ1RpdGxlIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtWyNGNUYxRUJdXCI+XHJcbiAgICAgICAgICAgICAgUmVtb3ZlciBpdGVtIGRvIGNhcnJpbmhvP1xyXG4gICAgICAgICAgICA8L0RpYWxvZ1RpdGxlPlxyXG4gICAgICAgICAgICA8RGlhbG9nRGVzY3JpcHRpb24gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LVsjQ0ZCMjhDXSBsZWFkaW5nLXJlbGF4ZWQgcHQtMVwiPlxyXG4gICAgICAgICAgICAgIERlc2VqYSByZWFsbWVudGUgcmVtb3ZlciBlc3RlIE5GVCBkbyBzZXUgY2FycmluaG8gZGUgY29tcHJhcz9cclxuICAgICAgICAgICAgPC9EaWFsb2dEZXNjcmlwdGlvbj5cclxuICAgICAgICAgIDwvRGlhbG9nSGVhZGVyPlxyXG5cclxuICAgICAgICAgIHtpdGVtVG9SZW1vdmUgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zLjUgcC0zLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLVsjM0YyMzE5XSBiZy1bIzE0MEQwQV0vNzAgbXktMlwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0xNCB3LTE0IHNocmluay0wIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItWyMzRjIzMTldXCI+XHJcbiAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgIHNyYz17aXRlbVRvUmVtb3ZlLm5mdC5pbWFnZVVybH1cclxuICAgICAgICAgICAgICAgICAgYWx0PXtpdGVtVG9SZW1vdmUubmZ0Lm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtZnVsbCB3LWZ1bGwgb2JqZWN0LWNvdmVyXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG1pbi13LTBcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNtIHRleHQtWyNGNUYxRUJdIHRydW5jYXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtpdGVtVG9SZW1vdmUubmZ0Lm5hbWV9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtWyNDRkIyOENdXCI+XHJcbiAgICAgICAgICAgICAgICAgIEVkacOnw6NvOiB7aXRlbVRvUmVtb3ZlLmVkaXRpb259XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LVsjRDI4QTRDXSBtdC0wLjVcIj5cclxuICAgICAgICAgICAgICAgICAge2l0ZW1Ub1JlbW92ZS5wcmljZUV0aH0gRVRIXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICA8RGlhbG9nRm9vdGVyIGNsYXNzTmFtZT1cIm10LTQgZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWVuZCBnYXAtM1wiPlxyXG4gICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEl0ZW1Ub1JlbW92ZShudWxsKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXItWyMzRjIzMTldIGJnLVsjMTQwRDBBXSB0ZXh0LVsjQ0ZCMjhDXSBob3ZlcjpiZy1bIzI0MTYxMl0gaG92ZXI6dGV4dC1bI0Y1RjFFQl0gdGV4dC14cyBoLTkgcHgtNCBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBDYW5jZWxhclxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgIGlmIChpdGVtVG9SZW1vdmUpIHtcclxuICAgICAgICAgICAgICAgICAgcmVtb3ZlSXRlbU11dGF0aW9uLm11dGF0ZShpdGVtVG9SZW1vdmUuaWQpXHJcbiAgICAgICAgICAgICAgICAgIHNldEl0ZW1Ub1JlbW92ZShudWxsKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctWyNEMjhBNENdIGhvdmVyOmJnLVsjRTg5QjU1XSB0ZXh0LVsjMTQwRDBBXSBmb250LWJvbGQgdGV4dC14cyBoLTkgcHgtNCBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBSZW1vdmVyIGl0ZW1cclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8L0RpYWxvZ0Zvb3Rlcj5cclxuICAgICAgICA8L0RpYWxvZ0NvbnRlbnQ+XHJcbiAgICAgIDwvRGlhbG9nPlxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvZmVsaWkvT25lRHJpdmUvw4FyZWEgZGUgVHJhYmFsaG8vSnVuZ2xlLUdhbWluZy1DaGFsbGVuZ2Uvc3JjL3JvdXRlcy9jYXJ0LnRzeCJ9
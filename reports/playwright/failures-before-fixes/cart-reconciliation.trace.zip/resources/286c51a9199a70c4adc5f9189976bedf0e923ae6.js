import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/login.tsx?tsr-split=component");const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=7abeec5e";
import { useNavigate } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=23b60560";
import { useAuth } from "/src/lib/auth.tsx?t=1792165206673";
import { HomePage } from "/src/components/HomePage.tsx?t=1792167170549";
var _jsxFileName = "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/routes/login.tsx?tsr-split=component";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7abeec5e";
var _s = $RefreshSig$();
function LoginPage() {
	_s();
	const { openAuthModal, isAuthenticated } = useAuth();
	const navigate = useNavigate();
	useEffect(() => {
		if (isAuthenticated) {
			navigate({ to: "/" });
			return;
		}
		openAuthModal("login");
	}, [
		isAuthenticated,
		navigate,
		openAuthModal
	]);
	return /* @__PURE__ */ _jsxDEV(HomePage, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 20,
		columnNumber: 10
	}, this);
}
_s(LoginPage, "jD2IJS9ZENRuxvgIt4ATyaf372I=", false, function() {
	return [useAuth, useNavigate];
});
_c = LoginPage;
export { LoginPage as component };
var _c;
$RefreshReg$(_c, "LoginPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/login.tsx?t=1792167170549&tsr-split=component";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/routes/login.tsx?tsr-split=component", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/routes/login.tsx?tsr-split=component", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/routes/login.tsx?tsr-split=component" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsU0FBU0EsaUJBQWlCO0FBQzFCLFNBQTBCQyxtQkFBbUI7QUFDN0MsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxnQkFBZ0I7Ozs7QUFNekIsU0FBU0MsWUFBWTs7Q0FDbkIsTUFBTSxFQUFFQyxlQUFlQyxvQkFBb0JKLFFBQVE7Q0FDbkQsTUFBTUssV0FBV04sWUFBWTtDQUU3QkQsZ0JBQWdCO0VBQ2QsSUFBSU0saUJBQWlCO0dBQ25CQyxTQUFTLEVBQUVDLElBQUksSUFBSSxDQUFDO0dBQ3BCO0VBQ0Y7RUFDQUgsY0FBYyxPQUFPO0NBQ3ZCLEdBQUc7RUFBQ0M7RUFBaUJDO0VBQVVGO0NBQWEsQ0FBQztDQUU3QyxPQUFPLHdCQUFDLFVBQUQsQ0FBUzs7Ozs7QUFDbEI7Ozs7O0FBQUMsU0FBQUQsYUFBQUsiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VOYXZpZ2F0ZSIsInVzZUF1dGgiLCJIb21lUGFnZSIsIkxvZ2luUGFnZSIsIm9wZW5BdXRoTW9kYWwiLCJpc0F1dGhlbnRpY2F0ZWQiLCJuYXZpZ2F0ZSIsInRvIiwiY29tcG9uZW50Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImxvZ2luLnRzeD90c3Itc3BsaXQ9Y29tcG9uZW50Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBjcmVhdGVGaWxlUm91dGUsIHVzZU5hdmlnYXRlIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcidcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJ0AvbGliL2F1dGgnXHJcbmltcG9ydCB7IEhvbWVQYWdlIH0gZnJvbSAnQC9jb21wb25lbnRzL0hvbWVQYWdlJ1xyXG5cclxuZXhwb3J0IGNvbnN0IFJvdXRlID0gY3JlYXRlRmlsZVJvdXRlKCcvbG9naW4nKSh7XHJcbiAgY29tcG9uZW50OiBMb2dpblBhZ2UsXHJcbn0pXHJcblxyXG5mdW5jdGlvbiBMb2dpblBhZ2UoKSB7XHJcbiAgY29uc3QgeyBvcGVuQXV0aE1vZGFsLCBpc0F1dGhlbnRpY2F0ZWQgfSA9IHVzZUF1dGgoKVxyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGlzQXV0aGVudGljYXRlZCkge1xyXG4gICAgICBuYXZpZ2F0ZSh7IHRvOiAnLycgfSlcclxuICAgICAgcmV0dXJuXHJcbiAgICB9XHJcbiAgICBvcGVuQXV0aE1vZGFsKCdsb2dpbicpXHJcbiAgfSwgW2lzQXV0aGVudGljYXRlZCwgbmF2aWdhdGUsIG9wZW5BdXRoTW9kYWxdKVxyXG5cclxuICByZXR1cm4gPEhvbWVQYWdlIC8+XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9mZWxpaS9PbmVEcml2ZS/DgXJlYSBkZSBUcmFiYWxoby9KdW5nbGUtR2FtaW5nLUNoYWxsZW5nZS9zcmMvcm91dGVzL2xvZ2luLnRzeCJ9
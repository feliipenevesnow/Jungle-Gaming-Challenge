import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/input.tsx");const React = ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(__vite__cjsImport0_react, 1);const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=7abeec5e";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/ui/input.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7abeec5e";
const Input = React.forwardRef(_c = ({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ _jsxDEV("input", {
		type,
		className: cn("flex h-10 w-full rounded-[5px] border border-[#3F2319] bg-[#140D0A]/70 px-3 py-2 font-mono text-sm text-[#F5F1EB] placeholder:text-[#B39463] focus-visible:outline-none focus-visible:border-[#D28A4C] focus-visible:ring-1 focus-visible:ring-[#D28A4C] disabled:cursor-not-allowed disabled:opacity-50 transition-colors", className),
		ref,
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 10,
		columnNumber: 7
	}, this);
});
_c2 = Input;
Input.displayName = "Input";
export { Input };
var _c, _c2;
$RefreshReg$(_c, "Input$React.forwardRef");
$RefreshReg$(_c2, "Input");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/input.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/ui/input.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/ui/input.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/ui/input.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsWUFBWSxXQUFXO0FBQ3ZCLFNBQVMsVUFBVTs7O0FBS25CLE1BQU0sUUFBUSxNQUFNLGlCQUNqQixFQUFFLFdBQVcsTUFBTSxHQUFHLFNBQVMsUUFBUTtDQUN0QyxPQUNFLHdCQUFDLFNBQUQ7RUFDUTtFQUNOLFdBQVcsR0FDVCw4VEFDQSxTQUNGO0VBQ0s7RUFDTCxHQUFJO0NBQ0w7Ozs7O0FBRUwsQ0FDRjs7QUFDQSxNQUFNLGNBQWM7QUFFcEIsU0FBUyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJpbnB1dC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IGNuIH0gZnJvbSAnQC9saWIvdXRpbHMnXHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElucHV0UHJvcHNcclxuICBleHRlbmRzIFJlYWN0LklucHV0SFRNTEF0dHJpYnV0ZXM8SFRNTElucHV0RWxlbWVudD4ge31cclxuXHJcbmNvbnN0IElucHV0ID0gUmVhY3QuZm9yd2FyZFJlZjxIVE1MSW5wdXRFbGVtZW50LCBJbnB1dFByb3BzPihcclxuICAoeyBjbGFzc05hbWUsIHR5cGUsIC4uLnByb3BzIH0sIHJlZikgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGlucHV0XHJcbiAgICAgICAgdHlwZT17dHlwZX1cclxuICAgICAgICBjbGFzc05hbWU9e2NuKFxyXG4gICAgICAgICAgJ2ZsZXggaC0xMCB3LWZ1bGwgcm91bmRlZC1bNXB4XSBib3JkZXIgYm9yZGVyLVsjM0YyMzE5XSBiZy1bIzE0MEQwQV0vNzAgcHgtMyBweS0yIGZvbnQtbW9ubyB0ZXh0LXNtIHRleHQtWyNGNUYxRUJdIHBsYWNlaG9sZGVyOnRleHQtWyNCMzk0NjNdIGZvY3VzLXZpc2libGU6b3V0bGluZS1ub25lIGZvY3VzLXZpc2libGU6Ym9yZGVyLVsjRDI4QTRDXSBmb2N1cy12aXNpYmxlOnJpbmctMSBmb2N1cy12aXNpYmxlOnJpbmctWyNEMjhBNENdIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCBkaXNhYmxlZDpvcGFjaXR5LTUwIHRyYW5zaXRpb24tY29sb3JzJyxcclxuICAgICAgICAgIGNsYXNzTmFtZVxyXG4gICAgICAgICl9XHJcbiAgICAgICAgcmVmPXtyZWZ9XHJcbiAgICAgICAgey4uLnByb3BzfVxyXG4gICAgICAvPlxyXG4gICAgKVxyXG4gIH1cclxuKVxyXG5JbnB1dC5kaXNwbGF5TmFtZSA9ICdJbnB1dCdcclxuXHJcbmV4cG9ydCB7IElucHV0IH1cclxuIl19
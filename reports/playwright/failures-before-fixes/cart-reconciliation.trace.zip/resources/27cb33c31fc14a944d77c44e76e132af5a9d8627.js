import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SummarySkeleton.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/SummarySkeleton.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7abeec5e";
export function SummarySkeleton({ label = "Carregando resumo do carrinho..." }) {
	return /* @__PURE__ */ _jsxDEV("span", {
		className: "summary-skeleton",
		role: "status",
		children: [/* @__PURE__ */ _jsxDEV("span", {
			className: "sr-only",
			children: label
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 3,
			columnNumber: 5
		}, this), [
			0,
			1,
			2,
			3
		].map((index) => /* @__PURE__ */ _jsxDEV("i", { className: "skeleton-shimmer" }, index, false, {
			fileName: _jsxFileName,
			lineNumber: 4,
			columnNumber: 32
		}, this))]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 2,
		columnNumber: 10
	}, this);
}
_c = SummarySkeleton;
var _c;
$RefreshReg$(_c, "SummarySkeleton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/SummarySkeleton.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/SummarySkeleton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/SummarySkeleton.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/SummarySkeleton.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFBQSxPQUFPLFNBQVMsZ0JBQWdCLEVBQUUsUUFBUSxzQ0FBMEQ7Q0FDbEcsT0FBTyx3QkFBQyxRQUFEO0VBQU0sV0FBVTtFQUFtQixNQUFLO1lBQXhDLENBQ0wsd0JBQUMsUUFBRDtHQUFNLFdBQVU7YUFBVztFQUFZOzs7O1lBQ3RDO0dBQUM7R0FBRztHQUFHO0dBQUc7RUFBQyxDQUFDLENBQUMsS0FBSSxVQUFTLHdCQUFDLEtBQUQsRUFBZSxXQUFVLG1CQUFvQixHQUFyQzs7OztTQUFxQyxDQUFDLENBQ3JFOzs7Ozs7QUFDUiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTdW1tYXJ5U2tlbGV0b24udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBmdW5jdGlvbiBTdW1tYXJ5U2tlbGV0b24oeyBsYWJlbCA9ICdDYXJyZWdhbmRvIHJlc3VtbyBkbyBjYXJyaW5oby4uLicgfTogeyBsYWJlbD86IHN0cmluZyB9KSB7XG4gIHJldHVybiA8c3BhbiBjbGFzc05hbWU9XCJzdW1tYXJ5LXNrZWxldG9uXCIgcm9sZT1cInN0YXR1c1wiPlxuICAgIDxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj57bGFiZWx9PC9zcGFuPlxuICAgIHtbMCwgMSwgMiwgM10ubWFwKGluZGV4ID0+IDxpIGtleT17aW5kZXh9IGNsYXNzTmFtZT1cInNrZWxldG9uLXNoaW1tZXJcIiAvPil9XG4gIDwvc3Bhbj5cbn1cbiJdfQ==
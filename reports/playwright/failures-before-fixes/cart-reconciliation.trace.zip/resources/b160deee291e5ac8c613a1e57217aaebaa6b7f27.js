import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/slider.tsx");const React = ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(__vite__cjsImport0_react, 1);const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=7abeec5e";
import * as SliderPrimitive from "/node_modules/.vite/deps/@radix-ui_react-slider.js?v=4819718b";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/ui/slider.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7abeec5e";
const Slider = React.forwardRef(_c = ({ className, ...props }, ref) => {
	const value = props.value || props.defaultValue || [0];
	return /* @__PURE__ */ _jsxDEV(SliderPrimitive.Root, {
		ref,
		className: cn("relative flex w-full touch-none select-none items-center py-2 cursor-pointer", className),
		...props,
		children: [/* @__PURE__ */ _jsxDEV(SliderPrimitive.Track, {
			className: "relative h-1.5 w-full grow overflow-hidden rounded-full bg-[#3F2319]",
			children: /* @__PURE__ */ _jsxDEV(SliderPrimitive.Range, { className: "absolute h-full bg-[#D28A4C]" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 7
		}, this), value.map((_, i) => /* @__PURE__ */ _jsxDEV(SliderPrimitive.Thumb, {
			"aria-label": i === 0 ? "Preço mínimo" : "Preço máximo",
			className: "block h-4 w-4 rounded-full border-2 border-[#140D0A] bg-[#D28A4C] ring-offset-[#140D0A] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D28A4C] focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 hover:scale-110 active:scale-95 shadow-md"
		}, i, false, {
			fileName: _jsxFileName,
			lineNumber: 24,
			columnNumber: 9
		}, this))]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 12,
		columnNumber: 5
	}, this);
});
_c2 = Slider;
Slider.displayName = SliderPrimitive.Root.displayName;
export { Slider };
var _c, _c2;
$RefreshReg$(_c, "Slider$React.forwardRef");
$RefreshReg$(_c2, "Slider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/slider.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/ui/slider.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/ui/slider.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/ui/slider.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsWUFBWSxXQUFXO0FBQ3ZCLFlBQVkscUJBQXFCO0FBQ2pDLFNBQVMsVUFBVTs7O0FBRW5CLE1BQU0sU0FBUyxNQUFNLGlCQUdsQixFQUFFLFdBQVcsR0FBRyxTQUFTLFFBQVE7Q0FDbEMsTUFBTSxRQUFRLE1BQU0sU0FBUyxNQUFNLGdCQUFnQixDQUFDLENBQUM7Q0FFckQsT0FDRSx3QkFBQyxnQkFBZ0IsTUFBakI7RUFDTztFQUNMLFdBQVcsR0FDVCxnRkFDQSxTQUNGO0VBQ0EsR0FBSTtZQU5OLENBUUUsd0JBQUMsZ0JBQWdCLE9BQWpCO0dBQXVCLFdBQVU7YUFDL0Isd0JBQUMsZ0JBQWdCLE9BQWpCLEVBQXVCLFdBQVUsK0JBQWdDOzs7OztFQUM1Qzs7OztZQUN0QixNQUFNLEtBQUssR0FBRyxNQUNiLHdCQUFDLGdCQUFnQixPQUFqQjtHQUVFLGNBQVksTUFBTSxJQUFJLGlCQUFpQjtHQUN2QyxXQUFVO0VBQ1gsR0FITTs7OztTQUdOLENBQ0YsQ0FDbUI7Ozs7OztBQUUxQixDQUFDOztBQUNELE9BQU8sY0FBYyxnQkFBZ0IsS0FBSztBQUUxQyxTQUFTIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInNsaWRlci50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnXHJcbmltcG9ydCAqIGFzIFNsaWRlclByaW1pdGl2ZSBmcm9tICdAcmFkaXgtdWkvcmVhY3Qtc2xpZGVyJ1xyXG5pbXBvcnQgeyBjbiB9IGZyb20gJ0AvbGliL3V0aWxzJ1xyXG5cclxuY29uc3QgU2xpZGVyID0gUmVhY3QuZm9yd2FyZFJlZjxcclxuICBSZWFjdC5FbGVtZW50UmVmPHR5cGVvZiBTbGlkZXJQcmltaXRpdmUuUm9vdD4sXHJcbiAgUmVhY3QuQ29tcG9uZW50UHJvcHNXaXRob3V0UmVmPHR5cGVvZiBTbGlkZXJQcmltaXRpdmUuUm9vdD5cclxuPigoeyBjbGFzc05hbWUsIC4uLnByb3BzIH0sIHJlZikgPT4ge1xyXG4gIGNvbnN0IHZhbHVlID0gcHJvcHMudmFsdWUgfHwgcHJvcHMuZGVmYXVsdFZhbHVlIHx8IFswXVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPFNsaWRlclByaW1pdGl2ZS5Sb290XHJcbiAgICAgIHJlZj17cmVmfVxyXG4gICAgICBjbGFzc05hbWU9e2NuKFxyXG4gICAgICAgICdyZWxhdGl2ZSBmbGV4IHctZnVsbCB0b3VjaC1ub25lIHNlbGVjdC1ub25lIGl0ZW1zLWNlbnRlciBweS0yIGN1cnNvci1wb2ludGVyJyxcclxuICAgICAgICBjbGFzc05hbWVcclxuICAgICAgKX1cclxuICAgICAgey4uLnByb3BzfVxyXG4gICAgPlxyXG4gICAgICA8U2xpZGVyUHJpbWl0aXZlLlRyYWNrIGNsYXNzTmFtZT1cInJlbGF0aXZlIGgtMS41IHctZnVsbCBncm93IG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLWZ1bGwgYmctWyMzRjIzMTldXCI+XHJcbiAgICAgICAgPFNsaWRlclByaW1pdGl2ZS5SYW5nZSBjbGFzc05hbWU9XCJhYnNvbHV0ZSBoLWZ1bGwgYmctWyNEMjhBNENdXCIgLz5cclxuICAgICAgPC9TbGlkZXJQcmltaXRpdmUuVHJhY2s+XHJcbiAgICAgIHt2YWx1ZS5tYXAoKF8sIGkpID0+IChcclxuICAgICAgICA8U2xpZGVyUHJpbWl0aXZlLlRodW1iXHJcbiAgICAgICAgICBrZXk9e2l9XHJcbiAgICAgICAgICBhcmlhLWxhYmVsPXtpID09PSAwID8gJ1ByZcOnbyBtw61uaW1vJyA6ICdQcmXDp28gbcOheGltbyd9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBoLTQgdy00IHJvdW5kZWQtZnVsbCBib3JkZXItMiBib3JkZXItWyMxNDBEMEFdIGJnLVsjRDI4QTRDXSByaW5nLW9mZnNldC1bIzE0MEQwQV0gdHJhbnNpdGlvbi1jb2xvcnMgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLW5vbmUgZm9jdXMtdmlzaWJsZTpyaW5nLTIgZm9jdXMtdmlzaWJsZTpyaW5nLVsjRDI4QTRDXSBmb2N1cy12aXNpYmxlOnJpbmctb2Zmc2V0LTIgZGlzYWJsZWQ6cG9pbnRlci1ldmVudHMtbm9uZSBkaXNhYmxlZDpvcGFjaXR5LTUwIGhvdmVyOnNjYWxlLTExMCBhY3RpdmU6c2NhbGUtOTUgc2hhZG93LW1kXCJcclxuICAgICAgICAvPlxyXG4gICAgICApKX1cclxuICAgIDwvU2xpZGVyUHJpbWl0aXZlLlJvb3Q+XHJcbiAgKVxyXG59KVxyXG5TbGlkZXIuZGlzcGxheU5hbWUgPSBTbGlkZXJQcmltaXRpdmUuUm9vdC5kaXNwbGF5TmFtZVxyXG5cclxuZXhwb3J0IHsgU2xpZGVyIH1cclxuIl19
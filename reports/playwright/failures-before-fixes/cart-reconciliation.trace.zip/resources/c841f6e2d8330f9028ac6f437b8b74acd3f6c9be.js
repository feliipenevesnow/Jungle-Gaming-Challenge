// Resource prefixes are stable so mutations and socket reconciliation can
// invalidate a family. Private records always include their owner.
export const keys = {
	session: (token) => ["session", token],
	nfts: (params) => ["nfts", params],
	nft: (id) => ["nft", id],
	cart: (userId) => ["cart", userId || "guest"],
	cartQuote: (userId, items, coupon) => [
		"cart-quote",
		userId || "guest",
		items,
		coupon
	],
	checkoutQuote: (userId, request) => [
		"checkout-quote",
		userId,
		request
	],
	wallets: (userId) => ["wallets", userId],
	profile: (userId) => ["profile", userId],
	favorites: (userId) => ["favorites", userId],
	order: (userId, id) => [
		"order",
		userId,
		id
	],
	attempt: (userId, id) => [
		"orders",
		userId,
		"attempt",
		id
	]
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFJQSxPQUFPLE1BQU0sT0FBTztDQUNsQixVQUFVLFVBQXlCLENBQUMsV0FBVyxLQUFLO0NBQ3BELE9BQU8sV0FBNEIsQ0FBQyxRQUFRLE1BQU07Q0FDbEQsTUFBTSxPQUFlLENBQUMsT0FBTyxFQUFFO0NBQy9CLE9BQU8sV0FBb0IsQ0FBQyxRQUFRLFVBQVUsT0FBTztDQUNyRCxZQUFZLFFBQTRCLE9BQThCLFdBQW9CO0VBQUM7RUFBYyxVQUFVO0VBQVM7RUFBTztDQUFNO0NBQ3pJLGdCQUFnQixRQUE0QixZQUEwQjtFQUFDO0VBQWtCO0VBQVE7Q0FBTztDQUN4RyxVQUFVLFdBQW9CLENBQUMsV0FBVyxNQUFNO0NBQ2hELFVBQVUsV0FBb0IsQ0FBQyxXQUFXLE1BQU07Q0FDaEQsWUFBWSxXQUFvQixDQUFDLGFBQWEsTUFBTTtDQUNwRCxRQUFRLFFBQTRCLE9BQWU7RUFBQztFQUFTO0VBQVE7Q0FBRTtDQUN2RSxVQUFVLFFBQTRCLE9BQWdCO0VBQUM7RUFBVTtFQUFRO0VBQVc7Q0FBRTtBQUN4RiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJxdWVyeS1rZXlzLnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgTkZUU2VhcmNoUGFyYW1zLCBRdW90ZVJlcXVlc3QgfSBmcm9tICdAL3R5cGVzL2FwaSdcblxuLy8gUmVzb3VyY2UgcHJlZml4ZXMgYXJlIHN0YWJsZSBzbyBtdXRhdGlvbnMgYW5kIHNvY2tldCByZWNvbmNpbGlhdGlvbiBjYW5cbi8vIGludmFsaWRhdGUgYSBmYW1pbHkuIFByaXZhdGUgcmVjb3JkcyBhbHdheXMgaW5jbHVkZSB0aGVpciBvd25lci5cbmV4cG9ydCBjb25zdCBrZXlzID0ge1xuICBzZXNzaW9uOiAodG9rZW46IHN0cmluZyB8IG51bGwpID0+IFsnc2Vzc2lvbicsIHRva2VuXSBhcyBjb25zdCxcbiAgbmZ0czogKHBhcmFtczogTkZUU2VhcmNoUGFyYW1zKSA9PiBbJ25mdHMnLCBwYXJhbXNdIGFzIGNvbnN0LFxuICBuZnQ6IChpZDogc3RyaW5nKSA9PiBbJ25mdCcsIGlkXSBhcyBjb25zdCxcbiAgY2FydDogKHVzZXJJZD86IHN0cmluZykgPT4gWydjYXJ0JywgdXNlcklkIHx8ICdndWVzdCddIGFzIGNvbnN0LFxuICBjYXJ0UXVvdGU6ICh1c2VySWQ6IHN0cmluZyB8IHVuZGVmaW5lZCwgaXRlbXM6IFF1b3RlUmVxdWVzdFsnaXRlbXMnXSwgY291cG9uPzogc3RyaW5nKSA9PiBbJ2NhcnQtcXVvdGUnLCB1c2VySWQgfHwgJ2d1ZXN0JywgaXRlbXMsIGNvdXBvbl0gYXMgY29uc3QsXG4gIGNoZWNrb3V0UXVvdGU6ICh1c2VySWQ6IHN0cmluZyB8IHVuZGVmaW5lZCwgcmVxdWVzdDogUXVvdGVSZXF1ZXN0KSA9PiBbJ2NoZWNrb3V0LXF1b3RlJywgdXNlcklkLCByZXF1ZXN0XSBhcyBjb25zdCxcbiAgd2FsbGV0czogKHVzZXJJZD86IHN0cmluZykgPT4gWyd3YWxsZXRzJywgdXNlcklkXSBhcyBjb25zdCxcbiAgcHJvZmlsZTogKHVzZXJJZD86IHN0cmluZykgPT4gWydwcm9maWxlJywgdXNlcklkXSBhcyBjb25zdCxcbiAgZmF2b3JpdGVzOiAodXNlcklkPzogc3RyaW5nKSA9PiBbJ2Zhdm9yaXRlcycsIHVzZXJJZF0gYXMgY29uc3QsXG4gIG9yZGVyOiAodXNlcklkOiBzdHJpbmcgfCB1bmRlZmluZWQsIGlkOiBzdHJpbmcpID0+IFsnb3JkZXInLCB1c2VySWQsIGlkXSBhcyBjb25zdCxcbiAgYXR0ZW1wdDogKHVzZXJJZDogc3RyaW5nIHwgdW5kZWZpbmVkLCBpZD86IHN0cmluZykgPT4gWydvcmRlcnMnLCB1c2VySWQsICdhdHRlbXB0JywgaWRdIGFzIGNvbnN0LFxufVxuIl19
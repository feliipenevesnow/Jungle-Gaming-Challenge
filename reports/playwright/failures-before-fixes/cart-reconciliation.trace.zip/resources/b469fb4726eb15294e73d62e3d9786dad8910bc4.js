import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/sheet.tsx");const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];const React = ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(__vite__cjsImport0_react, 1);import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=7abeec5e";
import * as SheetPrimitive from "/node_modules/.vite/deps/@radix-ui_react-dialog.js?v=c3b2d17a";
import { cva } from "/node_modules/.vite/deps/class-variance-authority.js?v=c618c6bd";
import { X } from "/node_modules/.vite/deps/lucide-react.js?v=c7b96d59";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/ui/sheet.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7abeec5e";
const Sheet = SheetPrimitive.Root;
const SheetTrigger = SheetPrimitive.Trigger;
const SheetClose = SheetPrimitive.Close;
const SheetPortal = SheetPrimitive.Portal;
const SheetOverlay = React.forwardRef(_c = ({ className, ...props }, ref) => /* @__PURE__ */ _jsxDEV(SheetPrimitive.Overlay, {
	className: cn("fixed inset-0 z-50 bg-[#140D0A]/80 backdrop-blur-sm data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props,
	ref
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 16,
	columnNumber: 3
}, this));
_c2 = SheetOverlay;
SheetOverlay.displayName = SheetPrimitive.Overlay.displayName;
const sheetVariants = cva("fixed z-50 gap-4 bg-[#241612] p-6 shadow-2xl transition ease-in-out data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:duration-300 data-[state=open]:duration-300 border-[#3F2319] text-[#F5F1EB] font-mono", {
	variants: { side: {
		top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
		bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
		left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
		right: "inset-y-0 right-0 h-full w-full border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-md"
	} },
	defaultVariants: { side: "right" }
});
const SheetContent = React.forwardRef(_c3 = ({ side = "right", className, children, ...props }, ref) => /* @__PURE__ */ _jsxDEV(SheetPortal, { children: [/* @__PURE__ */ _jsxDEV(SheetOverlay, {}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 55,
	columnNumber: 5
}, this), /* @__PURE__ */ _jsxDEV(SheetPrimitive.Content, {
	ref,
	className: cn(sheetVariants({ side }), className),
	...props,
	children: [children, /* @__PURE__ */ _jsxDEV(SheetPrimitive.Close, {
		className: "absolute right-4 top-4 rounded-sm p-1 text-[#CFB28C] opacity-70 transition-opacity hover:opacity-100 hover:text-[#D28A4C] focus:outline-none focus:ring-2 focus:ring-[#D28A4C]",
		children: [/* @__PURE__ */ _jsxDEV(X, { className: "h-5 w-5" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 63,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("span", {
			className: "sr-only",
			children: "Fechar"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 64,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 62,
		columnNumber: 7
	}, this)]
}, void 0, true, {
	fileName: _jsxFileName,
	lineNumber: 56,
	columnNumber: 5
}, this)] }, void 0, true, {
	fileName: _jsxFileName,
	lineNumber: 54,
	columnNumber: 3
}, this));
_c4 = SheetContent;
SheetContent.displayName = SheetPrimitive.Content.displayName;
const SheetHeader = ({ className, ...props }) => /* @__PURE__ */ _jsxDEV("div", {
	className: cn("flex flex-col space-y-2 text-center sm:text-left", className),
	...props
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 75,
	columnNumber: 3
}, this);
_c5 = SheetHeader;
SheetHeader.displayName = "SheetHeader";
const SheetFooter = ({ className, ...props }) => /* @__PURE__ */ _jsxDEV("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 89,
	columnNumber: 3
}, this);
_c6 = SheetFooter;
SheetFooter.displayName = "SheetFooter";
const SheetTitle = React.forwardRef(_c7 = ({ className, ...props }, ref) => /* @__PURE__ */ _jsxDEV(SheetPrimitive.Title, {
	ref,
	className: cn("text-lg font-bold text-[#F5F1EB]", className),
	...props
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 103,
	columnNumber: 3
}, this));
_c8 = SheetTitle;
SheetTitle.displayName = SheetPrimitive.Title.displayName;
const SheetDescription = React.forwardRef(_c9 = ({ className, ...props }, ref) => /* @__PURE__ */ _jsxDEV(SheetPrimitive.Description, {
	ref,
	className: cn("text-sm text-[#CFB28C]", className),
	...props
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 115,
	columnNumber: 3
}, this));
_c10 = SheetDescription;
SheetDescription.displayName = SheetPrimitive.Description.displayName;
export { Sheet, SheetPortal, SheetOverlay, SheetTrigger, SheetClose, SheetContent, SheetHeader, SheetFooter, SheetTitle, SheetDescription };
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10;
$RefreshReg$(_c, "SheetOverlay$React.forwardRef");
$RefreshReg$(_c2, "SheetOverlay");
$RefreshReg$(_c3, "SheetContent$React.forwardRef");
$RefreshReg$(_c4, "SheetContent");
$RefreshReg$(_c5, "SheetHeader");
$RefreshReg$(_c6, "SheetFooter");
$RefreshReg$(_c7, "SheetTitle$React.forwardRef");
$RefreshReg$(_c8, "SheetTitle");
$RefreshReg$(_c9, "SheetDescription$React.forwardRef");
$RefreshReg$(_c10, "SheetDescription");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/sheet.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/ui/sheet.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/ui/sheet.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/ui/sheet.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsWUFBWSxXQUFXO0FBQ3ZCLFlBQVksb0JBQW9CO0FBQ2hDLFNBQVMsV0FBOEI7QUFDdkMsU0FBUyxTQUFTO0FBQ2xCLFNBQVMsVUFBVTs7O0FBRW5CLE1BQU0sUUFBUSxlQUFlO0FBQzdCLE1BQU0sZUFBZSxlQUFlO0FBQ3BDLE1BQU0sYUFBYSxlQUFlO0FBQ2xDLE1BQU0sY0FBYyxlQUFlO0FBRW5DLE1BQU0sZUFBZSxNQUFNLGlCQUd4QixFQUFFLFdBQVcsR0FBRyxTQUFTLFFBQzFCLHdCQUFDLGVBQWUsU0FBaEI7Q0FDRSxXQUFXLEdBQ1QsK0tBQ0EsU0FDRjtDQUNBLEdBQUk7Q0FDQztBQUNOOzs7O1FBQ0Y7O0FBQ0QsYUFBYSxjQUFjLGVBQWUsUUFBUTtBQUVsRCxNQUFNLGdCQUFnQixJQUNwQiw4T0FDQTtDQUNFLFVBQVUsRUFDUixNQUFNO0VBQ0osS0FBSztFQUNMLFFBQ0U7RUFDRixNQUFNO0VBQ04sT0FDRTtDQUNKLEVBQ0Y7Q0FDQSxpQkFBaUIsRUFDZixNQUFNLFFBQ1I7QUFDRixDQUNGO0FBTUEsTUFBTSxlQUFlLE1BQU0sa0JBR3hCLEVBQUUsT0FBTyxTQUFTLFdBQVcsVUFBVSxHQUFHLFNBQVMsUUFDcEQsd0JBQUMsYUFBRCxhQUNFLHdCQUFDLGNBQUQsQ0FBZTs7OztVQUNmLHdCQUFDLGVBQWUsU0FBaEI7Q0FDTztDQUNMLFdBQVcsR0FBRyxjQUFjLEVBQUUsS0FBSyxDQUFDLEdBQUcsU0FBUztDQUNoRCxHQUFJO1dBSE4sQ0FLRyxVQUNELHdCQUFDLGVBQWUsT0FBaEI7RUFBc0IsV0FBVTtZQUFoQyxDQUNFLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7WUFDeEIsd0JBQUMsUUFBRDtHQUFNLFdBQVU7YUFBVTtFQUFZOzs7O1VBQ2xCOzs7OztTQUNBOzs7OztRQUNiOzs7O1FBQ2Q7O0FBQ0QsYUFBYSxjQUFjLGVBQWUsUUFBUTtBQUVsRCxNQUFNLGVBQWUsRUFDbkIsV0FDQSxHQUFHLFlBRUgsd0JBQUMsT0FBRDtDQUNFLFdBQVcsR0FDVCxvREFDQSxTQUNGO0NBQ0EsR0FBSTtBQUNMOzs7Ozs7QUFFSCxZQUFZLGNBQWM7QUFFMUIsTUFBTSxlQUFlLEVBQ25CLFdBQ0EsR0FBRyxZQUVILHdCQUFDLE9BQUQ7Q0FDRSxXQUFXLEdBQ1QsaUVBQ0EsU0FDRjtDQUNBLEdBQUk7QUFDTDs7Ozs7O0FBRUgsWUFBWSxjQUFjO0FBRTFCLE1BQU0sYUFBYSxNQUFNLGtCQUd0QixFQUFFLFdBQVcsR0FBRyxTQUFTLFFBQzFCLHdCQUFDLGVBQWUsT0FBaEI7Q0FDTztDQUNMLFdBQVcsR0FBRyxvQ0FBb0MsU0FBUztDQUMzRCxHQUFJO0FBQ0w7Ozs7UUFDRjs7QUFDRCxXQUFXLGNBQWMsZUFBZSxNQUFNO0FBRTlDLE1BQU0sbUJBQW1CLE1BQU0sa0JBRzVCLEVBQUUsV0FBVyxHQUFHLFNBQVMsUUFDMUIsd0JBQUMsZUFBZSxhQUFoQjtDQUNPO0NBQ0wsV0FBVyxHQUFHLDBCQUEwQixTQUFTO0NBQ2pELEdBQUk7QUFDTDs7OztRQUNGOztBQUNELGlCQUFpQixjQUFjLGVBQWUsWUFBWTtBQUUxRCxTQUNFLE9BQ0EsYUFDQSxjQUNBLGNBQ0EsWUFDQSxjQUNBLGFBQ0EsYUFDQSxZQUNBIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInNoZWV0LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCdcclxuaW1wb3J0ICogYXMgU2hlZXRQcmltaXRpdmUgZnJvbSAnQHJhZGl4LXVpL3JlYWN0LWRpYWxvZydcclxuaW1wb3J0IHsgY3ZhLCB0eXBlIFZhcmlhbnRQcm9wcyB9IGZyb20gJ2NsYXNzLXZhcmlhbmNlLWF1dGhvcml0eSdcclxuaW1wb3J0IHsgWCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcclxuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi91dGlscydcclxuXHJcbmNvbnN0IFNoZWV0ID0gU2hlZXRQcmltaXRpdmUuUm9vdFxyXG5jb25zdCBTaGVldFRyaWdnZXIgPSBTaGVldFByaW1pdGl2ZS5UcmlnZ2VyXHJcbmNvbnN0IFNoZWV0Q2xvc2UgPSBTaGVldFByaW1pdGl2ZS5DbG9zZVxyXG5jb25zdCBTaGVldFBvcnRhbCA9IFNoZWV0UHJpbWl0aXZlLlBvcnRhbFxyXG5cclxuY29uc3QgU2hlZXRPdmVybGF5ID0gUmVhY3QuZm9yd2FyZFJlZjxcclxuICBSZWFjdC5FbGVtZW50UmVmPHR5cGVvZiBTaGVldFByaW1pdGl2ZS5PdmVybGF5PixcclxuICBSZWFjdC5Db21wb25lbnRQcm9wc1dpdGhvdXRSZWY8dHlwZW9mIFNoZWV0UHJpbWl0aXZlLk92ZXJsYXk+XHJcbj4oKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9LCByZWYpID0+IChcclxuICA8U2hlZXRQcmltaXRpdmUuT3ZlcmxheVxyXG4gICAgY2xhc3NOYW1lPXtjbihcclxuICAgICAgJ2ZpeGVkIGluc2V0LTAgei01MCBiZy1bIzE0MEQwQV0vODAgYmFja2Ryb3AtYmx1ci1zbSBkYXRhLVtzdGF0ZT1vcGVuXTphbmltYXRlLWluIGRhdGEtW3N0YXRlPWNsb3NlZF06YW5pbWF0ZS1vdXQgZGF0YS1bc3RhdGU9Y2xvc2VkXTpmYWRlLW91dC0wIGRhdGEtW3N0YXRlPW9wZW5dOmZhZGUtaW4tMCcsXHJcbiAgICAgIGNsYXNzTmFtZVxyXG4gICAgKX1cclxuICAgIHsuLi5wcm9wc31cclxuICAgIHJlZj17cmVmfVxyXG4gIC8+XHJcbikpXHJcblNoZWV0T3ZlcmxheS5kaXNwbGF5TmFtZSA9IFNoZWV0UHJpbWl0aXZlLk92ZXJsYXkuZGlzcGxheU5hbWVcclxuXHJcbmNvbnN0IHNoZWV0VmFyaWFudHMgPSBjdmEoXHJcbiAgJ2ZpeGVkIHotNTAgZ2FwLTQgYmctWyMyNDE2MTJdIHAtNiBzaGFkb3ctMnhsIHRyYW5zaXRpb24gZWFzZS1pbi1vdXQgZGF0YS1bc3RhdGU9b3Blbl06YW5pbWF0ZS1pbiBkYXRhLVtzdGF0ZT1jbG9zZWRdOmFuaW1hdGUtb3V0IGRhdGEtW3N0YXRlPWNsb3NlZF06ZHVyYXRpb24tMzAwIGRhdGEtW3N0YXRlPW9wZW5dOmR1cmF0aW9uLTMwMCBib3JkZXItWyMzRjIzMTldIHRleHQtWyNGNUYxRUJdIGZvbnQtbW9ubycsXHJcbiAge1xyXG4gICAgdmFyaWFudHM6IHtcclxuICAgICAgc2lkZToge1xyXG4gICAgICAgIHRvcDogJ2luc2V0LXgtMCB0b3AtMCBib3JkZXItYiBkYXRhLVtzdGF0ZT1jbG9zZWRdOnNsaWRlLW91dC10by10b3AgZGF0YS1bc3RhdGU9b3Blbl06c2xpZGUtaW4tZnJvbS10b3AnLFxyXG4gICAgICAgIGJvdHRvbTpcclxuICAgICAgICAgICdpbnNldC14LTAgYm90dG9tLTAgYm9yZGVyLXQgZGF0YS1bc3RhdGU9Y2xvc2VkXTpzbGlkZS1vdXQtdG8tYm90dG9tIGRhdGEtW3N0YXRlPW9wZW5dOnNsaWRlLWluLWZyb20tYm90dG9tJyxcclxuICAgICAgICBsZWZ0OiAnaW5zZXQteS0wIGxlZnQtMCBoLWZ1bGwgdy0zLzQgYm9yZGVyLXIgZGF0YS1bc3RhdGU9Y2xvc2VkXTpzbGlkZS1vdXQtdG8tbGVmdCBkYXRhLVtzdGF0ZT1vcGVuXTpzbGlkZS1pbi1mcm9tLWxlZnQgc206bWF4LXctc20nLFxyXG4gICAgICAgIHJpZ2h0OlxyXG4gICAgICAgICAgJ2luc2V0LXktMCByaWdodC0wIGgtZnVsbCB3LWZ1bGwgYm9yZGVyLWwgZGF0YS1bc3RhdGU9Y2xvc2VkXTpzbGlkZS1vdXQtdG8tcmlnaHQgZGF0YS1bc3RhdGU9b3Blbl06c2xpZGUtaW4tZnJvbS1yaWdodCBzbTptYXgtdy1tZCcsXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgZGVmYXVsdFZhcmlhbnRzOiB7XHJcbiAgICAgIHNpZGU6ICdyaWdodCcsXHJcbiAgICB9LFxyXG4gIH1cclxuKVxyXG5cclxuaW50ZXJmYWNlIFNoZWV0Q29udGVudFByb3BzXHJcbiAgZXh0ZW5kcyBSZWFjdC5Db21wb25lbnRQcm9wc1dpdGhvdXRSZWY8dHlwZW9mIFNoZWV0UHJpbWl0aXZlLkNvbnRlbnQ+LFxyXG4gICAgVmFyaWFudFByb3BzPHR5cGVvZiBzaGVldFZhcmlhbnRzPiB7fVxyXG5cclxuY29uc3QgU2hlZXRDb250ZW50ID0gUmVhY3QuZm9yd2FyZFJlZjxcclxuICBSZWFjdC5FbGVtZW50UmVmPHR5cGVvZiBTaGVldFByaW1pdGl2ZS5Db250ZW50PixcclxuICBTaGVldENvbnRlbnRQcm9wc1xyXG4+KCh7IHNpZGUgPSAncmlnaHQnLCBjbGFzc05hbWUsIGNoaWxkcmVuLCAuLi5wcm9wcyB9LCByZWYpID0+IChcclxuICA8U2hlZXRQb3J0YWw+XHJcbiAgICA8U2hlZXRPdmVybGF5IC8+XHJcbiAgICA8U2hlZXRQcmltaXRpdmUuQ29udGVudFxyXG4gICAgICByZWY9e3JlZn1cclxuICAgICAgY2xhc3NOYW1lPXtjbihzaGVldFZhcmlhbnRzKHsgc2lkZSB9KSwgY2xhc3NOYW1lKX1cclxuICAgICAgey4uLnByb3BzfVxyXG4gICAgPlxyXG4gICAgICB7Y2hpbGRyZW59XHJcbiAgICAgIDxTaGVldFByaW1pdGl2ZS5DbG9zZSBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC00IHRvcC00IHJvdW5kZWQtc20gcC0xIHRleHQtWyNDRkIyOENdIG9wYWNpdHktNzAgdHJhbnNpdGlvbi1vcGFjaXR5IGhvdmVyOm9wYWNpdHktMTAwIGhvdmVyOnRleHQtWyNEMjhBNENdIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bI0QyOEE0Q11cIj5cclxuICAgICAgICA8WCBjbGFzc05hbWU9XCJoLTUgdy01XCIgLz5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCI+RmVjaGFyPC9zcGFuPlxyXG4gICAgICA8L1NoZWV0UHJpbWl0aXZlLkNsb3NlPlxyXG4gICAgPC9TaGVldFByaW1pdGl2ZS5Db250ZW50PlxyXG4gIDwvU2hlZXRQb3J0YWw+XHJcbikpXHJcblNoZWV0Q29udGVudC5kaXNwbGF5TmFtZSA9IFNoZWV0UHJpbWl0aXZlLkNvbnRlbnQuZGlzcGxheU5hbWVcclxuXHJcbmNvbnN0IFNoZWV0SGVhZGVyID0gKHtcclxuICBjbGFzc05hbWUsXHJcbiAgLi4ucHJvcHNcclxufTogUmVhY3QuSFRNTEF0dHJpYnV0ZXM8SFRNTERpdkVsZW1lbnQ+KSA9PiAoXHJcbiAgPGRpdlxyXG4gICAgY2xhc3NOYW1lPXtjbihcclxuICAgICAgJ2ZsZXggZmxleC1jb2wgc3BhY2UteS0yIHRleHQtY2VudGVyIHNtOnRleHQtbGVmdCcsXHJcbiAgICAgIGNsYXNzTmFtZVxyXG4gICAgKX1cclxuICAgIHsuLi5wcm9wc31cclxuICAvPlxyXG4pXHJcblNoZWV0SGVhZGVyLmRpc3BsYXlOYW1lID0gJ1NoZWV0SGVhZGVyJ1xyXG5cclxuY29uc3QgU2hlZXRGb290ZXIgPSAoe1xyXG4gIGNsYXNzTmFtZSxcclxuICAuLi5wcm9wc1xyXG59OiBSZWFjdC5IVE1MQXR0cmlidXRlczxIVE1MRGl2RWxlbWVudD4pID0+IChcclxuICA8ZGl2XHJcbiAgICBjbGFzc05hbWU9e2NuKFxyXG4gICAgICAnZmxleCBmbGV4LWNvbC1yZXZlcnNlIHNtOmZsZXgtcm93IHNtOmp1c3RpZnktZW5kIHNtOnNwYWNlLXgtMicsXHJcbiAgICAgIGNsYXNzTmFtZVxyXG4gICAgKX1cclxuICAgIHsuLi5wcm9wc31cclxuICAvPlxyXG4pXHJcblNoZWV0Rm9vdGVyLmRpc3BsYXlOYW1lID0gJ1NoZWV0Rm9vdGVyJ1xyXG5cclxuY29uc3QgU2hlZXRUaXRsZSA9IFJlYWN0LmZvcndhcmRSZWY8XHJcbiAgUmVhY3QuRWxlbWVudFJlZjx0eXBlb2YgU2hlZXRQcmltaXRpdmUuVGl0bGU+LFxyXG4gIFJlYWN0LkNvbXBvbmVudFByb3BzV2l0aG91dFJlZjx0eXBlb2YgU2hlZXRQcmltaXRpdmUuVGl0bGU+XHJcbj4oKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9LCByZWYpID0+IChcclxuICA8U2hlZXRQcmltaXRpdmUuVGl0bGVcclxuICAgIHJlZj17cmVmfVxyXG4gICAgY2xhc3NOYW1lPXtjbigndGV4dC1sZyBmb250LWJvbGQgdGV4dC1bI0Y1RjFFQl0nLCBjbGFzc05hbWUpfVxyXG4gICAgey4uLnByb3BzfVxyXG4gIC8+XHJcbikpXHJcblNoZWV0VGl0bGUuZGlzcGxheU5hbWUgPSBTaGVldFByaW1pdGl2ZS5UaXRsZS5kaXNwbGF5TmFtZVxyXG5cclxuY29uc3QgU2hlZXREZXNjcmlwdGlvbiA9IFJlYWN0LmZvcndhcmRSZWY8XHJcbiAgUmVhY3QuRWxlbWVudFJlZjx0eXBlb2YgU2hlZXRQcmltaXRpdmUuRGVzY3JpcHRpb24+LFxyXG4gIFJlYWN0LkNvbXBvbmVudFByb3BzV2l0aG91dFJlZjx0eXBlb2YgU2hlZXRQcmltaXRpdmUuRGVzY3JpcHRpb24+XHJcbj4oKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9LCByZWYpID0+IChcclxuICA8U2hlZXRQcmltaXRpdmUuRGVzY3JpcHRpb25cclxuICAgIHJlZj17cmVmfVxyXG4gICAgY2xhc3NOYW1lPXtjbigndGV4dC1zbSB0ZXh0LVsjQ0ZCMjhDXScsIGNsYXNzTmFtZSl9XHJcbiAgICB7Li4ucHJvcHN9XHJcbiAgLz5cclxuKSlcclxuU2hlZXREZXNjcmlwdGlvbi5kaXNwbGF5TmFtZSA9IFNoZWV0UHJpbWl0aXZlLkRlc2NyaXB0aW9uLmRpc3BsYXlOYW1lXHJcblxyXG5leHBvcnQge1xyXG4gIFNoZWV0LFxyXG4gIFNoZWV0UG9ydGFsLFxyXG4gIFNoZWV0T3ZlcmxheSxcclxuICBTaGVldFRyaWdnZXIsXHJcbiAgU2hlZXRDbG9zZSxcclxuICBTaGVldENvbnRlbnQsXHJcbiAgU2hlZXRIZWFkZXIsXHJcbiAgU2hlZXRGb290ZXIsXHJcbiAgU2hlZXRUaXRsZSxcclxuICBTaGVldERlc2NyaXB0aW9uLFxyXG59XHJcbiJdfQ==
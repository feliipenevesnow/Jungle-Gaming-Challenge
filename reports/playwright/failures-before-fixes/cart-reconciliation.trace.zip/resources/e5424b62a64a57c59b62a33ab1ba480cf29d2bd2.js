import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AuthModal.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport9_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=7abeec5e";
import { Eye, EyeOff, AlertCircle, Info } from "/node_modules/.vite/deps/lucide-react.js?v=c7b96d59";
import { isAxiosError } from "/node_modules/.vite/deps/axios.js?v=6e1d6a79";
import { apiErrorMessage } from "/src/lib/api-error.ts";
import { useAuth } from "/src/lib/auth.tsx?t=1792165206673";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "/src/components/ui/dialog.tsx?t=1792166201444";
import { Button } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { Label } from "/src/components/ui/label.tsx";
var _jsxFileName = "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/AuthModal.tsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7abeec5e";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
export function AuthModal() {
	_s();
	const { isAuthModalOpen, authModalMode } = useAuth();
	return isAuthModalOpen ? /* @__PURE__ */ _jsxDEV(AuthModalForm, {}, authModalMode, false, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 28
	}, this) : null;
}
_s(AuthModal, "K54qNQtKVRxM+NYFrIWr/xhU8Qk=", false, function() {
	return [useAuth];
});
_c = AuthModal;
function AuthModalForm() {
	_s2();
	const { isAuthModalOpen, closeAuthModal, authModalMode, login, register, restoreAuthFocus } = useAuth();
	const [mode, setMode] = useState(authModalMode);
	const [name, setName] = useState("");
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const [confirmation, setConfirmation] = useState("");
	const [showPassword, setShowPassword] = useState(false);
	const [isSubmitting, setIsSubmitting] = useState(false);
	const [errorMessage, setErrorMessage] = useState(null);
	const [socialNotice, setSocialNotice] = useState(null);
	const handleSubmit = async (e) => {
		e.preventDefault();
		setErrorMessage(null);
		setSocialNotice(null);
		setIsSubmitting(true);
		try {
			if (mode === "login") {
				await login({
					email,
					password
				});
			} else {
				if (!name.trim()) {
					setErrorMessage("Por favor, informe seu nome completo.");
					setIsSubmitting(false);
					return;
				}
				if (password !== confirmation) {
					setErrorMessage("A confirmação de senha não confere.");
					return;
				}
				await register({
					name,
					email,
					password
				});
			}
		} catch (err) {
			const status = isAxiosError(err) ? err.response?.status : undefined;
			if (status === 401) {
				setErrorMessage("Credenciais inválidas. Verifique seu e-mail e senha.");
			} else if (status === 409) {
				setErrorMessage("Este e-mail já está cadastrado na plataforma.");
			} else {
				setErrorMessage(apiErrorMessage(err, "Erro ao processar autenticação. Tente novamente."));
			}
		} finally {
			setIsSubmitting(false);
		}
	};
	const handleUnavailableAction = (actionName) => {
		setErrorMessage(null);
		setSocialNotice(`${actionName} não disponível no ambiente demonstrativo.`);
	};
	return /* @__PURE__ */ _jsxDEV(Dialog, {
		open: isAuthModalOpen,
		onOpenChange: (open) => !open && closeAuthModal(),
		children: /* @__PURE__ */ _jsxDEV(DialogContent, {
			"data-mode": mode,
			onCloseAutoFocus: (event) => {
				event.preventDefault();
				restoreAuthFocus();
			},
			className: "auth-dialog w-full max-w-[500px] p-0 overflow-hidden bg-[#241612] border border-[#3F2319] shadow-2xl rounded-xl",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "auth-mobile-brand",
					children: "KURIO"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 69,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "auth-mobile-title",
					children: mode === "login" ? "Entrar" : "Criar perfil de colecionador"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 70,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "auth-heading pt-10 pb-6 px-10 text-center",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-center gap-3",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setMode("login");
										setErrorMessage(null);
										setSocialNotice(null);
									},
									className: `text-xl font-mono transition-colors cursor-pointer ${mode === "login" ? "text-[#E89B55] font-bold border-b-2 border-[#D28A4C] pb-0.5" : "text-[#F5F1EB] hover:text-[#CFB28C]"}`,
									children: "Entrar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 75,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[#F0805F] font-mono text-lg font-bold",
									children: "|"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 90,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setMode("register");
										setErrorMessage(null);
										setSocialNotice(null);
									},
									className: `text-xl font-mono transition-colors cursor-pointer ${mode === "register" ? "text-[#E89B55] font-bold border-b-2 border-[#D28A4C] pb-0.5" : "text-[#F5F1EB] hover:text-[#CFB28C]"}`,
									children: "Criar conta"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 91,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 74,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(DialogTitle, {
							className: "sr-only",
							children: mode === "login" ? "Entrar no Kurio" : "Criar conta no Kurio"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 108,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(DialogDescription, {
							className: "mt-3 text-xs font-mono text-[#CFB28C] leading-relaxed max-w-sm mx-auto",
							children: mode === "login" ? "Entre para gerenciar sua carteira, coleção e perfil de criador." : "Crie sua conta para colecionar e gerenciar arte digital verificada."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 112,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 72,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("form", {
					onSubmit: handleSubmit,
					className: "auth-form px-10 pb-6 space-y-4",
					children: [
						errorMessage && /* @__PURE__ */ _jsxDEV("div", {
							id: "auth-error",
							role: "alert",
							className: "flex items-start gap-2 p-3 rounded-md bg-[#F0805F]/15 border border-[#F0805F]/40 text-[#F0805F] text-xs font-mono",
							children: [/* @__PURE__ */ _jsxDEV(AlertCircle, { className: "w-4 h-4 shrink-0 mt-0.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 123,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: errorMessage }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 124,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 122,
							columnNumber: 13
						}, this),
						socialNotice && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-start gap-2 p-3 rounded-md bg-[#D28A4C]/15 border border-[#D28A4C]/40 text-[#E89B55] text-xs font-mono",
							children: [/* @__PURE__ */ _jsxDEV(Info, { className: "w-4 h-4 shrink-0 mt-0.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 130,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: socialNotice }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 131,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 129,
							columnNumber: 13
						}, this),
						mode === "register" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ _jsxDEV(Label, {
								htmlFor: "auth-name",
								children: "Nome completo"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 137,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV(Input, {
								id: "auth-name",
								"aria-describedby": errorMessage ? "auth-error" : undefined,
								type: "text",
								required: true,
								placeholder: "Nome de usuário",
								value: name,
								onChange: (e) => setName(e.target.value),
								disabled: isSubmitting,
								className: "h-11"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 138,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 136,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ _jsxDEV(Label, {
								htmlFor: "auth-email",
								children: "E-mail"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 152,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(Input, {
								"aria-describedby": errorMessage ? "auth-error" : undefined,
								id: "auth-email",
								type: "email",
								required: true,
								placeholder: mode === "login" ? "contato@email.com" : "Digite seu e-mail",
								value: email,
								onChange: (e) => setEmail(e.target.value),
								disabled: isSubmitting,
								className: "h-11"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 153,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 151,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ _jsxDEV(Label, {
								htmlFor: "auth-password",
								children: "Senha"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 166,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "relative",
								children: [/* @__PURE__ */ _jsxDEV(Input, {
									"aria-describedby": errorMessage ? "auth-error" : undefined,
									minLength: mode === "register" ? 6 : undefined,
									autoComplete: mode === "register" ? "new-password" : "current-password",
									id: "auth-password",
									type: showPassword ? "text" : "password",
									required: true,
									placeholder: mode === "login" ? "***********" : "Senha",
									value: password,
									onChange: (e) => setPassword(e.target.value),
									disabled: isSubmitting,
									className: "h-11 pr-10"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 168,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setShowPassword(!showPassword),
									className: "absolute right-3 top-1/2 -translate-y-1/2 text-[#CFB28C] hover:text-[#D28A4C] p-1",
									children: [showPassword ? /* @__PURE__ */ _jsxDEV(EyeOff, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 184,
										columnNumber: 33
									}, this) : /* @__PURE__ */ _jsxDEV(Eye, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 184,
										columnNumber: 66
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "sr-only",
										children: "Alternar visualização de senha"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 185,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 178,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 167,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 165,
							columnNumber: 11
						}, this),
						mode === "register" && /* @__PURE__ */ _jsxDEV("div", {
							className: "relative",
							children: [
								/* @__PURE__ */ _jsxDEV(Label, {
									className: "sr-only",
									htmlFor: "auth-confirm",
									children: "Confirmar senha"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 190,
									columnNumber: 61
								}, this),
								/* @__PURE__ */ _jsxDEV(Input, {
									id: "auth-confirm",
									"aria-describedby": errorMessage ? "auth-error" : undefined,
									type: showPassword ? "text" : "password",
									required: true,
									placeholder: "Confirmar senha",
									value: confirmation,
									onChange: (e) => setConfirmation(e.target.value)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 190,
									columnNumber: 134
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									className: "auth-confirm-eye",
									"aria-label": "Mostrar confirmação de senha",
									onClick: () => setShowPassword(!showPassword),
									children: /* @__PURE__ */ _jsxDEV(EyeOff, { size: 16 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 190,
										columnNumber: 510
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 190,
									columnNumber: 370
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 190,
							columnNumber: 35
						}, this),
						mode === "login" && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex justify-end pt-0.5",
							children: /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => handleUnavailableAction("Recuperação de senha"),
								className: "text-xs font-mono text-[#E89B55] hover:underline",
								children: "Esqueceu a senha?"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 193,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 192,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(Button, {
							type: "submit",
							disabled: isSubmitting,
							className: "w-full h-11 bg-[#D28A4C] hover:bg-[#E89B55] text-[#140D0A] font-bold text-sm tracking-wider uppercase mt-2",
							children: isSubmitting ? /* @__PURE__ */ _jsxDEV("span", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-4 h-4 border-2 border-[#140D0A] border-t-transparent rounded-full animate-spin" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 210,
									columnNumber: 17
								}, this), "Processando..."]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 209,
								columnNumber: 15
							}, this) : mode === "login" ? "Entrar" : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "auth-desktop-submit",
								children: "Criar conta"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 216,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "auth-mobile-submit",
								children: "Criar perfil"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 216,
								columnNumber: 73
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 216,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 203,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "pt-2",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "relative flex items-center justify-center",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { className: "border-t border-[#3F2319] w-full" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 223,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "bg-[#241612] px-3 text-[11px] font-mono text-[#CFB28C] uppercase tracking-wider shrink-0",
										children: "Ou continue com"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 224,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { className: "border-t border-[#3F2319] w-full" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 227,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 222,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "mt-3 space-y-2",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => handleUnavailableAction("Login com Google"),
									className: "w-full h-10 flex items-center justify-center gap-3 rounded-[5px] border border-[#3F2319] bg-[#140D0A]/50 hover:bg-[#2F1D15] text-[#CFB28C] hover:text-[#F5F1EB] font-mono text-xs transition-colors",
									children: [/* @__PURE__ */ _jsxDEV("svg", {
										className: "w-4 h-4",
										viewBox: "0 0 24 24",
										children: [
											/* @__PURE__ */ _jsxDEV("path", {
												fill: "#EA4335",
												d: "M12 5c1.6 0 3 .6 4.1 1.6l3.1-3.1C17.3 1.7 14.8 1 12 1 7.5 1 3.7 3.6 1.9 7.4l3.7 2.9C6.5 7.4 8.9 5 12 5z"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 237,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("path", {
												fill: "#4285F4",
												d: "M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5 3.7-8.8z"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 241,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("path", {
												fill: "#FBBC05",
												d: "M5.6 14.7c-.2-.7-.4-1.5-.4-2.7s.2-2 .4-2.7L1.9 6.4C.7 8.8 0 10.3 0 12s.7 3.2 1.9 5.6l3.7-2.9z"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 245,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("path", {
												fill: "#34A853",
												d: "M12 23c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3.1 0-5.5-2.4-6.4-5.3L1.9 16C3.7 19.8 7.5 23 12 23z"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 249,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 236,
										columnNumber: 17
									}, this), "Continuar com Google"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 231,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => handleUnavailableAction("Login com Facebook"),
									className: "w-full h-10 flex items-center justify-center gap-3 rounded-[5px] border border-[#3F2319] bg-[#140D0A]/50 hover:bg-[#2F1D15] text-[#CFB28C] hover:text-[#F5F1EB] font-mono text-xs transition-colors",
									children: [/* @__PURE__ */ _jsxDEV("svg", {
										className: "w-4 h-4 fill-[#1877F2]",
										viewBox: "0 0 24 24",
										children: /* @__PURE__ */ _jsxDEV("path", { d: "M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 263,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 262,
										columnNumber: 17
									}, this), "Continuar com Facebook"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 257,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 230,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 221,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "auth-switch-mobile",
							onClick: () => {
								setMode(mode === "login" ? "register" : "login");
								setErrorMessage(null);
							},
							children: mode === "login" ? "Novo na Kurio? Crie uma conta" : "Já tem uma conta? Entre"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 270,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 120,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { className: "h-[10px] w-full bg-[#D28A4C]" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 274,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 68,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 67,
		columnNumber: 5
	}, this);
}
_s2(AuthModalForm, "wFeriBmymXRUw8hSXTeV4zhwYR0=", false, function() {
	return [useAuth];
});
_c2 = AuthModalForm;
var _c, _c2;
$RefreshReg$(_c, "AuthModal");
$RefreshReg$(_c2, "AuthModalForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/AuthModal.tsx?t=1792166201444";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/AuthModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/AuthModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/AuthModal.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLEtBQUssUUFBUSxhQUFhLFlBQVk7QUFDL0MsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsUUFBUSxlQUFlLGFBQWEseUJBQXlCO0FBQ3RFLFNBQVMsY0FBYztBQUN2QixTQUFTLGFBQWE7QUFDdEIsU0FBUyxhQUFhOzs7O0FBRXRCLE9BQU8sU0FBUyxZQUFZOztDQUMxQixNQUFNLEVBQUUsaUJBQWlCLGtCQUFrQixRQUFRO0NBQ25ELE9BQU8sa0JBQWtCLHdCQUFDLGVBQUQsQ0FBb0MsR0FBaEI7Ozs7UUFBZ0IsSUFBSTtBQUNuRTs7Ozs7QUFDQSxTQUFTLGdCQUFnQjs7Q0FDdkIsTUFBTSxFQUFFLGlCQUFpQixnQkFBZ0IsZUFBZSxPQUFPLFVBQVUscUJBQXFCLFFBQVE7Q0FHdEcsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUErQixhQUFhO0NBQ3BFLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxFQUFFO0NBQ25DLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxFQUFFO0NBQzNDLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLEVBQUU7Q0FDbkQsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsS0FBSztDQUN0RCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxLQUFLO0NBQ3RELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUF3QixJQUFJO0NBQ3BFLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUF3QixJQUFJO0NBRXBFLE1BQU0sZUFBZSxPQUFPLE1BQXVCO0VBQ2pELEVBQUUsZUFBZTtFQUNqQixnQkFBZ0IsSUFBSTtFQUNwQixnQkFBZ0IsSUFBSTtFQUNwQixnQkFBZ0IsSUFBSTtFQUVwQixJQUFJO0dBQ0YsSUFBSSxTQUFTLFNBQVM7SUFDcEIsTUFBTSxNQUFNO0tBQUU7S0FBTztJQUFTLENBQUM7R0FDakMsT0FBTztJQUNMLElBQUksQ0FBQyxLQUFLLEtBQUssR0FBRztLQUNoQixnQkFBZ0IsdUNBQXVDO0tBQ3ZELGdCQUFnQixLQUFLO0tBQ3JCO0lBQ0Y7SUFDQSxJQUFJLGFBQWEsY0FBYztLQUFFLGdCQUFnQixxQ0FBcUM7S0FBRztJQUFPO0lBQ2hHLE1BQU0sU0FBUztLQUFFO0tBQU07S0FBTztJQUFTLENBQUM7R0FDMUM7RUFDRixTQUFTLEtBQWM7R0FDckIsTUFBTSxTQUFTLGFBQWEsR0FBRyxJQUFJLElBQUksVUFBVSxTQUFTO0dBQzFELElBQUksV0FBVyxLQUFLO0lBQ2xCLGdCQUFnQixzREFBc0Q7R0FDeEUsT0FBTyxJQUFJLFdBQVcsS0FBSztJQUN6QixnQkFBZ0IsK0NBQStDO0dBQ2pFLE9BQU87SUFDTCxnQkFBZ0IsZ0JBQWdCLEtBQUssa0RBQWtELENBQUM7R0FDMUY7RUFDRixVQUFVO0dBQ1IsZ0JBQWdCLEtBQUs7RUFDdkI7Q0FDRjtDQUVBLE1BQU0sMkJBQTJCLGVBQXVCO0VBQ3RELGdCQUFnQixJQUFJO0VBQ3BCLGdCQUFnQixHQUFHLFdBQVcsMkNBQTJDO0NBQzNFO0NBRUEsT0FDRSx3QkFBQyxRQUFEO0VBQVEsTUFBTTtFQUFpQixlQUFlLFNBQVMsQ0FBQyxRQUFRLGVBQWU7WUFDN0Usd0JBQUMsZUFBRDtHQUFlLGFBQVc7R0FBTSxtQkFBa0IsVUFBUztJQUFFLE1BQU0sZUFBZTtJQUFHLGlCQUFpQjtHQUFFO0dBQUcsV0FBVTthQUFySDtJQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQW9CO0lBQVU7Ozs7O0lBQzdDLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQXFCLFNBQVMsVUFBVSxXQUFXO0lBQW9DOzs7OztJQUV0Ryx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BRUUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWU7VUFDYixRQUFRLE9BQU87VUFDZixnQkFBZ0IsSUFBSTtVQUNwQixnQkFBZ0IsSUFBSTtTQUN0QjtTQUNBLFdBQVcsc0RBQ1QsU0FBUyxVQUNMLGdFQUNBO21CQUVQO1FBRU87Ozs7O1FBQ1Isd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQTZDO1FBQU87Ozs7O1FBQ3BFLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsZUFBZTtVQUNiLFFBQVEsVUFBVTtVQUNsQixnQkFBZ0IsSUFBSTtVQUNwQixnQkFBZ0IsSUFBSTtTQUN0QjtTQUNBLFdBQVcsc0RBQ1QsU0FBUyxhQUNMLGdFQUNBO21CQUVQO1FBRU87Ozs7O09BQ0w7Ozs7OztNQUVMLHdCQUFDLGFBQUQ7T0FBYSxXQUFVO2lCQUNwQixTQUFTLFVBQVUsb0JBQW9CO01BQzdCOzs7OztNQUViLHdCQUFDLG1CQUFEO09BQW1CLFdBQVU7aUJBQzFCLFNBQVMsVUFDTixvRUFDQTtNQUNhOzs7OztLQUNoQjs7Ozs7O0lBR0wsd0JBQUMsUUFBRDtLQUFNLFVBQVU7S0FBYyxXQUFVO2VBQXhDO01BQ0csZ0JBQ0Msd0JBQUMsT0FBRDtPQUFLLElBQUc7T0FBYSxNQUFLO09BQVEsV0FBVTtpQkFBNUMsQ0FDRSx3QkFBQyxhQUFELEVBQWEsV0FBVSwwQkFBMkI7Ozs7aUJBQ2xELHdCQUFDLFFBQUQsWUFBTyxhQUFtQjs7OztlQUN2Qjs7Ozs7O01BR04sZ0JBQ0Msd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxNQUFELEVBQU0sV0FBVSwwQkFBMkI7Ozs7aUJBQzNDLHdCQUFDLFFBQUQsWUFBTyxhQUFtQjs7OztlQUN2Qjs7Ozs7O01BR04sU0FBUyxjQUNSLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFPLFNBQVE7a0JBQVk7T0FBb0I7Ozs7aUJBQy9DLHdCQUFDLE9BQUQ7UUFDRSxJQUFHO1FBQVksb0JBQWtCLGVBQWUsZUFBZTtRQUMvRCxNQUFLO1FBQ0w7UUFDQSxhQUFZO1FBQ1osT0FBTztRQUNQLFdBQVcsTUFBTSxRQUFRLEVBQUUsT0FBTyxLQUFLO1FBQ3ZDLFVBQVU7UUFDVixXQUFVO09BQ1g7Ozs7ZUFDRTs7Ozs7O01BR1Asd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQU8sU0FBUTtrQkFBYTtPQUFhOzs7O2lCQUN6Qyx3QkFBQyxPQUFEO1FBQ0Usb0JBQWtCLGVBQWUsZUFBZTtRQUFXLElBQUc7UUFDOUQsTUFBSztRQUNMO1FBQ0EsYUFBYSxTQUFTLFVBQVUsc0JBQXNCO1FBQ3RELE9BQU87UUFDUCxXQUFXLE1BQU0sU0FBUyxFQUFFLE9BQU8sS0FBSztRQUN4QyxVQUFVO1FBQ1YsV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFPLFNBQVE7a0JBQWdCO09BQVk7Ozs7aUJBQzNDLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUNFLG9CQUFrQixlQUFlLGVBQWU7U0FBVyxXQUFXLFNBQVMsYUFBYSxJQUFJO1NBQVcsY0FBYyxTQUFTLGFBQWEsaUJBQWlCO1NBQW9CLElBQUc7U0FDdkwsTUFBTSxlQUFlLFNBQVM7U0FDOUI7U0FDQSxhQUFhLFNBQVMsVUFBVSxnQkFBZ0I7U0FDaEQsT0FBTztTQUNQLFdBQVcsTUFBTSxZQUFZLEVBQUUsT0FBTyxLQUFLO1NBQzNDLFVBQVU7U0FDVixXQUFVO1FBQ1g7Ozs7a0JBQ0Qsd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlLGdCQUFnQixDQUFDLFlBQVk7U0FDNUMsV0FBVTttQkFIWixDQU1HLGVBQWUsd0JBQUMsUUFBRCxFQUFRLFdBQVUsVUFBVzs7OztvQkFBSSx3QkFBQyxLQUFELEVBQUssV0FBVSxVQUFXOzs7O21CQUMzRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBVTtTQUFvQzs7OztpQkFDeEQ7Ozs7O2dCQUNMOzs7OztlQUNGOzs7Ozs7TUFFSixTQUFTLGNBQWMsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFBMEIsd0JBQUMsT0FBRDtTQUFPLFdBQVU7U0FBVSxTQUFRO21CQUFlO1FBQXNCOzs7OztRQUFDLHdCQUFDLE9BQUQ7U0FBTyxJQUFHO1NBQWUsb0JBQWtCLGVBQWUsZUFBZTtTQUFXLE1BQU0sZUFBZSxTQUFTO1NBQVk7U0FBUyxhQUFZO1NBQWtCLE9BQU87U0FBYyxXQUFVLE1BQUssZ0JBQWdCLEVBQUUsT0FBTyxLQUFLO1FBQUk7Ozs7O1FBQUMsd0JBQUMsVUFBRDtTQUFRLE1BQUs7U0FBUyxXQUFVO1NBQW1CLGNBQVc7U0FBK0IsZUFBZSxnQkFBZ0IsQ0FBQyxZQUFZO21CQUFHLHdCQUFDLFFBQUQsRUFBUSxNQUFNLEdBQUs7Ozs7O1FBQVM7Ozs7O09BQU07Ozs7OztNQUNwaEIsU0FBUyxXQUNSLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLFVBQUQ7UUFDRSxNQUFLO1FBQ0wsZUFBZSx3QkFBd0Isc0JBQXNCO1FBQzdELFdBQVU7a0JBQ1g7T0FFTzs7Ozs7TUFDTDs7Ozs7TUFHUCx3QkFBQyxRQUFEO09BQ0UsTUFBSztPQUNMLFVBQVU7T0FDVixXQUFVO2lCQUVULGVBQ0Msd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsbUZBQW9GOzs7O2tCQUFDLGdCQUVqRzs7Ozs7a0JBQ0osU0FBUyxVQUNYLFdBRUEsZ0RBQUUsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQXNCO09BQWlCOzs7O2lCQUFDLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFxQjtPQUFrQjs7OztlQUFHOzs7OztNQUVoSDs7Ozs7TUFHUix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRCxFQUFLLFdBQVUsbUNBQW9DOzs7OztTQUNuRCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBMkY7U0FFckc7Ozs7O1NBQ04sd0JBQUMsT0FBRCxFQUFLLFdBQVUsbUNBQW9DOzs7OztRQUNoRDs7Ozs7aUJBRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWUsd0JBQXdCLGtCQUFrQjtTQUN6RCxXQUFVO21CQUhaLENBS0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7VUFBVSxTQUFRO29CQUFqQztXQUNFLHdCQUFDLFFBQUQ7WUFDRSxNQUFLO1lBQ0wsR0FBRTtXQUNIOzs7OztXQUNELHdCQUFDLFFBQUQ7WUFDRSxNQUFLO1lBQ0wsR0FBRTtXQUNIOzs7OztXQUNELHdCQUFDLFFBQUQ7WUFDRSxNQUFLO1lBQ0wsR0FBRTtXQUNIOzs7OztXQUNELHdCQUFDLFFBQUQ7WUFDRSxNQUFLO1lBQ0wsR0FBRTtXQUNIOzs7OztVQUNFOzs7OzttQkFBQyxzQkFFQTs7Ozs7a0JBRVIsd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlLHdCQUF3QixvQkFBb0I7U0FDM0QsV0FBVTttQkFIWixDQUtFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO1VBQXlCLFNBQVE7b0JBQzlDLHdCQUFDLFFBQUQsRUFBTSxHQUFFLGlTQUFrUzs7Ozs7U0FDdlM7Ozs7bUJBQUMsd0JBRUE7Ozs7O2dCQUNMOzs7OztlQUNGOzs7Ozs7TUFFTCx3QkFBQyxVQUFEO09BQVEsTUFBSztPQUFTLFdBQVU7T0FBcUIsZUFBZTtRQUFFLFFBQVEsU0FBUyxVQUFVLGFBQWEsT0FBTztRQUFHLGdCQUFnQixJQUFJO09BQUU7aUJBQUksU0FBUyxVQUFVLGtDQUFrQztNQUFrQzs7Ozs7S0FDck87Ozs7OztJQUdOLHdCQUFDLE9BQUQsRUFBSyxXQUFVLCtCQUFnQzs7Ozs7R0FDbEM7Ozs7OztDQUNUOzs7OztBQUVaIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkF1dGhNb2RhbC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IEV5ZSwgRXllT2ZmLCBBbGVydENpcmNsZSwgSW5mbyB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcclxuaW1wb3J0IHsgaXNBeGlvc0Vycm9yIH0gZnJvbSAnYXhpb3MnXHJcbmltcG9ydCB7IGFwaUVycm9yTWVzc2FnZSB9IGZyb20gJ0AvbGliL2FwaS1lcnJvcidcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJ0AvbGliL2F1dGgnXHJcbmltcG9ydCB7IERpYWxvZywgRGlhbG9nQ29udGVudCwgRGlhbG9nVGl0bGUsIERpYWxvZ0Rlc2NyaXB0aW9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2RpYWxvZydcclxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbidcclxuaW1wb3J0IHsgSW5wdXQgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvaW5wdXQnXHJcbmltcG9ydCB7IExhYmVsIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2xhYmVsJ1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIEF1dGhNb2RhbCgpIHtcclxuICBjb25zdCB7IGlzQXV0aE1vZGFsT3BlbiwgYXV0aE1vZGFsTW9kZSB9ID0gdXNlQXV0aCgpXHJcbiAgcmV0dXJuIGlzQXV0aE1vZGFsT3BlbiA/IDxBdXRoTW9kYWxGb3JtIGtleT17YXV0aE1vZGFsTW9kZX0gLz4gOiBudWxsXHJcbn1cclxuZnVuY3Rpb24gQXV0aE1vZGFsRm9ybSgpIHtcclxuICBjb25zdCB7IGlzQXV0aE1vZGFsT3BlbiwgY2xvc2VBdXRoTW9kYWwsIGF1dGhNb2RhbE1vZGUsIGxvZ2luLCByZWdpc3RlciwgcmVzdG9yZUF1dGhGb2N1cyB9ID0gdXNlQXV0aCgpXHJcblxyXG5cclxuICBjb25zdCBbbW9kZSwgc2V0TW9kZV0gPSB1c2VTdGF0ZTwnbG9naW4nIHwgJ3JlZ2lzdGVyJz4oYXV0aE1vZGFsTW9kZSlcclxuICBjb25zdCBbbmFtZSwgc2V0TmFtZV0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbZW1haWwsIHNldEVtYWlsXSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW2NvbmZpcm1hdGlvbiwgc2V0Q29uZmlybWF0aW9uXSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFtzaG93UGFzc3dvcmQsIHNldFNob3dQYXNzd29yZF0gPSB1c2VTdGF0ZShmYWxzZSlcclxuICBjb25zdCBbaXNTdWJtaXR0aW5nLCBzZXRJc1N1Ym1pdHRpbmddID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgY29uc3QgW2Vycm9yTWVzc2FnZSwgc2V0RXJyb3JNZXNzYWdlXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpXHJcbiAgY29uc3QgW3NvY2lhbE5vdGljZSwgc2V0U29jaWFsTm90aWNlXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpXHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKVxyXG4gICAgc2V0RXJyb3JNZXNzYWdlKG51bGwpXHJcbiAgICBzZXRTb2NpYWxOb3RpY2UobnVsbClcclxuICAgIHNldElzU3VibWl0dGluZyh0cnVlKVxyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGlmIChtb2RlID09PSAnbG9naW4nKSB7XHJcbiAgICAgICAgYXdhaXQgbG9naW4oeyBlbWFpbCwgcGFzc3dvcmQgfSlcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBpZiAoIW5hbWUudHJpbSgpKSB7XHJcbiAgICAgICAgICBzZXRFcnJvck1lc3NhZ2UoJ1BvciBmYXZvciwgaW5mb3JtZSBzZXUgbm9tZSBjb21wbGV0by4nKVxyXG4gICAgICAgICAgc2V0SXNTdWJtaXR0aW5nKGZhbHNlKVxyXG4gICAgICAgICAgcmV0dXJuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChwYXNzd29yZCAhPT0gY29uZmlybWF0aW9uKSB7IHNldEVycm9yTWVzc2FnZSgnQSBjb25maXJtYcOnw6NvIGRlIHNlbmhhIG7Do28gY29uZmVyZS4nKTsgcmV0dXJuIH1cclxuICAgICAgICBhd2FpdCByZWdpc3Rlcih7IG5hbWUsIGVtYWlsLCBwYXNzd29yZCB9KVxyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnI6IHVua25vd24pIHtcclxuICAgICAgY29uc3Qgc3RhdHVzID0gaXNBeGlvc0Vycm9yKGVycikgPyBlcnIucmVzcG9uc2U/LnN0YXR1cyA6IHVuZGVmaW5lZFxyXG4gICAgICBpZiAoc3RhdHVzID09PSA0MDEpIHtcclxuICAgICAgICBzZXRFcnJvck1lc3NhZ2UoJ0NyZWRlbmNpYWlzIGludsOhbGlkYXMuIFZlcmlmaXF1ZSBzZXUgZS1tYWlsIGUgc2VuaGEuJylcclxuICAgICAgfSBlbHNlIGlmIChzdGF0dXMgPT09IDQwOSkge1xyXG4gICAgICAgIHNldEVycm9yTWVzc2FnZSgnRXN0ZSBlLW1haWwgasOhIGVzdMOhIGNhZGFzdHJhZG8gbmEgcGxhdGFmb3JtYS4nKVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldEVycm9yTWVzc2FnZShhcGlFcnJvck1lc3NhZ2UoZXJyLCAnRXJybyBhbyBwcm9jZXNzYXIgYXV0ZW50aWNhw6fDo28uIFRlbnRlIG5vdmFtZW50ZS4nKSlcclxuICAgICAgfVxyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNTdWJtaXR0aW5nKGZhbHNlKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgY29uc3QgaGFuZGxlVW5hdmFpbGFibGVBY3Rpb24gPSAoYWN0aW9uTmFtZTogc3RyaW5nKSA9PiB7XHJcbiAgICBzZXRFcnJvck1lc3NhZ2UobnVsbClcclxuICAgIHNldFNvY2lhbE5vdGljZShgJHthY3Rpb25OYW1lfSBuw6NvIGRpc3BvbsOtdmVsIG5vIGFtYmllbnRlIGRlbW9uc3RyYXRpdm8uYClcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8RGlhbG9nIG9wZW49e2lzQXV0aE1vZGFsT3Blbn0gb25PcGVuQ2hhbmdlPXsob3BlbikgPT4gIW9wZW4gJiYgY2xvc2VBdXRoTW9kYWwoKX0+XHJcbiAgICAgIDxEaWFsb2dDb250ZW50IGRhdGEtbW9kZT17bW9kZX0gb25DbG9zZUF1dG9Gb2N1cz17ZXZlbnQgPT4geyBldmVudC5wcmV2ZW50RGVmYXVsdCgpOyByZXN0b3JlQXV0aEZvY3VzKCkgfX0gY2xhc3NOYW1lPVwiYXV0aC1kaWFsb2cgdy1mdWxsIG1heC13LVs1MDBweF0gcC0wIG92ZXJmbG93LWhpZGRlbiBiZy1bIzI0MTYxMl0gYm9yZGVyIGJvcmRlci1bIzNGMjMxOV0gc2hhZG93LTJ4bCByb3VuZGVkLXhsXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLW1vYmlsZS1icmFuZFwiPktVUklPPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLW1vYmlsZS10aXRsZVwiPnttb2RlID09PSAnbG9naW4nID8gJ0VudHJhcicgOiAnQ3JpYXIgcGVyZmlsIGRlIGNvbGVjaW9uYWRvcid9PC9kaXY+XHJcbiAgICAgICAgey8qIE1vZGFsIEhlYWRlciAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtaGVhZGluZyBwdC0xMCBwYi02IHB4LTEwIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICB7LyogVGFicyBTd2l0Y2hlcjogRW50cmFyIHwgQ3JpYXIgY29udGEgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRNb2RlKCdsb2dpbicpXHJcbiAgICAgICAgICAgICAgICBzZXRFcnJvck1lc3NhZ2UobnVsbClcclxuICAgICAgICAgICAgICAgIHNldFNvY2lhbE5vdGljZShudWxsKVxyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdGV4dC14bCBmb250LW1vbm8gdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgJHtcclxuICAgICAgICAgICAgICAgIG1vZGUgPT09ICdsb2dpbidcclxuICAgICAgICAgICAgICAgICAgPyAndGV4dC1bI0U4OUI1NV0gZm9udC1ib2xkIGJvcmRlci1iLTIgYm9yZGVyLVsjRDI4QTRDXSBwYi0wLjUnXHJcbiAgICAgICAgICAgICAgICAgIDogJ3RleHQtWyNGNUYxRUJdIGhvdmVyOnRleHQtWyNDRkIyOENdJ1xyXG4gICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgRW50cmFyXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsjRjA4MDVGXSBmb250LW1vbm8gdGV4dC1sZyBmb250LWJvbGRcIj58PC9zcGFuPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgc2V0TW9kZSgncmVnaXN0ZXInKVxyXG4gICAgICAgICAgICAgICAgc2V0RXJyb3JNZXNzYWdlKG51bGwpXHJcbiAgICAgICAgICAgICAgICBzZXRTb2NpYWxOb3RpY2UobnVsbClcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRleHQteGwgZm9udC1tb25vIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyICR7XHJcbiAgICAgICAgICAgICAgICBtb2RlID09PSAncmVnaXN0ZXInXHJcbiAgICAgICAgICAgICAgICAgID8gJ3RleHQtWyNFODlCNTVdIGZvbnQtYm9sZCBib3JkZXItYi0yIGJvcmRlci1bI0QyOEE0Q10gcGItMC41J1xyXG4gICAgICAgICAgICAgICAgICA6ICd0ZXh0LVsjRjVGMUVCXSBob3Zlcjp0ZXh0LVsjQ0ZCMjhDXSdcclxuICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIENyaWFyIGNvbnRhXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPERpYWxvZ1RpdGxlIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5cclxuICAgICAgICAgICAge21vZGUgPT09ICdsb2dpbicgPyAnRW50cmFyIG5vIEt1cmlvJyA6ICdDcmlhciBjb250YSBubyBLdXJpbyd9XHJcbiAgICAgICAgICA8L0RpYWxvZ1RpdGxlPlxyXG5cclxuICAgICAgICAgIDxEaWFsb2dEZXNjcmlwdGlvbiBjbGFzc05hbWU9XCJtdC0zIHRleHQteHMgZm9udC1tb25vIHRleHQtWyNDRkIyOENdIGxlYWRpbmctcmVsYXhlZCBtYXgtdy1zbSBteC1hdXRvXCI+XHJcbiAgICAgICAgICAgIHttb2RlID09PSAnbG9naW4nXHJcbiAgICAgICAgICAgICAgPyAnRW50cmUgcGFyYSBnZXJlbmNpYXIgc3VhIGNhcnRlaXJhLCBjb2xlw6fDo28gZSBwZXJmaWwgZGUgY3JpYWRvci4nXHJcbiAgICAgICAgICAgICAgOiAnQ3JpZSBzdWEgY29udGEgcGFyYSBjb2xlY2lvbmFyIGUgZ2VyZW5jaWFyIGFydGUgZGlnaXRhbCB2ZXJpZmljYWRhLid9XHJcbiAgICAgICAgICA8L0RpYWxvZ0Rlc2NyaXB0aW9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogRm9ybSBCb2R5ICovfVxyXG4gICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cImF1dGgtZm9ybSBweC0xMCBwYi02IHNwYWNlLXktNFwiPlxyXG4gICAgICAgICAge2Vycm9yTWVzc2FnZSAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgaWQ9XCJhdXRoLWVycm9yXCIgcm9sZT1cImFsZXJ0XCIgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMiBwLTMgcm91bmRlZC1tZCBiZy1bI0YwODA1Rl0vMTUgYm9yZGVyIGJvcmRlci1bI0YwODA1Rl0vNDAgdGV4dC1bI0YwODA1Rl0gdGV4dC14cyBmb250LW1vbm9cIj5cclxuICAgICAgICAgICAgICA8QWxlcnRDaXJjbGUgY2xhc3NOYW1lPVwidy00IGgtNCBzaHJpbmstMCBtdC0wLjVcIiAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuPntlcnJvck1lc3NhZ2V9PC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAge3NvY2lhbE5vdGljZSAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMiBwLTMgcm91bmRlZC1tZCBiZy1bI0QyOEE0Q10vMTUgYm9yZGVyIGJvcmRlci1bI0QyOEE0Q10vNDAgdGV4dC1bI0U4OUI1NV0gdGV4dC14cyBmb250LW1vbm9cIj5cclxuICAgICAgICAgICAgICA8SW5mbyBjbGFzc05hbWU9XCJ3LTQgaC00IHNocmluay0wIG10LTAuNVwiIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4+e3NvY2lhbE5vdGljZX08L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7bW9kZSA9PT0gJ3JlZ2lzdGVyJyAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cclxuICAgICAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cImF1dGgtbmFtZVwiPk5vbWUgY29tcGxldG88L0xhYmVsPlxyXG4gICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgaWQ9XCJhdXRoLW5hbWVcIiBhcmlhLWRlc2NyaWJlZGJ5PXtlcnJvck1lc3NhZ2UgPyAnYXV0aC1lcnJvcicgOiB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJOb21lIGRlIHVzdcOhcmlvXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtuYW1lfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROYW1lKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmd9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTExXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxyXG4gICAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cImF1dGgtZW1haWxcIj5FLW1haWw8L0xhYmVsPlxyXG4gICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICBhcmlhLWRlc2NyaWJlZGJ5PXtlcnJvck1lc3NhZ2UgPyAnYXV0aC1lcnJvcicgOiB1bmRlZmluZWR9IGlkPVwiYXV0aC1lbWFpbFwiXHJcbiAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXttb2RlID09PSAnbG9naW4nID8gJ2NvbnRhdG9AZW1haWwuY29tJyA6ICdEaWdpdGUgc2V1IGUtbWFpbCd9XHJcbiAgICAgICAgICAgICAgdmFsdWU9e2VtYWlsfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RW1haWwoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmd9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC0xMVwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XHJcbiAgICAgICAgICAgIDxMYWJlbCBodG1sRm9yPVwiYXV0aC1wYXNzd29yZFwiPlNlbmhhPC9MYWJlbD5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgYXJpYS1kZXNjcmliZWRieT17ZXJyb3JNZXNzYWdlID8gJ2F1dGgtZXJyb3InIDogdW5kZWZpbmVkfSBtaW5MZW5ndGg9e21vZGUgPT09ICdyZWdpc3RlcicgPyA2IDogdW5kZWZpbmVkfSBhdXRvQ29tcGxldGU9e21vZGUgPT09ICdyZWdpc3RlcicgPyAnbmV3LXBhc3N3b3JkJyA6ICdjdXJyZW50LXBhc3N3b3JkJ30gaWQ9XCJhdXRoLXBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgIHR5cGU9e3Nob3dQYXNzd29yZCA/ICd0ZXh0JyA6ICdwYXNzd29yZCd9XHJcbiAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e21vZGUgPT09ICdsb2dpbicgPyAnKioqKioqKioqKionIDogJ1NlbmhhJ31cclxuICAgICAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGFzc3dvcmQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU3VibWl0dGluZ31cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTEgcHItMTBcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93UGFzc3dvcmQoIXNob3dQYXNzd29yZCl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0zIHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB0ZXh0LVsjQ0ZCMjhDXSBob3Zlcjp0ZXh0LVsjRDI4QTRDXSBwLTFcIlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge3Nob3dQYXNzd29yZCA/IDxFeWVPZmYgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+IDogPEV5ZSBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz59XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCI+QWx0ZXJuYXIgdmlzdWFsaXphw6fDo28gZGUgc2VuaGE8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAge21vZGUgPT09ICdyZWdpc3RlcicgJiYgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPjxMYWJlbCBjbGFzc05hbWU9XCJzci1vbmx5XCIgaHRtbEZvcj1cImF1dGgtY29uZmlybVwiPkNvbmZpcm1hciBzZW5oYTwvTGFiZWw+PElucHV0IGlkPVwiYXV0aC1jb25maXJtXCIgYXJpYS1kZXNjcmliZWRieT17ZXJyb3JNZXNzYWdlID8gJ2F1dGgtZXJyb3InIDogdW5kZWZpbmVkfSB0eXBlPXtzaG93UGFzc3dvcmQgPyAndGV4dCcgOiAncGFzc3dvcmQnfSByZXF1aXJlZCBwbGFjZWhvbGRlcj1cIkNvbmZpcm1hciBzZW5oYVwiIHZhbHVlPXtjb25maXJtYXRpb259IG9uQ2hhbmdlPXtlID0+IHNldENvbmZpcm1hdGlvbihlLnRhcmdldC52YWx1ZSl9IC8+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiYXV0aC1jb25maXJtLWV5ZVwiIGFyaWEtbGFiZWw9XCJNb3N0cmFyIGNvbmZpcm1hw6fDo28gZGUgc2VuaGFcIiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93UGFzc3dvcmQoIXNob3dQYXNzd29yZCl9PjxFeWVPZmYgc2l6ZT17MTZ9IC8+PC9idXR0b24+PC9kaXY+fVxyXG4gICAgICAgICAge21vZGUgPT09ICdsb2dpbicgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgcHQtMC41XCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVVbmF2YWlsYWJsZUFjdGlvbignUmVjdXBlcmHDp8OjbyBkZSBzZW5oYScpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1vbm8gdGV4dC1bI0U4OUI1NV0gaG92ZXI6dW5kZXJsaW5lXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBFc3F1ZWNldSBhIHNlbmhhP1xyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU3VibWl0dGluZ31cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTEgYmctWyNEMjhBNENdIGhvdmVyOmJnLVsjRTg5QjU1XSB0ZXh0LVsjMTQwRDBBXSBmb250LWJvbGQgdGV4dC1zbSB0cmFja2luZy13aWRlciB1cHBlcmNhc2UgbXQtMlwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHtpc1N1Ym1pdHRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctNCBoLTQgYm9yZGVyLTIgYm9yZGVyLVsjMTQwRDBBXSBib3JkZXItdC10cmFuc3BhcmVudCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1zcGluXCIgLz5cclxuICAgICAgICAgICAgICAgIFByb2Nlc3NhbmRvLi4uXHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICApIDogbW9kZSA9PT0gJ2xvZ2luJyA/IChcclxuICAgICAgICAgICAgICAnRW50cmFyJ1xyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIDw+PHNwYW4gY2xhc3NOYW1lPVwiYXV0aC1kZXNrdG9wLXN1Ym1pdFwiPkNyaWFyIGNvbnRhPC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cImF1dGgtbW9iaWxlLXN1Ym1pdFwiPkNyaWFyIHBlcmZpbDwvc3Bhbj48Lz5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG5cclxuICAgICAgICAgIHsvKiBTb2NpYWwgU2lnbiBJbiBEaXZpZGVyICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci10IGJvcmRlci1bIzNGMjMxOV0gdy1mdWxsXCIgLz5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1bIzI0MTYxMl0gcHgtMyB0ZXh0LVsxMXB4XSBmb250LW1vbm8gdGV4dC1bI0NGQjI4Q10gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgICBPdSBjb250aW51ZSBjb21cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItdCBib3JkZXItWyMzRjIzMTldIHctZnVsbFwiIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIHNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVW5hdmFpbGFibGVBY3Rpb24oJ0xvZ2luIGNvbSBHb29nbGUnKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0zIHJvdW5kZWQtWzVweF0gYm9yZGVyIGJvcmRlci1bIzNGMjMxOV0gYmctWyMxNDBEMEFdLzUwIGhvdmVyOmJnLVsjMkYxRDE1XSB0ZXh0LVsjQ0ZCMjhDXSBob3Zlcjp0ZXh0LVsjRjVGMUVCXSBmb250LW1vbm8gdGV4dC14cyB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGw9XCIjRUE0MzM1XCJcclxuICAgICAgICAgICAgICAgICAgICBkPVwiTTEyIDVjMS42IDAgMyAuNiA0LjEgMS42bDMuMS0zLjFDMTcuMyAxLjcgMTQuOCAxIDEyIDEgNy41IDEgMy43IDMuNiAxLjkgNy40bDMuNyAyLjlDNi41IDcuNCA4LjkgNSAxMiA1elwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsbD1cIiM0Mjg1RjRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGQ9XCJNMjMuNSAxMi4zYzAtLjgtLjEtMS42LS4yLTIuM0gxMnY0LjVoNi41Yy0uMyAxLjUtMS4xIDIuOC0yLjQgMy43bDMuNyAyLjljMi4yLTIgMy43LTUgMy43LTguOHpcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGw9XCIjRkJCQzA1XCJcclxuICAgICAgICAgICAgICAgICAgICBkPVwiTTUuNiAxNC43Yy0uMi0uNy0uNC0xLjUtLjQtMi43cy4yLTIgLjQtMi43TDEuOSA2LjRDLjcgOC44IDAgMTAuMyAwIDEycy43IDMuMiAxLjkgNS42bDMuNy0yLjl6XCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgICBmaWxsPVwiIzM0QTg1M1wiXHJcbiAgICAgICAgICAgICAgICAgICAgZD1cIk0xMiAyM2MzLjIgMCA2LTEuMSA4LTNsLTMuNy0yLjljLTEuMS43LTIuNSAxLjItNC4zIDEuMi0zLjEgMC01LjUtMi40LTYuNC01LjNMMS45IDE2QzMuNyAxOS44IDcuNSAyMyAxMiAyM3pcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICBDb250aW51YXIgY29tIEdvb2dsZVxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVVuYXZhaWxhYmxlQWN0aW9uKCdMb2dpbiBjb20gRmFjZWJvb2snKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0zIHJvdW5kZWQtWzVweF0gYm9yZGVyIGJvcmRlci1bIzNGMjMxOV0gYmctWyMxNDBEMEFdLzUwIGhvdmVyOmJnLVsjMkYxRDE1XSB0ZXh0LVsjQ0ZCMjhDXSBob3Zlcjp0ZXh0LVsjRjVGMUVCXSBmb250LW1vbm8gdGV4dC14cyB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTQgaC00IGZpbGwtWyMxODc3RjJdXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8cGF0aCBkPVwiTTI0IDEyLjA3M2MwLTYuNjI3LTUuMzczLTEyLTEyLTEycy0xMiA1LjM3My0xMiAxMmMwIDUuOTkgNC4zODggMTAuOTU0IDEwLjEyNSAxMS44NTR2LTguMzg1SDcuMDc4di0zLjQ3aDMuMDQ3VjkuNDNjMC0zLjAwNyAxLjc5Mi00LjY2OSA0LjUzMy00LjY2OSAxLjMxMiAwIDIuNjg2LjIzNSAyLjY4Ni4yMzV2Mi45NTNIMTUuODNjLTEuNDkxIDAtMS45NTYuOTI1LTEuOTU2IDEuODc0djIuMjVoMy4zMjhsLS41MzIgMy40N2gtMi43OTZ2OC4zODVDMTkuNjEyIDIzLjAyNyAyNCAxOC4wNjIgMjQgMTIuMDczelwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgIENvbnRpbnVhciBjb20gRmFjZWJvb2tcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJhdXRoLXN3aXRjaC1tb2JpbGVcIiBvbkNsaWNrPXsoKSA9PiB7IHNldE1vZGUobW9kZSA9PT0gJ2xvZ2luJyA/ICdyZWdpc3RlcicgOiAnbG9naW4nKTsgc2V0RXJyb3JNZXNzYWdlKG51bGwpIH19Pnttb2RlID09PSAnbG9naW4nID8gJ05vdm8gbmEgS3VyaW8/IENyaWUgdW1hIGNvbnRhJyA6ICdKw6EgdGVtIHVtYSBjb250YT8gRW50cmUnfTwvYnV0dG9uPlxyXG4gICAgICAgIDwvZm9ybT5cclxuXHJcbiAgICAgICAgey8qIEJvdHRvbSAxMHB4IGFjY2VudCBiYXIgbWF0Y2hpbmcgRmlnbWEgOToxMjI4ICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC1bMTBweF0gdy1mdWxsIGJnLVsjRDI4QTRDXVwiIC8+XHJcbiAgICAgIDwvRGlhbG9nQ29udGVudD5cclxuICAgIDwvRGlhbG9nPlxyXG4gIClcclxufVxyXG4iXX0=
import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/NFTSkeleton.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=7abeec5e";
var _jsxFileName = "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/NFTSkeleton.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7abeec5e";
export const NFTSkeleton = () => {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "nft-skeleton flex w-full flex-col",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "nft-art relative w-full",
			children: /* @__PURE__ */ _jsxDEV("div", { className: "nft-skeleton-art skeleton-shimmer" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 6,
				columnNumber: 48
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 6,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "nft-caption",
			children: [/* @__PURE__ */ _jsxDEV("div", { className: "nft-skeleton-name skeleton-shimmer" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 8,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", { className: "nft-skeleton-price skeleton-shimmer" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 9,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 7,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 5,
		columnNumber: 5
	}, this);
};
_c = NFTSkeleton;
var _c;
$RefreshReg$(_c, "NFTSkeleton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/NFTSkeleton.tsx?t=1792165205066";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/NFTSkeleton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/NFTSkeleton.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/felii/OneDrive/Área de Trabalho/Jungle-Gaming-Challenge/src/components/NFTSkeleton.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXOzs7QUFFbEIsT0FBTyxNQUFNLG9CQUE4QjtDQUN6QyxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO0VBQW9DLGVBQVk7WUFBL0QsQ0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUEwQix3QkFBQyxPQUFELEVBQUssV0FBVSxvQ0FBcUM7Ozs7O0VBQU07Ozs7WUFDbkcsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLE9BQUQsRUFBSyxXQUFVLHFDQUFzQzs7OzthQUNyRCx3QkFBQyxPQUFELEVBQUssV0FBVSxzQ0FBdUM7Ozs7V0FDbkQ7Ozs7O1VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk5GVFNrZWxldG9uLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXHJcblxyXG5leHBvcnQgY29uc3QgTkZUU2tlbGV0b246IFJlYWN0LkZDID0gKCkgPT4ge1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm5mdC1za2VsZXRvbiBmbGV4IHctZnVsbCBmbGV4LWNvbFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5mdC1hcnQgcmVsYXRpdmUgdy1mdWxsXCI+PGRpdiBjbGFzc05hbWU9XCJuZnQtc2tlbGV0b24tYXJ0IHNrZWxldG9uLXNoaW1tZXJcIiAvPjwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5mdC1jYXB0aW9uXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJuZnQtc2tlbGV0b24tbmFtZSBza2VsZXRvbi1zaGltbWVyXCIgLz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5mdC1za2VsZXRvbi1wcmljZSBza2VsZXRvbi1zaGltbWVyXCIgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuIl19